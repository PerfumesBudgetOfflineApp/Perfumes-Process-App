# شاشة البدء — لوقو شفّاف وسط خلفية بيضاء

الهدف: شعار شفّاف في وسط خلفية بيضاء `#FFFFFF` — لا صورة مقصوصة تملأ الشاشة.

## آلية الخلفية
الخلفية تأتي من اللون لا من الصورة: `assets/splash.png` شعار شفّاف، والخلفية تُضبط أبيض عبر:
- أمر التوليد: `npx capacitor-assets generate --android --splashBackgroundColor "#FFFFFF"`
- أو يدويا: السطر في `colors-snippet.xml` داخل `res/values/colors.xml`:
  `<color name="splash_bg">#FFFFFF</color>`
- و`capacitor.config.ts` → `androidScaleType: 'FIT_CENTER'` كي يظهر الشعار وسط الأبيض بلا قصّ.

## خطأ Duplicate resources (إن ظهر)
سببه وجود `splash.png` و`splash.xml` معا باسم `splash` في `drawable/`. الحلّ: أبقِ ملفّا واحدا — إمّا الصورة الشفّافة وحدها، أو ملفّ `splash.xml` (مع `splash_logo.png` + سطر اللون في `colors.xml`) واحذف أيّ `splash.png` في مجلّدات `drawable-*`.

## بعدها
```
npx cap sync android
```
ثمّ Build › Clean Project › Rebuild. يختفي خطأ التكرار ويظهر الشعار وسط الأبيض.

> هذه الملفّات مرجعيّة لمشروع أندرويد المولّد محلّيا (مجلّد android/ ليس ضمن مصدر الويب).
