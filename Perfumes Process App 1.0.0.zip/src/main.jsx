import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'
// خطوط جوجل مُضمّنة محلياً (تعمل أوفلاين على كل الأجهزة) — للواجهة وللتصدير.
import '@fontsource/amiri/400.css'
import '@fontsource/amiri/700.css'
import '@fontsource/cairo/400.css'
import '@fontsource/cairo/700.css'
import '@fontsource/tajawal/400.css'
import '@fontsource/tajawal/700.css'
import '@fontsource/cinzel/400.css'
import '@fontsource/cinzel/700.css'
import { initThemeWatcher } from '@/lib/theme'
import { initThemeColorWatcher } from '@/lib/themeColor'
import { initFramesWatcher } from '@/lib/useFrames'

// Offline image guard — if any <img> fails to load (e.g. a local catalogue
// image that hasn't been downloaded yet), swap it once to the bundled default
// placeholder instead of showing a broken-image icon. All catalogue image
// fields point to local paths, so nothing is ever fetched from the internet.
if (typeof window !== 'undefined') {
  window.addEventListener('error', (e) => {
    const el = e.target;
    if (el && el.tagName === 'IMG' && el.dataset.imgFallback !== '1') {
      el.dataset.imgFallback = '1';
      el.src = '/img-fallback.svg';
    }
  }, true); // capture phase: image error events don't bubble
}

// Apply the saved theme (or default light) before render, and keep it in sync
// with the device when the user picks "System".
initThemeWatcher();
// Apply the saved brand color (white-gilded by default).
initThemeColorWatcher();
// Apply saved frame options (table/image frames on perfume & brand pages).
initFramesWatcher();

const isNative = () => typeof window !== 'undefined' && window.Capacitor?.isNativePlatform?.();

// Status bar that follows the app theme
//
// Capacitor 6 StatusBar.Style:
//   Style.Dark   = DARK content/icons (use on LIGHT backgrounds)
//   Style.Light  = LIGHT content/icons (use on DARK backgrounds)
async function syncStatusBarWithTheme() {
  if (!isNative()) return;

  try {
    const { StatusBar, Style } = await import('@capacitor/status-bar');
    const isDark = document.documentElement.classList.contains('dark');

    if (isDark) {
      // Dark theme: black-ish bar, white text/icons
      await StatusBar.setBackgroundColor({ color: '#0a0a0a' });
      await StatusBar.setStyle({ style: Style.Light });
    } else {
      // Light theme: white bar, dark text/icons
      await StatusBar.setBackgroundColor({ color: '#ffffff' });
      await StatusBar.setStyle({ style: Style.Dark });
    }
    if (StatusBar.setOverlaysWebView) {
      await StatusBar.setOverlaysWebView({ overlay: false });
    }
  } catch (e) {
    console.warn('StatusBar plugin not available', e);
  }
}

async function setupNative() {
  if (!isNative()) return;

  await syncStatusBarWithTheme();

  // Watch <html class="dark"> for changes
  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.type === 'attributes' && m.attributeName === 'class') {
        syncStatusBarWithTheme();
        break;
      }
    }
  });
  observer.observe(document.documentElement, { attributes: true });

  // Android hardware back button
  try {
    const { App: CapApp } = await import('@capacitor/app');
    CapApp.addListener('backButton', ({ canGoBack }) => {
      if (canGoBack) window.history.back();
      else CapApp.exitApp();
    });
  } catch (e) {
    console.warn('App plugin not available', e);
  }
}

setupNative();

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)
