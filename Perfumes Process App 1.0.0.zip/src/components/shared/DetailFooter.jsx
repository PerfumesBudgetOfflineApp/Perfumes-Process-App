import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Copy, Check, ChevronLeft, ChevronRight } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import BookmarkButton from "@/components/shared/BookmarkButton";

/**
 * DetailFooter — a generic bottom-of-page footer for detail screens that are
 * NOT stories (notes, perfumers, blog posts). Mirrors StoryFooter but works for
 * items whose content isn't a single bilingual `meaning` field.
 *
 * Uses fixed neutral styling (not dynamic Tailwind classes, which get purged).
 *
 * Props:
 *   items         : full ordered list for prev/next (already sorted)
 *   currentId     : id of the item being viewed
 *   pathFor(item) : builds the route, e.g. (n) => `/note?id=${n.id}`
 *   labelFor(item): display label for prev/next buttons
 *   copyText      : full text to copy
 *   copyTextAr/En : optional language-specific copies (enable extra buttons)
 *   bookmark      : descriptor for the notebook button
 */
export default function DetailFooter({
  items = [],
  currentId,
  pathFor,
  labelFor,  
  copyText = "",
  copyTextAr = "",
  copyTextEn = "",
  bookmark,
  extraActions = null,
}) {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [copied, setCopied] = useState("");

  const copy = async (which, text) => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(which);
      setTimeout(() => setCopied(""), 1500);
    } catch { /* ignore */ }
  };

  const idx = items.findIndex((it) => String(it.id) === String(currentId));
  const prev = idx > 0 ? items[idx - 1] : null;
  const next = idx >= 0 && idx < items.length - 1 ? items[idx + 1] : null;

  const CopyBtn = ({ which, label, text }) => (
    <button
      type="button"
      onClick={() => copy(which, text)}
      className="flex items-center justify-center gap-1.5 rounded-none text-foreground/80 text-xs font-body transition-colors"
    >
      {copied === which ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
      {label}
    </button>
  );

  return (
    <div className="pt-6 mt-4 border-t border-border/60 space-y-5">
      {(copyText || bookmark || extraActions) && (
        <div className="flex flex-wrap items-center justify-center gap-2">
          {copyTextAr && <CopyBtn which="ar" label={isAr ? "عربي" : "AR"} text={copyTextAr} />}
          {copyTextEn && <CopyBtn which="en" label={isAr ? "إنجليزي" : "EN"} text={copyTextEn} />}
          {copyText && (copyTextAr && copyTextEn
            ? <CopyBtn which="both" label={isAr ? "الكل" : "Both"} text={copyText} />
            : <CopyBtn which="all" label={isAr ? "نسخ" : "Copy"} text={copyText} />)}
          {extraActions}
          {bookmark && <BookmarkButton size={34} descriptor={bookmark} />}
        </div>
      )}

      {(prev || next) && (
        <div className="flex items-stretch gap-2">
          <button
            type="button"
            disabled={!prev}
            onClick={() => prev && navigate(pathFor(prev))}
            className="flex-1 flex items-center gap-1.5 px-2 py-2 rounded-none bg-transparent disabled:opacity-30 disabled:cursor-not-allowed text-[#2E7D32] hover:text-[var(--brand)] transition-colors text-left"
          >
            {isAr ? <ChevronRight className="w-4 h-4 flex-shrink-0" /> : <ChevronLeft className="w-4 h-4 flex-shrink-0" />}
            <span className="text-xs font-body font-medium">{isAr ? "السابق" : "Previous"}</span>
          </button>
          <button
            type="button"
            disabled={!next}
            onClick={() => next && navigate(pathFor(next))}
            className="flex-1 flex items-center justify-end gap-1.5 px-2 py-2 rounded-none bg-transparent disabled:opacity-30 disabled:cursor-not-allowed text-[#2E7D32] hover:text-[var(--brand)] transition-colors text-right"
          >
            <span className="text-xs font-body font-medium">{isAr ? "التالي" : "Next"}</span>
            {isAr ? <ChevronLeft className="w-4 h-4 flex-shrink-0" /> : <ChevronRight className="w-4 h-4 flex-shrink-0" />}
          </button>
        </div>
      )}
    </div>
  );
}
