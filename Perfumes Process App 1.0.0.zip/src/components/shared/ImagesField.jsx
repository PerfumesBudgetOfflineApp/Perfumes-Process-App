import ImageUploadButton from "@/components/ui/ImageUploadButton";
import { X } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

// حقل صور مشترك: حتى خمس صور (data URLs)، معاينات مصغّرة مع زر إزالة لكلّ صورة.
export default function ImagesField({ value = [], onChange, max = 5 }) {
  const { isAr } = useLang();
  const images = Array.isArray(value) ? value.filter(Boolean) : [];
  const remove = (i) => onChange(images.filter((_, idx) => idx !== i));
  const add = (url) => { if (url && images.length < max) onChange([...images, url]); };
  return (
    <div className="space-y-2">
      <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
        {isAr ? `صور (حتى ${max})` : `Images (up to ${max})`}
      </label>
      {images.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {images.map((url, i) => (
            <div key={i} className="relative w-16 h-16 border border-border/60">
              <img src={url} alt="" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => remove(i)}
                aria-label="remove image"
                className="absolute -top-2 -start-2 bg-white border border-border rounded-none p-0.5 hover:bg-rose-50"
              >
                <X className="w-3 h-3 text-rose-600" />
              </button>
            </div>
          ))}
        </div>
      )}
      {images.length < max ? (
        <ImageUploadButton onUploaded={add} />
      ) : (
        <p className="text-[10px] text-muted-foreground font-body">{isAr ? "بلغت الحدّ الأقصى" : "Maximum reached"}</p>
      )}
    </div>
  );
}
