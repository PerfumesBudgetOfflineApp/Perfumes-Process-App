import { Pin } from "lucide-react";
import { toast } from "sonner";
import { useLang } from "@/lib/LanguageContext";
import { usePins, maxPinsFor } from "@/lib/usePins";

/**
 * PinButton — أيقونة تثبيت بلا إطار لرؤوس صفحات التفصيل (عطر / براند).
 * أبيض/شفّاف بلا خلفية، تماشياً مع BookmarkButton. عند بلوغ الحدّ (٦) يُظهر
 * تنبيهاً لطيفاً بدل التثبيت.
 *
 * kind: "perfume" | "brand"
 */
export default function PinButton({ kind, id, size = 32 }) {
  const { isAr } = useLang();
  const { isPinned, togglePin } = usePins(kind);
  if (!id) return null;
  const pinned = isPinned(id);

  const onClick = () => {
    const res = togglePin(id);
    if (res === "full") {
      toast.message(
        isAr
          ? `بلغتَ الحدّ الأقصى للتثبيت (${maxPinsFor(kind)}). أزِل واحداً أولاً.`
          : `Pin limit reached (${maxPinsFor(kind)}). Unpin one first.`
      );
      return;
    }
    if (pinned) toast.message(isAr ? "أُزيل التثبيت" : "Unpinned");
    else toast.message(isAr ? "ثُبِّت في الأعلى" : "Pinned to top");
  };

  return (
    <button
      type="button"
      onClick={onClick}
      title={pinned ? (isAr ? "مثبَّت" : "Pinned") : (isAr ? "تثبيت في الأعلى" : "Pin to top")}
      aria-label={pinned ? "Pinned" : "Pin to top"}
      className="flex items-center justify-center bg-transparent transition-opacity hover:opacity-70 flex-shrink-0"
      style={{ width: size, height: size }}
    >
      <Pin
        className="w-4 h-4"
        strokeWidth={1.25}
        style={{ color: pinned ? "#2E7D32" : "var(--brand)" }}
        fill={pinned ? "var(--brand)" : "none"}
      />
    </button>
  );
}
