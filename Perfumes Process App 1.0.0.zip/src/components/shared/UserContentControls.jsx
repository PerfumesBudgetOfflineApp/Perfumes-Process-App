import { useState } from "react";
import { X, Plus } from "lucide-react";
import EraserIcon from "@/components/icons/EraserIcon";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import ImageUploadButton from "@/components/ui/ImageUploadButton";
import { useLang } from "@/lib/LanguageContext";
import { useNavigate } from "react-router-dom";

/**
 * UserContentControls
 *
 * A small, self-contained row of Edit / Delete actions that sits BELOW the
 * like / thought buttons on glossary terms, stories, and quotes. It lets the
 * user modify or remove an entry, and (for glossary/story) attach an image.
 *
 * It is intentionally additive: it never touches the reaction/thought system.
 * Built-in entries can be edited & hidden; user-created entries are deleted
 * outright. Both paths go through the same onSave / onDelete callbacks the
 * parent supplies, so this component holds no persistence logic of its own —
 * keeping the app's data layer untouched and safe.
 *
 * Props:
 *   kind        : "glossary" | "quote"
 *   entry       : the current record (built-in or user) — may be null
 *   isUser      : true if this entry was created by the user (=> hard delete)
 *   onSave      : async (fields) => void   — persist edits
 *   onDelete    : async () => void         — remove / hide entry
 *   compact     : smaller buttons when true
 */
export default function UserContentControls({
  kind,
  entry,
  isUser = false,
  onSave,
  onDelete,
  compact = false,
}) {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [editOpen, setEditOpen] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({});

  const isQuote = kind === "quote";

  const openEditor = () => {
    // كلّ الأنواع: صفحة تعديل مستقلة بدل المنبثقة (تحرير الجوال أدقّ).
    if (entry?.id) {
      navigate(isQuote ? `/content-edit?type=quote&id=${entry.id}` : `/glossary-term-edit?id=${entry.id}`);
    }
  };


  const handleDelete = async () => {
    setSaving(true);
    try {
      await onDelete();
      setConfirmDel(false);
    } finally {
      setSaving(false);
    }
  };

  const btn = compact
    ? "flex items-center gap-1 px-2 py-1 text-[11px]"
    : "flex items-center gap-1.5 px-3 py-1.5 text-xs";

  return (
    <>
      {/* Action row — tweak (✏️) + cast-away (eraser), calm/borderless, same line */}
      <div className="flex items-center gap-1.5 pt-1">
        <button
          type="button"
          onClick={openEditor}
          title={isAr ? "تعديل" : "Edit"}
          aria-label={isAr ? "تعديل" : "Edit"}
          className="w-8 h-8 rounded-none flex items-center justify-center text-base hover:bg-secondary/40 transition-colors"
        >
          ✏️
        </button>
        <button
          type="button"
          onClick={() => setConfirmDel(true)}
          title={isAr ? (isUser ? "حذف" : "إهمال") : isUser ? "Delete" : "Cast Out"}
          aria-label={isAr ? (isUser ? "حذف" : "إهمال") : isUser ? "Delete" : "Cast Out"}
          className="w-8 h-8 rounded-none flex items-center justify-center text-muted-foreground hover:text-[var(--brand)] hover:bg-secondary/40 transition-colors"
        >
          <EraserIcon className="w-4 h-4" />
        </button>
      </div>

      {/* Edit dialog */}
      

      {/* Delete / hide confirmation */}
      <Dialog open={confirmDel} onOpenChange={setConfirmDel}>
        <DialogContent className="max-w-xs rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {isUser
                ? isAr ? "حذف المدخل؟" : "Delete entry?"
                : isAr ? "إهمال المدخل؟" : "Cast out entry?"}
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs font-body text-muted-foreground" dir="auto">
            {isUser
              ? isAr
                ? "سيُحذف هذا المدخل نهائياً"
                : "This entry will be permanently deleted."
              : isAr
                ? "سينتقل هذا المدخل إلى سلة المهمل و يمكنك استعادته منها متى شئت"
                : "This entry will move to Trash. You can restore it anytime."}
          </p>
          <div className="flex gap-2 pt-2">
            <Button
              variant="destructive"
              className="flex-1 h-10 rounded-none"
              onClick={handleDelete}
              disabled={saving}
            >
              {saving
                ? isAr ? "جارٍ.." : ".."
                : isUser
                  ? isAr ? "حذف" : "Delete"
                  : isAr ? "إهمال" : "Cast Out"}
            </Button>
            <Button
              variant="outline"
              className="h-10 rounded-none"
              onClick={() => setConfirmDel(false)}
            >
              {isAr ? "إلغاء" : "Cancel"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

/** "Add new" button + dialog, used on the Glossary and Quotes index pages. */
export function AddContentButton({ kind, onCreate, className = "" }) {
  const { isAr } = useLang();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const isQuote = kind === "quote";
  const blank = isQuote
    ? { text_en: "", text_ar: "", quoteauthor: "", category: "" }
    : { term_en: "", term_ar: "", meaning: "", meaning_ar: "", meaning_extraar: "", tags: "", image_url: "", entry_type: "term" };
  const [form, setForm] = useState(blank);

  const handleCreate = async () => {
    setSaving(true);
    try {
      await onCreate(form);
      setForm(blank);
      setOpen(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={() => { setForm(blank); setOpen(true); }}
        className={`flex items-center gap-1.5 rounded-none text-primary-foreground text-xs font-body font-medium hover:opacity-90 transition-opacity ${className}`}
      >
        <Plus className="w-4 h-4" />
        {isQuote
          ? isAr ? "أضف اقتباساً" : "Add quote"
          : isAr ? "أضف مدخلاً" : "Add entry"}
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-sm rounded-none max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {isQuote
                ? isAr ? "اقتباس جديد" : "New quote"
                : isAr ? "مدخل جديد" : "New entry"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {isQuote ? (
              <>
                <Field label={isAr ? "النص (إنجليزي)" : "Text (EN)"}>
                  <Textarea
                    value={form.text_en}
                    onChange={(e) => setForm((f) => ({ ...f, text_en: e.target.value }))}
                    className="rounded-none font-body text-xs min-h-[60px] resize-none"
                    dir="auto"
                  />
                </Field>
                <Field label={isAr ? "النص (عربي)" : "Text (AR)"}>
                  <Textarea
                    value={form.text_ar}
                    onChange={(e) => setForm((f) => ({ ...f, text_ar: e.target.value }))}
                    className="rounded-none font-body text-xs min-h-[60px] resize-none"
                    dir="auto"
                  />
                </Field>
                <Field label={isAr ? "القائل" : "Author"}>
                  <Input
                    value={form.quoteauthor}
                    onChange={(e) => setForm((f) => ({ ...f, quoteauthor: e.target.value }))}
                    className="rounded-none font-body text-xs"
                    dir="auto"
                  />
                </Field>
                <Field label={isAr ? "التصنيف" : "Category"}>
                  <Input
                    value={form.category}
                    onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
                    placeholder={isAr ? "مثال: إلهام Inspiration" : "e.g. Inspiration إلهام"}
                    className="rounded-none font-body text-xs"
                    dir="auto"
                  />
                </Field>
              </>
            ) : (
              <>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, entry_type: "term" }))}
                    className={`flex-1 py-1.5 rounded-none text-xs font-body border ${
                      form.entry_type === "term"
                        ? "bg-emerald-50 border-emerald-300 text-emerald-700 dark:bg-emerald-950/30"
                        : "border-border text-muted-foreground"
                    }`}
                  >
                    {isAr ? "مصطلح" : "Term"}
                  </button>
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, entry_type: "story" }))}
                    className={`flex-1 py-1.5 rounded-none text-xs font-body border ${
                      form.entry_type === "story"
                        ? "bg-amber-50 border-amber-300 text-amber-700 dark:bg-amber-950/30"
                        : "border-border text-muted-foreground"
                    }`}
                  >
                    {isAr ? "قصة" : "Story"}
                  </button>
                </div>
                <Field label={isAr ? "العنوان (إنجليزي)" : "Title (EN)"}>
                  <Input
                    value={form.term_en}
                    onChange={(e) => setForm((f) => ({ ...f, term_en: e.target.value }))}
                    className="rounded-none font-body text-xs"
                    dir="auto"
                  />
                </Field>
                <Field label={isAr ? "العنوان (عربي)" : "Title (AR)"}>
                  <Input
                    value={form.term_ar}
                    onChange={(e) => setForm((f) => ({ ...f, term_ar: e.target.value }))}
                    className="rounded-none font-body text-xs"
                    dir="auto"
                  />
                </Field>
                <Field label={form.entry_type === "story" ? (isAr ? "القصة (إنجليزي)" : "Story (English)") : (isAr ? "المعنى (إنجليزي)" : "Meaning (English)")}>
                  <Textarea
                    value={form.meaning}
                    onChange={(e) => setForm((f) => ({ ...f, meaning: e.target.value }))}
                    className="rounded-none font-body text-xs min-h-[120px] resize-none"
                    dir="ltr"
                  />
                </Field>
                <Field label={form.entry_type === "story" ? (isAr ? "القصة (عربي)" : "Story (Arabic)") : (isAr ? "المعنى (عربي)" : "Meaning (Arabic)")}>
                  <Textarea
                    value={form.meaning_ar}
                    onChange={(e) => setForm((f) => ({ ...f, meaning_ar: e.target.value }))}
                    className="rounded-none font-body text-xs min-h-[120px] resize-none text-right"
                    dir="rtl"
                  />
                </Field>
                {form.entry_type === "story" && (
                  <Field label={isAr ? "ترجمة عربية إضافية" : "Extra Arabic Translation"}>
                    <Textarea
                      value={form.meaning_extraar || ""}
                      onChange={(e) => setForm((f) => ({ ...f, meaning_extraar: e.target.value }))}
                      className="rounded-none font-body text-xs min-h-[120px] resize-none text-right"
                      dir="rtl"
                    />
                  </Field>
                )}
                <Field label={isAr ? "وسوم" : "Tags"}>
                  <Input
                    value={form.tags}
                    onChange={(e) => setForm((f) => ({ ...f, tags: e.target.value }))}
                    className="rounded-none font-body text-xs"
                    dir="auto"
                  />
                </Field>
                <Field label={isAr ? "صورة" : "Image"}>
                  <div className="flex items-center gap-2 flex-wrap">
                    {form.image_url && (
                      <div className="relative">
                        <img src={form.image_url} alt="" className="w-16 h-16 object-cover rounded-none border border-border" />
                        <button
                          type="button"
                          onClick={() => setForm((f) => ({ ...f, image_url: "" }))}
                          className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-rose-500 text-white rounded-none flex items-center justify-center"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                    <ImageUploadButton onUploaded={(url) => setForm((f) => ({ ...f, image_url: url }))} />
                  </div>
                </Field>
              </>
            )}
            <div className="flex gap-2 pt-1">
              <Button className="flex-1 h-10 rounded-none" onClick={handleCreate} disabled={saving}>
                {saving ? (isAr ? "جارٍ.." : "Saving..") : isAr ? "إضافة" : "Add"}
              </Button>
              <Button variant="outline" className="h-10 rounded-none" onClick={() => setOpen(false)}>
                {isAr ? "إلغاء" : "Cancel"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

function Field({ label, children }) {
  return (
    <div className="space-y-1">
      <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
        {label}
      </label>
      {children}
    </div>
  );
}
