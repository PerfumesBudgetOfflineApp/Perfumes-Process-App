import { useState, useEffect } from "react";
import { X, ZoomIn } from "lucide-react";

/**
 * ZoomableImage
 *
 * A responsive thumbnail that the user can tap to open full-screen, then tap
 * (or press Esc, or hit the ✕) to close. Designed for story / glossary images:
 * it never overflows the column, keeps a tasteful max height inline, and only
 * goes full-bleed inside the lightbox overlay.
 *
 * It renders nothing when no `src` is given, so callers can pass an optional
 * image safely.
 *
 * Props:
 *   src       : image URL (or base64 data URL) — optional
 *   alt       : accessible label
 *   caption   : small italic line shown under the inline image (optional)
 *   className  : extra classes for the inline thumbnail wrapper
 */
export default function ZoomableImage({ src, alt = "", caption = "", className = "", bare = false, inlineMaxHeight = "60vh", hideZoomBadge = false }) {
  const [open, setOpen] = useState(false);

  // Close on Escape; lock body scroll while the lightbox is open.
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open]);

  if (!src) return null;

  // bare = خلفية شفافة بلا إطار/زوايا (لصورة العطر أعلى الصفحة).
  const figureCls = bare ? className : `my-4 ${className}`;
  const btnCls = bare
    ? "group relative block w-full overflow-hidden bg-transparent"
    : "group relative block w-full overflow-hidden rounded-none border border-amber-200/60 bg-stone-50";

  return (
    <>
      {/* Inline thumbnail — constrained so it never breaks the layout */}
      <figure className={figureCls}>
        <button
          type="button"
          onClick={() => setOpen(true)}
          className={btnCls}
          aria-label={alt || "Enlarge image"}
        >
          <img
            src={src}
            alt={alt}
            loading="lazy"
            className="w-full object-contain mx-auto"
            style={{ maxHeight: inlineMaxHeight }}
          />
          {!hideZoomBadge && (
            <span className="absolute top-2 right-2 inline-flex items-center justify-center w-7 h-7 rounded-none bg-black/45 text-white opacity-80 group-hover:opacity-100 transition-opacity">
              <ZoomIn className="w-4 h-4" />
            </span>
          )}
        </button>
        {caption && (
          <figcaption
            className="mt-2 text-center text-[11px] italic text-muted-foreground font-body"
            dir="auto"
          >
            {caption}
          </figcaption>
        )}
      </figure>

      {/* Full-screen lightbox */}
      {open && (
        <div
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/85 backdrop-blur-sm p-4"
          onClick={() => setOpen(false)}
          role="dialog"
          aria-modal="true"
        >
          <button
            type="button"
            onClick={() => setOpen(false)}
            className="absolute top-4 right-4 inline-flex items-center justify-center w-10 h-10 rounded-none bg-white/15 text-white hover:bg-white/25 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
          <img
            src={src}
            alt={alt}
            onClick={(e) => e.stopPropagation()}
            className="max-w-full max-h-full object-contain rounded-none shadow-2xl"
          />
          {caption && (
            <p
              className="absolute bottom-5 left-0 right-0 text-center text-xs text-white/80 italic font-body px-6"
              dir="auto"
            >
              {caption}
            </p>
          )}
        </div>
      )}
    </>
  );
}
