// قائمة «شرح و إشارات» (Reference & Explanation) — قائمة واحدة مطوية تضم كل
// الحقول المرفقة كصفوف فرعية ثنائية اللغة، مكوّن مشترك للأنواع الأربعة
// (قصص/معجم/رمزيات/حكم).
//
// مواصفة المحررة (1.0.0 — حرفية):
// - رأس واحد للقائمة: «شرح و إشارات»، و في القراءة الإنجليزية الصرفة
//   «Reference & Explanation». عنوان الرأس وحده يتبع لغة القراءة؛ المحتوى يبقى
//   ثنائيّ اللغة دائمًا (العربي ثم الإنجليزي).
// - قائمة واحدة لا عدّة قوائم؛ بلا أسهم و لا مثلثات و لا إطارات و لا جداول —
//   رأس نصّي يضغط للفتح، و نص جارٍ بخط المتن (Amiri للعربي) بحجم أصغر درجة.
// - أربعة صفوف بالترتيب، كلٌّ يسبقه عنوان فرعي صغير ثنائي اللغة ليتمايز:
//     • شرح و إشارة     Reference     glossery_explain_ar / glossery_explain
//     • ترادف و تعدد    Synonymy      synonymy_ar / synonymy_en
//     • أضداد           Antonyms      antonyms_ar / antonyms_en
//     • نطق             Pronunciation pronunciation_ar / pronunciation_en
// - العنصر النائب «لا يوجد نص no text» و الفراغ يعاملان فراغا → الصف لا يُرسم؛
//   و إن خلت الصفوف الأربعة جميعا → لا تُرسم القائمة و لا رأسها.

import { useState } from "react";

const PLACEHOLDER = "لا يوجد نص no text";
const real = (v) => {
  const t = String(v || "").trim();
  return t && t !== PLACEHOLDER ? t : "";
};

// الصفوف الفرعية بالترتيب — عنوان فرعي ثنائي + حقلا العربي/الإنجليزي.
const ROWS = [
  { key: "explain", ar: "شرح و إشارة", en: "Reference", fAr: "glossery_explain_ar", fEn: "glossery_explain" },
  { key: "synonymy", ar: "ترادف و تعدد", en: "Synonymy & variants", fAr: "synonymy_ar", fEn: "synonymy_en" },
  { key: "antonyms", ar: "أضداد", en: "Antonyms", fAr: "antonyms_ar", fEn: "antonyms_en" },
  { key: "pron", ar: "نطق", en: "Pronunciation", fAr: "pronunciation_ar", fEn: "pronunciation_en" },
];

export default function GlosseryExplain({ entry, showAr = true, showEn = false, className = "" }) {
  const [open, setOpen] = useState(false);

  // اجمع الصفوف غير الفارغة (أيٌّ من اللغتين يحمل نصًّا حقيقيًّا)
  const rows = ROWS.map((r) => ({
    ...r,
    ar: real(entry?.[r.fAr]),
    en: real(entry?.[r.fEn]),
  })).filter((r) => r.ar || r.en);

  if (rows.length === 0) return null; // القائمة كلها تختفي إن خلت الصفوف

  const enTitle = showEn && !showAr; // قراءة إنجليزية صرفة → عنوان الرأس إنجليزي

  return (
    <div className={className ? `space-y-2 ${className}` : "space-y-2"}>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="cursor-pointer font-body select-none bg-transparent p-0 text-start"
        style={{ fontSize: 13, opacity: 0.85, fontWeight: 600, fontFamily: enTitle ? undefined : "'Amiri', serif", border: "none", display: "block" }}
        dir={enTitle ? "ltr" : "rtl"}
      >
        {enTitle ? "Reference & Explanation" : "شرح و إشارات"}
      </button>

      {open ? (
        <div className="space-y-3">
          {rows.map((r) => (
            <div key={r.key} className="space-y-1">
              {/* عنوان فرعي صغير ثنائي اللغة يميّز الصف داخل القائمة الواحدة */}
              <p
                className="font-body"
                dir={enTitle ? "ltr" : "rtl"}
                style={{ margin: 0, fontSize: 11, opacity: 0.6, fontWeight: 600, fontFamily: enTitle ? undefined : "'Amiri', serif" }}
              >
                {enTitle ? r.en : `${r.ar} ${r.en}`}
              </p>
              {r.ar ? (
                <p dir="rtl" className="font-body" style={{ margin: 0, fontSize: 15, lineHeight: 1.9, whiteSpace: "pre-wrap", fontFamily: "'Amiri', serif" }}>{r.ar}</p>
              ) : null}
              {r.en ? (
                <p dir="ltr" className="font-body" style={{ margin: 0, fontSize: 13, lineHeight: 1.8, whiteSpace: "pre-wrap" }}>{r.en}</p>
              ) : null}
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
}
