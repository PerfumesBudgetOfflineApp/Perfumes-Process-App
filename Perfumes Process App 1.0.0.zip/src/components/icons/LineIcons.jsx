/**
 * أيقونات خطّية inline (currentColor) — مرسومة يدوياً لأن lucide 1.16 قد لا
 * تتضمّن بعضها فتكسر البناء. كلها تقبل className / strokeWidth / style مثل lucide.
 */
function Svg({ className, strokeWidth = 2, style, children }) {
  return (
    <svg
      className={className}
      style={style}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {children}
    </svg>
  );
}

export const ArrowLeftIcon = (p) => (
  <Svg {...p}><path d="M19 12H5" /><path d="m12 19-7-7 7-7" /></Svg>
);

export const DownloadIcon = (p) => (
  <Svg {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><path d="M7 10l5 5 5-5" /><path d="M12 15V3" /></Svg>
);

export const FileTextIcon = (p) => (
  <Svg {...p}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /><path d="M8 13h8" /><path d="M8 17h8" /></Svg>
);

export const ImageIcon = (p) => (
  <Svg {...p}><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="9" cy="9" r="2" /><path d="m21 15-4.5-4.5L7 20" /></Svg>
);

export const PdfIcon = (p) => (
  <Svg {...p}><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><path d="M14 2v6h6" /><path d="M8.5 13v5" /><path d="M8.5 13h1.2a1.3 1.3 0 0 1 0 2.6H8.5" /><path d="M13.5 13h2.5" /><path d="M13.5 13v5" /><path d="M13.5 15.5H15" /></Svg>
);

export const CheckSquareIcon = (p) => (
  <Svg {...p}><path d="M9 11l3 3L22 4" /><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" /></Svg>
);

export const SquareIcon = (p) => (
  <Svg {...p}><rect x="3" y="3" width="18" height="18" rx="2" /></Svg>
);

export const SparklesIcon = (p) => (
  <Svg {...p}><path d="M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6z" /><path d="M18 14l.8 2.2L21 17l-2.2.8L18 20l-.8-2.2L15 17l2.2-.8z" /></Svg>
);

export const SearchIcon = (p) => (
  <Svg {...p}><circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" /></Svg>
);

export const XIcon = (p) => (
  <Svg {...p}><path d="M18 6 6 18" /><path d="m6 6 12 12" /></Svg>
);

export const LibraryIcon = (p) => (
  <Svg {...p}><path d="M4 4v16" /><path d="M8 4v16" /><path d="M12 4v16" /><rect x="15" y="4" width="5" height="16" rx="1" transform="rotate(12 17 12)" /></Svg>
);

export const DatabaseIcon = (p) => (
  <Svg {...p}><ellipse cx="12" cy="5" rx="8" ry="3" /><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5" /><path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" /></Svg>
);
