/**
 * أيقونة ممحاة (Eraser) inline — موحّدة لرمز "الإهمال/المهملات" في كل التطبيق.
 * مرسومة inline لأن lucide 1.16 قد لا تتضمّن Eraser فتكسر البناء.
 * تقبل className / strokeWidth / style مثل أيقونات lucide.
 */
export default function EraserIcon({ className, strokeWidth = 2, style }) {
  return (
    <svg
      className={className}
      style={style}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <path d="m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21" />
      <path d="M22 21H7" />
      <path d="m5 11 9 9" />
    </svg>
  );
}
