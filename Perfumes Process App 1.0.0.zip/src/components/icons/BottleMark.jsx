export default function BottleMark({ className }) {
  return (
    <svg
      className={className}
      viewBox="0 0 40 40"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      strokeLinejoin="round"
      strokeLinecap="round"
      aria-hidden="true"
    >
      <rect x="16" y="4" width="8" height="6" rx="1.5" />
      <path d="M22 10 v3 q6 1.5 6 7 v12 q0 2 -2 2 h-12 q-2 0 -2 -2 v-12 q0 -5.5 6 -7 v-3 z" />
      <line x1="13" y1="25" x2="27" y2="25" strokeWidth="1.6" opacity="0.7" />
    </svg>
  );
}
