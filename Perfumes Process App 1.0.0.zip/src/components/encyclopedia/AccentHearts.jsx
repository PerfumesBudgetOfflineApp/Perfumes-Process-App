import { ENC_ACCENTS } from "@/lib/encAccents";

// منتقي ألوان — مربّعات بزوايا حادة. المختار بإطار، الافتراضي بلون التطبيق.
// value: اللون الحاليّ ("" = الافتراضي). onPick(color). colors: لوحة الألوان.
export default function AccentHearts({ value, onPick, colors = ENC_ACCENTS, size = 16 }) {
  const norm = (x) => String(x || "").toLowerCase();
  return (
    <>
      {colors.map((c, i) => {
        const col = c || "var(--brand)";
        const active = norm(value) === norm(c);
        return (
          <button key={i} type="button" onClick={() => onPick(c)} aria-label={c || "default"}
            className="transition-transform hover:scale-110"
            style={{ width: size, height: size, background: col, borderRadius: 0, border: 0,
              outline: active ? "2px solid var(--foreground)" : "1px solid rgba(0,0,0,.18)", outlineOffset: 1, padding: 0, cursor: "pointer" }} />
        );
      })}
    </>
  );
}
