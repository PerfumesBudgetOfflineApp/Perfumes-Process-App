import { useState, useRef } from "react";
import { TYPE_COLORS } from "./ActivityTimeline";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, FileText, Image, FileImage } from "lucide-react";
import { format, subDays, subWeeks, subMonths, subYears } from "date-fns";
import { openHtmlReport, saveCanvasAsImage, downloadBlob } from "@/lib/exportHelper";
import ExportOptionsBar from "@/components/export/ExportOptionsBar";
const PERIOD_OPTIONS = [
  { value: "day", label: "Today" },
  { value: "week", label: "This Week" },
  { value: "month", label: "This Month" },
  { value: "year", label: "This Year" },
  { value: "all", label: "All Time" },
];

const TYPE_OPTIONS = [
  { key: "reviews", label: "📝 Reviews" },
  { key: "purchases", label: "🛍 Purchases" },
  { key: "favorites", label: "🤎 Favorites" },
  { key: "wearLogs", label: "💧 Wear Logs" },
  { key: "blogEntries", label: "📖 Blog Entries" },
  { key: "goals", label: "🎯 Goals / Tasks" },
  { key: "budgetEntries", label: "💰 Budget Entries" },
  { key: "moodEntries", label: "😊 Mood Entries" },
];

const FORMAT_OPTIONS = [
  { value: "txt", label: "Text (.txt)", icon: FileText },
  { value: "pdf", label: "PDF (.pdf)", icon: FileImage },
  { value: "image", label: "Image (.png)", icon: Image },
];

const TYPE_MAP = {
  review: "reviews", purchase: "purchases", favorite: "favorites",
  wear: "wearLogs", blog: "blogEntries", glossary: "glossaryEntries", goal: "goals",
  budget: "budgetEntries", quote: "quotesActivity", mood: "moodEntries",
};


function getStartDate(period) {
  const now = new Date();
  if (period === "day") return subDays(now, 1);
  if (period === "week") return subWeeks(now, 1);
  if (period === "month") return subMonths(now, 1);
  if (period === "year") return subYears(now, 1);
  return null;
}

export default function ActivityExportDialog({ open, onOpenChange, activities }) {
  const [period, setPeriod] = useState("month");
  const [exportFormat, setExportFormat] = useState("txt");
  const [selectedTypes, setSelectedTypes] = useState({
    reviews: true, purchases: true, favorites: true,
    wearLogs: true, blogEntries: true, glossaryEntries: true, goals: true,
    budgetEntries: true, quotesActivity: true, moodEntries: true,
  });
  const [exporting, setExporting] = useState(false);
  const previewRef = useRef(null);

  const toggleType = (key) => setSelectedTypes((s) => ({ ...s, [key]: !s[key] }));

  const getFiltered = () => {
    const startDate = getStartDate(period);
    return activities.filter((a) => {
      const typeKey = TYPE_MAP[a.type];
      if (!selectedTypes[typeKey]) return false;
      if (startDate && a.date < startDate) return false;
      return true;
    });
  };

  const buildLines = (filtered) => {
    // كما في الصفحة: سيل واحد — بلا عنوان ولا تواريخ ولا أعداد ولا تجميع
    const lines = [];
    filtered.forEach((a) => {
      lines.push(String(a.title || ""));
      if (a.subtitle) lines.push("   " + a.subtitle);
      lines.push("");
    });
    return lines;
  };

  const exportTxt = async (filtered) => {
    const lines = buildLines(filtered);
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    await downloadBlob(blob, `activities-${period}-${format(new Date(), "yyyyMMdd")}.txt`);
  };

  const exportPdf = async (filtered) => {
    // تقرير مذهب أنيق يطابق الصفحة: بلا نص Activity Report، بلا تواريخ ولا أعداد
    // ولا أخضر ولا جداول — معين ملون حسب النوع، العنوان والنص تحته، حسب الفترة المختارة.
    const rowsHtml = filtered.map((a) => {
      const c = TYPE_COLORS[a.type] || "var(--brand)";
      return `<div style="display:flex; align-items:flex-start; gap:12px; padding:13px 2px; border-bottom:1px solid rgba(200,160,46,0.18);">
        <span style="width:8px; height:8px; margin-top:7px; flex-shrink:0; border:1.5px solid ${c}; display:inline-block;"></span>
        <div style="min-width:0;">
          <div style="font-size:14.5px; color:#1f2937; font-weight:600;">${a.title || ""}${a.emoji ? ` <span style="font-size:17px;">${a.emoji}</span>` : ""}${a.ratingStars ? ` <span style="color:var(--brand); font-size:12px;">${a.ratingStars}</span>` : ""}</div>
          ${a.subtitle ? `<div style="font-size:12.5px; color:#8a7a55; margin-top:3px;">${a.subtitle}</div>` : ""}
        </div>
      </div>`;
    }).join("");

    const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8"/>
  <title>برفيومز بروسس اب Perfumes Process App</title>
  <style>
    @font-face { font-family: 'Cairo'; src: url('/fonts/Cairo.woff') format('woff'); font-weight: 400 800; font-display: swap; }
    * { box-sizing: border-box; }
    body { font-family: 'Cairo', 'Arial', 'Segoe UI', Tahoma, sans-serif; direction: rtl; margin: 0; padding: 30px 38px; background: #fff; color: #222; }
    @media print { body { padding: 20px 28px; } }
  </style>
</head>
<body>
  <div style="height:3px; background:linear-gradient(90deg,#e7d39a,var(--brand),#e7d39a); margin-bottom:14px;"></div>
  ${rowsHtml}
  <div style="height:3px; background:linear-gradient(90deg,#e7d39a,var(--brand),#e7d39a); margin-top:14px;"></div>
</body>
</html>`;

    await openHtmlReport(html);
  };

  const exportImage = async (filtered) => {
    // بطاقة مذهبة تطابق الصفحة: سيل واحد، معين ملون لكل نوع، بلا عنوان/تواريخ/أعداد/أخضر
    const W = 1080;
    const PADDING = 56;
    const canvas = document.createElement("canvas");
    canvas.width = W;
    const itemH = (a) => (a.subtitle ? 86 : 56);
    const totalH = 46 + filtered.reduce((sum, a) => sum + itemH(a), 0) + PADDING;
    canvas.height = totalH;
    const ctx = canvas.getContext("2d");

    ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, W, totalH);
    const goldGrad = ctx.createLinearGradient(0, 0, W, 0);
    goldGrad.addColorStop(0, "#e7d39a"); goldGrad.addColorStop(0.5, "var(--brand)"); goldGrad.addColorStop(1, "#e7d39a");
    ctx.fillStyle = goldGrad; ctx.fillRect(0, 0, W, 4); ctx.fillRect(0, totalH - 4, W, 4);

    const titleFont = "600 26px 'Segoe UI', 'Arial', sans-serif";
    const subFont = "20px 'Segoe UI', 'Arial', sans-serif";
    const ellips = (font, text, maxW) => { ctx.font = font; let t = String(text || ""); while (ctx.measureText(t).width > maxW && t.length > 6) t = t.slice(0, -1); return t === String(text || "") ? t : t + ".."; };

    let y = 46;
    filtered.forEach((a) => {
      const c = TYPE_COLORS[a.type] || "var(--brand)";
      // المعين على اليمين كما في الصفحة
      ctx.save();
      ctx.translate(W - PADDING - 7, y + 16); ctx.rotate(Math.PI / 4);
      ctx.strokeStyle = c; ctx.lineWidth = 2.4; ctx.strokeRect(-6, -6, 12, 12);
      ctx.restore();
      // العنوان من اليمين
      const tMax = W - PADDING * 2 - 40;
      ctx.textAlign = "right"; ctx.fillStyle = "#1f2937";
      const line = ellips(titleFont, a.title, tMax - (a.ratingStars ? 110 : 0));
      ctx.font = titleFont;
      ctx.fillText(line, W - PADDING - 28, y + 24);
      const lw = ctx.measureText(line).width;
      if (a.emoji) {
        ctx.font = "26px 'Segoe UI Emoji', 'Apple Color Emoji', sans-serif";
        ctx.fillText(a.emoji, W - PADDING - 28 - lw - 12, y + 24);
      }
      if (a.ratingStars) {
        ctx.font = "18px 'Arial', sans-serif"; ctx.fillStyle = "var(--brand)";
        ctx.textAlign = "left"; ctx.fillText(a.ratingStars, PADDING, y + 24); ctx.textAlign = "right";
      }
      if (a.subtitle) {
        ctx.fillStyle = "#8a7a55";
        const subLine = ellips(subFont, a.subtitle, tMax);
        ctx.font = subFont;
        ctx.fillText(subLine, W - PADDING - 28, y + 56);
      }
      ctx.strokeStyle = "rgba(200,160,46,0.18)"; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(PADDING, y + itemH(a) - 12); ctx.lineTo(W - PADDING, y + itemH(a) - 12); ctx.stroke();
      y += itemH(a);
    });

    await saveCanvasAsImage(canvas, `activities-${period}-${format(new Date(), "yyyyMMdd")}.png`);
  };

const handleExport = async () => {
    const filtered = getFiltered();
    if (filtered.length === 0) {
      alert("No activities match the selected filters.");
      return;
    }
    setExporting(true);
    try {
      if (exportFormat === "txt") exportTxt(filtered);
      else if (exportFormat === "pdf") exportPdf(filtered);
      else if (exportFormat === "image") await exportImage(filtered);
    } finally {
      setExporting(false);
    }
  };

  const previewCount = getFiltered().length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-none max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading text-base">تصدير النشاطات Export Activities</DialogTitle>
          <DialogDescription>
            Choose time period, format, and activity types to export
          </DialogDescription>
        </DialogHeader>
          <ExportOptionsBar />

        <div className="space-y-4">
          {/* Period */}
          <div className="space-y-2">
            <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">الفترة الزمنية Time Period</p>
            <div className="grid grid-cols-3 gap-1.5">
              {PERIOD_OPTIONS.map(({ value, label }) => (
                <button key={value} onClick={() => setPeriod(value)}
                  className={`py-2 rounded-none text-xs font-body font-medium transition-all ${period === value ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Format */}
          <div className="space-y-2">
            <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">صيغة التصدير Export Format</p>
            <div className="grid grid-cols-3 gap-1.5">
              {FORMAT_OPTIONS.map(({ value, label, icon: Icon }) => (
                <button key={value} onClick={() => setExportFormat(value)}
                  className={`flex flex-col items-center gap-1 py-2.5 rounded-none text-[10px] font-body font-medium transition-all ${exportFormat === value ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Types */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">تضمين Include</p>
              <button
                onClick={() => {
                  const allOn = TYPE_OPTIONS.every((t) => selectedTypes[t.key]);
                  const next = {};
                  TYPE_OPTIONS.forEach((t) => (next[t.key] = !allOn));
                  setSelectedTypes(next);
                }}
                className="text-[10px] text-primary font-body underline"
              >
                {TYPE_OPTIONS.every((t) => selectedTypes[t.key]) ? "Deselect All" : "Select All"}
              </button>
            </div>
            <div className="space-y-1.5">
              {TYPE_OPTIONS.map(({ key, label }) => (
                <button key={key} onClick={() => toggleType(key)} className="w-full flex items-center gap-2 text-xs font-body">
                  <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors flex-shrink-0 ${selectedTypes[key] ? "bg-primary border-primary" : "border-border"}`}>
                    {selectedTypes[key] && <div className="w-2 h-2 bg-white rounded-none" />}
                  </div>
                  <span className={selectedTypes[key] ? "text-foreground" : "text-muted-foreground"}>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Preview count */}
          <p className="text-xs text-muted-foreground font-body text-center">
            {previewCount} activities will be exported
          </p>

          <Button className="w-full h-10 rounded-none font-body gap-2" onClick={handleExport} disabled={previewCount === 0 || exporting}>
            <Download className="w-4 h-4" />
            {exporting ? "Exporting.." : `Export as ${exportFormat.toUpperCase()}`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}