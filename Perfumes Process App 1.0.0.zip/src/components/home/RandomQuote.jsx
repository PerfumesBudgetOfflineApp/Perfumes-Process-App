import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { Link } from "react-router-dom";
import { Heart, ThumbsUp, ThumbsDown, RotateCw } from "lucide-react";
import EraserIcon from "@/components/icons/EraserIcon";
import BookmarkButton from "@/components/shared/BookmarkButton";

/**
 * RandomQuote — اقتباس عشوائي على Goals/Home.
 * يعرض اللغتين دائماً، بلا تصنيف، بخلفية مختلفة وبلا إطارات، وبخمسة أزرار
 * تفاعل بلا إطارات: مفضّل · إعجاب · عدم إعجاب · مذهول 😱 · إبعاد (cast away).
 * الإبعاد يُخفي الاقتباس من الدوران ويسجّله reaction="castaway".
 */
export default function RandomQuote({ linkTo }) {
  const { isAr } = useLang();
  const [currentQuote, setCurrentQuote] = useState(null);
  const qc = useQueryClient();

  // حوض عشوائي من قسم «اقتباسات / Quotes» في الموسوعة (يحلّ محلّ جدول Quote القديم).
  const { data: quotes = [] } = useQuery({
    queryKey: ["enc-quotes-random-pool"],
    queryFn: async () => {
      const sections = (await apphost.entities.EncSection.list("order", 200)) || [];
      const sec = sections.find((s) => s.name_en === "Quotes");
      if (!sec) return [];
      const all = (await apphost.entities.EncEntry.filter({ section_id: sec.id }, "order", 20000)) || [];
      if (!all.length) return [];
      const POOL = Math.min(12, all.length);
      const idxs = new Set();
      while (idxs.size < POOL) idxs.add(Math.floor(Math.random() * all.length));
      return [...idxs].map((i) => {
        const e = all[i];
        const en = (e.texts?.en || e.titles?.en || "").trim();
        const ar = (e.texts?.ar || e.titles?.ar || "").trim();
        return { id: e.id, text_en: en, text_ar: ar, text_enar: "", text: en || ar, category: "", author: e.source || "", reactions: e.reactions || (e.reaction ? { person1: e.reaction } : {}) };
      });
    },
    staleTime: 1000 * 60 * 5,
  });

  // رابط «كل الاقتباسات» → قسم الاقتباسات في الموسوعة (لا الجدول القديم)
  const { data: quotesSecId } = useQuery({
    queryKey: ["enc-quotes-sec-id"],
    queryFn: async () => {
      const secs = (await apphost.entities.EncSection.list("order", 200)) || [];
      const s = secs.find((x) => x.name_en === "Quotes");
      return s ? s.id : null;
    },
    staleTime: 1000 * 60 * 5,
  });
  const allQuotesLink = quotesSecId ? `/encyclopedia?sec=${quotesSecId}` : "/encyclopedia";

  // التفاعلات تغذّي الموسوعة مباشرةً: تُحفظ في EncEntry.reactions حسب المستخدم النشط.
  const activePerson = (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1";

  const pickNewQuote = (excludeId = null) => {
    const ex = excludeId != null ? String(excludeId) : null;
    const withText = quotes.filter(
      (q) => (q.text_enar || q.text_en || q.text_ar || q.text) &&
        (q.reactions?.[activePerson] !== "castaway") &&
        String(q.id) !== ex
    );
    const pool = withText.length > 0 ? withText : quotes.filter((q) => String(q.id) !== ex);
    if (pool.length > 0) setCurrentQuote(pool[Math.floor(Math.random() * pool.length)]);
  };

  useEffect(() => {
    pickNewQuote();
     
  }, [quotes.length]);

  useEffect(() => {
    const handle = () => pickNewQuote();
    window.addEventListener("refreshQuote", handle);
    return () => window.removeEventListener("refreshQuote", handle);
     
  }, [quotes.length]);

  if (!currentQuote) return null;

  const userReaction = currentQuote.reactions?.[activePerson] || "none";
  const react = (reaction) => {
    const newReaction = userReaction === reaction ? "none" : reaction;
    const reactions = { ...(currentQuote.reactions || {}) };
    if (newReaction === "none") delete reactions[activePerson]; else reactions[activePerson] = newReaction;
    setCurrentQuote({ ...currentQuote, reactions }); // عرض فوريّ
    const id = currentQuote.id;
    apphost.entities.EncEntry.update(id, { reactions }).then(() => {
      qc.invalidateQueries({ queryKey: ["enc-fav-entries"] });
    }).catch(() => {});
    if (newReaction === "castaway") setTimeout(() => pickNewQuote(id), 0);
  };

  // اللغتان دائماً: نفضّل المدمج، وإلا نعرض الإنجليزي والعربي معاً.
  const enar = currentQuote.text_enar || "";
  const en = currentQuote.text_en || currentQuote.text || "";
  const ar = currentQuote.text_ar || "";

  const RBtn = ({ active, activeColor, title, onClick, children }) => (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-label={title}
      className={`flex items-center justify-center w-8 h-8 bg-transparent transition-all ${
        active ? activeColor : "text-muted-foreground/55 hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );

  return (
    <div className="px-1 py-2 space-y-3">
      {/* Bilingual quote — always both languages */}
      {enar ? (
        <p className="text-sm font-body font-medium leading-relaxed" dir="auto" style={{ unicodeBidi: "plaintext" }}>{enar}</p>
      ) : (
        <div className="space-y-1">
          {en && <p className="text-sm font-body font-medium leading-relaxed" dir="ltr">{en}</p>}
          {ar && <p className="text-sm font-body font-medium leading-relaxed" dir="rtl">{ar}</p>}
        </div>
      )}

      {currentQuote.author && (
        <p className="text-xs text-muted-foreground font-body" dir="auto" style={{ unicodeBidi: "plaintext" }}>— {currentQuote.author}</p>
      )}

      {currentQuote.category && (
        <span className="inline-block text-[10px] font-body text-amber-700 dark:text-amber-300" dir="auto" style={{ unicodeBidi: "plaintext" }}>
          {currentQuote.category}
        </span>
      )}

      <div className="flex items-center gap-2 justify-between pt-1 flex-wrap-reverse">
        <div className="flex gap-2 items-center">
          <Link to={allQuotesLink} className="text-primary text-[10px] font-body hover:underline whitespace-nowrap">
            {isAr ? "كل الاقتباسات" : "Read all quotes"}
          </Link>
          <button type="button" onClick={pickNewQuote}
            className="p-1.5 text-muted-foreground/60 hover:text-primary transition-colors"
            title={isAr ? "اقتباس آخر" : "Next quote"}>
            <RotateCw className="w-4 h-4" />
          </button>
        </div>
        {/* Five reactions, borderless */}
        <div className="flex gap-1 items-center">
          <RBtn active={userReaction === "favorite"} activeColor="text-rose-500" title={isAr ? "مفضّل" : "Favourite"} onClick={() => react("favorite")}>
            <Heart className={`w-4 h-4 ${userReaction === "favorite" ? "fill-current" : ""}`} />
          </RBtn>
          <RBtn active={userReaction === "like"} activeColor="text-emerald-600" title={isAr ? "إعجاب" : "Like"} onClick={() => react("like")}>
            <ThumbsUp className="w-4 h-4" />
          </RBtn>
          <RBtn active={userReaction === "dislike"} activeColor="text-slate-500" title={isAr ? "عدم إعجاب" : "Dislike"} onClick={() => react("dislike")}>
            <ThumbsDown className="w-4 h-4" />
          </RBtn>
          <RBtn active={userReaction === "wtf"} activeColor="opacity-100" title={isAr ? "مذهل/غريب" : "Astonishing"} onClick={() => react("wtf")}>
            <span className={`text-base leading-none ${userReaction === "wtf" ? "opacity-100" : "opacity-60"}`}>😱</span>
          </RBtn>
          <BookmarkButton size={32} descriptor={{
            item_type: "quote", item_id: String(currentQuote.id),
            title_en: currentQuote.text_en || currentQuote.text || currentQuote.text_enar || "",
            title_ar: currentQuote.text_ar || "",
            subtitle: currentQuote.category || "", path: linkTo || "/quotes",
          }} />
          <RBtn active={userReaction === "castaway"} activeColor="text-amber-600" title={isAr ? "إبعاد" : "Cast away"} onClick={() => react("castaway")}>
            <EraserIcon className="w-4 h-4" strokeWidth={2} />
          </RBtn>
        </div>
      </div>
    </div>
  );
}
