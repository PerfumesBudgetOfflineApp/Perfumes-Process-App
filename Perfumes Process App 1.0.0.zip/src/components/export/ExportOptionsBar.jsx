/**
 * ExportOptionsBar — bilingual 3-toggle row used at the top of every
 * export dialog.
 *
 *   [ ] User Mark         علامتي
 *   [ ] App Name          اسم التطبيق
 *   [ ] Date              التاريخ
 *
 * All three default OFF. State persists across sessions in localStorage.
 * Components don't need to track state — they read from getExportSettings()
 * (or useExportSettings) at the moment of export.
 */

import React from "react";
import { useExportSettings } from "@/lib/exportSettings";
import { useLang } from "@/lib/LanguageContext";

export default function ExportOptionsBar({ userMarkAvailable = true, compact = false, showInteractionToggle = false }) {
  const [settings, setSettings] = useExportSettings();
  const { isAr } = useLang();

  const toggle = (key) => setSettings({ [key]: !settings[key] });

  const labels = {
    mark:    isAr ? "علامتي"          : "User Mark",
    name:    isAr ? "الاسم"           : "Name",
    date:    isAr ? "التاريخ"          : "Date",
    photo:   isAr ? "صورتي"           : "Photo",
    interaction: isAr ? "تفاعلي" : "My Interaction",
    title:   isAr ? "ما يظهر في الصورة" : "Show in export",
  };

  const Row = ({ enabled, onClick, label, disabled = false }) => (
    <button
      type="button"
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      className={`flex items-center gap-1.5 rounded-none text-[11px] font-body transition-colors ${
 disabled
 ? "opacity-40 cursor-not-allowed "
 : enabled
 ? " text-primary "
 : " text-muted-foreground hover:text-foreground "
 }`}
    >
      <span className={`w-3 h-3 rounded-none border flex items-center justify-center text-[10px] leading-none ${
        enabled ? "bg-primary border-primary text-primary-foreground" : "border-muted-foreground/50"
      }`}>
        {enabled ? "✓" : ""}
      </span>
      <span>{label}</span>
    </button>
  );

  return (
    <div className={`flex flex-wrap items-center gap-1.5 ${compact ? "" : "mb-2"}`}>
      {!compact && (
        <span className="text-[10px] font-body uppercase text-muted-foreground tracking-wider mr-1">
          {labels.title}
        </span>
      )}
      <Row
        enabled={settings.showUserMark}
        onClick={() => toggle("showUserMark")}
        label={labels.mark}
        disabled={!userMarkAvailable}
      />
      <Row
        enabled={settings.showUserPhoto}
        onClick={() => toggle("showUserPhoto")}
        label={labels.photo}
      />
      <Row
        enabled={settings.showName}
        onClick={() => toggle("showName")}
        label={labels.name}
      />
      <Row
        enabled={settings.showDate}
        onClick={() => toggle("showDate")}
        label={labels.date}
      />
      {showInteractionToggle && (
        <Row
          enabled={settings.showUserInteraction}
          onClick={() => toggle("showUserInteraction")}
          label={labels.interaction}
        />
      )}
    </div>
  );
}
