import { useState } from "react";
import { Layers, Trash2, CalendarDays, Pencil, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { typeDisplay } from "@/lib/perfumeTypes";
import { StrengthBar } from "@/components/perfume/StrengthIndicator";
import { perfumeFacets, buildBlendReport } from "@/lib/blendReport";

export default function LayerCard({ layer, names, personColor, perfumeMap, isAr, onExport, onEdit, onDelete, onLogWear, onRateUpdate }) {
  const [showExport, setShowExport] = useState(false);
  const personLabel = layer.person === "both" ? (names.both || "Both") : layer.person === "person2" ? names.person2 : names.person1;
  const pColor = personColor ? personColor(layer.person) : "var(--brand)";

  // Support both new multi-perfume format and legacy 2-perfume format
  const perfumeList = layer.perfume_names
    ? layer.perfume_names.split(",").map((n, i) => {
        const brands = layer.perfume_brands ? layer.perfume_brands.split(",") : [];
        return { name: n.trim(), brand: brands[i]?.trim() || "" };
      })
    : [
        { name: layer.perfume1_name, brand: layer.perfume1_brand },
        { name: layer.perfume2_name, brand: layer.perfume2_brand },
      ];

  return (
    <div className="pb-3 border-b border-border/30 space-y-3">
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          {layer.name && (
            <p className="text-sm font-body font-semibold truncate mb-1">{layer.name}</p>
          )}
          {/* Perfume list */}
          <div className="flex items-start gap-1.5 flex-wrap">
            {perfumeList.map((p, i) => (
              <div key={i} className="flex items-center gap-1">
                {i > 0 && <Layers className="w-2.5 h-2.5 flex-shrink-0" style={{ color: pColor, opacity: 0.7 }} />}
                <div className="flex items-baseline gap-1">
                  <span className="text-xs font-body font-medium text-foreground/90">{p.name}</span>
                  {p.brand && <span className="text-[9px] text-muted-foreground font-body">— {p.brand}</span>}
                </div>
              </div>
            ))}
          </div>
          {perfumeList.length > 2 && (
            <p className="text-[10px] font-body mt-0.5" style={{ color: pColor }}>{perfumeList.length}-perfume blend</p>
          )}
        </div>
        <div className="flex items-center gap-2 flex-shrink-0 mt-0.5">
          {onExport && (
            <div className="relative">
              <button onClick={() => setShowExport((v) => !v)} aria-label="Export" className="text-muted-foreground hover:text-foreground transition-colors">
                <Download className="w-3.5 h-3.5" />
              </button>
              {showExport && (
                <div className="absolute end-0 mt-1 z-20 bg-card border border-border shadow-md rounded-none py-1 min-w-[120px]">
                  {[["ar", "IMG AR"], ["aren", "IMG AR EN"], ["merged", "IMG Merged"]].map(([v, lbl]) => (
                    <button key={v} onClick={() => { setShowExport(false); onExport(v); }}
                      className="w-full text-start px-3 py-1.5 text-xs font-body hover:bg-secondary/60 transition-colors">{lbl}</button>
                  ))}
                </div>
              )}
            </div>
          )}
          <button onClick={onEdit} aria-label="Edit" className="text-muted-foreground hover:text-foreground transition-colors">
            <Pencil className="w-3.5 h-3.5" />
          </button>
          <button onClick={onDelete} aria-label="Delete" className="text-muted-foreground hover:text-destructive transition-colors">
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Notes */}
      {layer.notes && (
        <p className="text-xs font-body text-muted-foreground italic leading-relaxed">— {layer.notes}</p>
      )}

      {/* فروق العطور — كأنك تتصفّح عدة عطور: نوع · كثافة · جنس · أكوردات · هرم · مناسبات · صحة + تقرير */}
      {(() => {
        const ids = (layer.perfume_ids ? layer.perfume_ids.split(",") : [layer.perfume1_id, layer.perfume2_id])
          .map((x) => String(x || "").trim()).filter(Boolean);
        const ps = ids.map((id) => (perfumeMap ? perfumeMap[id] : null)).filter(Boolean);
        const facets = ps.map((p) => perfumeFacets(p)).filter(Boolean);
        if (facets.length < 2) return null;
        const report = buildBlendReport(ps);
        const NoteLine = ({ lbl, arr, color }) => arr.length === 0 ? null : (
          <p className="text-[9px] font-body leading-snug text-muted-foreground" dir="auto">
            <span style={{ color, fontWeight: 600 }}>{lbl}</span> {arr.slice(0, 5).join("، ")}
          </p>
        );
        return (
          <div className="space-y-2 pt-0.5">
            <p className="text-[9px] uppercase tracking-wider font-body" style={{ color: pColor, opacity: 0.7 }}>{isAr ? "الفروق" : "Differences"}</p>
            {facets.map((f, i) => (
              <div key={i} className="space-y-1 pb-1.5" style={{ borderBottom: i < facets.length - 1 ? "1px solid var(--border)" : "none" }} dir={isAr ? "rtl" : "ltr"}>
                <div className="flex items-center gap-1.5">
                  {f.dominant && <span style={{ width: 8, height: 8, borderRadius: 2, background: f.dominant.color, display: "inline-block", flexShrink: 0 }} />}
                  <span className="text-[11px] font-body font-semibold text-foreground/90">{f.name}</span>
                </div>
                <div className="flex items-center gap-2 flex-wrap ps-3">
                  {f.typeText && <span className="text-[9px] text-muted-foreground font-body">{typeDisplay(f.typeValue, isAr ? "ar" : "en")}</span>}
                  {f.strength && <StrengthBar strength={f.strength} width={40} height={5} />}
                  {f.gender && <span className="text-[9px] font-body" style={{ color: pColor, opacity: 0.85 }}>{isAr ? f.gender.ar : f.gender.en}</span>}
                </div>
                {f.accords.length > 0 && (
                  <div className="flex items-center gap-1 flex-wrap ps-3">
                    {f.accords.map((a, j) => (
                      <span key={j} className="text-[9px] font-body inline-flex items-center gap-1 rounded-full px-1.5" style={{ color: "var(--muted-foreground)", border: `1px solid ${a.color}55` }} dir="auto">
                        <span style={{ width: 6, height: 6, borderRadius: 999, background: a.color, flexShrink: 0 }} />{isAr ? a.ar : a.en}
                      </span>
                    ))}
                  </div>
                )}
                {(f.top.length || f.heart.length || f.base.length) > 0 && (
                  <div className="ps-3 space-y-0.5">
                    <NoteLine lbl={isAr ? "مقدمة" : "Top"} arr={f.top} color="#3b82c4" />
                    <NoteLine lbl={isAr ? "قلب" : "Heart"} arr={f.heart} color="#c4607f" />
                    <NoteLine lbl={isAr ? "أساس" : "Base"} arr={f.base} color="#b08948" />
                  </div>
                )}
                {(f.occasions.length > 0 || f.health.length > 0) && (
                  <div className="ps-3 flex items-center gap-2 flex-wrap text-[11px]" dir="auto" title="">
                    {f.occasions.map((o, j) => <span key={`o${j}`} title={isAr ? o.ar : o.en}>{o.emoji}</span>)}
                    {f.health.map((h, j) => <span key={`h${j}`} title={isAr ? h.ar : h.en}>{h.emoji}</span>)}
                  </div>
                )}
              </div>
            ))}
            {report.ar && (
              <p className="text-[10px] font-body leading-relaxed text-foreground/75 pt-1" dir={isAr ? "rtl" : "ltr"} style={{ whiteSpace: "pre-line" }}>
                {isAr ? report.ar : report.en}
              </p>
            )}
          </div>
        );
      })()}

      {/* Meta row — اسم المستخدم بلونه، بلا خلفية */}
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-[10px] font-body font-semibold" style={{ color: pColor }}>{personLabel}</span>
        {layer.wear_count > 0 && (
          <span className="text-[10px] text-muted-foreground font-body flex items-center gap-0.5">
            <CalendarDays className="w-3 h-3" /> {layer.wear_count}× worn
          </span>
        )}
        {layer.last_worn && (
          <span className="text-[10px] text-muted-foreground font-body">last: {layer.last_worn}</span>
        )}
      </div>

      {/* Rating + Log */}
      <div className="flex items-center justify-between">
        <div className="flex gap-0.5">
          {[1, 2, 3, 4, 5].map((s) => (
            <button key={s} onClick={() => onRateUpdate(layer.rating === s ? 0 : s)}
              className="text-base transition-all"
              style={{ color: s <= (layer.rating || 0) ? pColor : "var(--border)" }}>{s <= (layer.rating || 0) ? "■" : "□"}</button>
          ))}
        </div>
        <Button size="sm" variant="outline" className="rounded-none font-body text-[10px] h-7 px-3 gap-1" onClick={onLogWear}>
          <CalendarDays className="w-3 h-3" /> Log Wear
        </Button>
      </div>
    </div>
  );
}
