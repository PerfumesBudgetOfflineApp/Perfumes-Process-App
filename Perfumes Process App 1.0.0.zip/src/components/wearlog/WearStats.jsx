import { useMemo } from "react";

export default function WearStats({ logs, perfumes }) {
  const stats = useMemo(() => {
    const counts = {};
    logs.forEach((l) => {
      const key = l.perfume_id;
      if (!counts[key]) counts[key] = { perfume_name: l.perfume_name, brand_name: l.brand_name, count: 0 };
      counts[key].count++;
    });
    return Object.values(counts).sort((a, b) => b.count - a.count);
  }, [logs]);

  const max = stats[0]?.count || 1;

  if (!stats.length)
    return <p className="text-xs text-muted-foreground font-body text-center py-4">لا سجل ارتداء بعد No wear history yet</p>;

  return (
    <div className="space-y-3">
      {stats.slice(0, 8).map((s, i) => (
        <div key={i} className="space-y-1">
          <div className="flex items-center justify-between">
            <div className="min-w-0 flex-1">
              <p className="text-xs font-body font-semibold truncate">{s.perfume_name}</p>
              <p className="text-[10px] text-muted-foreground font-body truncate">{s.brand_name}</p>
            </div>
            <span className="text-xs font-body font-bold text-primary ml-2 flex-shrink-0">
              {s.count}×
            </span>
          </div>
          <div className="h-1.5 bg-secondary rounded-none overflow-hidden">
            <div
              className="h-full bg-primary rounded-none transition-all duration-500"
              style={{ width: `${(s.count / max) * 100}%` }}
            />
          </div>
        </div>
      ))}
    </div>
  );
}