import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import PerfumePicker from "@/components/wearlog/PerfumePicker";

export default function EditLogDialog({ log, open, onOpenChange, perfumes, names }) {
  const [formData, setFormData] = useState({
    perfume_id: log?.perfume_id,
    perfume_name: log?.perfume_name,
    mood: log?.mood || "",
    note: log?.note || "",
  });
  const qc = useQueryClient();

  const updateMutation = useMutation({
    mutationFn: (data) => apphost.entities.WearLog.update(log.id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wear-logs"] });
      toast.success("تم التحديث");
      onOpenChange(false);
    },
  });

  const handleSave = () => {
    if (!formData.perfume_id) {
      toast.error("اختر عطراً");
      return;
    }
    updateMutation.mutate({
      perfume_id: formData.perfume_id,
      perfume_name: formData.perfume_name,
      mood: formData.mood || null,
      note: formData.note,
    });
  };

  const MOOD_OPTIONS = [
    { value: "amazing", emoji: "😍" },
    { value: "happy", emoji: "😊" },
    { value: "calm", emoji: "😌" },
    { value: "confident", emoji: "😎" },
    { value: "romantic", emoji: "💕" },
    { value: "sexy", emoji: "🔥" },
    { value: "sad", emoji: "😔" },
    { value: "energetic", emoji: "⚡" },
    { value: "thoughtful", emoji: "🤔" },
    { value: "relaxing", emoji: "😴" },
    { value: "unknown", emoji: "🤷" },
    { value: "neutral", emoji: "😑" },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-none">
        <DialogHeader>
          <DialogTitle className="font-heading text-base">تعديل السجل Edit Log</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <PerfumePicker
            perfumes={perfumes}
            selected={perfumes.find((p) => String(p.id) === String(formData.perfume_id))}
            onSelect={(p) => setFormData({ ...formData, perfume_id: p.id, perfume_name: p.name })}
          />
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">المزاج Mood</p>
            <div className="grid grid-cols-6 gap-1.5">
              {MOOD_OPTIONS.map(({ value, emoji }) => (
                <button
                  key={value}
                  onClick={() => setFormData({ ...formData, mood: formData.mood === value ? "" : value })}
                  className={`py-2 rounded-none text-lg transition-all ${
                    formData.mood === value
                      ? "bg-primary/10 border border-primary shadow-sm"
                      : "bg-secondary border border-border/50 hover:border-primary/30"
                  }`}
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>
          <Textarea
            value={formData.note}
            onChange={(e) => setFormData({ ...formData, note: e.target.value })}
            placeholder="ملاحظة... Note.."
            className="rounded-none font-body text-xs min-h-[60px] resize-none"
          />
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1 rounded-none font-body" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button className="flex-1 rounded-none font-body" onClick={handleSave} disabled={updateMutation.isPending}>
              {updateMutation.isPending ? "Saving.." : "Save"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}