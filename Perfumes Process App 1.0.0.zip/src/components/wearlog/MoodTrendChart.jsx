import { useMemo, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";

const MOOD_COLORS = {
  amazing: "hsl(340, 70%, 55%)",
  happy: "hsl(43, 90%, 55%)",
  calm: "hsl(120, 55%, 45%)",
  confident: "hsl(280, 55%, 55%)",
  romantic: "hsl(0, 70%, 60%)",
  sexy: "hsl(350, 80%, 50%)",
  sad: "hsl(197, 65%, 50%)",
  energetic: "hsl(27, 80%, 50%)",
  thoughtful: "hsl(240, 50%, 50%)",
  relaxing: "hsl(160, 70%, 45%)",
  neutral: "hsl(30, 20%, 50%)",
  unknown: "hsl(0, 0%, 60%)",
};

const MOODS = ["amazing", "happy", "calm", "confident", "romantic", "sexy", "sad", "energetic", "thoughtful", "relaxing", "neutral", "unknown"];

function ChartCard({ title, subtitle, children }) {
  return (
    <div className="bg-card rounded-none p-4 border border-border/60 space-y-3">
      <div>
        <h3 className="font-heading font-semibold text-sm">{title}</h3>
        {subtitle && <p className="text-[11px] text-muted-foreground font-body">{subtitle}</p>}
      </div>
      {children}
    </div>
  );
}

export default function MoodTrendChart({ logs, perfumes }) {
  const [groupBy, setGroupBy] = useState("brand");

  const data = useMemo(() => {
    if (logs.length === 0) return [];

    // Map perfume IDs to details
    const perfumeMap = {};
    perfumes.forEach((p) => {
      perfumeMap[p.id] = p;
    });

    // Group by brand or type
    const groups = {};
    logs.forEach((log) => {
      const perfume = perfumeMap[log.perfume_id];
      if (!perfume) return;

      const groupKey = groupBy === "brand" ? perfume.brand_name : perfume.type || "Unknown";
      if (!groups[groupKey]) {
        groups[groupKey] = {};
        MOODS.forEach((m) => {
          groups[groupKey][m] = 0;
        });
      }
      if (log.mood && groups[groupKey].hasOwnProperty(log.mood)) {
        groups[groupKey][log.mood]++;
      }
    });

    return Object.entries(groups).map(([name, moodCounts]) => ({
      name: name.length > 16 ? name.slice(0, 13) + ".." : name,
      ...moodCounts,
    }));
  }, [logs, perfumes, groupBy]);

  if (data.length === 0) {
    return (
      <ChartCard title="Mood Trends" subtitle={`Most frequent moods by ${groupBy}`}>
        <div className="py-6 text-center text-xs text-muted-foreground font-body">لا بيانات مزاج No mood data available</div>
      </ChartCard>
    );
  }

  return (
    <ChartCard title="Mood Trends" subtitle={`Most frequent moods by ${groupBy}`}>
      <div className="flex gap-2 mb-3">
        <button
          onClick={() => setGroupBy("brand")}
          className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
            groupBy === "brand"
              ? "bg-primary text-primary-foreground shadow"
              : "bg-secondary text-muted-foreground hover:text-foreground"
          }`}
        >
          By Brand
        </button>
        <button
          onClick={() => setGroupBy("type")}
          className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
            groupBy === "type"
              ? "bg-primary text-primary-foreground shadow"
              : "bg-secondary text-muted-foreground hover:text-foreground"
          }`}
        >
          By Type
        </button>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart
          data={data}
          margin={{ left: 0, right: 16, top: 4, bottom: 4 }}
          layout="vertical"
        >
          <XAxis type="number" tick={{ fontSize: 10, fontFamily: "var(--font-body)" }} allowDecimals={false} />
          <YAxis
            type="category"
            dataKey="name"
            width={100}
            tick={{ fontSize: 10, fontFamily: "var(--font-body)" }}
          />
          <Tooltip contentStyle={{ fontSize: 11, fontFamily: "var(--font-body)", borderRadius: 8, border: "1px solid hsl(var(--border))" }} />
          <Legend iconType="circle" iconSize={7} wrapperStyle={{ fontSize: 10, fontFamily: "var(--font-body)" }} />
          {MOODS.map((mood) => (
            <Bar key={mood} dataKey={mood} stackId="a" fill={MOOD_COLORS[mood]} name={mood} />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </ChartCard>
  );
}