import { useState } from "react";
import { ExternalLink } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { DEFAULT_MAIN_CATEGORIES, DEFAULT_SUB_CATEGORIES } from "@/lib/shopCategories";

export default function ShopCategoryManager({ isAr }) {
  const navigate = useNavigate();
  const [expanded, setExpanded] = useState(null);

  return (
    <div className="space-y-3 pb-10">
      <h2 className="text-sm font-body font-semibold text-muted-foreground uppercase tracking-wider py-2">
        {isAr ? "الأقسام الرئيسية" : "Main Categories"}
      </h2>

      <div className="grid grid-cols-4 gap-2">
        {DEFAULT_MAIN_CATEGORIES.map(cat => (
          <div key={cat.id} className="bg-[var(--page-bg,#fff)] border border-border/50 rounded-none overflow-hidden">
            <button
              onClick={() => { navigate(`/shop-category/${cat.id}`); }}
              className="flex flex-col items-center gap-1 p-2 w-full hover:bg-primary/5 transition-colors"
            >
              <span className="text-2xl">{cat.icon}</span>
              <p className="text-[10px] font-body font-medium text-center leading-tight w-full line-clamp-2">
                {isAr ? cat.name_ar : cat.name_en}
              </p>
              <span className="text-[9px] text-muted-foreground font-body rounded-none">
                {(DEFAULT_SUB_CATEGORIES[cat.id] || []).length} {isAr ? "فرعي" : "subs"}
              </span>
            </button>
          </div>
        ))}
      </div>

      {/* Subcategory explorer */}
      <h2 className="text-sm font-body font-semibold text-muted-foreground uppercase tracking-wider pt-3">
        {isAr ? "الأقسام الفرعية" : "Subcategories"}
      </h2>

      <div className="space-y-1.5">
        {DEFAULT_MAIN_CATEGORIES.map(cat => {
          const subs = DEFAULT_SUB_CATEGORIES[cat.id] || [];
          const isOpen = expanded === cat.id;
          return (
            <div key={cat.id} className="bg-[var(--page-bg,#fff)] border border-border/40 rounded-none overflow-hidden">
              <button
                onClick={() => setExpanded(isOpen ? null : cat.id)}
                className="w-full flex items-center gap-2 px-3 py-2.5 hover:bg-secondary/50 transition-colors"
              >
                <span>{cat.icon}</span>
                <span className="flex-1 text-left text-xs font-body font-semibold">
                  {isAr ? cat.name_ar : cat.name_en}
                </span>
                <span className="text-[9px] text-muted-foreground font-body rounded-none">
                  {subs.length}
                </span>
                <span className="text-muted-foreground text-xs">{isOpen ? "▲" : "▼"}</span>
              </button>
              {isOpen && (
                <div className="border-t border-border/30 px-3 py-2 space-y-1">
                  {subs.map(sub => (
                    <button
                      key={sub.id}
                      onClick={() => navigate(`/shop-category/${sub.id}`)}
                      className="w-full flex items-center gap-2 py-1 px-1.5 rounded-none hover:bg-secondary/50 transition-colors"
                    >
                      <div className="w-1.5 h-1.5 rounded-none flex-shrink-0" style={{ background: cat.color }} />
                      <span className="flex-1 text-left text-xs font-body">
                        {isAr ? sub.name_ar : sub.name_en}
                      </span>
                      <ExternalLink className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}