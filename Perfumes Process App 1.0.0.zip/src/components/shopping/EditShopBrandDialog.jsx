import { useState } from "react";
import { apphost } from "@/api/apphostClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Pin, Bookmark, Archive, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useBookmarks } from "@/hooks/useBookmarks";

const TYPE_OPTIONS = [
  { v: "perfume_store", en: "Perfume", ar: "عطور" },
  { v: "online_platform", en: "Online", ar: "أونلاين" },
  { v: "personal_store", en: "Personal", ar: "شخصي" },
  { v: "brand_only", en: "Brand", ar: "ماركة" },
];

// نافذة تعديل المتجر الموسّعة — مع تثبيت، دفتر (Bookmark)، مهملات (Cast away)،
// وحذف نهائي من داخل التعديل برسالة تأكيد. تعمل على كيان ShopBrand الموحّد.
export default function EditShopBrandDialog({ store, isAr, onClose, onSaved, onDeleted }) {
  const qc = useQueryClient();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: store.name || "",
    name_ar: store.name_ar || "",
    type: store.type || "perfume_store",
    category_name_en: store.category_name_en || "",
    category_name_ar: store.category_name_ar || "",
    website: store.website || "",
    logo_url: store.logo_url || "",
    country: store.country || "",
    description: store.description || "",
    pinned: !!store.pinned,
  });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const bookmarked = isBookmarked("store", store.id);

  // عدّة براندات لمتجر واحد: قائمة معرّفات براندات مرتبطة بهذا المتجر.
  const [linkedIds, setLinkedIds] = useState(
    (store.linked_brand_ids || "").split(",").map((s) => s.trim()).filter(Boolean)
  );
  const [brandSearch, setBrandSearch] = useState("");

  // المرتبطة تُجلب بمعرفاتها (getMany)؛ قائمة الـ٨٤٩٩ كاملة لا تُحمَّل إلا عند
  // أول كتابة في البحث (و تُخزَّن مؤقتاً).
  const { data: linkedBrands = [] } = useQuery({
    queryKey: ["brands-byid", linkedIds.join(",")],
    queryFn: () => apphost.entities.PerfumeBrand.getMany(linkedIds),
    enabled: linkedIds.length > 0,
    staleTime: 1000 * 60 * 5,
  });
  const { data: allBrands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
    staleTime: 1000 * 60 * 5,
    enabled: !!brandSearch.trim(),
  });
  const brandResults = brandSearch.trim()
    ? allBrands
        .filter((b) => !linkedIds.includes(String(b.id)) &&
          (((b.name || "").toLowerCase().includes(brandSearch.toLowerCase())) || (b.name_ar || "").includes(brandSearch)))
        .slice(0, 8)
    : [];
  const addBrand = (id) => { setLinkedIds((p) => [...p, String(id)]); setBrandSearch(""); };
  const removeBrand = (id) => setLinkedIds((p) => p.filter((x) => x !== String(id)));

  const save = async () => {
    if (!form.name.trim()) { toast.error(isAr ? "اسم المتجر مطلوب" : "Store name required"); return; }
    setSaving(true);
    try {
      await apphost.entities.ShopBrand.update(store.id, {
        name: form.name,
        name_ar: form.name_ar || "",
        type: form.type,
        category_name_en: form.category_name_en || null,
        category_name_ar: form.category_name_ar || null,
        website: form.website || null,
        logo_url: form.logo_url || null,
        country: form.country || "",
        description: form.description || null,
        pinned: !!form.pinned,
        linked_brand_ids: linkedIds.join(","),
      });
      await qc.invalidateQueries({ queryKey: ["shop-brands"] });
      toast.success(isAr ? "حُفظ المتجر" : "Store saved");
      onSaved?.();
      onClose?.();
    } catch {
      toast.error(isAr ? "تعذّر الحفظ" : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const castAway = async () => {
    if (!confirm(isAr ? "نقل هذا المتجر إلى المهملات؟ يمكن استرجاعه لاحقاً." : "Move this store to Cast Away? You can restore it later.")) return;
    try {
      await apphost.entities.ShopBrand.update(store.id, { hidden: true });
      await qc.invalidateQueries({ queryKey: ["shop-brands"] });
      toast.success(isAr ? "نُقل إلى المهملات" : "Moved to Cast Away");
      onSaved?.();
      onClose?.();
    } catch {
      toast.error(isAr ? "تعذّر النقل" : "Failed");
    }
  };

  const del = async () => {
    if (!confirm(isAr ? "حذف هذا المتجر نهائياً؟ لا يمكن التراجع." : "Delete this store permanently? This cannot be undone.")) return;
    try {
      await apphost.entities.ShopBrand.delete(store.id);
      await qc.invalidateQueries({ queryKey: ["shop-brands"] });
      toast.success(isAr ? "حُذف المتجر" : "Store deleted");
      onDeleted?.();
      onClose?.();
    } catch {
      toast.error(isAr ? "تعذّر الحذف" : "Delete failed");
    }
  };

  return (
    <Dialog open onOpenChange={(o) => { if (!o) onClose?.(); }}>
      <DialogContent className="max-w-sm w-[95vw] rounded-none max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading">{isAr ? "تعديل المتجر" : "Edit Store"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {/* إجراءات سريعة: تثبيت / دفتر / مهملات */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => set("pinned", !form.pinned)}
              className={cn(
                "flex flex-col items-center gap-1 py-2 rounded-none border text-[10px] font-body transition-colors",
                form.pinned ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"
              )}
            >
              <Pin className="w-4 h-4" /> {isAr ? "تثبيت" : "Pin"}
            </button>
            <button
              onClick={() => toggleBookmark({ item_type: "store", item_id: store.id, title_en: form.name, title_ar: form.name_ar, subtitle: isAr ? "متجر" : "Store", path: `/store?id=${store.id}` })}
              className={cn(
                "flex flex-col items-center gap-1 py-2 rounded-none border text-[10px] font-body transition-colors",
                bookmarked ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"
              )}
            >
              <Bookmark className={cn("w-4 h-4", bookmarked && "fill-current")} /> {isAr ? "دفتر" : "Notebook"}
            </button>
            <button
              onClick={castAway}
              className="flex flex-col items-center gap-1 py-2 rounded-none border border-border text-muted-foreground text-[10px] font-body hover:border-[var(--brand)] hover:text-[#2E7D32] transition-colors"
            >
              <Archive className="w-4 h-4" /> {isAr ? "مهملات" : "Cast away"}
            </button>
          </div>

          <Input placeholder={isAr ? "اسم المتجر *" : "Store name *"} value={form.name} onChange={(e) => set("name", e.target.value)} className="rounded-none h-10" />
          <Input placeholder={isAr ? "الاسم بالعربية" : "Arabic name"} value={form.name_ar} onChange={(e) => set("name_ar", e.target.value)} className="rounded-none h-10" dir="rtl" />

          <div className="grid grid-cols-4 gap-1.5">
            {TYPE_OPTIONS.map((o) => (
              <button
                key={o.v}
                onClick={() => set("type", o.v)}
                className={cn(
                  "py-1.5 rounded-none text-[10px] font-body border transition-colors",
                  form.type === o.v ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"
                )}
              >
                {isAr ? o.ar : o.en}
              </button>
            ))}
          </div>

          <Input placeholder={isAr ? "القسم (إنجليزي)" : "Category (EN)"} value={form.category_name_en} onChange={(e) => set("category_name_en", e.target.value)} className="rounded-none h-10" />
          <Input placeholder={isAr ? "القسم (عربي)" : "Category (AR)"} value={form.category_name_ar} onChange={(e) => set("category_name_ar", e.target.value)} className="rounded-none h-10" dir="rtl" />
          <Input placeholder={isAr ? "الموقع الإلكتروني" : "Website"} value={form.website} onChange={(e) => set("website", e.target.value)} className="rounded-none h-10" />
          <Input placeholder={isAr ? "رابط الشعار" : "Logo URL"} value={form.logo_url} onChange={(e) => set("logo_url", e.target.value)} className="rounded-none h-10 text-xs" />
          <Input placeholder={isAr ? "الدولة" : "Country"} value={form.country} onChange={(e) => set("country", e.target.value)} className="rounded-none h-10" />
          <textarea name="EditShopBrandDialog-tex1" placeholder={isAr ? "الوصف" : "Description"} value={form.description} onChange={(e) => set("description", e.target.value)} className="w-full rounded-none border border-border bg-background px-3 py-2 text-sm font-body min-h-[60px]" />

          {/* عدّة براندات لمتجر واحد */}
          <div className="space-y-1.5">
            <p className="text-[11px] font-body text-muted-foreground">{isAr ? "براندات المتجر" : "Store brands"}</p>
            {linkedBrands.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {linkedBrands.map((b) => (
                  <span key={b.id} className="inline-flex items-center gap-1 text-primary rounded-none text-[11px] font-body">
                    {isAr ? (b.name_ar || b.name) : b.name}
                    <button onClick={() => removeBrand(b.id)}><X className="w-3 h-3" /></button>
                  </span>
                ))}
              </div>
            )}
            <Input
              placeholder={isAr ? "ابحث وأضِف برانداً.." : "Search & add a brand.."}
              value={brandSearch}
              onChange={(e) => setBrandSearch(e.target.value)}
              className="rounded-none h-9 text-sm"
            />
            {brandResults.length > 0 && (
              <div className="border border-border rounded-none divide-y divide-border/40 max-h-40 overflow-y-auto">
                {brandResults.map((b) => (
                  <button key={b.id} onClick={() => addBrand(b.id)} className="w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary/50 transition-colors">
                    {isAr ? (b.name_ar || b.name) : b.name}
                  </button>
                ))}
              </div>
            )}
          </div>

          <Button className="w-full rounded-none h-10" onClick={save} disabled={saving}>
            {saving ? (isAr ? "جارٍ الحفظ.." : "Saving..") : (isAr ? "حفظ" : "Save")}
          </Button>

          {/* حذف من داخل التعديل برسالة تأكيد */}
          <Button variant="ghost" className="w-full rounded-none h-9 text-destructive hover:text-destructive font-body gap-2" onClick={del}>
            <Trash2 className="w-4 h-4" /> {isAr ? "حذف المتجر" : "Delete store"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
