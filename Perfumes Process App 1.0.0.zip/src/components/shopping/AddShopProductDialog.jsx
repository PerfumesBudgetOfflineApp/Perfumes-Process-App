import { useState, useMemo } from "react";
import { apphost } from "@/api/apphostClient";
import { useQuery } from "@tanstack/react-query";
import { searchPerfumeIds, normalizeSearch, searchIndexReady } from "@/lib/searchIndex";
import { rankName } from "@/lib/sortName";
import { X, Upload, Search, Square } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { usePersonNames } from "@/lib/usePersonNames";
import { useNumberEncryption } from "@/lib/useNumberEncryption";
import { useHistoryDismiss } from "@/lib/useHistoryDismiss";

const FREQUENCIES = [
  { value: "once", en: "One-time", ar: "مرة واحدة" },
  { value: "weekly", en: "Weekly", ar: "أسبوعي" },
  { value: "monthly", en: "Monthly", ar: "شهري" },
  { value: "yearly", en: "Yearly", ar: "سنوي" },
];

function StarRatingInput({ value, onChange }) {
  return (
    <div className="flex gap-1">
      {[1,2,3,4,5].map(n => (
        <button key={n} type="button" onClick={() => onChange(n)}>
          <Square className={`w-5 h-5 transition-colors ${n <= value ? "fill-[var(--brand)] text-[var(--brand)]" : "fill-none text-[var(--brand)]/30"}`} />
        </button>
      ))}
    </div>
  );
}

export default function AddShopProductDialog({ isAr, brands, categories, mainCategories, subCategories, onClose, onSaved, prefillBrandId }) {
  useHistoryDismiss(true, onClose);
  const { names } = usePersonNames();
  const { encryptNumbers } = useNumberEncryption();
  
  const PERSONS = useMemo(() => [
    { value: "person1", en: names?.person1 || "Profile A", ar: names?.person1 || "ملف أ" },
    { value: "person2", en: names?.person2 || "Profile B", ar: names?.person2 || "ملف ب" },
    { value: "family", en: "Family", ar: "العائلة" },
  ], [names]);

  const [form, setForm] = useState({
    name: "", name_ar: "", brand_id: prefillBrandId || "", brand_name: "",
    category_id: "", category_name_en: "", category_name_ar: "",
    subcategory_id: "", subcategory_name_en: "", subcategory_name_ar: "",
    description: "", description_ar: "", image_url: "", receipt_url: "",
    cost: "", recurring: false, recurring_frequency: "once", expiry_date: "", purchase_date: new Date().toISOString().slice(0,10),
    person: "family", linked_perfume_id: "", linked_perfume_name: "", purchase_type: "product", ml: "",
    rating: 0, quality_rating: 0, value_rating: 0, review: "", review_ar: "", repurchase: false,
    status: "active", notes: "", tags: "",
  });

  const [uploading, setUploading] = useState(false);
  const [uploadingReceipt, setUploadingReceipt] = useState(false);
  const [saving, setSaving] = useState(false);
  const [perfumeSearch, setPerfumeSearch] = useState("");
  const [showPerfumeList, setShowPerfumeList] = useState(false);
  const [brandSearch, setBrandSearch] = useState(brands?.find(b => String(b.id) === String(prefillBrandId))?.name || "");

  const selectedBrand = brands?.find(b => String(b.id) === String(form.brand_id));
  const isPerfumeStore = selectedBrand?.type === "perfume_store";
  const [showPerfumeLink, setShowPerfumeLink] = useState(isPerfumeStore);

  // بحث مفهرس عند الكتابة: نجلب مرشّحين قلائل عبر فهرس التوكنات (أو بادئة sort_key
  // إن لم يكتمل الفهرس) — بدل تحميل 130 ألفاً لقائمةٍ من 6 نتائج.
  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfume-pick", perfumeSearch],
    enabled: (showPerfumeLink || isPerfumeStore) && !!perfumeSearch.trim(),
    staleTime: 1000 * 60 * 5,
    queryFn: async () => {
      const term = perfumeSearch.trim();
      if (searchIndexReady()) {
        const { ids } = await searchPerfumeIds(term);
        if (!ids.length) return [];
        return await apphost.entities.Perfume.getMany(ids.slice(0, 30));
      }
      const t = normalizeSearch(term);
      const prefix = String(rankName(t)) + t;
      const { items } = await apphost.entities.Perfume.pageByIndexRange(
        "sort_key", { lower: prefix, upper: prefix + "\uffff" }, 0, 30, "next", false
      );
      return items || [];
    },
  });

  const update = (k, v) => setForm(p => ({ ...p, [k]: v }));

  const filteredBrands = useMemo(() => {
    if (!brandSearch) return (brands || []).slice(0, 5);
    return (brands || []).filter(b => b.name?.toLowerCase().includes(brandSearch.toLowerCase())).slice(0, 5);
  }, [brands, brandSearch]);

  const filteredPerfumes = useMemo(() => {
    if (!perfumeSearch) return [];
    const q = normalizeSearch(perfumeSearch);
    return perfumes.filter(p =>
      normalizeSearch([p.name_en, p.name_ar, p.name].filter(Boolean).join(" ")).includes(q)
    ).slice(0, 6);
  }, [perfumes, perfumeSearch]);

  const subs = useMemo(() => (subCategories || []).filter(s => s.parent_id === form.category_id), [subCategories, form.category_id]);

  const handleImg = async (e, field) => {
    try {
      const file = e.target.files?.[0];
      if (!file) return;
      
      if (field === "image_url") setUploading(true);
      else setUploadingReceipt(true);
      
      const { file_url } = await apphost.integrations.Core.UploadFile({ file });
      update(field, file_url);
    } catch (error) {
      console.error("Add product failed:", error);
      toast.error(isAr ? "⚠️ خطأ في رفع الملف" : "⚠️ Error uploading file");
      console.error("Upload error:", error);
    } finally {
      if (field === "image_url") setUploading(false);
      else setUploadingReceipt(false);
    }
  };

  const handleSave = async () => {
    console.log("🛒 handleSave clicked. form:", form);
    try {
      // ===== VALIDATION =====
      if (!form.name?.trim()) {
        console.warn("⚠️ name required");
        toast.error(isAr ? "⚠️ أدخل اسم المنتج" : "⚠️ Product name required");
        return;
      }
      if (!form.person) {
        console.warn("⚠️ person required");
        toast.error(isAr ? "⚠️ حدد لمن هذا المنتج" : "⚠️ Select who for (required)");
        return;
      }
      
      setSaving(true);

      let saveForm = { ...form };
      
      // If no category selected, use Uncategorized
      if (!saveForm.category_id) {
        const uncategorized = (mainCategories || []).find(c => c.name_en === "Other" || c.name_en === "Uncategorized");
        if (uncategorized) {
          saveForm.category_id = uncategorized.id;
          saveForm.category_name_en = uncategorized.name_en;
          saveForm.category_name_ar = uncategorized.name_ar;
        } else {
          saveForm.category_name_en = "Uncategorized";
          saveForm.category_name_ar = "غير مصنف";
        }
      }

      // Prepare data
      const saveData = {
        ...saveForm,
        cost: saveForm.cost ? Number(saveForm.cost) : 0,
        ml: saveForm.ml ? Number(saveForm.ml) : undefined,
        rating: saveForm.rating || 0,
        quality_rating: saveForm.quality_rating || 0,
        value_rating: saveForm.value_rating || 0,
        brand_name: saveForm.brand_name || undefined,
        linked_perfume_name: saveForm.linked_perfume_name || undefined,
        description: saveForm.description || undefined,
        description_ar: saveForm.description_ar || undefined,
        notes: saveForm.notes || undefined,
        tags: saveForm.tags || undefined,
        review: saveForm.review || undefined,
        review_ar: saveForm.review_ar || undefined,
      };

      // Save product
      console.log("🛒 Creating ShopProduct:", saveData);
      const createdProduct = await apphost.entities.ShopProduct.create(saveData);
      console.log("ShopProduct created:", createdProduct?.id);

      // Create budget expense if cost > 0
      if (saveData.cost > 0) {
        const budgetData = {
          date: saveData.purchase_date || new Date().toISOString().slice(0,10),
          amount: saveData.cost,
          category: saveData.linked_perfume_id ? "perfume" : "shopping",
          description: saveData.name,
          person: saveData.person,
          recurring: saveData.recurring,
          frequency: saveData.recurring_frequency,
          type: saveData.linked_perfume_id ? "luxury" : "essential",
        };
        if (saveData.linked_perfume_id) {
          budgetData.perfume_id = saveData.linked_perfume_id;
          budgetData.perfume_name = saveData.linked_perfume_name;
          console.log("💰 Budget linked to perfume:", saveData.linked_perfume_name);
        }
        await apphost.entities.BudgetExpense.create(budgetData);
      }

      toast.success(isAr ? "تمت الإضافة بنجاح" : "Product added!");
      onSaved();
    } catch (error) {
      console.error("Save error:", error);
      const msg = error?.message || error?.toString() || "Unknown error";
      toast.error(isAr ? `⚠️ ${msg}` : `⚠️ ${msg}`);
    } finally {
      setSaving(false);
    }
  };

  const setMainCat = (catId) => {
    const cat = (mainCategories || []).find(c => String(c.id) === String(catId));
    update("category_id", catId);
    update("category_name_en", cat?.name_en || "");
    update("category_name_ar", cat?.name_ar || "");
    update("subcategory_id", "");
    update("subcategory_name_en", "");
    update("subcategory_name_ar", "");
  };

  const setSubCat = (catId) => {
    const cat = (subCategories || []).find(c => String(c.id) === String(catId));
    update("subcategory_id", catId);
    update("subcategory_name_en", cat?.name_en || "");
    update("subcategory_name_ar", cat?.name_ar || "");
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-background w-full max-w-lg rounded-none max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className="sticky top-0 bg-background flex items-center justify-between px-5 py-4 border-b border-border z-10">
          <h2 className="font-heading text-lg font-bold">{isAr ? "إضافة منتج جديد" : "Add New Product"}</h2>
          <button onClick={onClose}><X className="w-5 h-5" /></button>
        </div>

        <div className="p-5 space-y-4">
          {/* Name */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الاسم (EN)" : "Name (EN)"} *</label>
              <Input value={form.name} onChange={e => update("name", e.target.value)} placeholder="اسم المنتج  Product name" className="rounded-none h-10 font-body mt-1" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">الاسم (AR)</label>
              <Input value={form.name_ar} onChange={e => update("name_ar", e.target.value)} placeholder="اسم المنتج" className="rounded-none h-10 font-body mt-1" dir="rtl" />
            </div>
          </div>

          {/* Cost & Date */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "التكلفة" : "Cost"}</label>
              <Input value={form.cost} onChange={e => update("cost", e.target.value)} type="number" placeholder="0.00" className="rounded-none h-10 font-body mt-1" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "تاريخ الشراء" : "Purchase Date"}</label>
              <Input value={form.purchase_date} onChange={e => update("purchase_date", e.target.value)} type="date" className="rounded-none h-10 font-body mt-1" />
            </div>
          </div>

          {/* Category */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "القسم الرئيسي" : "Main Category"}</label>
              <Select value={form.category_id} onValueChange={setMainCat}>
                <SelectTrigger className="rounded-none h-10 font-body mt-1">
                  <SelectValue placeholder={isAr ? "اختر.." : "Select.."} />
                </SelectTrigger>
                <SelectContent>
                  {(mainCategories || []).map(c => (
                    <SelectItem key={c.id} value={c.id}>{c.icon} {isAr ? c.name_ar : c.name_en}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الفرعي" : "Subcategory"}</label>
              {subs.length > 0 ? (
                <Select value={form.subcategory_id} onValueChange={setSubCat}>
                  <SelectTrigger className="rounded-none h-10 font-body mt-1">
                    <SelectValue placeholder={isAr ? "اختر.." : "Select.."} />
                  </SelectTrigger>
                  <SelectContent>
                    {subs.map(c => (
                      <SelectItem key={c.id} value={c.id}>{isAr ? c.name_ar : c.name_en}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <div className="rounded-none h-10 font-body mt-1 border border-dashed border-border flex items-center justify-center bg-secondary/30">
                  <span className="text-[9px] text-muted-foreground font-body">
                    {form.category_id ? (isAr ? "لا يوجد" : "None") : (isAr ? "اختر أولاً" : "Select first")}
                  </span>
                </div>
              )}
            </div>
          </div>

          {/* Person */}
          <div>
            <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "لمن؟" : "For whom?"} *</label>
            <div className="flex flex-wrap gap-2 mt-1">
              {PERSONS.map(p => (
                <button key={p.value} onClick={() => update("person", p.value)}
                  className={`flex-1 min-w-[60px] py-1.5 rounded-none text-xs font-body border transition-all ${form.person === p.value ? "bg-primary text-primary-foreground border-primary" : "bg-secondary border-border"}`}>
                  {isAr ? p.ar : p.en}
                </button>
              ))}
            </div>
          </div>

          {/* Brand */}
          <div>
            <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "المتجر / الشركة" : "Store / Brand"}</label>
            <div className="relative mt-1">
              <Input
                value={selectedBrand ? selectedBrand.name : brandSearch}
                onChange={e => {
                  setBrandSearch(e.target.value);
                  if (!e.target.value) {
                    update("brand_id", "");
                    update("brand_name", "");
                  }
                }}
                placeholder={isAr ? "اختر متجر.." : "Select store.."}
                className="rounded-none h-10 font-body"
              />
              {(brandSearch || !form.brand_id) && filteredBrands.length > 0 && (
                <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20 max-h-40 overflow-y-auto">
                  {filteredBrands.map(b => (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => {
                        update("brand_id", b.id);
                        update("brand_name", b.name);
                        setBrandSearch("");
                      }}
                      className="w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary border-b border-border/30 last:border-b-0"
                    >
                      {b.name}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Perfume link */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowPerfumeLink(p => !p)}
              className={`w-10 h-5 rounded-none transition-colors relative flex-shrink-0 ${showPerfumeLink ? "bg-purple-500" : "bg-border"}`}
            >
              <div className={`absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all ${showPerfumeLink ? "left-5" : "left-0.5"}`} />
            </button>
            <span className="text-sm font-body">🌸 {isAr ? "ربط بعطر" : "Link to Perfume"}</span>
          </div>

          {(showPerfumeLink || isPerfumeStore) && (
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "ربط عطر" : "Link Perfume"}</label>
              <div className="relative mt-1">
                <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
                <Input
                  value={form.linked_perfume_name || perfumeSearch}
                  onChange={e => {
                    setPerfumeSearch(e.target.value);
                    update("linked_perfume_id", "");
                    update("linked_perfume_name", "");
                    setShowPerfumeList(true);
                  }}
                  placeholder={isAr ? "ابحث.." : "Search.."}
                  className="pl-9 rounded-none h-10 font-body"
                />
                {form.linked_perfume_id && (
                  <button
                    onClick={() => {
                      update("linked_perfume_id", "");
                      update("linked_perfume_name", "");
                      setPerfumeSearch("");
                    }}
                    className="absolute right-3 top-2.5 text-muted-foreground"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
                {showPerfumeList && filteredPerfumes.length > 0 && (
                  <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20 max-h-40 overflow-y-auto">
                    {filteredPerfumes.map(p => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => {
                          update("linked_perfume_id", p.id);
                          update("linked_perfume_name", p.name_en || p.name);
                          setPerfumeSearch("");
                          setShowPerfumeList(false);
                        }}
                        className="w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary border-b border-border/30 last:border-b-0"
                      >
                        <span className="font-semibold">{p.name_en}</span>
                        {p.brand_name && <span className="text-xs text-muted-foreground ml-2">· {p.brand_name}</span>}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Recurring */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => update("recurring", !form.recurring)}
              className={`w-10 h-5 rounded-none transition-colors relative ${form.recurring ? "bg-primary" : "bg-border"}`}
            >
              <div className={`absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all ${form.recurring ? "left-5" : "left-0.5"}`} />
            </button>
            <span className="text-sm font-body">{isAr ? "متكرر" : "Recurring"}</span>
          </div>

          {form.recurring && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "التكرار" : "Frequency"}</label>
                <div className="flex flex-wrap gap-1 mt-1">
                  {FREQUENCIES.map(f => (
                    <button
                      key={f.value}
                      onClick={() => update("recurring_frequency", f.value)}
                      className={`px-3 py-1.5 rounded-none text-[10px] font-body transition-all ${form.recurring_frequency === f.value ? " bg-primary text-primary-foreground " : " bg-muted text-muted-foreground "}`}
                    >
                      {isAr ? f.ar : f.en}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الانتهاء" : "End Date"}</label>
                <Input value={form.expiry_date} onChange={e => update("expiry_date", e.target.value)} type="date" className="rounded-none h-10 font-body mt-1" />
              </div>
            </div>
          )}

          {/* Product Image */}
          <div>
            <p className="text-[9px] text-muted-foreground font-body uppercase mb-1">{isAr ? "صورة المنتج" : "Product Photo"}</p>
            <label className="w-full h-20 rounded-none bg-secondary flex flex-col items-center justify-center cursor-pointer overflow-hidden border-2 border-dashed border-border hover:border-primary/50 transition-colors">
              {uploading ? (
                <div className="w-4 h-4 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
              ) : form.image_url ? (
                <img src={form.image_url} className="w-full h-full object-cover" />
              ) : (
                <>
                  <Upload className="w-5 h-5 text-muted-foreground" />
                  <span className="text-[9px] text-muted-foreground mt-1">{isAr ? "ارفع صورة" : "Upload"}</span>
                </>
              )}
              <input type="file" accept="image/*" className="hidden" onChange={e => handleImg(e, "image_url")} />
            </label>
          </div>

          {/* Receipt */}
          <div>
            <p className="text-[9px] text-muted-foreground font-body uppercase mb-1">{isAr ? "الفاتورة" : "Invoice / Receipt"}</p>
            <label className="w-full h-20 rounded-none bg-[#FAF5EC] dark:bg-[#7a6418]/20 flex flex-col items-center justify-center cursor-pointer overflow-hidden border-2 border-dashed border-[var(--brand)]/40 dark:border-[#2E7D32] hover:border-[var(--brand)] transition-colors">
              {uploadingReceipt ? (
                <div className="w-4 h-4 border-2 border-[var(--brand)]/30 border-t-[var(--brand)] rounded-full animate-spin" />
              ) : form.receipt_url ? (
                <img src={form.receipt_url} className="w-full h-full object-cover" />
              ) : (
                <>
                  <Upload className="w-5 h-5 text-[var(--brand)]" />
                  <span className="text-[9px] text-[#2E7D32] dark:text-[var(--brand)] mt-1 font-body font-semibold">{isAr ? "فاتورة" : "Invoice"}</span>
                </>
              )}
              <input type="file" accept="image/*,application/pdf" className="hidden" onChange={e => handleImg(e, "receipt_url")} />
            </label>
          </div>

          {/* Notes & Tags */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "ملاحظات" : "Notes"}</label>
              <Input value={form.notes} onChange={e => update("notes", e.target.value)} placeholder=".." className="rounded-none h-10 font-body mt-1" />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "علامات" : "Tags"}</label>
              <Input value={form.tags} onChange={e => update("tags", e.target.value)} placeholder=".." className="rounded-none h-10 font-body mt-1" />
            </div>
          </div>

          {/* Ratings */}
          <div className="space-y-2">
            <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "التقييم" : "Ratings"}</label>
            {[
              { key: "rating", en: "Overall", ar: "عام" },
              { key: "quality_rating", en: "Quality", ar: "الجودة" },
              { key: "value_rating", en: "Value", ar: "القيمة" },
            ].map(({ key, en, ar }) => (
              <div key={key} className="flex items-center justify-between gap-3">
                <span className="text-xs font-body">{isAr ? ar : en}</span>
                <StarRatingInput value={form[key]} onChange={v => update(key, v)} />
              </div>
            ))}
          </div>

          {/* Save Button */}
          <Button className="w-full h-11 rounded-none font-body" onClick={handleSave} disabled={saving}>
            {saving ? (isAr ? "جاري الحفظ.." : "Saving..") : (isAr ? "إضافة المنتج" : "Add Product")}
          </Button>

          <div className="h-6" />
        </div>
      </div>
    </div>
  );
}