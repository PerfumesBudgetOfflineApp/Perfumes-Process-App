import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line, CartesianGrid } from "recharts";

const COLORS = ["#8b5cf6","#ec4899","#f59e0b","#10b981","#6366f1","#0ea5e9","#f43f5e","#84cc16","#fb923c","#a855f7","#38bdf8","#fbbf24","#fb7185","#94a3b8"];

function Section({ title, children }) {
  return (
    <div className="bg-card border border-border/50 rounded-none p-4 space-y-3">
      <h3 className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wider">{title}</h3>
      {children}
    </div>
  );
}

// Safe cost extraction
function safeCost(p) {
  const c = p?.cost;
  if (typeof c === 'number') return isFinite(c) ? c : 0;
  if (typeof c === 'string') {
    const n = parseFloat(c);
    return isFinite(n) ? n : 0;
  }
  return 0;
}

export default function ShopAnalytics({ products = [], brands = [], categories = [], isAr, currency = "USD", names = {} }) {
  const safeProducts = useMemo(() => {
    return (products || []).map(p => ({
      ...p,
      cost: safeCost(p),
      rating: typeof p?.rating === 'number' ? p.rating : 0,
    }));
  }, [products]);

  const mainCats = useMemo(() => (categories || []).filter(c => !c.parent_id), [categories]);

  const byMonth = useMemo(() => {
    try {
      const map = {};
      safeProducts.forEach(p => {
        if (!p.purchase_date) return;
        const key = String(p.purchase_date).slice(0, 7);
        map[key] = (map[key] || 0) + p.cost;
      });
      return Object.entries(map).sort((a, b) => a[0].localeCompare(b[0])).slice(-12).map(([k, v]) => ({ month: k.slice(5), amount: Math.round(v) }));
    } catch { return []; }
  }, [safeProducts]);

  const byDay = useMemo(() => {
    try {
      const days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
      const daysAr = ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
      const map = Array(7).fill(0);
      safeProducts.forEach(p => {
        if (!p.purchase_date) return;
        const d = new Date(p.purchase_date).getDay();
        if (!isNaN(d)) map[d] += p.cost;
      });
      return map.map((v, i) => ({ day: isAr ? daysAr[i] : days[i], amount: Math.round(v) }));
    } catch { return []; }
  }, [safeProducts, isAr]);

  const byCategory = useMemo(() => {
    try {
      const map = {};
      safeProducts.forEach(p => {
        const cat = mainCats.find(c => String(c.id) === String(p.category_id));
        const key = cat ? (isAr ? (cat.name_ar || cat.name_en) : cat.name_en) : (isAr ? "غير مصنف" : "Uncategorized");
        map[key] = (map[key] || 0) + p.cost;
      });
      return Object.entries(map).sort((a, b) => b[1] - a[1]).map(([name, value]) => ({ name, value: Math.round(value) }));
    } catch { return []; }
  }, [safeProducts, mainCats, isAr]);

  const byPerson = useMemo(() => {
    try {
      const map = {};
      safeProducts.forEach(p => {
        const key = names?.[p.person] || p.person || (isAr ? "غير محدد" : "Unknown");
        map[key] = (map[key] || 0) + p.cost;
      });
      return Object.entries(map).map(([name, value]) => ({ name, value: Math.round(value) }));
    } catch { return []; }
  }, [safeProducts, names, isAr]);

  const topBrands = useMemo(() => {
    try {
      const map = {};
      safeProducts.forEach(p => {
        if (!p.brand_name) return;
        map[p.brand_name] = (map[p.brand_name] || 0) + p.cost;
      });
      return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, value]) => ({ name, value: Math.round(value) }));
    } catch { return []; }
  }, [safeProducts]);

  const topRated = useMemo(() => {
    try {
      return safeProducts.filter(p => p.rating >= 4).sort((a, b) => b.rating - a.rating).slice(0, 5);
    } catch { return []; }
  }, [safeProducts]);

  const total = useMemo(() => safeProducts.reduce((s, p) => s + p.cost, 0), [safeProducts]);
  const avgCost = safeProducts.length > 0 ? Math.round(total / safeProducts.length) : 0;
  const recurring = useMemo(() => safeProducts.filter(p => p.recurring), [safeProducts]);
  const recurringTotal = useMemo(() => recurring.reduce((s, p) => s + p.cost, 0), [recurring]);

  const chartTooltipStyle = { backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 11, fontFamily: "var(--font-body)" };

  if (!safeProducts.length) {
    return (
      <div className="bg-card border border-border/50 rounded-none p-8 text-center">
        <div className="text-5xl mb-3">📊</div>
        <p className="font-body text-muted-foreground">
          {isAr ? "لا توجد بيانات بعد. أضف منتجات أولاً." : "No data yet. Add products first."}
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-10">
      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-gradient-to-br from-violet-500/10 to-fuchsia-500/10 border border-violet-300/30 rounded-none p-3">
          <p className="text-xs font-body text-muted-foreground">{isAr ? "الإجمالي" : "Total"}</p>
          <p className="text-xl font-heading font-bold text-violet-600">{Math.round(total)} {currency}</p>
        </div>
        <div className="bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-300/30 rounded-none p-3">
          <p className="text-xs font-body text-muted-foreground">{isAr ? "متوسط/منتج" : "Avg / Item"}</p>
          <p className="text-xl font-heading font-bold text-emerald-600">{avgCost} {currency}</p>
        </div>
        <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-300/30 rounded-none p-3">
          <p className="text-xs font-body text-muted-foreground">{isAr ? "عدد المنتجات" : "Items"}</p>
          <p className="text-xl font-heading font-bold text-amber-600">{safeProducts.length}</p>
        </div>
        <div className="bg-gradient-to-br from-rose-500/10 to-pink-500/10 border border-rose-300/30 rounded-none p-3">
          <p className="text-xs font-body text-muted-foreground">{isAr ? "متكرر شهرياً" : "Recurring"}</p>
          <p className="text-xl font-heading font-bold text-rose-600">{Math.round(recurringTotal)} {currency}</p>
        </div>
      </div>

      {byCategory.length > 0 && (
        <Section title={isAr ? "الإنفاق حسب الفئة" : "Spending by Category"}>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={byCategory} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={60} label={(e) => `${e.value}`}>
                {byCategory.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={chartTooltipStyle} formatter={v => [`${v} ${currency}`, ""]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1">
            {byCategory.map((c, i) => (
              <div key={c.name} className="flex items-center gap-2 text-xs font-body">
                <span className="w-2 h-2 rounded-none" style={{ background: COLORS[i % COLORS.length] }} />
                <span className="flex-1 truncate">{c.name}</span>
                <span className="font-bold">{c.value} {currency}</span>
              </div>
            ))}
          </div>
        </Section>
      )}

      {byMonth.length > 0 && (
        <Section title={isAr ? "الإنفاق الشهري" : "Monthly Spending"}>
          <ResponsiveContainer width="100%" height={140}>
            <LineChart data={byMonth}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.5} />
              <XAxis dataKey="month" tick={{ fontSize: 9, fontFamily: "var(--font-body)" }} />
              <YAxis tick={{ fontSize: 8 }} width={30} />
              <Tooltip contentStyle={chartTooltipStyle} formatter={v => [`${v} ${currency}`, ""]} />
              <Line type="monotone" dataKey="amount" stroke="#8b5cf6" strokeWidth={2} dot={{ r: 3, fill: "#8b5cf6" }} />
            </LineChart>
          </ResponsiveContainer>
        </Section>
      )}

      {byDay.some(d => d.amount > 0) && (
        <Section title={isAr ? "أيام الأسبوع الأكثر إنفاقاً" : "Spending by Day"}>
          <ResponsiveContainer width="100%" height={120}>
            <BarChart data={byDay} barSize={24}>
              <XAxis dataKey="day" tick={{ fontSize: 9, fontFamily: "var(--font-body)" }} />
              <YAxis tick={{ fontSize: 8 }} width={30} />
              <Tooltip contentStyle={chartTooltipStyle} formatter={v => [`${v} ${currency}`, ""]} />
              <Bar dataKey="amount" radius={[4,4,0,0]}>
                {byDay.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Section>
      )}

      {byPerson.length > 1 && (
        <Section title={isAr ? "الإنفاق حسب الشخص" : "By Person"}>
          <div className="space-y-2">
            {byPerson.map((p, i) => {
              const pct = total > 0 ? ((p.value / total) * 100).toFixed(0) : 0;
              return (
                <div key={p.name}>
                  <div className="flex justify-between text-xs font-body mb-1">
                    <span>{p.name}</span>
                    <span className="font-bold">{p.value} {currency} <span className="text-muted-foreground">({pct}%)</span></span>
                  </div>
                  <div className="h-2 bg-secondary rounded-none overflow-hidden">
                    <div className="h-full rounded-none" style={{ width: `${pct}%`, background: COLORS[i % COLORS.length] }} />
                  </div>
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {topBrands.length > 0 && (
        <Section title={isAr ? "أكثر المتاجر إنفاقاً" : "Top Stores by Spending"}>
          <div className="space-y-2">
            {topBrands.map((b, i) => {
              const pct = topBrands[0].value > 0 ? ((b.value / topBrands[0].value) * 100).toFixed(0) : 0;
              return (
                <div key={b.name} className="flex items-center gap-2">
                  <span className="text-[10px] text-muted-foreground font-body w-4">{i + 1}</span>
                  <div className="flex-1 h-1.5 bg-secondary rounded-none overflow-hidden">
                    <div className="h-full rounded-none" style={{ width: `${pct}%`, background: COLORS[i % COLORS.length] }} />
                  </div>
                  <span className="text-[10px] font-body truncate max-w-[80px]">{b.name}</span>
                  <span className="text-[10px] font-bold font-body text-primary flex-shrink-0">{b.value} {currency}</span>
                </div>
              );
            })}
          </div>
        </Section>
      )}

      {topRated.length > 0 && (
        <Section title={isAr ? "أعلى المنتجات تقييماً" : "Top Rated Products"}>
          <div className="space-y-2">
            {topRated.map(p => (
              <div key={p.id} className="flex items-center gap-2">
                {p.image_url && <img src={p.image_url} className="w-8 h-8 rounded-none object-cover flex-shrink-0" alt="" />}
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-body font-semibold truncate">{isAr ? (p.name_ar || p.name) : p.name}</p>
                  <p className="text-[9px] text-muted-foreground">{p.brand_name}</p>
                </div>
                <div className="flex gap-0.5">
                  {Array.from({length:5}).map((_, i) => <span key={i} className="text-xs" style={{ color: "var(--brand)" }}>{i < p.rating ? "■" : "□"}</span>)}
                </div>
              </div>
            ))}
          </div>
        </Section>
      )}
    </div>
  );
}
