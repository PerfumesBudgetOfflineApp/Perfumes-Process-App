import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Store, Globe, Square, Package, ChevronRight, Edit2, Pin } from "lucide-react";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import AddShopProductDialog from "./AddShopProductDialog";
import EditShopBrandDialog from "./EditShopBrandDialog";
import { openExternalUrl } from "@/lib/exportHelper";

const TYPE_COLORS = {
  perfume_store: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-300",
  shopping_store: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  online_platform: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300",
  brand_only: "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
  personal_store: "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300",
};
const TYPE_LABELS = {
  perfume_store: { en: "Perfume", ar: "عطور" },
  shopping_store: { en: "Shopping", ar: "تسوق" },
  online_platform: { en: "Online", ar: "أونلاين" },
  brand_only: { en: "Brand", ar: "ماركة" },
  personal_store: { en: "Personal", ar: "شخصي" },
};

export default function ShopBrandList({ brands, search, isAr, names, currency, mainCategories, products, viewMode, onRefresh }) {
  const [addProductFor, setAddProductFor] = useState(null);
  const [expanded, setExpanded] = useState({});
  const [editStore, setEditStore] = useState(null);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  // أخفِ المتاجر المنقولة للمهملات (hidden)، ورتّب المثبّت (pinned) أولاً.
  const filtered = brands
    .filter((b) => !b.hidden)
    .filter((b) => !search || b.name?.toLowerCase().includes(search.toLowerCase()) || b.name_ar?.includes(search))
    .sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0));

  // ترقيم: ٥٠ براند/صفحة (قسم العطور قد يضمّ آلاف البراندات تلقائياً → تفادي البطء)
  const PAGE_SIZE = 50;
  const [page, setPage] = useState(1);
  useEffect(() => { setPage(1); }, [search]);
  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pageCount);
  const paged = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  const getBrandProducts = (brandId) => products.filter(p => p.brand_id === brandId);
  const getBrandTotal = (brandId) => getBrandProducts(brandId).reduce((s, p) => s + (p.cost || 0), 0);

  if (filtered.length === 0) return (
    <div className="text-center py-16">
      <Store className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
      <p className="text-sm text-muted-foreground font-body">{isAr ? "لا يوجد متاجر بعد" : "No stores yet"}</p>
    </div>
  );

  return (
    <div className="divide-y divide-border/40 pb-10">
      {paged.map(brand => {
        const brandProducts = getBrandProducts(brand.id);
        const total = getBrandTotal(brand.id);
        const isExpanded = expanded[brand.id];
        const typeLabel = TYPE_LABELS[brand.type];

        return (
          <div key={brand.id} className="transition-colors">{/* بلا صندوق — قائمة مسطورة */}
            {/* Brand Header */}
            <div className="p-4">
              <div className="flex items-start gap-3">
                {brand.logo_url ? (
                  <img src={brand.logo_url} alt={brand.name} className="w-12 h-12 rounded-none object-cover flex-shrink-0" />
                ) : (
                  <div className="w-12 h-12 rounded-none bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center flex-shrink-0">
                    <Store className="w-5 h-5 text-primary/60" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-heading font-bold text-base flex items-center gap-1">
                        {brand.pinned && <Pin className="w-3 h-3 text-primary fill-primary" />}{brand.name}
                      </h3>
                      {brand.name_ar && <p className="text-xs text-muted-foreground font-body" dir="rtl">{brand.name_ar}</p>}
                    </div>
                    <div className="flex gap-1 flex-shrink-0 items-center">
                      <button onClick={() => setAddProductFor(brand)}
                        className=" text-primary rounded-none transition-colors text-[10px] font-body font-bold whitespace-nowrap">
                        {isAr ? "إضافة" : "Add"}
                      </button>
                      <button onClick={() => setEditStore(brand)} className="p-1.5 text-muted-foreground hover:bg-secondary rounded-none transition-colors">
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
                    {brand.type && (
                      <span className={`text-[9px] font-body font-bold rounded-none ${TYPE_COLORS[brand.type] || " text-muted-foreground"}`}>
                        {isAr ? typeLabel?.ar : typeLabel?.en}
                      </span>
                    )}
                    {brand.category_name_en && (
                      <span className="text-[9px] font-body text-muted-foreground rounded-none">
                        {isAr ? brand.category_name_ar : brand.category_name_en}
                      </span>
                    )}
                    {brand.is_online && (
                      <span className="text-[9px] font-body text-emerald-600 rounded-none">🌐 Online</span>
                    )}
                    {brand.rating > 0 && (
                      <span className="text-[9px] font-body text-[var(--brand)] flex items-center gap-0.5">
                        <Square className="w-3 h-3 fill-[var(--brand)] text-[var(--brand)]" /> {brand.rating}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {brand.description && (
                <p className="text-xs text-muted-foreground font-body mt-2 leading-relaxed">{isAr ? (brand.description_ar || brand.description) : brand.description}</p>
              )}

              <div className="flex items-center justify-between mt-3 pt-2 border-t border-border/40">
                <div className="flex gap-4">
                  <div>
                    <p className="text-[9px] text-muted-foreground font-body">{isAr ? "الإجمالي" : "Total Spent"}</p>
                    <p className="text-sm font-bold text-primary">{total.toFixed(0)} {currency}</p>
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground font-body">{isAr ? "منتجات" : "Products"}</p>
                    <p className="text-sm font-bold">{brandProducts.length}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {brand.website && (
                    <button type="button" onClick={(e) => { e.preventDefault(); openExternalUrl(brand.website); }}className="p-1.5 text-muted-foreground hover:text-primary">
                      <Globe className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {brandProducts.length > 0 && (
                    <button onClick={() => setExpanded(e => ({ ...e, [brand.id]: !e[brand.id] }))}
                      className="flex items-center gap-1 text-[10px] text-muted-foreground font-body hover:text-foreground transition-colors">
                      <Package className="w-3.5 h-3.5" />
                      <ChevronRight className={cn("w-3 h-3 transition-transform", isExpanded && "rotate-90")} />
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Products Expanded */}
            {isExpanded && brandProducts.length > 0 && (
              <div className="border-t border-border/30 bg-secondary/20 divide-y divide-border/20">
                {brandProducts.map(p => (
                  <button key={p.id} onClick={() => navigate(`/shop-product?id=${p.id}`)} className="px-4 py-2.5 flex items-center gap-3 w-full hover:bg-secondary/40 transition-colors text-left">
                    {p.image_url && <img src={p.image_url} className="w-8 h-8 rounded-none object-cover flex-shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-body font-semibold truncate">{p.name}</p>
                      <p className="text-[9px] text-muted-foreground font-body">
                        {p.subcategory_name_en || p.category_name_en}
                        {p.purchase_date && ` · ${p.purchase_date}`}
                      </p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <p className="text-xs font-bold text-primary">{(p.cost || 0).toFixed(0)} {currency}</p>
                      {p.rating > 0 && (
                        <p className="text-[9px]" style={{ color: "var(--brand)" }}>{"■".repeat(p.rating)}{"□".repeat(Math.max(0, 5 - p.rating))}</p>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        );
      })}

      {filtered.length > PAGE_SIZE && (
        <div className="flex items-center justify-center gap-4 pt-3">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={safePage <= 1}
            className="text-xs font-body text-primary disabled:opacity-30 disabled:cursor-default rounded-none transition-colors"
          >
            {isAr ? "السابق" : "Prev"}
          </button>
          <span className="text-xs text-muted-foreground font-body">
            {safePage} / {pageCount}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(pageCount, p + 1))}
            disabled={safePage >= pageCount}
            className="text-xs font-body text-primary disabled:opacity-30 disabled:cursor-default rounded-none transition-colors"
          >
            {isAr ? "التالي" : "Next"}
          </button>
        </div>
      )}

      {addProductFor && (
        <AddShopProductDialog
          isAr={isAr}
          brands={[addProductFor]}
          categories={[]}
          mainCategories={[]}
          subCategories={[]}
          prefillBrandId={addProductFor.id}
          onClose={() => setAddProductFor(null)}
          onSaved={() => {
            setAddProductFor(null);
            queryClient.invalidateQueries({ queryKey: ["shop-products"] });
            queryClient.invalidateQueries({ queryKey: ["shop-brands"] });
          }} />
      )}

      {editStore && (
        <EditShopBrandDialog
          store={editStore}
          isAr={isAr}
          onClose={() => setEditStore(null)}
          onSaved={() => { setEditStore(null); onRefresh(); }}
          onDeleted={() => { setEditStore(null); onRefresh(); }}
        />
      )}
    </div>
  );
}