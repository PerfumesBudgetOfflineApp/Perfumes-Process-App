import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const COLORS = [
  "hsl(36,60%,42%)", "hsl(36,55%,55%)", "hsl(36,45%,65%)",
  "hsl(20,50%,55%)", "hsl(20,40%,65%)", "hsl(30,35%,70%)",
  "hsl(45,60%,55%)", "hsl(15,55%,55%)",
];

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-none px-3 py-2 shadow-lg">
      <p className="text-xs font-body font-semibold">{payload[0].payload.name}</p>
      <p className="text-xs text-muted-foreground font-body">{payload[0].value} perfume{payload[0].value !== 1 ? "s" : ""}</p>
    </div>
  );
};

export default function BrandChart({ perfumes }) {
  const brandCounts = perfumes.reduce((acc, p) => {
    if (p.brand_name) acc[p.brand_name] = (acc[p.brand_name] || 0) + 1;
    return acc;
  }, {});

  const data = Object.entries(brandCounts)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  if (!data.length) return <EmptyChart />;

  return (
    <ResponsiveContainer width="100%" height={200}>
      <BarChart data={data} margin={{ top: 4, right: 4, left: -24, bottom: 40 }}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(30,15%,88%)" />
        <XAxis
          dataKey="name"
          tick={{ fontSize: 10, fontFamily: "var(--font-body)", fill: "hsl(20,8%,50%)" }}
          angle={-35}
          textAnchor="end"
          interval={0}
          tickLine={false}
          axisLine={false}
        />
        <YAxis tick={{ fontSize: 10, fontFamily: "var(--font-body)", fill: "hsl(20,8%,50%)" }} tickLine={false} axisLine={false} allowDecimals={false} />
        <Tooltip content={<CustomTooltip />} cursor={{ fill: "hsl(30,20%,96%)" }} />
        <Bar dataKey="count" radius={[6, 6, 0, 0]}>
          {data.map((_, i) => (
            <Cell key={i} fill={COLORS[i % COLORS.length]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}

function EmptyChart() {
  return <div className="h-[200px] flex items-center justify-center text-xs text-muted-foreground font-body">لا بيانات بعد No data yet</div>;
}