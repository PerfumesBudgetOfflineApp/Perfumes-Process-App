const LIST_CONFIG = {
  favorite: { label: "Favorites", color: "bg-red-400" },
  own: { label: "Own", color: "bg-emerald-400" },
  recommend: { label: "Recommend", color: "bg-amber-400" },
  wishlist: { label: "Wishlist", color: "bg-blue-400" },
  dislike: { label: "Dislike", color: "bg-slate-400" },
  none: { label: "Uncategorized", color: "bg-border" },
};

export default function ListDistribution({ perfumes }) {
  const total = perfumes.length;
  if (!total) return <div className="text-xs text-muted-foreground font-body text-center py-4">لا بيانات بعد No data yet</div>;

  const counts = perfumes.reduce((acc, p) => {
    const key = p.list || "none";
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});

  const items = Object.entries(LIST_CONFIG)
    .map(([key, config]) => ({ key, ...config, count: counts[key] || 0 }))
    .filter((item) => item.count > 0);

  return (
    <div className="space-y-3">
      {/* Stacked bar */}
      <div className="flex h-3 rounded-none overflow-hidden gap-0.5">
        {items.map((item) => (
          <div
            key={item.key}
            className={`${item.color} transition-all duration-500`}
            style={{ width: `${(item.count / total) * 100}%` }}
          />
        ))}
      </div>
      {/* Legend rows */}
      <div className="space-y-2">
        {items.map((item) => (
          <div key={item.key} className="flex items-center gap-2">
            <div className={`w-2.5 h-2.5 rounded-none flex-shrink-0 ${item.color}`} />
            <span className="text-xs font-body flex-1 text-foreground/80">{item.label}</span>
            <span className="text-xs font-body font-medium">{item.count}</span>
            <span className="text-[10px] text-muted-foreground font-body w-8 text-right">
              {Math.round((item.count / total) * 100)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}