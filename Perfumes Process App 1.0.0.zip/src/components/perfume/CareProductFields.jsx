import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X, Search } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { CARE_MATERIALS, STATUS_COLOR, STATUS_LABEL } from "@/lib/careMaterials";
import { computeCareSafety, CARE_STATUS_COLOR, CARE_STATUS_LABEL } from "@/lib/careSafety";

// CareProductFields — الحقول المخصّصة لمنتج العناية داخل صفحة إضافة العطر.
// تُخزَّن كلها في form.care_profile. تعرض شارة سلامة التركيب حيّةً عبر computeCareSafety.
export default function CareProductFields({ form, setForm }) {
  const { isAr } = useLang();
  const cp = form.care_profile || {};
  const setCP = (patch) => setForm((prev) => ({ ...prev, care_profile: { ...(prev.care_profile || {}), ...patch } }));

  const composition = Array.isArray(cp.composition) ? cp.composition : [];
  const [matSearch, setMatSearch] = useState("");

  const safety = useMemo(() => computeCareSafety(composition), [composition]);
  const sColor = CARE_STATUS_COLOR[safety.status];
  const sLab = CARE_STATUS_LABEL[safety.status];

  const selectedKeys = new Set(composition.map((c) => c.key));
  const matches = useMemo(() => {
    const q = matSearch.trim().toLowerCase();
    if (!q) return [];
    return CARE_MATERIALS.filter(
      (m) => !selectedKeys.has(m.id) && [m.ar, m.en, m.inci].some((v) => String(v || "").toLowerCase().includes(q))
    ).slice(0, 8);
  }, [matSearch, composition]);

  const addMat = (m) => { setCP({ composition: [...composition, { key: m.id, pct: "" }] }); setMatSearch(""); };
  const removeMat = (key) => setCP({ composition: composition.filter((c) => c.key !== key) });
  const setPct = (key, pct) => setCP({ composition: composition.map((c) => (c.key === key ? { ...c, pct } : c)) });

  const PRODUCT_CLASSES = [
    { v: "skincare", ar: "عناية بالبشرة", en: "Skincare" },
    { v: "cream", ar: "كريم", en: "Cream" },
    { v: "ambient", ar: "معطّر جوّ", en: "Air freshener" },
  ];
  const AGES = [
    { v: "baby", ar: "رضّع", en: "Babies" },
    { v: "child", ar: "أطفال", en: "Children" },
    { v: "adult", ar: "بالغون", en: "Adults" },
    { v: "all", ar: "كل الأعمار", en: "All ages" },
  ];
  const APPS = [
    { v: "leave_on", ar: "يبقى على البشرة", en: "Leave-on" },
    { v: "rinse_off", ar: "يُغسل", en: "Rinse-off" },
    { v: "ambient", ar: "هواء", en: "Ambient air" },
  ];
  const ages = Array.isArray(cp.target_age) ? cp.target_age : [];
  const toggleAge = (v) => setCP({ target_age: ages.includes(v) ? ages.filter((a) => a !== v) : [...ages, v] });

  const Pill = ({ active, onClick, children }) => (
    <button type="button" onClick={onClick}
      className="px-3 py-1.5 text-xs font-body rounded-none border transition-colors"
      style={active ? { borderColor: "var(--brand)", background: "var(--brand)", color: "#fff" } : { borderColor: "#e2dccd", color: "var(--mut,#6B6760)" }}>
      {children}
    </button>
  );

  return (
    <div className="space-y-4 rounded-none border p-4" style={{ borderColor: "#D7DEEC", background: "#F6F8FC" }}>
      <Label className="text-xs font-body font-semibold uppercase tracking-wider" style={{ color: "#3A4A7A" }}>
        🧴 منتج عناية Care Product
      </Label>

      {/* فئة المنتج */}
      <div className="space-y-1.5">
        <p className="text-[10px] font-body font-semibold text-foreground">{isAr ? "الفئة" : "Product class"}</p>
        <div className="flex flex-wrap gap-2">
          {PRODUCT_CLASSES.map((c) => (
            <Pill key={c.v} active={cp.product_class === c.v} onClick={() => setCP({ product_class: c.v })}>{isAr ? c.ar : c.en}</Pill>
          ))}
        </div>
      </div>

      {/* العمر */}
      <div className="space-y-1.5">
        <p className="text-[10px] font-body font-semibold text-foreground">{isAr ? "الفئة العمرية" : "Target age"}</p>
        <div className="flex flex-wrap gap-2">
          {AGES.map((a) => <Pill key={a.v} active={ages.includes(a.v)} onClick={() => toggleAge(a.v)}>{isAr ? a.ar : a.en}</Pill>)}
        </div>
      </div>

      {/* الاستعمال */}
      <div className="space-y-1.5">
        <p className="text-[10px] font-body font-semibold text-foreground">{isAr ? "طريقة الاستعمال" : "Application"}</p>
        <div className="flex flex-wrap gap-2">
          {APPS.map((a) => (
            <Pill key={a.v} active={cp.application === a.v} onClick={() => setCP({ application: a.v })}>{isAr ? a.ar : a.en}</Pill>
          ))}
        </div>
      </div>

      {/* التركيب — اختيار المواد */}
      <div className="space-y-1.5">
        <p className="text-[10px] font-body font-semibold text-foreground">{isAr ? "التركيب — اختر المواد" : "Composition — pick materials"}</p>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={matSearch} onChange={(e) => setMatSearch(e.target.value)}
            placeholder={isAr ? "ابحث عن مادة بالاسم أو INCI" : "Search material by name or INCI"} className="pl-9 rounded-none h-10 font-body text-sm" />
          {matches.length > 0 && (
            <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20 max-h-56 overflow-y-auto">
              {matches.map((m) => (
                <button key={m.id} type="button" onClick={() => addMat(m)}
                  className="w-full text-start px-3 py-2 text-sm font-body hover:bg-secondary border-b border-border/40 last:border-b-0 flex items-center justify-between gap-2">
                  <span>{m.ar} <span className="text-muted-foreground text-xs">{m.en}</span></span>
                  <span className="text-[10px] flex-shrink-0" style={{ color: STATUS_COLOR[m.status] }}>{STATUS_LABEL[m.status].ar}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* المواد المختارة */}
        {composition.length > 0 && (
          <div className="space-y-1.5 pt-1">
            {composition.map((c) => {
              const m = CARE_MATERIALS.find((x) => x.id === c.key);
              if (!m) return null;
              return (
                <div key={c.key} className="flex items-center gap-2 border-b pb-1.5" style={{ borderColor: "var(--rule,#E7E3DA)" }}>
                  <span className="flex-1 font-body text-[13px]">{m.ar} <span className="text-muted-foreground text-[11px]">{m.en}</span></span>
                  <span className="text-[10px] flex-shrink-0" style={{ color: STATUS_COLOR[m.status] }}>{STATUS_LABEL[m.status].ar}</span>
                  <Input value={c.pct} onChange={(e) => setPct(c.key, e.target.value)} placeholder="%" className="w-14 h-8 rounded-none text-xs text-center" />
                  <button type="button" onClick={() => removeMat(c.key)} className="text-muted-foreground hover:text-foreground"><X className="w-4 h-4" /></button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* شارة سلامة التركيب الحيّة */}
      {composition.length > 0 && (
        <div className="flex items-center justify-between rounded-none border-b pt-1 pb-2" style={{ borderColor: sColor }}>
          <span className="font-body text-sm font-semibold" style={{ color: sColor }}>
            {sLab.ar} <span className="text-muted-foreground font-normal text-[11px]">{sLab.en}</span>
          </span>
          <span className="font-body text-[11px] text-muted-foreground">
            {safety.breakdown.banned ? `${isAr ? "محظورة" : "banned"} ${safety.breakdown.banned} — ` : ""}
            {safety.breakdown.restricted ? `${isAr ? "مقيّدة" : "restricted"} ${safety.breakdown.restricted}` : ""}
          </span>
        </div>
      )}
      <p className="font-body text-[10px] text-muted-foreground">{isAr ? "معلومات تنظيمية للتوعية، ليست نصيحة طبية." : "Regulatory information for awareness, not medical advice."}</p>
    </div>
  );
}
