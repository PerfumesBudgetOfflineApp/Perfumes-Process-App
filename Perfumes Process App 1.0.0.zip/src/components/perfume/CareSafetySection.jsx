import { useMemo } from "react";
import { useLang } from "@/lib/LanguageContext";
import { CARE_MATERIALS, STATUS_COLOR, STATUS_LABEL } from "@/lib/careMaterials";
import { computeCareSafety, CARE_STATUS_COLOR, CARE_STATUS_LABEL } from "@/lib/careSafety";

// CareSafetySection — تُعرض في صفحة المنتج (=صفحة العطر) حين يكون المنتج منتجَ عناية
// أي حين perfume.care_profile موجود. تعرض شارة سلامة التركيب + قائمة المواد بحالاتها.
export default function CareSafetySection({ perfume }) {
  const { isAr } = useLang();
  const cp = perfume && perfume.care_profile;
  const composition = cp && Array.isArray(cp.composition) ? cp.composition : [];
  const safety = useMemo(() => computeCareSafety(composition), [composition]);
  if (!cp) return null;

  const sColor = CARE_STATUS_COLOR[safety.status];
  const sLab = CARE_STATUS_LABEL[safety.status];
  const CLASS = { skincare: { ar: "عناية بالبشرة", en: "Skincare" }, cream: { ar: "كريم", en: "Cream" }, ambient: { ar: "معطّر جوّ", en: "Air freshener" } };
  const APP = { leave_on: { ar: "يبقى على البشرة", en: "Leave-on" }, rinse_off: { ar: "يُغسل", en: "Rinse-off" }, ambient: { ar: "هواء", en: "Ambient" } };
  const cls = CLASS[cp.product_class];
  const app = APP[cp.application];

  return (
    <div className="space-y-3 pt-2">
      <div className="flex items-center justify-between border-b pb-1.5" style={{ borderColor: sColor }}>
        <span className="text-[10px] font-body font-semibold uppercase tracking-widest" style={{ color: "#3A4A7A" }}>
          {isAr ? "سلامة التركيب" : "Composition Safety"} <span className="text-muted-foreground">Care Product</span>
        </span>
        <span className="font-body text-sm font-semibold" style={{ color: sColor }}>
          {sLab.ar} <span className="text-muted-foreground font-normal text-[11px]">{sLab.en}</span>
        </span>
      </div>

      <div className="flex flex-wrap gap-2 text-[11px] font-body text-muted-foreground">
        {cls && <span>{isAr ? cls.ar : cls.en}</span>}
        {app && <span>— {isAr ? app.ar : app.en}</span>}
        {Array.isArray(cp.target_age) && cp.target_age.length > 0 && <span>— {cp.target_age.join(" ")}</span>}
      </div>

      {composition.length > 0 && (
        <div className="space-y-1">
          {composition.map((c) => {
            const m = CARE_MATERIALS.find((x) => x.id === c.key);
            if (!m) return null;
            return (
              <div key={c.key} className="flex items-center justify-between gap-2 border-b pb-1" style={{ borderColor: "var(--rule,#E7E3DA)" }}>
                <span className="font-body text-[13px]">{m.ar} <span className="text-muted-foreground text-[11px]">{m.en}</span>{c.pct ? <span className="text-muted-foreground text-[11px]"> — {c.pct}%</span> : null}</span>
                <span className="text-[10px] flex-shrink-0" style={{ color: STATUS_COLOR[m.status] }}>{STATUS_LABEL[m.status].ar} {STATUS_LABEL[m.status].en}</span>
              </div>
            );
          })}
        </div>
      )}
      <p className="font-body text-[10px] text-muted-foreground">{isAr ? "معلومات تنظيمية للتوعية، ليست نصيحة طبية. اخضر يعني لا محظور و لا تجاوز حدّ، لا انعدام مخاطر." : "Regulatory info for awareness, not medical advice. Green means no banned/over-limit, not zero risk."}</p>
    </div>
  );
}
