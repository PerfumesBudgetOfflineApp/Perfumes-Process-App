import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { unknownAccord } from "@/lib/accordFallback";
import { decadeFromYear } from "@/lib/decade";

/**
 * AccordFlaconCard — قنينة العطر الزجاجية النحيلة «بلا صندوق» (أكتاف · رقبة · غطاء مقفل · لمعة زجاج).
 *
 * المظهر المعتمد:
 *   - علبة عريضة، إطار ذهبي رفيع، الغطاء + الرقبة «إطار ذهبي فقط» (بلا تعبئة ذهبية).
 *   - السائل يملأ النصف السفلي فقط: الأكورد المسيطر طبقة كبيرة حافتها العليا تحت المنتصف،
 *     وبقية الأكوردات طبقات رفيعة مكدّسة فوقه (تتجاوز المنتصف قليلاً) بأوزانها. النصف الأعلى أبيض.
 *   - حدّ رفيع بلون الجنس يحيط منطقة السائل بالكامل (داخل الإطار الذهبي).
 *   - النوع (يسار) والسنة (يمين) بخط Cinzel الفنّي بلون الجنس، حجم صغير جداً.
 *   - اسم الأكورد المسيطر: الإنجليزي يسار (Cinzel، أول حرف كبير) والعربي يمين (Aref Ruqaa)،
 *     بلون متكيّف من حقل `font` في قاعدة الأكوردات (أبيض على الداكن، داكن على الفاتح).
 *   - اسم العطر/البراند/التقييم/الشرائط: خارج هذا المكوّن (في PerfumeCard).
 */
const GOLD = "var(--brand)";

const TYPE_SHORT = {
  "Parfum - Extrait de Parfum": "Extrait",
  "Eau de Parfum - EDP": "EDP",
  "Eau de Toilette - EDT": "EDT",
  "Eau de Cologne - EDC": "EDC",
  "Eau Fraîche": "Fraîche",
  "Bakhoor Natural Oud - Nadd": "Nadd",
  "Bakhoor Synthetic Oud": "B.Oud",
  "Bakhoor Blue Oud": "B.Blue",
  "Oil Misk Wood": "Oil",
  "Rose Oil": "Rose",
  "Oils": "Oil",
  "Mukhallat": "Mukh",
  "Khumrah": "Khum",
  "Anbar Zafaran": "Anbar",
  "Ward Water": "Ward",
  "Musk Myrrh Benzoin": "Musk",
  "Temple Incense & Sacred Woods": "Incense",
  "Agarwood": "Agar",
  "Luban Frankincense Sandalwood": "Luban",
  "Body Mist": "Mist",
  "Body Lotion": "Lotion",
};

function genderColor(g) {
  if (g === "Men" || g === "Male") return "#22c55e";
  if (g === "Women" || g === "Female") return "#f472b6";
  return "#fcd34d"; // Unisex / unknown
}

function cap1(s) {
  s = String(s || "");
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

function parseAccords(raw) {
  const list = String(raw || "")
    .split(";")
    .map((e) => {
      const [id, w] = e.split(":");
      if (!id) return null;
      const ref = ACCORDS[id] || unknownAccord(id);
      return {
        id,
        w: parseFloat(w) || 1,
        color: ref.bar || "#94a3b8",
        font: ref.font || "#ffffff",
        en: ref.en || "",
        ar: ref.ar || "",
      };
    })
    .filter(Boolean);
  list.sort((a, b) => b.w - a.w); // المسيطر = الأعلى وزناً
  return list;
}

export default function AccordFlaconCard({ perfume = {}, className = "", style, bestOfDecade = false }) {
  const list = parseAccords(perfume.accords);
  const has = list.length > 0;
  const dom = list[0] || { color: "#e5e7eb", font: "#475569", en: "", ar: "" };
  const rest = list.slice(1);
  const gcol = genderColor(perfume.gender);

  // هندسة التعبئة داخل الجسم الزجاجيّ النحيل (مستقيم y:92→132، نحيل x:41..85).
  const bottomY = 131;
  const domTop = rest.length ? 113 : 108;
  const ndStackH = 8;
  const ndTop = rest.length ? domTop - ndStackH : domTop;
  const sumR = rest.reduce((a, x) => a + x.w, 0) || 1;

  let y = domTop;
  const ndBands = rest.map((a, i) => {
    const h = (ndStackH * a.w) / sumR;
    const yy = y - h;
    y = yy;
    return <rect key={i} x="41" y={yy} width="44" height={h + 0.4} fill={a.color} opacity="0.7" />;
  });

  const nameY = domTop + (bottomY - domTop) / 2 + 1.8;
  const typeShort = TYPE_SHORT[perfume.type] || (perfume.type ? perfume.type.slice(0, 7) : "");
  const year = perfume.release_year || "";
  const clipId = `fl-${perfume.id != null ? perfume.id : Math.random().toString(36).slice(2)}`;

  // مسار الجسم الزجاجيّ: قاعدة مدوّرة → جانبان مستقيمان → أكتاف → رقبة
  const bodyPath = "M44 132 L82 132 Q86 132 86 128 L86 92 Q86 84 70 81 L70 77 L56 77 L56 81 Q40 84 40 92 L40 128 Q40 132 44 132 Z";

  return (
    <svg
      viewBox="25 60 76 76"
      width="100%"
      height="100%"
      className={className}
      style={{ direction: "ltr", ...(style || {}) }}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      <defs>
        <clipPath id={clipId}><rect x="40" y="92" width="46" height="40" /></clipPath>
        <clipPath id={`b${clipId}`}><rect x="40" y="92" width="46" height="40" /></clipPath>
      </defs>

      {/* السائل: المسيطر بالأسفل + الثانوية فوقه — مقصوص داخل الجسم */}
      <g clipPath={`url(#${clipId})`}>
        {ndBands}
        <rect x="41" y={domTop} width="44" height={bottomY - domTop} fill={dom.color} opacity="0.85" />
      </g>

      {/* حدّ رفيع بلون الجنس حول منطقة السائل */}
      {has ? <rect x="41" y={ndTop} width="44" height={bottomY - ndTop} fill="none" stroke={gcol} strokeWidth="0.9" opacity="0.7" /> : null}

      {/* لمعة الزجاج — خطّ ضوء ناعم على يسار الجسم */}
      <path d="M46 96 Q44 114 48 129" fill="none" stroke="#ffffff" strokeWidth="2.2" strokeLinecap="round" opacity="0.42" />

      {/* الرقبة المقفلة: غطاء مصمت يجلس على فوهة الرقبة فيغلقها */}
      <rect x="53" y="64" width="20" height="14" rx="3" fill="#ffffff" opacity="0.55" />
      {/* إطار الجسم + الرقبة + الغطاء المقفل */}
      <g fill="none" stroke={GOLD} strokeOpacity="0.85" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round">
        <path d={bodyPath} />
        <rect x="53" y="64" width="20" height="14" rx="3" />
      </g>

      {/* شارة «أفضل العقد»: خمس مربّعات خضراء صغيرة جداً بوسط الغطاء */}
      {((bestOfDecade || perfume.best_of_decade) && decadeFromYear(perfume.release_year) !== null) ? (
        <g fill="#3B6D11">
          <rect x="55.6" y="69.6" width="1.9" height="1.9" />
          <rect x="58.6" y="69.6" width="1.9" height="1.9" />
          <rect x="61.6" y="69.6" width="1.9" height="1.9" />
          <rect x="64.6" y="69.6" width="1.9" height="1.9" />
          <rect x="67.6" y="69.6" width="1.9" height="1.9" />
        </g>
      ) : null}

      {/* النوع / السنة / اسم الأكورد — مقصوصة داخل الجسم */}
      <g clipPath={`url(#b${clipId})`}>
        {typeShort ? <text x="42" y="99" fontSize="3.5" letterSpacing="0.3" fill={gcol} fontFamily="'Cinzel', serif">{typeShort}</text> : null}
        {year ? <text x="84" y="99" fontSize="3.5" letterSpacing="0.4" fill={gcol} textAnchor="end" fontFamily="'Cinzel', serif">{year}</text> : null}
        {has && dom.en ? <text x="42" y={nameY} fontSize="4.4" letterSpacing="0.3" fill={dom.font} fontFamily="'Cinzel', serif">{cap1(dom.en)}</text> : null}
        {has && dom.ar ? <text x="84" y={nameY} fontSize="4.8" fill={dom.font} textAnchor="end" fontFamily="'Aref Ruqaa', serif">{dom.ar}</text> : null}
      </g>
    </svg>
  );
}
