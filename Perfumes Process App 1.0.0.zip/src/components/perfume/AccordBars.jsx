/**
 * AccordBars.jsx — "البصمة" accord display (Option 3).
 *
 * Renders a perfume's scent accords using the official catalogue colors and
 * percentages. The dominant accord is shown as a large colored band; the
 * rest follow as small tinted chips. Bilingual (EN + AR) with NO separator
 * dot between the two languages, per the project language rule.
 *
 * Input: `accords` string in catalogue form "a75:100;a35:80;a59:72;.."
 *        (accord_id:percent, already sorted descending).
 * Lookup: src/data/builtin_database/accords_builtin.json  →  id -> {en, ar, bar, font}
 */
import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { unknownAccord } from "@/lib/accordFallback";
import { useLang } from "@/lib/LanguageContext";
import { StrengthBar } from "@/components/perfume/StrengthIndicator";

function parseAccords(raw = "") {
  return String(raw)
    .split(";")
    .map((e) => {
      const [id, pct] = e.split(":");
      if (!id) return null;
      const ref = ACCORDS[id] || unknownAccord(id);
      const n = parseInt(pct, 10);
      return { id, pct: Number.isFinite(n) ? n : 0, ...ref };
    })
    .filter(Boolean);
}

export default function AccordBars({ accords, strength = null }) {
  const { isAr, isMixed } = useLang();
  const list = parseAccords(accords);
  if (!list.length) return null;

  // العائلة العطرية تُعرض دائماً ثنائية اللغة (إنجليزي ثم عربي) بمسافة، بلا نقطة.
  // الإنجليزيّ بأحرف كبيرة (GREEN, FRESH SPICY)، والعربيّ كما هو.
  const label = (a) => {
    const en = String(a.en || "").toUpperCase();
    return a.ar ? `${en} ${a.ar}` : en;
  };
  const [top, ...rest] = list;
  const heading = isAr ? "العائلة العطرية" : isMixed ? "العائلة العطرية Odor Family" : "Odor Family";

  return (
    <div className="bg-card rounded-none px-5 py-4">
      <div className="flex items-center justify-between gap-3 mb-3">
        <p className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest">
          {heading}
        </p>
        {strength != null && <StrengthBar strength={strength} />}
      </div>

      {/* صندوق الأكورد المسيطر — يحوي كل الأكوردات. حدّ بلونه الأساسي، تعبئة خفيفة بلونه. */}
      <div
        className="rounded-none px-4 py-3"
        style={{ border: `1.5px solid ${top.bar}`, background: top.bar + "14" }}
        dir={isAr ? "rtl" : "ltr"}
      >
        {/* المسيطر — صفّ مفرد بلا فاصل: الاسم بلونه (النسبة مخفية) */}
        <div className="flex items-baseline gap-2 flex-wrap">
          <span className="text-xs font-body font-bold" style={{ color: top.bar }}>{label(top)}</span>
        </div>

        {/* الباقي — نصٌّ بلون كل أكورد، بلا خلفية بلا إطار (النسبة مخفية) */}
        {rest.length > 0 && (
          <div className="flex flex-wrap gap-x-3.5 gap-y-1 mt-2">
            {rest.map((a) => (
              <span key={a.id} className="inline-flex items-baseline gap-1 text-[11px] font-body font-semibold" style={{ color: a.bar }}>
                {label(a)}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
