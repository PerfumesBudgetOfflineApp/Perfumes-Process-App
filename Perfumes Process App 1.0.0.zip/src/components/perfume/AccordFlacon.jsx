import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { unknownAccord } from "@/lib/accordFallback";

/**
 * AccordFlacon — قنينة العطر الافتراضية (نفس شكل PerfumePlaceholder) ملوّنة
 * حسب أكوردات العطر:
 *   - الأكورد المسيطر (الأول) يلوّن حدود القنينة + السائل.
 *   - الأكورد الثاني يلوّن الغطاء.
 *   - بلا أكوردات → قنينة رمادية محايدة.
 *
 * البيانات (`accords` = "a24:100;a34:76;..") موجودة أصلاً في سجلّ العطر المحمّل،
 * فالتلوين مجرّد تقسيم نصّ + بحث في خريطة 92 أكوردًا بالذاكرة — لا أثر على الأداء.
 */
function parseAccords(raw) {
  return String(raw || "")
    .split(";")
    .map((e) => {
      const id = e.split(":")[0];
      if (!id) return null;
      const ref = ACCORDS[id] || unknownAccord(id);
      return { id, ...ref };
    })
    .filter(Boolean);
}

// أعلى أكورد (للاسم/اللون في زاوية البطاقة)
export function dominantAccord(accords) {
  return parseAccords(accords)[0] || null;
}

export function topAccords(accords, n = 4) {
  return parseAccords(accords).slice(0, n);
}

export default function AccordFlacon({ accords, className = "", style }) {
  const list = parseAccords(accords);
  const dom = list[0];
  const sec = list[1] || list[0];
  const has = !!dom;
  const lineC = has ? dom.bar : "#94a3b8"; // الجسم/السائل (المسيطر)
  const capC = has ? sec.bar : "#94a3b8";  // الغطاء (الثاني)
  const cid = `sf-${Math.random().toString(36).slice(2)}`;
  // جسم زجاجيّ نحيل: قاعدة مدوّرة → جانبان → أكتاف → رقبة
  const bodyPath = "M45 132 L81 132 Q85 132 85 128 L85 92 Q85 84 69 81 L69 76 L57 76 L57 81 Q41 84 41 92 L41 128 Q41 132 45 132 Z";

  return (
    <svg
      viewBox="22 57 82 82"
      width="100%"
      height="100%"
      className={className}
      style={style}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      <defs><clipPath id={cid}><rect x="41" y="92" width="44" height="40" /></clipPath></defs>
      {/* السائل بلون المسيطر — مقصوص داخل الجسم */}
      <g clipPath={`url(#${cid})`}>
        <rect x="41" y="108" width="44" height="24" fill={lineC} opacity={has ? 0.78 : 0.45} />
      </g>
      {/* لمعة الزجاج */}
      <path d="M47 96 Q45 114 49 129" fill="none" stroke="#ffffff" strokeWidth="2.2" strokeLinecap="round" opacity="0.42" />
      {/* الغطاء المقفل بلون الثاني — يجلس على فوهة الرقبة فيغلقها */}
      <rect x="51" y="62" width="24" height="16" rx="3" fill={capC} opacity={has ? 0.6 : 0.55} />
      {/* الحدود: الجسم بالمسيطر، الغطاء بالثاني */}
      <g fill="none" strokeWidth="2.4" strokeLinejoin="round" strokeLinecap="round">
        <path d={bodyPath} stroke={lineC} />
        <rect x="51" y="62" width="24" height="16" rx="3" stroke={capC} />
      </g>
    </svg>
  );
}
