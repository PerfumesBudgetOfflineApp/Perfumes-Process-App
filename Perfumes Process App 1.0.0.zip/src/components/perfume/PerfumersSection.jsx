import { hilalBorder } from "@/lib/hilalArt";
import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";


import { fetchByEnglishNames, fetchByIds, mergeUnique } from "@/lib/indexedLookup";

export default function PerfumersSection({ perfume }) {
  const navigate = useNavigate();
  const { isAr } = useLang();

  const linkedIds = useMemo(
    () => (Array.isArray(perfume.perfumer_ids) ? perfume.perfumer_ids.join(",") : String(perfume.perfumer_ids || "")).split(",").map(s => s.trim()).filter(Boolean),
    [perfume.perfumer_ids]
  );

  // أسماء العطّارين المكتوبة على العطر (perfumer_names) — للربط بالاسم عند غياب
  // المعرّفات (perfumer_ids)، تماماً كما في صفحة البراند. يحلّ مشكلة عدم ظهور
  // العطّارة المرتبطة بالاسم فقط (مثل عطّار التطبيق Attara على عطر Aaatar).
  const linkedNames = useMemo(
    () => (Array.isArray(perfume.perfumer_names) ? perfume.perfumer_names.join(",") : String(perfume.perfumer_names || "")).split(",").map(s => s.trim()).filter(Boolean),
    [perfume.perfumer_names]
  );

  // جلب مفهرس: المعرّفات عبر getMany، و الأسماء عبر فهرس name (الاسم الإنجليزي
  // المعتمد — مطابقة تامة كأسماء البذرة) — بدل تحميل الـ٣٠٧١ عطّاراً كاملة.
  const { data: linkedPerfumers = [] } = useQuery({
    queryKey: ["perfumers-linked", linkedIds.join("|"), linkedNames.join("|")],
    queryFn: async () => {
      const [byId, byName] = await Promise.all([
        fetchByIds("Perfumer", linkedIds),
        fetchByEnglishNames("Perfumer", linkedNames),
      ]);
      return mergeUnique(byId, byName);
    },
    enabled: linkedIds.length > 0 || linkedNames.length > 0,
    staleTime: 1000 * 60 * 5,
  });

  return (
    <div className="space-y-3 py-2">
      <p className="text-xs font-body font-bold uppercase tracking-widest px-1 text-violet-600 dark:text-violet-400">{isAr ? "من ابتكر هذا العطر" : "Who Created This Perfume"}</p>

      {/* Linked perfumers display */}
      {linkedPerfumers.length > 0 && (
        <div className="grid grid-cols-4 sm:grid-cols-5 lg:grid-cols-6 gap-2">
          {linkedPerfumers.map(p => {
            const isFemale = p.gender === "Female";
            return (
              <button
                key={p.id}
                onClick={() => navigate(`/perfumer?id=${p.id}`)}
                className="flex flex-col items-center gap-1 hover:opacity-80 transition-opacity"
              >
                <div className="w-full aspect-square rounded-none overflow-hidden bg-white flex items-center justify-center"
                  style={{ border: hilalBorder(p.name, p.name_ar, "1px solid rgba(212,175,55,0.35)") }}>
                  {p.photo_url ? (
                    <img src={p.photo_url} alt={p.name} className="w-full h-full object-cover"
                      onError={(e) => { e.currentTarget.style.display = "none"; }} />
                  ) : (
                    <div className="w-full h-full bg-white" />
                  )}
                </div>
                <div className="text-center space-y-0.5">
                  <p className={`text-[10px] font-body font-semibold leading-tight line-clamp-2 ${isFemale ? "text-pink-500" : "text-blue-700 dark:text-blue-400"}`}>{p.name}</p>
                  {p.name_ar && <p className={`text-[9px] font-body leading-tight ${isFemale ? "text-pink-400" : "text-blue-600 dark:text-blue-500"}`} dir="rtl">{p.name_ar}</p>}
                </div>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}