import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { CalendarClock, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

/**
 * WearScheduleSection — FUTURE planning for a perfume (the mirror of Wear
 * History, which is PAST logging). Lives right after Wear History on the
 * perfume page.
 *
 * Hard rule: a schedule date can NEVER be in the past — only today or later.
 */
const REPEATS = [
  { v: "once", ar: "مرة", en: "Once" },
  { v: "daily", ar: "يومي", en: "Daily" },
  { v: "weekly", ar: "أسبوعي", en: "Weekly" },
  { v: "monthly", ar: "شهري", en: "Monthly" },
  { v: "yearly", ar: "سنوي", en: "Yearly" },
];

export default function WearScheduleSection({ perfume, activePerson = "person1", names }) {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const today = format(new Date(), "yyyy-MM-dd");
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(today);
  const [time, setTime] = useState("");
  const [repeat, setRepeat] = useState("once");
  const [note, setNote] = useState("");

  const { data: schedules = [] } = useQuery({
    queryKey: ["wear-schedules-perfume", perfume.id],
    queryFn: () => apphost.entities.WearSchedule.filter({ perfume_id: perfume.id }, "scheduled_date"),
    enabled: !!perfume.id,
  });

  const activeSchedules = schedules.filter((s) => s.is_active);

  const createSchedule = useMutation({
    mutationFn: (data) => apphost.entities.WearSchedule.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wear-schedules-perfume", perfume.id] });
      qc.invalidateQueries({ queryKey: ["wear-schedules"] });
      toast.success(isAr ? "تمت جدولة الارتداء" : "Wear scheduled");
      setOpen(false);
      setNote("");
      setRepeat("once");
      setDate(today);
      setTime("");
    },
    onError: (e) => toast.error((isAr ? "فشل: " : "Failed: ") + (e?.message || "")),
  });

  const deleteSchedule = useMutation({
    mutationFn: (sid) => apphost.entities.WearSchedule.delete(sid),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wear-schedules-perfume", perfume.id] });
      qc.invalidateQueries({ queryKey: ["wear-schedules"] });
      toast.success(isAr ? "حُذف الجدول" : "Schedule removed");
    },
  });

  const handleSave = () => {
    if (!date) {
      toast.error(isAr ? "اختر التاريخ" : "Pick a date");
      return;
    }
    // قاعدة صارمة: لا يمكن جدولة ارتداء في الماضي
    if (date < today) {
      toast.error(isAr ? "لا يمكن جدولة ارتداء في الماضي" : "Cannot schedule a wear in the past");
      return;
    }
    createSchedule.mutate({
      perfume_id: perfume.id,
      perfume_name: perfume.name_en || perfume.name_ar || perfume.name || "",
      brand_name: perfume.brand_name || "",
      image_url: perfume.image_url || "",
      scheduled_date: date,
      scheduled_time: time || "",
      repeat,
      person: activePerson,
      note,
      is_active: true,
    });
  };

  const repeatLabel = (r) => {
    const o = REPEATS.find((x) => x.v === r) || REPEATS[0];
    return isAr ? o.ar : o.en;
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading font-semibold flex items-center gap-2">
            <CalendarClock className="w-4 h-4 text-amber-600" />
            {isAr ? "جدول الارتداء" : "Wear Schedule"}
          </h2>
          <p className="text-xs text-muted-foreground font-body">
            {activeSchedules.length} {isAr ? "مجدول" : (activeSchedules.length === 1 ? "scheduled" : "scheduled")}
          </p>
        </div>
        <Button size="sm" style={{ backgroundColor: "#c2410c", color: "#fff" }} className="rounded-none font-body h-9 px-4 min-w-[104px] hover:opacity-90" onClick={() => { setDate(today); setOpen(true); }}>
          {isAr ? "جدولة" : "Schedule"}
        </Button>
      </div>

      {activeSchedules.length === 0 ? (
        <p className="text-xs text-muted-foreground font-body">{isAr ? "لا جدولة ارتداء قادمة." : "No upcoming wear scheduled."}</p>
      ) : (
        <div className="space-y-2">
          {activeSchedules.map((s) => (
            <div key={s.id} className="flex items-center gap-2 py-2.5">
              <span className={`text-[9px] font-bold rounded-none ${s.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                {s.person === "person2" ? names?.person2 : names?.person1}
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-body font-medium">
                  {s.scheduled_date}{s.scheduled_time ? ` — ${s.scheduled_time}` : ""}
                  <span className="text-[10px] text-muted-foreground"> — {repeatLabel(s.repeat)}</span>
                </p>
                {s.note && <p className="text-[10px] text-muted-foreground font-body truncate">{s.note}</p>}
              </div>
              <button onClick={() => deleteSchedule.mutate(s.id)} className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0">
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Schedule dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-sm w-[calc(100vw-2rem)] rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base flex items-center gap-2">
              <CalendarClock className="w-4 h-4 text-amber-600" /> {isAr ? "جدولة ارتداء العطر" : "Schedule Wear"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="bg-secondary/40 rounded-none p-2.5">
              <p className="text-xs font-body font-bold">{perfume.name_en || perfume.name_ar}</p>
              <p className="text-[10px] text-muted-foreground">{perfume.brand_name}</p>
            </div>

            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-1">{isAr ? "التاريخ (اليوم أو لاحقاً)" : "Date (today or later)"}</p>
              {/* min=today يمنع اختيار تاريخ ماضٍ */}
              <Input type="date" min={today} value={date} onChange={(e) => setDate(e.target.value)} className="rounded-none h-10 font-body text-sm" />
            </div>

            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-1">{isAr ? "الوقت (اختياري)" : "Time (optional)"}</p>
              <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="rounded-none h-10 font-body text-sm" />
            </div>

            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-1">{isAr ? "التكرار" : "Repeat"}</p>
              <div className="flex flex-wrap gap-1.5">
                {REPEATS.map((r) => (
                  <button
                    key={r.v}
                    type="button"
                    onClick={() => setRepeat(r.v)}
                    className={` rounded-none text-xs font-body font-medium transition-all ${repeat === r.v ? " text-white " : " text-muted-foreground"}`}
                  >
                    {isAr ? r.ar : r.en}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-1">{isAr ? "ملاحظة (اختياري)" : "Note (optional)"}</p>
              <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder={isAr ? "مناسبة، سبب.." : "Occasion, reason.."} className="rounded-none h-10 font-body text-sm" dir={isAr ? "rtl" : "ltr"} />
            </div>

            <Button className="w-full h-10 rounded-none font-body" onClick={handleSave} disabled={createSchedule.isPending}>
              {createSchedule.isPending ? (isAr ? "جارٍ.." : "Saving..") : (isAr ? "جدولة" : "Schedule")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
