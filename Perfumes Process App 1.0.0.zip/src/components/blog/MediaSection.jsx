import { useState, useRef } from "react";
import { apphost } from "@/api/apphostClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Upload, Link2, X, Loader2, Video } from "lucide-react";
import { openExternalUrl } from "@/lib/exportHelper";


function isImage(url) {
  return /\.(jpg|jpeg|png|gif|webp|heic)$/i.test(url);
}

function isVideo(url) {
  return /\.(mp4|mov|webm|avi)$/i.test(url);
}

// Comma-safe splitter for media_urls. Uploaded images are stored as base64
// data URLs (e.g. "data:image/jpeg;base64,AAAA"), which themselves contain a
// comma between the mime prefix and the payload. A naive split(",") therefore
// shreds one image into two broken fragments ("two images, none show"). This
// rejoins any "data:...;base64" prefix with the payload that follows it.
// Backward compatible: plain (non-data:) entries split as before.
export function splitMedia(v) {
  if (Array.isArray(v)) return v.map((s) => String(s).trim()).filter(Boolean);
  if (!v) return [];
  const raw = String(v).split(",");
  const out = [];
  for (let i = 0; i < raw.length; i++) {
    let part = raw[i].trim();
    if (/^data:[^,]*;base64$/i.test(part) && i + 1 < raw.length) {
      part = part + "," + raw[++i].trim();
    }
    if (part) out.push(part);
  }
  return out;
}

export function MediaViewer({ mediaUrls = "", mediaLinks = "", bodyText = "" }) {
  // يتحمّل النصّ (CSV) أو المصفوفة أو الفراغ — كانت القيمة الافتراضية مصفوفة
  // فتنهار `[].split`. الآن نوحّد أيّ شكل إلى قائمة.
  const toList = (v) => Array.isArray(v)
    ? v.map((s) => String(s).trim()).filter(Boolean)
    : (v ? String(v).split(",").map((u) => u.trim()).filter(Boolean) : []);
  const urls = splitMedia(mediaUrls);
  const links = toList(mediaLinks);
  
  if (!urls.length && !links.length) return null;

  return (
    <div className="space-y-2">
      {/* Uploaded media */}
      {urls.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {urls.map((url, i) => (
            isVideo(url) ? (
              <video key={i} src={url} controls className="w-full rounded-none max-h-60 object-cover" />
            ) : (
              <img key={i} src={url} alt="" className="h-20 w-20 object-cover rounded-lg" />
            )
          ))}
        </div>
      )}
      {/* External links (يوتيوب أُزيل نهائيًا — أي مشاهدة مضمّنة خارج حساب جوجل تُحسب بوتاً) */}
      {links.map((link, i) => (
        <button type="button" key={i} onClick={(e) => { e.preventDefault(); openExternalUrl(link); }} className="flex items-center gap-2 text-xs font-body text-primary hover:underline rounded-none">
          <Link2 className="w-3.5 h-3.5" />{link}
        </button>
      ))}
    </div>
  );
}

export default function MediaSection({ mediaUrls, mediaLinks, onMediaUrlsChange, onMediaLinksChange, onMediaChange }) {
  const [linkInput, setLinkInput] = useState("");
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef();

  const toList = (v) => Array.isArray(v)
    ? v.map((s) => String(s).trim()).filter(Boolean)
    : (v ? String(v).split(",").map((u) => u.trim()).filter(Boolean) : []);
  const urlList = splitMedia(mediaUrls);
  const linkList = toList(mediaLinks);

  const handleUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    // Reset input value FIRST to prevent re-trigger on Android WebView
    if (e.target) e.target.value = "";
    if (!files.length || uploading) return;
    setUploading(true);
    try {
      const uploaded = await Promise.all(files.map((file) => apphost.integrations.Core.UploadFile({ file })));
      const newOnes = uploaded.map((r) => r.file_url).filter(Boolean);
      // Dedup: avoid adding the same data URL twice (Android WebView can re-fire change)
      const existing = new Set(urlList);
      const additions = newOnes.filter(u => !existing.has(u));
      if (additions.length === 0) return; // nothing new
      const newUrls = [...urlList, ...additions].join(",");
      if (onMediaChange) {
        onMediaChange(newUrls, mediaLinks);
      } else {
        onMediaUrlsChange(newUrls);
      }
    } catch (err) {
      console.error("Upload failed:", err);
      alert("Image upload failed. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const removeUrl = (idx) => {
    const updated = urlList.filter((_, i) => i !== idx).join(",");
    if (onMediaChange) {
      onMediaChange(updated, mediaLinks);
    } else {
      onMediaUrlsChange(updated);
    }
  };

  const addLink = () => {
    const trimmed = linkInput.trim();
    if (!trimmed) return;
    const updated = [...linkList, trimmed].join(",");
    if (onMediaChange) {
      onMediaChange(mediaUrls, updated);
    } else {
      onMediaLinksChange(updated);
    }
    setLinkInput("");
  };

  const removeLink = (idx) => {
    const updated = linkList.filter((_, i) => i !== idx).join(",");
    if (onMediaChange) {
      onMediaChange(mediaUrls, updated);
    } else {
      onMediaLinksChange(updated);
    }
  };

  return (
    <div className="space-y-3 bg-secondary/40 rounded-none p-3">
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">الوسائط Media</p>

      {/* Uploaded previews */}
      {urlList.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {urlList.map((url, i) => (
            <div key={i} className="relative">
              {isVideo(url) ? (
                <div className="w-16 h-16 rounded-none bg-secondary flex items-center justify-center border border-border">
                  <Video className="w-5 h-5 text-muted-foreground" />
                </div>
              ) : (
                <img src={url} alt="" className="w-16 h-16 rounded-none object-cover border border-border" />
              )}
              <button type="button" onClick={() => removeUrl(i)} className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-destructive rounded-none flex items-center justify-center">
                <X className="w-2.5 h-2.5 text-white" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Upload button */}
      <button
        type="button"
        onClick={() => fileRef.current?.click()}
        disabled={uploading}
        className="flex items-center gap-2 text-xs font-body text-muted-foreground hover:text-foreground transition-colors border-dashed rounded-none w-full justify-center"
      >
        {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
        {uploading ? "Uploading.." : "Upload Photos / Videos"}
      </button>
      <input ref={fileRef} type="file" accept="image/*,video/*" multiple className="hidden" onChange={handleUpload} />

      {/* External links */}
      {linkList.length > 0 && (
        <div className="space-y-1">
          {linkList.map((link, i) => {
            return (
              <div key={i} className="flex items-center gap-2 px-2 py-1.5 bg-background rounded-none border border-border">
                <Link2 className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
                <span className="text-[11px] font-body text-foreground/70 flex-1 truncate">{link}</span>
                <button type="button" onClick={() => removeLink(i)} className="text-muted-foreground hover:text-destructive">
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Add link */}
      <div className="flex gap-2">
        <Input
          value={linkInput}
          onChange={(e) => setLinkInput(e.target.value)}
          placeholder="الصق رابطًا... Paste link.."
          className="rounded-none h-9 font-body text-xs flex-1"
          onKeyDown={(e) => e.key === "Enter" && addLink()}
        />
        <Button size="sm" variant="outline" onClick={addLink} className="rounded-none h-9 px-3 text-xs font-body flex-shrink-0">
          Add
        </Button>
      </div>
    </div>
  );
}