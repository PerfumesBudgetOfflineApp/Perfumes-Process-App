import { useState, useMemo } from "react";
import { X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";

/**
 * Searchable tag picker for main_notes (Top / Heart / Base).
 * value: comma-separated string
 * onChange(newVal): callback
 */
export default function MainNotesSearch({ value = "", onChange, placeholder = "Search notes..", disabled = false }) {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);

  const { data: mainNotes = [] } = useQuery({
    queryKey: ["notes-all-for-tagsearch"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: 1000 * 60 * 5,
  });

  const selected = value.split(",").map(s => s.trim()).filter(Boolean);

  const filtered = useMemo(() => {
    if (!search) return mainNotes;
    return mainNotes.filter(n => n.name?.toLowerCase().includes(search.toLowerCase()));
  }, [search, mainNotes]);

  const handleSelect = (noteName) => {
    const trimmed = noteName.trim();
    if (!selected.includes(trimmed)) {
      onChange([...selected, trimmed].join(","));
    }
    setSearch("");
    setOpen(false);
  };

  const removeNote = (noteName) => {
    onChange(selected.filter(n => n.trim() !== noteName.trim()).join(","));
  };

  if (disabled) {
    return (
      <div className="flex flex-wrap gap-1 bg-secondary/30 rounded-none p-2 min-h-[32px] opacity-60">
        {selected.length > 0
          ? selected.map(n => <span key={n} className="text-[9px] rounded-none">{n}</span>)
          : <span className="text-[9px] text-muted-foreground">{placeholder}</span>}
      </div>
    );
  }

  return (
    <div className="space-y-1.5">
      {/* Tags */}
      {selected.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {selected.map(note => (
            <span key={note} className="inline-flex items-center gap-1 text-foreground text-[9px] rounded-none">
              {note}
              <button type="button" onClick={() => removeNote(note)}><X className="w-2.5 h-2.5" /></button>
            </span>
          ))}
        </div>
      )}
      {/* Search input */}
      <div className="relative">
        <input name="MainNotesSearch-1"
          type="text"
          placeholder={placeholder}
          value={search}
          onChange={e => { setSearch(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          className="w-full h-8 rounded-none border border-input bg-transparent px-3 text-xs font-body placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
        />
        {open && filtered.length > 0 && (
          <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-30 max-h-44 overflow-y-auto">
            {filtered.map(note => {
              const isSel = selected.includes(note.name);
              return (
                <button
                  key={note.id}
                  type="button"
                  onMouseDown={() => handleSelect(note.name)}
                  className={`w-full text-left px-3 py-1.5 text-xs font-body hover:bg-secondary border-b border-border/30 last:border-b-0 transition-colors ${isSel ? "bg-primary/10 text-primary font-semibold" : ""}`}
                >
                  {note.name}
                  {note.category && <span className="text-[9px] text-muted-foreground ml-2">{note.category}</span>}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}