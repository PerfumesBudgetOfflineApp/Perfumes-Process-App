import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { X, Search } from "lucide-react";

/**
 * Reusable perfumer search+tag component.
 * value: comma-separated perfumer IDs
 * namesValue: comma-separated perfumer names (for display/caching)
 * onChange(ids, names): called on each change
 */
export default function PerfumerSearchTag({ value = "", namesValue = "", onChange }) {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [touched, setTouched] = useState(false); // أول تركيز على البحث يفعّل تحميل القائمة

  // قائمة البحث الكاملة تُحمَّل عند أول تركيز/كتابة فقط — لا عند فتح الصفحة
  const { data: allPerfumers = [] } = useQuery({
    queryKey: ["perfumers-all"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
    staleTime: 1000 * 60 * 5,
    enabled: touched,
  });

  const selectedIds = value.split(",").map(s => s.trim()).filter(Boolean);

  // المختارون يُجلبون بمعرفاتهم مباشرة (getMany) — لا حاجة للقائمة الكاملة لعرضهم
  const { data: selectedFetched = [] } = useQuery({
    queryKey: ["perfumers-byid", selectedIds.join(",")],
    queryFn: () => apphost.entities.Perfumer.getMany(selectedIds),
    enabled: selectedIds.length > 0,
    staleTime: 1000 * 60 * 5,
  });
  const selectedPerfumers = selectedIds
    .map(id => selectedFetched.find(p => String(p.id) === String(id)))
    .filter(Boolean);

  const filtered = useMemo(() => {
    if (!search) return allPerfumers;
    return allPerfumers.filter(p =>
      p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.name_ar?.includes(search)
    );
  }, [search, allPerfumers]);

  const toggle = (perfumer) => {
    const ids = [...selectedIds];
    const names = selectedPerfumers.map(p => p.name);
    const idx = ids.findIndex(x => String(x) === String(perfumer.id));
    if (idx > -1) {
      ids.splice(idx, 1);
      names.splice(idx, 1);
    } else {
      ids.push(String(perfumer.id));
      names.push(perfumer.name);
    }
    onChange(ids.join(","), names.join(","));
  };

  const remove = (perfumer) => toggle(perfumer);

  return (
    <div className="space-y-1.5">
      {/* Selected tags */}
      {selectedPerfumers.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {selectedPerfumers.map(p => (
            <span key={p.id} className="inline-flex items-center gap-1 text-green-800 dark:text-green-300 text-xs rounded-none font-body font-semibold">
              {p.photo_url && <img src={p.photo_url} className="w-4 h-4 rounded-none object-cover" alt="" />}
              {p.name}
              <button type="button" onClick={() => remove(p)} className="hover:opacity-60 ml-0.5">
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>
      )}
      {/* Search input */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
        <input name="PerfumerSearchTag-1"
          type="text"
          placeholder="ابحث عن عطار.."
          value={search}
          onChange={e => { setTouched(true); setSearch(e.target.value); setOpen(true); }}
          onFocus={() => { setTouched(true); setOpen(true); }}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          className="w-full h-9 pl-9 pr-3 rounded-none border border-input bg-transparent text-sm font-body placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
        />
        {open && filtered.length > 0 && (
          <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-30 max-h-48 overflow-y-auto">
            {filtered.map(p => {
              const selected = selectedIds.includes(p.id);
              return (
                <button
                  key={p.id}
                  type="button"
                  onMouseDown={() => toggle(p)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-body hover:bg-secondary border-b border-border/30 last:border-b-0 transition-colors ${selected ? "bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 font-semibold" : ""}`}
                >
                  <div className="w-7 h-7 rounded-none overflow-hidden flex-shrink-0 bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    {p.photo_url
                      ? <img src={p.photo_url} alt={p.name} className="w-full h-full object-cover" />
                      : <span className="text-[10px] font-bold text-green-700">{p.name?.[0]}</span>
                    }
                  </div>
                  <div className="flex-1 text-left">
                    <p>{p.name}</p>
                    {p.nationality && <p className="text-[10px] text-muted-foreground">{p.nationality}</p>}
                  </div>
                  {selected && <span className="text-green-600 text-[10px]">✓ مرتبط</span>}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}