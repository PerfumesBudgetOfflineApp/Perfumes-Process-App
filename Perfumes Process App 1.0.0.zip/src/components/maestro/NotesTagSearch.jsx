import { useState, useMemo } from "react";
import { X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";

/**
 * Reusable notes tag input that searches PerfumeNote from DB.
 * noteCategory: "main_note" | "sub_notes" | "low_notes" | "all"
 */
export default function NotesTagSearch({ value, onChange, placeholder, noteCategory = "main_note", id }) {
  const [inputVal, setInputVal] = useState("");
  const [open, setOpen] = useState(false);

  // نجلب كل النوتات ثم نفلتر محلياً. سبب ذلك أن الفلترة على note_category في
  // قاعدة البيانات كانت تُخفي النوتات غير المصنّفة (الحقل فارغ) — وهي الأغلبية
  // بعد فصل الدمج الثنائي للغة. الآن: main_note يشمل المصنّفة صراحةً + غير المصنّفة.
  const { data: allDbNotes = [] } = useQuery({
    queryKey: ["notes-all-for-tagsearch"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: 1000 * 60 * 5,
  });

  const dbNotes = useMemo(() => {
    if (noteCategory === "all") return allDbNotes;
    if (noteCategory === "main_note") {
      // النوتات الرئيسية + أي نوتة بلا تصنيف (تُعامل كصالحة للاختيار)
      return allDbNotes.filter(n => !n.note_category || n.note_category === "main_note");
    }
    return allDbNotes.filter(n => n.note_category === noteCategory);
  }, [allDbNotes, noteCategory]);

  const tags = value ? value.split(",").map(s => s.trim()).filter(Boolean) : [];

  const filtered = useMemo(() => {
    if (!inputVal) return dbNotes;
    const q = inputVal.toLowerCase();
    return dbNotes.filter(n =>
      (n.name?.toLowerCase().includes(q) || n.name_ar?.includes(inputVal)) &&
      !tags.includes(n.name)
    );
  }, [inputVal, dbNotes, tags]);

  const addTag = (name) => {
    const trimmed = name.trim();
    if (!trimmed || tags.includes(trimmed)) return;
    const newTags = tags.length > 0 ? [...tags, trimmed] : [trimmed];
    onChange(newTags.join(", "));
    setInputVal("");
    setOpen(false);
  };

  const removeTag = (tag) => {
    const remaining = tags.filter(t => t !== tag);
    onChange(remaining.length > 0 ? remaining.join(", ") : "");
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      if (inputVal.trim()) addTag(inputVal);
    } else if (e.key === "Backspace" && !inputVal && tags.length > 0) {
      removeTag(tags[tags.length - 1]);
    }
  };

  return (
    <div className="relative">
      <div
        className="min-h-[44px] rounded-none border border-input bg-transparent px-3 py-2 flex flex-wrap gap-1 items-center cursor-text"
        onClick={() => document.getElementById(`nts-${id}`)?.focus()}
      >
        {tags.map(t => (
          <span key={t} className="inline-flex items-center gap-1 text-foreground text-xs rounded-none">
            {t}
            <button type="button" onClick={() => removeTag(t)}><X className="w-3 h-3" /></button>
          </span>
        ))}
        <input
           id={`nts-${id}`}
           value={inputVal}
          onChange={e => { setInputVal(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          onKeyDown={handleKeyDown}
          placeholder={tags.length === 0 ? placeholder : ""}
          className="flex-1 min-w-[80px] bg-transparent outline-none text-sm font-body placeholder:text-muted-foreground"
        />
      </div>
      {open && filtered.length > 0 && (
        <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-30 max-h-52 overflow-y-auto">
          {filtered.map(n => (
            <button
              key={n.id}
              type="button"
              onMouseDown={() => addTag(n.name)}
              className="w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary border-b border-border/30 last:border-b-0"
            >
              {n.name}
              {n.name_ar && <span className="text-[11px] text-muted-foreground mr-2">· {n.name_ar}</span>}
              {n.pyramid && <span className="text-[10px] text-muted-foreground ml-2">{n.pyramid}</span>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}