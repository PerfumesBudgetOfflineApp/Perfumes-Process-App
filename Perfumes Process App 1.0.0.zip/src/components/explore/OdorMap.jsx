import { useState, useMemo, useRef } from "react";
import { Link } from "react-router-dom";
import { Droplets, X, ZoomIn, ZoomOut, RotateCcw } from "lucide-react";

/**
 * Odor Coordinate System
 *
 * X axis: Dry ←————————————→ Sweet/Rich
 * Y axis: Light/Fresh ↑————————————↓ Heavy/Deep
 *
 * Each category is placed on this grid (x: 0–100, y: 0–100)
 */
const CATEGORY_COORDS = {
  // Citrus, Aquatic, Green → Fresh/Dry
  Citrus:     { x: 15, y: 10, color: "#f59e0b" },
  Aquatic:    { x: 25, y: 15, color: "#38bdf8" },
  Green:      { x: 20, y: 25, color: "#84cc16" },
  Aromatic:   { x: 35, y: 20, color: "#a3e635" },
  Fougere:    { x: 30, y: 30, color: "#4ade80" },

  // Floral → Middle
  Floral:     { x: 55, y: 28, color: "#f472b6" },
  Fruity:     { x: 65, y: 22, color: "#fb923c" },

  // Powdery, Musky → Center/Sweet
  Powdery:    { x: 70, y: 45, color: "#c4b5fd" },
  Musky:      { x: 60, y: 55, color: "#a78bfa" },

  // Woody, Earthy → Dry/Deep
  Woody:      { x: 30, y: 65, color: "#a16207" },
  Earthy:     { x: 20, y: 72, color: "#78716c" },
  Mossy:      { x: 25, y: 78, color: "#65a30d" },

  // Oriental, Spicy, Gourmand → Rich/Deep
  Oriental:   { x: 72, y: 70, color: "#dc2626" },
  Spicy:      { x: 80, y: 62, color: "#ea580c" },
  Gourmand:   { x: 82, y: 45, color: "#d97706" },
  Resinous:   { x: 68, y: 80, color: "#b45309" },
  Leather:    { x: 45, y: 82, color: "#92400e" },
  Smoky:      { x: 38, y: 88, color: "#57534e" },
};

// Odor family → category mapping for fallback

function getCategoryFromPerfume(perfume) {
  if (perfume.category) {
    const cat = Object.keys(CATEGORY_COORDS).find(
      (k) => k.toLowerCase() === perfume.category.toLowerCase()
    );
    if (cat) return cat;
  }
  // Try partial match
  const partialCat = Object.keys(CATEGORY_COORDS).find(
    (k) => perfume.category?.toLowerCase().includes(k.toLowerCase())
  );
  if (partialCat) return partialCat;
  return null;
}

function jitter(value, seed, range = 4) {
  const hash = ((seed * 2654435761) >>> 0) % (range * 100);
  return value + (hash / 100) - range / 2;
}

const AXIS_LABELS = {
  left: "Dry",
  right: "Sweet",
  top: "Fresh",
  bottom: "Deep",
};

const ALL_CATEGORIES = Object.keys(CATEGORY_COORDS);

export default function OdorMap({ perfumes }) {
  const [zoom, setZoom] = useState(1);
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [panStart, setPanStart] = useState(null);
  const [activePerfume, setActivePerfume] = useState(null);
  const [categoryFilter, setCategoryFilter] = useState(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });
  const containerRef = useRef(null);

  // Map perfumes to coordinates
  const mappedPerfumes = useMemo(() => {
    return perfumes
      .map((p, i) => {
        const cat = getCategoryFromPerfume(p);
        if (!cat) return null;
        const coords = CATEGORY_COORDS[cat];
        return {
          ...p,
          mapCategory: cat,
          x: jitter(coords.x, p.id?.charCodeAt(0) || i, 5),
          y: jitter(coords.y, (p.id?.charCodeAt(1) || i) + 7, 5),
          color: coords.color,
        };
      })
      .filter(Boolean);
  }, [perfumes]);

  const unmapped = perfumes.length - mappedPerfumes.length;

  const visiblePerfumesAll = categoryFilter
    ? mappedPerfumes.filter((p) => p.mapCategory === categoryFilter)
    : mappedPerfumes;
  // حد أقصى للنقاط المرسومة: رسم آلاف عناصر SVG يبطّئ التطبيق.
  // نكتفي بـ 400 نقطة (تكفي بصرياً) ونعرض عدّاد الباقي.
  const MAP_LIMIT = 400;
  const visiblePerfumes = visiblePerfumesAll.slice(0, MAP_LIMIT);
  const hiddenCount = Math.max(0, visiblePerfumesAll.length - MAP_LIMIT);

  // Cluster counts per category
  const categoryCounts = useMemo(() => {
    const map = {};
    mappedPerfumes.forEach((p) => {
      map[p.mapCategory] = (map[p.mapCategory] || 0) + 1;
    });
    return map;
  }, [mappedPerfumes]);

  const usedCategories = Object.keys(categoryCounts).sort();

  // Pan handlers
  const handlePointerDown = (e) => {
    if (activePerfume) return;
    setIsPanning(true);
    setPanStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
  };
  const handlePointerMove = (e) => {
    if (!isPanning) return;
    setPanOffset({ x: e.clientX - panStart.x, y: e.clientY - panStart.y });
  };
  const handlePointerUp = () => setIsPanning(false);

  const handlePerfumeClick = (p, e) => {
    e.stopPropagation();
    const rect = containerRef.current?.getBoundingClientRect();
    setTooltipPos({ x: e.clientX - (rect?.left || 0), y: e.clientY - (rect?.top || 0) });
    setActivePerfume(activePerfume?.id === p.id ? null : p);
  };

  const reset = () => { setZoom(1); setPanOffset({ x: 0, y: 0 }); };

  return (
    <div className="space-y-4">
      {/* Category legend + filter */}
      <div className="flex gap-1.5 flex-wrap">
        <button
          onClick={() => setCategoryFilter(null)}
          className={`text-[10px] rounded-none font-body font-semibold transition-all ${!categoryFilter ? " text-background " : " text-muted-foreground hover:text-foreground"}`}
        >
          All ({mappedPerfumes.length})
        </button>
        {usedCategories.map((cat) => {
          const color = CATEGORY_COORDS[cat]?.color;
          return (
            <button
              key={cat}
              onClick={() => setCategoryFilter(categoryFilter === cat ? null : cat)}
              className={`text-[10px] rounded-none font-body font-semibold transition-all ${categoryFilter === cat ? "border-current " : " text-muted-foreground hover:text-foreground"}`}
              style={categoryFilter === cat ? { background: color + "22", color, borderColor: color } : {}}
            >
              {cat} {categoryCounts[cat]}
            </button>
          );
        })}
      </div>

      {/* Map Container */}
      <div
        ref={containerRef}
        className="relative bg-card border border-border rounded-none overflow-hidden select-none"
        style={{ height: 420, cursor: isPanning ? "grabbing" : "grab" }}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        onClick={() => setActivePerfume(null)}
      >
        {/* Axis labels */}
        <div className="absolute inset-0 pointer-events-none z-10">
          {/* X axis */}
          <span className="absolute top-1/2 left-2 -translate-y-1/2 text-[9px] font-body font-bold text-muted-foreground/60 uppercase tracking-widest" style={{ writingMode: "vertical-rl", transform: "translateY(-50%) rotate(180deg)" }}>{AXIS_LABELS.left}</span>
          <span className="absolute top-1/2 right-2 -translate-y-1/2 text-[9px] font-body font-bold text-muted-foreground/60 uppercase tracking-widest" style={{ writingMode: "vertical-rl" }}>{AXIS_LABELS.right}</span>
          {/* Y axis */}
          <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[9px] font-body font-bold text-muted-foreground/60 uppercase tracking-widest">{AXIS_LABELS.top}</span>
          <span className="absolute bottom-2 left-1/2 -translate-x-1/2 text-[9px] font-body font-bold text-muted-foreground/60 uppercase tracking-widest">{AXIS_LABELS.bottom}</span>
          {/* Cross lines */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-full h-px bg-border/30" />
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="h-full w-px bg-border/30" />
          </div>
          {/* Quadrant labels */}
          <span className="absolute top-6 left-8 text-[8px] font-body text-muted-foreground/40 italic">Fresh · Dry</span>
          <span className="absolute top-6 right-8 text-[8px] font-body text-muted-foreground/40 italic text-right">Fresh · Sweet</span>
          <span className="absolute bottom-6 left-8 text-[8px] font-body text-muted-foreground/40 italic">Deep · Dry</span>
          <span className="absolute bottom-6 right-8 text-[8px] font-body text-muted-foreground/40 italic text-right">Deep · Rich</span>
        </div>

        {/* Transformed layer */}
        <div
          className="absolute inset-0"
          style={{
            transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${zoom})`,
            transformOrigin: "center center",
            transition: isPanning ? "none" : "transform 0.15s ease",
          }}
        >
          {/* Category zone backgrounds */}
          {Object.entries(CATEGORY_COORDS).map(([cat, coords]) => {
            const count = categoryCounts[cat];
            if (!count) return null;
            return (
              <div
                key={cat}
                className="absolute rounded-none pointer-events-none"
                style={{
                  left: `${coords.x}%`,
                  top: `${coords.y}%`,
                  width: Math.max(40, count * 8),
                  height: Math.max(40, count * 8),
                  transform: "translate(-50%, -50%)",
                  background: coords.color + "12",
                  border: `1px solid ${coords.color}30`,
                }}
              />
            );
          })}

          {/* Category name labels */}
          {Object.entries(CATEGORY_COORDS).map(([cat, coords]) => {
            const count = categoryCounts[cat];
            if (!count) return null;
            return (
              <div
                key={cat + "-label"}
                className="absolute pointer-events-none"
                style={{ left: `${coords.x}%`, top: `${coords.y - 5}%`, transform: "translate(-50%, -100%)" }}
              >
                <span className="text-[9px] font-body font-bold whitespace-nowrap" style={{ color: coords.color }}>{cat}</span>
              </div>
            );
          })}

          {/* Perfume dots */}
          {visiblePerfumes.map((p) => {
            const isActive = activePerfume?.id === p.id;
            return (
              <button
                key={p.id}
                className="absolute rounded-none transition-all hover:scale-125 hover:z-30"
                style={{
                  left: `${p.x}%`,
                  top: `${p.y}%`,
                  width: isActive ? 14 : 10,
                  height: isActive ? 14 : 10,
                  transform: "translate(-50%, -50%)",
                  background: p.color,
                  boxShadow: isActive ? `0 0 0 3px white, 0 0 0 5px ${p.color}` : `0 1px 3px rgba(0,0,0,0.3)`,
                  zIndex: isActive ? 30 : 10,
                }}
                onClick={(e) => handlePerfumeClick(p, e)}
              >
                {p.image_url && (
                  <img src={p.image_url} alt={p.name} className="w-full h-full rounded-none object-cover opacity-80" />
                )}
              </button>
            );
          })}
        </div>

        {/* Tooltip / Perfume popup */}
        {activePerfume && (
          <div
            className="absolute z-50 bg-popover border border-border rounded-none shadow-xl p-3 w-52 pointer-events-auto"
            style={{
              left: Math.min(tooltipPos.x, containerRef.current?.offsetWidth - 220) + 10,
              top: Math.max(tooltipPos.y - 80, 10),
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-start gap-3">
              <div className="w-12 h-12 rounded-none overflow-hidden bg-secondary flex-shrink-0">
                {activePerfume.image_url ? (
                  <img src={activePerfume.image_url} alt={activePerfume.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center"><Droplets className="w-5 h-5 text-primary/40" /></div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[10px] text-muted-foreground font-body truncate">{activePerfume.brand_name}</p>
                <p className="text-sm font-heading font-semibold leading-tight line-clamp-2">{activePerfume.name}</p>
                <div className="flex flex-wrap gap-1 mt-1">
                  <span className="text-[9px] px-1.5 py-0.5 rounded-none font-body font-semibold text-white"
                    style={{ background: activePerfume.color }}>{activePerfume.mapCategory}</span>
                  {activePerfume.gender && (
                    <span className="text-[9px] rounded-none text-muted-foreground font-body">{activePerfume.gender}</span>
                  )}
                  {activePerfume.rating && (
                    <span className="text-[9px] rounded-none text-primary font-body">{"■".repeat(Math.round(activePerfume.rating))}{"□".repeat(Math.max(0, 5 - Math.round(activePerfume.rating)))}</span>
                  )}
                </div>
              </div>
              <button onClick={() => setActivePerfume(null)} className="flex-shrink-0 text-muted-foreground hover:text-foreground">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            {(activePerfume.top_notes || activePerfume.heart_notes) && (
              <div className="mt-2 pt-2 border-t border-border/50">
                {activePerfume.top_notes && <p className="text-[9px] font-body text-muted-foreground"><span className="text-sky-500 font-semibold">Top:</span> {activePerfume.top_notes}</p>}
                {activePerfume.heart_notes && <p className="text-[9px] font-body text-muted-foreground"><span className="text-rose-500 font-semibold">Heart:</span> {activePerfume.heart_notes}</p>}
                {activePerfume.base_notes && <p className="text-[9px] font-body text-muted-foreground"><span className="text-amber-600 font-semibold">Base:</span> {activePerfume.base_notes}</p>}
              </div>
            )}
            <Link
              to={`/perfume?id=${activePerfume.id}`}
              className="block mt-2.5 text-center text-[10px] font-body font-semibold text-primary hover:underline"
            >
              View Details →
            </Link>
          </div>
        )}

        {/* Zoom controls */}
        <div className="absolute bottom-3 right-3 flex flex-col gap-1 z-20">
          <button onClick={(e) => { e.stopPropagation(); setZoom((z) => Math.min(z + 0.3, 3)); }}
            className="w-8 h-8 bg-card border border-border rounded-none flex items-center justify-center hover:bg-secondary shadow-sm">
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button onClick={(e) => { e.stopPropagation(); setZoom((z) => Math.max(z - 0.3, 0.5)); }}
            className="w-8 h-8 bg-card border border-border rounded-none flex items-center justify-center hover:bg-secondary shadow-sm">
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button onClick={(e) => { e.stopPropagation(); reset(); }}
            className="w-8 h-8 bg-card border border-border rounded-none flex items-center justify-center hover:bg-secondary shadow-sm">
            <RotateCcw className="w-3 h-3" />
          </button>
        </div>

        {/* Stats bar */}
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 bg-card/80 backdrop-blur-sm border border-border/50 rounded-none px-3 py-1 flex items-center gap-2">
          <span className="text-[10px] font-body text-muted-foreground">{visiblePerfumes.length} perfumes mapped</span>
          {unmapped > 0 && <span className="text-[10px] font-body text-muted-foreground/60">· {unmapped} without category</span>}
        </div>
      </div>

      {/* Bottom note */}
      <p className="text-[10px] text-muted-foreground font-body text-center">
        Tap a dot to preview · Pinch or use ± to zoom · Drag to pan · Category required on perfume to appear
      </p>
    </div>
  );
}