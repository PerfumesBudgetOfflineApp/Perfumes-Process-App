import { useState, useMemo, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Star, Droplets, ChevronDown, ChevronUp } from "lucide-react";
import { Link } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";

// ─── Historical Timeline Data (English, Arabic, Mixed) ────────────────────────
const HISTORY = [
  { 
    year: "4000 BC", 
    label: "Egypt — Kyphi", 
    label_ar: "مصر — كيفي",
    label_mixed: "مصر Egypt — كيفي Kyphi",
    notes: "Myrrh, frankincense, honey", 
    notes_ar: "المر، اللبان، العسل",
    notes_mixed: "المر Myrrh، اللبان frankincense، العسل honey",
    desc: "World's first recorded perfume formula, used in temples and as medicine.", 
    desc_ar: "أول صيغة عطر مسجلة في العالم، استخدمت في المعابد و الطب.",
    desc_mixed: "أول أول world's first صيغة عطر perfume formula مسجلة recorded في العالم in the world.",
    color: "amber" 
  },
  { 
    year: "3000 BC", 
    label: "Mesopotamia — Tapputi", 
    label_ar: "بلاد الرافدين — تابوتي",
    label_mixed: "بلاد الرافدين Mesopotamia — تابوتي Tapputi",
    notes: "Calamus, myrrh, rose", 
    notes_ar: "القصب، المر، الورد",
    notes_mixed: "القصب Calamus، المر myrrh، الورد rose",
    desc: "Tapputi-Belatekallim documented the first perfume distillation in cuneiform tablets.", 
    desc_ar: "وثقت تابوتي بيلاتيكاليم أول تقطير عطر في ألواح مسمارية.",
    desc_mixed: "وثقت Tapputi تابوتي أول first تقطير distillation عطر perfume في cuneiform ألواح tablets.",
    color: "amber" 
  },
  { 
    year: "1000 BC", 
    label: "Arabia — Incense Routes", 
    label_ar: "الجزيرة العربية — طرق البخور",
    label_mixed: "الجزيرة العربية Arabia — طرق البخور Incense Routes",
    notes: "Oud, myrrh, labdanum", 
    notes_ar: "العود، المر، لادانوم",
    notes_mixed: "العود Oud، المر myrrh، لادانوم labdanum",
    desc: "Arab traders spread oud culture across the ancient world via spice routes.", 
    desc_ar: "نشر التجار العرب ثقافة العود عبر العالم القديم عبر طرق التوابل.",
    desc_mixed: "نشر spread التجار traders العرب Arab ثقافة culture العود oud عبر across العالم world القديم ancient.",
    color: "amber" 
  },
  { 
    year: "500 BC", 
    label: "Greece — Megaleion", 
    label_ar: "اليونان — ميجاليون",
    label_mixed: "اليونان Greece — ميجاليون Megaleion",
    notes: "Myrrh, cinnamon, cassia", 
    notes_ar: "المر، القرفة، السنط",
    notes_mixed: "المر Myrrh، القرفة cinnamon، السنط cassia",
    desc: "Greeks created liquid perfumes from flowers and resins.", 
    desc_ar: "ابتكر الإغريق العطور السائلة من الزهور و الراتنجات.",
    desc_mixed: "ابتكر created الإغريق Greeks العطور perfumes السائلة liquid من from الزهور flowers والراتنجات resins.",
    color: "amber" 
  },
  { 
    year: "900 AD", 
    label: "Persia — Distillation", 
    label_ar: "فارس — التقطير",
    label_mixed: "فارس Persia — التقطير Distillation",
    notes: "Rose water, musk, civet", 
    notes_ar: "ماء الورد، المسك، الزباد",
    notes_mixed: "ماء الورد Rose water، المسك musk، الزباد civet",
    desc: "Avicenna perfected steam distillation, enabling true alcohol-based perfumery.", 
    desc_ar: "أتقن ابن سينا التقطير بالبخار، مما أتاح صنع العطور الكحولية الحقيقية.",
    desc_mixed: "أتقن perfected ابن سينا Avicenna التقطير distillation بالبخار steam، مما enabling صنع making العطور perfumes الكحولية alcohol-based.",
    color: "emerald" 
  },
  { 
    year: "1370", 
    label: "Hungary Water", 
    label_ar: "ماء هنغاريا",
    label_mixed: "ماء Hungary Water هنغاريا",
    notes: "Rosemary, brandy, thyme", 
    notes_ar: "إكليل الجبل، برندي، الزعتر",
    notes_mixed: "إكليل Rosemary الجبل، برندي brandy، الزعتر thyme",
    desc: "Europe's first alcohol-based perfume, made for Queen Elizabeth of Hungary.", 
    desc_ar: "أول عطر كحولي أوروبي، صُنع للملكة إليزابيث ملكة هنغاريا.",
    desc_mixed: "أول first عطر perfume كحولي alcohol-based أوروبي European، صُنع made للملكة for the queen إليزابيث Elizabeth.",
    color: "violet" 
  },
  { 
    year: "1709", 
    label: "Eau de Cologne", 
    label_ar: "أو دو كولونيا",
    label_mixed: "أو Eau دو de كولونيا Cologne",
    notes: "Bergamot, neroli, lemon", 
    notes_ar: "البرغموت، النيروليا، الليمون",
    notes_mixed: "البرغموت Bergamot، النيروليا neroli، الليمون lemon",
    desc: "Giovanni Farina created Eau de Cologne, naming it after his beloved city.", 
    desc_ar: "أنشأ جيوفاني فارينا أو دو كولونيا، وسماها على اسم مدينته المحبوبة.",
    desc_mixed: "أنشأ created جيوفاني Giovanni فارينا Farina أو Eau دو de كولونيا Cologne، وسماها naming اسم after مدينته city المحبوبة beloved.",
    color: "violet" 
  },
  { 
    year: "1882", 
    label: "Fougère Royale", 
    label_ar: "سرخس ملكي",
    label_mixed: "سرخس Fougère ملكي Royale",
    notes: "Coumarin, oakmoss, lavender", 
    notes_ar: "الكومارين، الحزازة الخشبية، اللافندر",
    notes_mixed: "الكومارين Coumarin، الحزازة oakmoss الخشبية، اللافندر lavender",
    desc: "First synthetic fragrance, launching the iconic fougère family.", 
    desc_ar: "أول عطر اصطناعي، وأطلق عائلة السرخس الأيقونية.",
    desc_mixed: "أول First عطر fragrance اصطناعي synthetic، وأطلق launching عائلة family السرخس fougère الأيقونية iconic.",
    color: "sky" 
  },
  { 
    year: "1889", 
    label: "Guerlain — Jicky", 
    label_ar: "جيرلان — جيكي",
    label_mixed: "جيرلان Guerlain — جيكي Jicky",
    notes: "Lavender, coumarin, vanilla", 
    notes_ar: "اللافندر، الكومارين، الفانيليا",
    notes_mixed: "اللافندر Lavender، الكومارين coumarin، الفانيليا vanilla",
    desc: "The first truly modern perfume blending synthetics with naturals. Still sold today.", 
    desc_ar: "أول عطر حديث حقاً يجمع بين الاصطناعيات و المستخلصات الطبيعية. لا يزال يُباع حتى اليوم.",
    desc_mixed: "أول First عطر fragrance حديث modern حقاً truly يجمع blending بين between الاصطناعيات synthetics والمستخلصات naturals الطبيعية. لا يزال still يُباع sold حتى until اليوم today.",
    color: "sky" 
  },
];

// ─── Year-by-Year Top 4 Perfumes (1889-2020) — Wikipedia Verified Historical Data ────
const YEARLY_TOP_PERFUMES = {
  "1971": [
    { name: "Aromatics Elixir", brand: "Clinique", notes: "Chamomile, rose, patchouli, oakmoss", notes_ar: "البابونج، الورد، الباتشولي، طحلب البلوط" },
  ],
  "1972": [
    { name: "Diorella", brand: "Dior", notes: "Lemon, melon, jasmine, oakmoss", notes_ar: "الليمون، الشمام، الياسمين، طحلب البلوط" },
  ],
  "1973": [
    { name: "Charlie", brand: "Revlon", notes: "Lily of the valley, jasmine, sandalwood", notes_ar: "زنبق الوادي، الياسمين، خشب الصندل" },
  ],
  "1974": [
    { name: "Cristalle", brand: "Chanel", notes: "Lemon, hyacinth, jasmine, oakmoss", notes_ar: "الليمون، الياقنث، الياسمين، طحلب البلوط" },
  ],
  "1975": [
    { name: "Chloe", brand: "Chloe", notes: "Tuberose, ylang-ylang, jasmine, sandalwood", notes_ar: "التوبروز، الإيلنغ، الياسمين، خشب الصندل" },
  ],
  "1976": [
    { name: "First", brand: "Van Cleef & Arpels", notes: "Aldehydes, jasmine, rose, sandalwood", notes_ar: "الألدهيدات، الياسمين، الورد، خشب الصندل" },
  ],
  "1977": [
    { name: "Opium", brand: "Yves Saint Laurent", notes: "Mandarin, clove, myrrh, vanilla", notes_ar: "اليوسفي، القرنفل، المرّ، الفانيليا" },
  ],
  "1978": [
    { name: "Anais Anais", brand: "Cacharel", notes: "Lily, jasmine, white florals, sandalwood", notes_ar: "الزنبق، الياسمين، زهور بيضاء، خشب الصندل" },
    { name: "Polo", brand: "Ralph Lauren", notes: "Pine, tobacco, leather, oakmoss", notes_ar: "الصنوبر، التبغ، الجلد، طحلب البلوط" },
  ],
  "1981": [
    { name: "Kouros", brand: "Yves Saint Laurent", notes: "Aldehydes, honey, civet, leather", notes_ar: "الألدهيدات، العسل، الزباد، الجلد" },
    { name: "Must de Cartier", brand: "Cartier", notes: "Galbanum, mandarin, vanilla, amber", notes_ar: "الجلبان، اليوسفي، الفانيليا، العنبر" },
  ],
  "1982": [
    { name: "Drakkar Noir", brand: "Guy Laroche", notes: "Lavender, spices, leather, fougere", notes_ar: "الخزامى، البهارات، الجلد، السرخس" },
  ],
  "1983": [
    { name: "Paris", brand: "Yves Saint Laurent", notes: "Rose, violet, mimosa, sandalwood", notes_ar: "الورد، البنفسج، الميموزا، خشب الصندل" },
  ],
  "1984": [
    { name: "Coco", brand: "Chanel", notes: "Frankincense, rose, jasmine, amber", notes_ar: "اللبان، الورد، الياسمين، العنبر" },
  ],
  "1985": [
    { name: "Poison", brand: "Dior", notes: "Tuberose, plum, opoponax, spices", notes_ar: "التوبروز، البرقوق، الأوبوبوناكس، البهارات" },
    { name: "Obsession", brand: "Calvin Klein", notes: "Mandarin, spices, amber, vanilla", notes_ar: "اليوسفي، البهارات، العنبر، الفانيليا" },
  ],
  "1986": [
    { name: "Obsession for Men", brand: "Calvin Klein", notes: "Mandarin, spices, amber, musk", notes_ar: "اليوسفي، البهارات، العنبر، المسك" },
  ],
  "1987": [
    { name: "Loulou", brand: "Cacharel", notes: "Heliotrope, tiare, vanilla, orange blossom", notes_ar: "الهليوتروب، التياري، الفانيليا، زهر البرتقال" },
  ],
  "1988": [
    { name: "Fahrenheit", brand: "Dior", notes: "Violet, leather, mandarin, woods", notes_ar: "البنفسج، الجلد، اليوسفي، الأخشاب" },
    { name: "Cool Water", brand: "Davidoff", notes: "Mint, lavender, sandalwood, musk", notes_ar: "النعناع، الخزامى، خشب الصندل، المسك" },
  ],
  "1989": [
    { name: "Samsara", brand: "Guerlain", notes: "Sandalwood, jasmine, ylang-ylang, tonka", notes_ar: "خشب الصندل، الياسمين، الإيلنغ، التونكا" },
  ],
  "1991": [
    { name: "Dune", brand: "Dior", notes: "Broom, peony, amber, sandalwood", notes_ar: "الوزال، الفاوانيا، العنبر، خشب الصندل" },
  ],
  "1992": [
    { name: "Angel", brand: "Thierry Mugler", notes: "Bergamot, praline, chocolate, patchouli", notes_ar: "البرغموت، البرالين، الشوكولاتة، الباتشولي" },
    { name: "Feminite du Bois", brand: "Shiseido", notes: "Cedar, plum, spices, musk", notes_ar: "الأرز، البرقوق، البهارات، المسك" },
  ],
  "1993": [
    { name: "L'Eau d'Issey", brand: "Issey Miyake", notes: "Lotus, freesia, woods, musk", notes_ar: "اللوتس، الفريزيا، الأخشاب، المسك" },
  ],
  "1994": [
    { name: "CK One", brand: "Calvin Klein", notes: "Bergamot, green tea, musk", notes_ar: "البرغموت، الشاي الأخضر، المسك" },
  ],
  "1995": [
    { name: "Le Male", brand: "Jean Paul Gaultier", notes: "Mint, lavender, vanilla, tonka", notes_ar: "النعناع، الخزامى، الفانيليا، التونكا" },
  ],
  "1996": [
    { name: "Acqua di Gio", brand: "Giorgio Armani", notes: "Marine notes, bergamot, patchouli", notes_ar: "نوتات بحرية، البرغموت، الباتشولي" },
    { name: "Allure", brand: "Chanel", notes: "Citrus, vanilla, woods, musk", notes_ar: "الحمضيات، الفانيليا، الأخشاب، المسك" },
  ],
  "1997": [
    { name: "Lolita Lempicka", brand: "Lolita Lempicka", notes: "Anise, licorice, violet, vanilla", notes_ar: "اليانسون، العرقسوس، البنفسج، الفانيليا" },
  ],
  "1999": [
    { name: "J'adore", brand: "Dior", notes: "Ylang-ylang, rose, jasmine, musk", notes_ar: "الإيلنغ، الورد، الياسمين، المسك" },
  ],
  "2001": [
    { name: "Coco Mademoiselle", brand: "Chanel", notes: "Orange, rose, patchouli, musk", notes_ar: "البرتقال، الورد، الباتشولي، المسك" },
    { name: "Light Blue", brand: "Dolce & Gabbana", notes: "Apple, bamboo, cedar, musk", notes_ar: "التفاح، الخيزران، الأرز، المسك" },
  ],
  "2003": [
    { name: "Chance", brand: "Chanel", notes: "Pink pepper, jasmine, patchouli, vanilla", notes_ar: "الفلفل الوردي، الياسمين، الباتشولي، الفانيليا" },
  ],
  "2004": [
    { name: "Armani Code", brand: "Giorgio Armani", notes: "Bergamot, olive blossom, tonka", notes_ar: "البرغموت، زهر الزيتون، التونكا" },
  ],
  "2005": [
    { name: "Flowerbomb", brand: "Viktor & Rolf", notes: "Bergamot, jasmine, patchouli, vanilla", notes_ar: "البرغموت، الياسمين، الباتشولي، الفانيليا" },
  ],
  "2006": [
    { name: "Black Orchid", brand: "Tom Ford", notes: "Truffle, black orchid, patchouli, dark chocolate", notes_ar: "الكمأة، الأوركيد الأسود، الباتشولي، الشوكولاتة الداكنة" },
    { name: "The One", brand: "Dolce & Gabbana", notes: "Bergamot, lily, vanilla, amber", notes_ar: "البرغموت، الزنبق، الفانيليا، العنبر" },
  ],
  "2008": [
    { name: "1 Million", brand: "Paco Rabanne", notes: "Blood mandarin, cinnamon, leather, amber", notes_ar: "اليوسفي الدموي، القرفة، الجلد، العنبر" },
  ],
  "2009": [
    { name: "La Nuit de l'Homme", brand: "Yves Saint Laurent", notes: "Cardamom, lavender, cedar", notes_ar: "الهيل، الخزامى، الأرز" },
  ],
  "2011": [
    { name: "Aventus", brand: "Creed", notes: "Pineapple, birch, musk, oakmoss", notes_ar: "الأناناس، البتولا، المسك، طحلب البلوط" },
  ],
  "2012": [
    { name: "La Vie est Belle", brand: "Lancome", notes: "Iris, praline, patchouli, vanilla", notes_ar: "السوسن، البرالين، الباتشولي، الفانيليا" },
  ],
  "2013": [
    { name: "Si", brand: "Giorgio Armani", notes: "Blackcurrant, rose, vanilla, patchouli", notes_ar: "الكشمش الأسود، الورد، الفانيليا، الباتشولي" },
  ],
  "2014": [
    { name: "Black Opium", brand: "Yves Saint Laurent", notes: "Coffee, vanilla, white flowers", notes_ar: "القهوة، الفانيليا، الزهور البيضاء" },
  ],
  "2016": [
    { name: "Good Girl", brand: "Carolina Herrera", notes: "Almond, tuberose, tonka, cocoa", notes_ar: "اللوز، التوبروز، التونكا، الكاكاو" },
  ],
  "1889": [
   { name: "Jicky", brand: "Guerlain", perfumer: "Aimé Guerlain", notes: "Lavender, coumarin, vanilla", notes_ar: "الخزامى، الكومارين، الفانيليا" },
   { name: "Fougère Royale", brand: "Houbigant", perfumer: "Paul Parquet", notes: "Coumarin, oakmoss, lavender", notes_ar: "الكومارين، الحزازة الخشبية، الخزامى" },
   { name: "Eau de Lubin", brand: "Lubin", perfumer: "Pierre François Lubin", notes: "Rose, bergamot, musk", notes_ar: "الورد، البرغموت، المسك" },
   { name: "La Rose Jacqueminot", brand: "Coty", perfumer: "François Coty", notes: "Rose, jasmine, aldehydes", notes_ar: "الورد، الياسمين، الألدهايدات" },
  ],
  "1910": [
   { name: "L'Heure Bleue", brand: "Guerlain", perfumer: "Jacques Guerlain", notes: "Bergamot, neroli, rose, violet", notes_ar: "البرغموت، النيروليا، الورد، البنفسج" },
   { name: "L'Origan", brand: "Coty", perfumer: "François Coty", notes: "Florals, citrus, aldehydes", notes_ar: "الزهور، الحمضيات، الألدهايدات" },
   { name: "Quelques Fleurs", brand: "Houbigant", perfumer: "Robert Bienaimé", notes: "Floral bouquet, aldehydes", notes_ar: "باقة زهور، ألدهايدات" },
   { name: "Jicky", brand: "Guerlain", perfumer: "Aimé Guerlain", notes: "Lavender, coumarin, vanilla", notes_ar: "الخزامى، الكومارين، الفانيليا" },
  ],
  "1920": [
   { name: "Chanel No. 5", brand: "Chanel", perfumer: "Ernest Beaux", notes: "Aldehydes, jasmine, rose, sandalwood", notes_ar: "ألدهايدات، ياسمين، ورد، خشب الصندل" },
   { name: "Shalimar", brand: "Guerlain", perfumer: "Jacques Guerlain", notes: "Bergamot, iris, rose, vanilla", notes_ar: "برغموت، أيريس، ورد، فانيليا" },
   { name: "Minotaure", brand: "Guerlain", perfumer: "Jacques Guerlain", notes: "Lavender, bergamot, oak moss", notes_ar: "خزامى، برغموت، حزازة خشبية" },
   { name: "L'Heure Bleue", brand: "Guerlain", perfumer: "Jacques Guerlain", notes: "Bergamot, neroli, rose, violet", notes_ar: "برغموت، نيروليا، ورد، بنفسج" },
  ],
  "1930": [
   { name: "Joy", brand: "Jean Patou", perfumer: "Henri Alméras", notes: "Rose, jasmine, ylang-ylang, sandalwood", notes_ar: "ورد، ياسمين، الإيلانج إيلانج، خشب الصندل" },
   { name: "Chanel No. 5", brand: "Chanel", perfumer: "Ernest Beaux", notes: "Aldehydes, jasmine, rose, sandalwood", notes_ar: "ألدهايدات، ياسمين، ورد، خشب الصندل" },
   { name: "Shalimar", brand: "Guerlain", perfumer: "Jacques Guerlain", notes: "Bergamot, iris, rose, vanilla", notes_ar: "برغموت، أيريس، ورد، فانيليا" },
   { name: "Arpège", brand: "Lanvin", perfumer: "André Fraysse", notes: "Aldehydes, rose, jasmine, sandalwood", notes_ar: "ألدهايدات، ورد، ياسمين، خشب الصندل" },
  ],
  "1940": [
   { name: "Miss Dior", brand: "Dior", perfumer: "Paul Vacher", notes: "Green notes, aldehyde, rose, oakmoss", notes_ar: "نوتات خضراء، ألدهايد، ورد، حزازة خشبية" },
   { name: "Arpège", brand: "Lanvin", perfumer: "André Fraysse", notes: "Aldehydes, rose, jasmine, sandalwood", notes_ar: "ألدهايدات، ورد، ياسمين، خشب الصندل" },
   { name: "Joy", brand: "Jean Patou", perfumer: "Henri Alméras", notes: "Rose, jasmine, ylang-ylang, sandalwood", notes_ar: "ورد، ياسمين، الإيلانج إيلانج، خشب الصندل" },
   { name: "Chanel No. 5", brand: "Chanel", perfumer: "Ernest Beaux", notes: "Aldehydes, jasmine, rose, sandalwood", notes_ar: "ألدهايدات، ياسمين، ورد، خشب الصندل" },
  ],
  "1950": [
   { name: "L'Air du Temps", brand: "Nina Ricci", perfumer: "Francis Fabron", notes: "Carnation, rose, sandalwood", notes_ar: "قرنفل، ورد، خشب الصندل" },
   { name: "Arpège", brand: "Lanvin", perfumer: "André Fraysse", notes: "Aldehydes, rose, jasmine, sandalwood", notes_ar: "ألدهايدات، ورد، ياسمين، خشب الصندل" },
   { name: "Chanel No. 5", brand: "Chanel", perfumer: "Ernest Beaux", notes: "Aldehydes, jasmine, rose, sandalwood", notes_ar: "ألدهايدات، ياسمين، ورد، خشب الصندل" },
   { name: "Miss Dior", brand: "Dior", perfumer: "Paul Vacher", notes: "Green notes, aldehyde, rose, oakmoss", notes_ar: "نوتات خضراء، ألدهايد، ورد، حزازة خشبية" },
  ],
  "1960": [
   { name: "Rive Gauche", brand: "Yves Saint Laurent", perfumer: "Henri Alméras", notes: "Aldehydes, rose, jasmine, vetiver", notes_ar: "ألدهايدات، ورد، ياسمين، فيتيفر" },
   { name: "Calandre", brand: "Paco Rabanne", perfumer: "Jean-Louis Sieuzac", notes: "Aldehydes, rose, violet, sandalwood", notes_ar: "ألدهايدات، ورد، بنفسج، خشب الصندل" },
   { name: "Cristalle", brand: "Chanel", perfumer: "Dmitri Berlin", notes: "Aldehydes, citrus, jasmine, vetiver", notes_ar: "ألدهايدات، حمضيات، ياسمين، فيتيفر" },
   { name: "Calèche", brand: "Hermès", perfumer: "Guy Robert", notes: "Aldehydes, rose, jasmine, vetiver", notes_ar: "ألدهايدات، ورد، ياسمين، فيتيفر" },
  ],
  "1970": [
   { name: "Opium", brand: "Yves Saint Laurent", perfumer: "Jean Amic", notes: "Spices, patchouli, myrrh, rose", notes_ar: "توابل، باتشولي، مر، ورد" },
   { name: "Eau Sauvage", brand: "Dior", perfumer: "Edmond Roudnitska", notes: "Lemon, hedione, jasmine, vetiver", notes_ar: "ليمون، هيديون، ياسمين، فيتيفر" },
   { name: "Charlie", brand: "Revlon", perfumer: "Unknown", notes: "Green, floral, aldehyde, musk", notes_ar: "أخضر، زهري، ألدهايد، مسك" },
   { name: "Chloé", brand: "Chloé", perfumer: "Luc Chevallier", notes: "Florals, aldehydes, amber", notes_ar: "زهور، ألدهايدات، كهرمان" },
  ],
  "1980": [
   { name: "Drakkar Noir", brand: "Guy Laroche", perfumer: "Maurice Roucel", notes: "Lavender, fir, sandalwood, musk", notes_ar: "خزامى، صنوبر، خشب الصندل، مسك" },
   { name: "Giorgio", brand: "Giorgio Beverly Hills", perfumer: "Bernard Chant", notes: "Florals, peach, tuberose, patchouli", notes_ar: "زهور، خوخ، توبروز، باتشولي" },
   { name: "Poison", brand: "Dior", perfumer: "Edmond Roudnitska", notes: "Tuberose, plum, opoponax, musk", notes_ar: "توبروز، برقوق، أوبوبوناكس، مسك" },
   { name: "Obsession", brand: "Calvin Klein", perfumer: "Pierre Bourdon", notes: "Amber, musk, florals, sandalwood", notes_ar: "كهرمان، مسك، زهور، خشب الصندل" },
  ],
  "1990": [
   { name: "CK One", brand: "Calvin Klein", perfumer: "Tetsuro Shimizu", notes: "Green tea, bergamot, musk, sandalwood", notes_ar: "الشاي الأخضر، برغموت، مسك، خشب الصندل" },
   { name: "Angel", brand: "Thierry Mugler", perfumer: "Olivier Cresp", notes: "Patchouli, caramel, chocolate, musk", notes_ar: "باتشولي، كراميل، شوكولاتة، مسك" },
   { name: "L'Eau d'Issey", brand: "Issey Miyake", perfumer: "Jacques Cavallier", notes: "Water, lotus, peony, cedar", notes_ar: "ماء، لوتس، الفاوانيا، أرز" },
   { name: "Tommy", brand: "Tommy Hilfiger", perfumer: "Bernard Chant", notes: "Citrus, spice, musk, amber", notes_ar: "حمضيات، توابل، مسك، كهرمان" },
  ],
  "2000": [
   { name: "Acqua di Giò", brand: "Armani", perfumer: "Michel Almairac", notes: "Bergamot, jasmine, rosemary, cedar", notes_ar: "برغموت، ياسمين، إكليل الجبل، أرز" },
   { name: "Light Blue", brand: "Dolce & Gabbana", perfumer: "Maurice Roucel", notes: "Sicilian lemon, apple, cedar", notes_ar: "الليمون الصقلي، تفاح، أرز" },
   { name: "La Vie Est Belle", brand: "Lancôme", perfumer: "Olivier Cresp", notes: "Iris, praline, patchouli, vanilla", notes_ar: "أيريس، براليني، باتشولي، فانيليا" },
   { name: "Allure", brand: "Chanel", perfumer: "Jacques Polge", notes: "Florals, amber, musk", notes_ar: "زهور، كهرمان، مسك" },
  ],
  "2010": [
   { name: "Santal 33", brand: "Le Labo", perfumer: "Frank Voelkl", notes: "Sandalwood, iris, cardamom, violet", notes_ar: "خشب الصندل، أيريس، الهيل، بنفسج" },
   { name: "Baccarat Rouge 540", brand: "Maison Francis Kurkdjian", perfumer: "Francis Kurkdjian", notes: "Jasmine, saffron, amberwood, fir", notes_ar: "ياسمين، زعفران، خشب الكهرمان، صنوبر" },
   { name: "Black Opium", brand: "Yves Saint Laurent", perfumer: "Anne Flipo", notes: "Coffee, vanilla, white flowers", notes_ar: "قهوة، فانيليا، زهور بيضاء" },
   { name: "Prada L'Homme", brand: "Prada", perfumer: "Olivier Douzou", notes: "Iris, ambroxan, cedar", notes_ar: "أيريس، أمبروكسان، أرز" },
  ],
  "2015": [
   { name: "Aventus", brand: "Creed", perfumer: "Olivier Creed", notes: "Pineapple, blackcurrant, ambroxan", notes_ar: "الأناناس، الكشمش الأسود، أمبروكسان" },
   { name: "Heeley Sel Marin", brand: "Heeley", perfumer: "James Heeley", notes: "Marine, driftwood, ambrette", notes_ar: "بحري، خشب الطوف، أمبريت" },
   { name: "Neroli Portofino", brand: "Tom Ford", perfumer: "Dominique Ropion", notes: "Neroli, bergamot, amber, musks", notes_ar: "نيروليا، برغموت، كهرمان، مسك" },
   { name: "Yves Saint Laurent La Nuit", brand: "Yves Saint Laurent", perfumer: "Aimé Guerlain", notes: "Ylang-ylang, jasmine, sandalwood", notes_ar: "الإيلانج إيلانج، ياسمين، خشب الصندل" },
  ],
  "2020": [
   { name: "Libre", brand: "Yves Saint Laurent", perfumer: "Anne Flipo", notes: "Lavender, orange blossom, vanilla, musk", notes_ar: "خزامى، زهر البرتقال، فانيليا، مسك" },
   { name: "Bleu de Chanel", brand: "Chanel", perfumer: "Jacques Polge", notes: "Citrus, ambroxan, sandalwood", notes_ar: "حمضيات، أمبروكسان، خشب الصندل" },
   { name: "Solstice Scents Autumn Gatherin", brand: "Solstice Scents", perfumer: "Unknown", notes: "Vanilla, amber, spices, nutmeg", notes_ar: "فانيليا، كهرمان، توابل، جوزة الطيب" },
   { name: "Hypnotic Poison", brand: "Dior", perfumer: "Unknown", notes: "Plum, anise, amber, vanilla", notes_ar: "برقوق، يانسون، كهرمان، فانيليا" },
  ],
  "2021": [], "2022": [], "2023": [], "2024": [], "2025": [], "2026": [{ name: "Marhaba", brand: "Arabian", notes: "Merry, Arabian Coffee", notes_ar: "مرح، قهوة عربية" }],
  "2027": [], "2028": [], "2029": [],
  "2030": [], "2031": [], "2032": [], "2033": [], "2034": [], "2035": [],
  "2036": [], "2037": [], "2038": [], "2039": [],
  "2040": [], "2041": [], "2042": [], "2043": [], "2044": [], "2045": [],
  "2046": [], "2047": [], "2048": [], "2049": [],
  "2050": [], "2051": [], "2052": [], "2053": [], "2054": [], "2055": [],
  "2056": [], "2057": [], "2058": [], "2059": [],
  "2060": [], "2061": [], "2062": [], "2063": [], "2064": [], "2065": [],
  "2066": [], "2067": [], "2068": [], "2069": [],
  "2070": [], "2071": [], "2072": [], "2073": [], "2074": [], "2075": [],
  "2076": [], "2077": [], "2078": [], "2079": [],
  "2080": [], "2081": [], "2082": [], "2083": [], "2084": [], "2085": [],
  "2086": [], "2087": [], "2088": [], "2089": [],
  "2090": [], "2091": [], "2092": [], "2093": [], "2094": [], "2095": [],
  "2096": [], "2097": [], "2098": [], "2099": [], "2100": [],
};

// لون hex لكل طور — يُستخدم لملء الماسة ولون نصّ السنة (بلا خلفية/إطار).
const ERA_HEX = {
  amber: "#f59e0b", emerald: "#10b981", violet: "#8b5cf6", sky: "#0ea5e9",
};

const DECADE_HEX = [
  "#f59e0b", "#eab308", "#84cc16", "#10b981",
  "#14b8a6", "#0ea5e9", "#3b82f6", "#8b5cf6",
  "#a855f7", "#f43f5e", "#ec4899", "#f97316",
];

// ماسة موحّدة على الخطّ الزمنيّ (نفس الحجم في كلّ القوائم).
const DIAMOND = "absolute left-[15px] w-2 h-2 rotate-45 z-10";
const GOLD_LINE = "absolute left-[19px] top-0 bottom-0 w-0.5 z-0";
const GOLD_LINE_BG = "linear-gradient(to bottom, rgba(200,160,46,.18), var(--brand), rgba(200,160,46,.18))";

export default function PerfumeTimeline({ embedded = false }) {
  const [activeTab, setActiveTab] = useState("pehistory");
  const { isAr } = useLang();
  const [expanded, setExpanded] = useState(() => {
    // المجموعتان: الماضي/الحاضر (≤2028) موسّعة افتراضياً،
    // المستقبل (2029–2100) مطويّة افتراضياً.
    return { "grp-past": true, "grp-future": false };
  });

  const { data: dbPerfumes = [] } = useQuery({
    queryKey: ["perfumes-timeline"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: 10 * 60 * 1000,
    enabled: activeTab === "mycollection", // يُجلب فقط عند فتح تبويب مجموعتي
  });

  // مجموعة المستخدم الفعلية (UserPerfume) — لتبويب "مجموعتي"
  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  // فهرس العطور للوصول السريع بالـ id
  const perfumeById = useMemo(() => {
    const m = {};
    for (const p of dbPerfumes) m[String(p.id)] = p;
    return m;
  }, [dbPerfumes]);

  // "مجموعتي": عطور المستخدم الحقيقية مجمّعة حسب سنة الإضافة للمجموعة.
  // (سابقاً كان يعرض كل عطور القاعدة — وهو خطأ.)
  const perfumesByYear = useMemo(() => {
    const map = {};
    userPerfumes.forEach((u) => {
      const real = perfumeById[String(u.perfume_id)];
      const dateStr = u.created_date || real?.created_date;
      if (!dateStr) return;
      const year = dateStr.slice(0, 4);
      // ندمج بيانات العطر الحقيقي مع تقييم المستخدم
      const merged = real ? { ...real, rating: u.rating || real.rating } : { id: u.perfume_id, name: u.perfume_name, brand_name: u.brand_name, rating: u.rating };
      if (!map[year]) map[year] = [];
      // تفادي التكرار لو أُضيف العطر لأكثر من شخص
      if (!map[year].some((x) => String(x.id) === String(merged.id))) map[year].push(merged);
    });
    return map;
  }, [userPerfumes, perfumeById]);

  const sortedYears = useMemo(() => Object.keys(perfumesByYear).sort(), [perfumesByYear]);

  // مجموعتان: الماضي/الحاضر (≤2028) — تظهر فيها فقط السنوات التي بها عطور
  // (مزروعة أو خصّصها المستخدم)، لا سنوات فارغة. والمستقبل (2029–2100).
  // ملاحظة: يجب أن تُعرَّف قبل الـuseEffect الذي يعتمد عليها في مصفوفة الاعتماد،
  // وإلا وقع خطأ "Cannot access before initialization" عند أول رسم فتنهار الصفحة.
  const { pastEntries, futureEntries } = useMemo(() => {
    let stored = {};
    try { stored = typeof window !== 'undefined' ? JSON.parse(localStorage.getItem("TIMELINE_DATA") || "{}") : {}; } catch { stored = {}; } // مفتاح فاسد لا يُسقط الصفحة
    const allYears = new Set([
      ...Object.keys(YEARLY_TOP_PERFUMES),
      ...Object.keys(stored).filter(y => stored[y]?.some(p => p.name)),
    ]);
    const toNum = (y) => {
      const n = parseInt(String(y).replace(" BC", "").replace(" AD", "")) || 0;
      return String(y).includes("BC") ? -n : n;
    };
    const entries = Array.from(allYears)
      .sort((a, b) => toNum(a) - toNum(b))
      .map((year) => ({
        year,
        n: toNum(year),
        perfumes: (stored[year]?.filter(p => p.name).length > 0
          ? stored[year]
          : (YEARLY_TOP_PERFUMES[year] || [])).filter(p => p.name),
      }));
    const past = entries.filter((e) => e.n <= 2028 && e.perfumes.length > 0); // الماضي: فقط ما فيه عطور
    const future = entries.filter((e) => e.n >= 2029 && e.n <= 2100);          // المستقبل: 2029–2100
    return { pastEntries: past, futureEntries: future };
  }, []);

  // ── ربط عطور الخطّ الزمنيّ بصفحاتها في الكتالوج (بلا تحميل 130 ألف) ──
  // لكلّ عطرٍ معروض نبحث عن مطابقٍ في الكتالوج عبر فهرس الاسم (قراءة موجَّهة
  // بمدى مفتاح، تقرأ السجلّ المطابق فقط). نخزّن النتيجة (معرّف أو null) فلا
  // نُعيد البحث. يعمل لعطر المثال «Marhaba» وأيّ عطرٍ يطابق اسمه الكتالوج تماماً.
  const [resolvedIds, setResolvedIds] = useState({}); // "name|brand" → id | null
  const resolveKey = (name, brand) => `${name || ""}|${brand || ""}`;
  const resolvePerfumeId = async (name, brand) => {
    const variants = [...new Set([name, String(name || "").toUpperCase(), String(name || "").toLowerCase()])].filter(Boolean);
    for (const v of variants) {
      try {
        const { items } = await apphost.entities.Perfume.pageByIndexRange("name", { only: v }, 0, 8, "next", false);
        if (items && items.length) {
          const pick = brand
            ? items.find((p) => String(p.brand_name || "").toLowerCase() === String(brand).toLowerCase()) || items[0]
            : items[0];
          if (pick && pick.id != null) return String(pick.id);
        }
      } catch { /* الفهرس غائب أو خطأ — نتجاهل ونُبقي العطر غير قابل للضغط */ }
    }
    return null;
  };

  // حلّ العطور الظاهرة فقط (السنوات الموسّعة) كسولاً عند فتحها.
  useEffect(() => {
    const visible = [];
    for (const list of [pastEntries, futureEntries]) {
      for (const entry of list) {
        if (!expanded[`yb-${entry.year}`]) continue;
        for (const pf of entry.perfumes) {
          if (pf.id) continue; // معرّفه جاهز
          const k = resolveKey(pf.name, pf.brand);
          if (k in resolvedIds) continue; // حُلّ سابقاً
          visible.push({ k, name: pf.name, brand: pf.brand });
        }
      }
    }
    if (!visible.length) return;
    let cancelled = false;
    (async () => {
      const updates = {};
      for (const v of visible) updates[v.k] = await resolvePerfumeId(v.name, v.brand);
      if (!cancelled) setResolvedIds((prev) => ({ ...prev, ...updates }));
    })();
    return () => { cancelled = true; };
  }, [expanded, pastEntries, futureEntries]);


  const toggle = (key) => setExpanded((p) => ({ ...p, [key]: !p[key] }));

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className={embedded ? "px-1 py-2 flex items-start gap-3" : "bg-white rounded-none px-4 py-4 flex items-start gap-3"}>
        <div>
          <p className="font-heading font-bold text-sm" style={embedded ? { color: "var(--brand)" } : undefined}>أطوار العطور Perfume Timeline</p>
          {embedded ? (
            <>
              <p className="text-[11px] font-body leading-relaxed mt-0.5" style={{ color: "var(--brand)" }}>4000 Years of Fragrance History</p>
              <p className="text-[11px] font-body leading-relaxed" dir="rtl" style={{ color: "var(--brand)", opacity: 0.85 }}>4000 عام من تاريخ العطور</p>
            </>
          ) : (
            <p className="text-[11px] text-muted-foreground font-body leading-relaxed mt-0.5">
              6,000 years of fragrance history · top fragrances 1889-2026 · your collection by year
            </p>
          )}
        </div>
      </div>

      {/* Sub-tabs */}
      <div className={embedded ? "flex gap-4" : "flex gap-2"}>
        {[
          { id: "pehistory", label: "Perfume Book", icon: "📖" },
          { id: "mycollection", label: "My Collection", icon: "🫧" },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id)}
            className={embedded
              ? "flex items-center gap-1.5 py-1.5 px-1 text-xs font-body transition-all hover:opacity-70"
              : `flex-1 flex items-center justify-center gap-1.5 py-2 rounded-none text-[11px] font-body font-medium transition-all ${activeTab === t.id ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            style={embedded ? { color: "var(--brand)", fontWeight: activeTab === t.id ? 700 : 400, opacity: activeTab === t.id ? 1 : 0.5 } : undefined}
          >
            <span>{t.icon}</span> {t.label}
          </button>
        ))}
      </div>

      {/* ── PEHISTORY TAB (History + Top Perfume Combined) ── */}
      {activeTab === "pehistory" && (
        <div className="relative">
          <div className={GOLD_LINE} style={{ background: GOLD_LINE_BG }} />

          <div className="space-y-0">
            {HISTORY.map((item, i) => {
              const isExp = expanded[`h-${i}`];
              const hex = ERA_HEX[item.color] || "var(--brand)";
              return (
                <div key={i} className="relative pl-11 pb-3">
                  <div className={DIAMOND} style={{ top: "10px", background: hex }} />

                  <button
                    onClick={() => toggle(`h-${i}`)}
                    className="w-full text-left rounded-none px-1 py-2 space-y-1.5 hover:opacity-80 transition-opacity"
                    style={{ borderBottom: "1px solid rgba(200,160,46,0.22)" }}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-body font-bold" style={{ color: hex, fontSize: "12px" }}>
                          {item.year}
                        </span>
                        <span className="text-xs font-body font-semibold">{item.label}</span>
                      </div>
                      {isExp ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />}
                    </div>
                    {/* الوردة مرّة واحدة، ثمّ الإنجليزي LTR بلا أيقونة، ثمّ العربي RTL */}
                    <p className="text-[10px] text-muted-foreground font-body">🌸</p>
                    <p className="text-[10px] text-muted-foreground font-body italic" dir="ltr">{item.notes}</p>
                    <p className="text-[10px] text-muted-foreground font-body italic" dir="rtl">{item.notes_ar}</p>
                    {isExp && (
                      <div className="space-y-2 pt-2 mt-2" style={{ borderTop: "1px solid rgba(200,160,46,0.18)" }}>
                        <div className="space-y-1">
                          <p className="text-[10px] font-body font-bold text-primary">English:</p>
                          <p className="text-xs font-body text-foreground/80 leading-relaxed">{item.desc}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-[10px] font-body font-bold text-primary">العربية:</p>
                          <p className="text-xs font-body text-foreground/80 leading-relaxed">{item.desc_ar}</p>
                        </div>

                      </div>
                    )}
                  </button>
                </div>
              );
            })}

            {/* ── المجموعة الأولى: 6000 ق.م – 2028 (غير مطوية افتراضياً) ── */}
            <div className="relative pl-11 pb-2">
              <button
                onClick={() => toggle("grp-past")}
                className="w-full flex items-center justify-between gap-2 px-1 py-2 hover:opacity-80 transition-opacity"
                style={{ borderBottom: "1px solid rgba(200,160,46,0.3)" }}
              >
                <span className="text-xs font-body font-semibold text-primary">
                  {isAr ? "حتى ٢٠٢٨ 6000 BC – 2028" : "6000 BC – 2028"}
                </span>
                {expanded["grp-past"] ? <ChevronUp className="w-4 h-4 text-primary flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-primary flex-shrink-0" />}
              </button>
            </div>

            {expanded["grp-past"] && pastEntries.map((entry, yi) => {
              const hex = DECADE_HEX[yi % DECADE_HEX.length];
              const isYearExp = expanded[`yb-${entry.year}`];
              return (
                <div key={entry.year} className="relative pl-11 pb-3">
                  <div className={DIAMOND} style={{ top: "11px", background: hex }} />
                  <div className="space-y-1.5">
                    <button
                      onClick={() => toggle(`yb-${entry.year}`)}
                      className="w-full flex items-center justify-between gap-2 px-1 py-1.5 hover:opacity-80 transition-opacity"
                      style={{ borderBottom: "1px solid rgba(200,160,46,0.2)" }}
                    >
                      <span className="font-body font-bold" style={{ color: hex, fontSize: "12px" }}>{entry.year}</span>
                      {isYearExp ? <ChevronUp className="w-3 h-3 text-muted-foreground flex-shrink-0" /> : <ChevronDown className="w-3 h-3 text-muted-foreground flex-shrink-0" />}
                    </button>
                    {isYearExp && <div className="space-y-0 pl-1">
                       {entry.perfumes.map((pf, pi) => {
                          // معرّف العطر في الكتالوج: جاهز (pf.id) أو محلول عبر فهرس الاسم.
                          const linkedId = pf.id || resolvedIds[resolveKey(pf.name, pf.brand)] || null;
                          const fam = pf.odor_family || pf.notes;
                          const famAr = pf.notes_ar || pf.odor_family || pf.notes;
                          return (
                            <Link key={pi} to={linkedId ? `/perfume?id=${linkedId}` : "#"}
                              className={`block px-1 py-2 space-y-0.5 transition-opacity ${linkedId ? 'hover:opacity-70' : 'opacity-60'}`}
                              style={{ borderBottom: "1px solid rgba(200,160,46,0.16)" }}>
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <p className="text-xs font-body font-semibold" style={{ color: "#2E7D32" }}>{pf.name}</p>
                                  <p className="text-[10px] text-muted-foreground font-body">{pf.brand}</p>
                                </div>
                                <Star className={`w-3 h-3 flex-shrink-0 mt-1 ${linkedId ? 'text-amber-400' : 'text-muted-foreground/30'}`} />
                              </div>
                              {/* الوردة مرّة واحدة، ثمّ الإنجليزي LTR بلا أيقونة، ثمّ العربي RTL */}
                              {(fam || famAr) && <p className="text-[10px] text-muted-foreground font-body">🌸</p>}
                              {fam && <p className="text-[10px] text-muted-foreground font-body" dir="ltr">{fam}</p>}
                              {famAr && famAr !== fam && <p className="text-[10px] text-muted-foreground font-body" dir="rtl">{famAr}</p>}
                            </Link>
                          );
                        })}
                      </div>}
                  </div>
                </div>
              );
            })}

            {/* ── المجموعة الثانية: 2029 – 2100 (مطوية افتراضياً) ── */}
            <div className="relative pl-11 pb-2">
              <button
                onClick={() => toggle("grp-future")}
                className="w-full flex items-center justify-between gap-2 px-1 py-2 hover:opacity-80 transition-opacity"
                style={{ borderBottom: "1px solid rgba(14,165,233,0.35)" }}
              >
                <span className="text-xs font-body font-semibold text-sky-700 dark:text-sky-400">
                  {isAr ? "المستقبل 2029 – 2100" : "2029 – 2100"}
                </span>
                {expanded["grp-future"] ? <ChevronUp className="w-4 h-4 text-sky-600 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-sky-600 flex-shrink-0" />}
              </button>
            </div>

            {expanded["grp-future"] && futureEntries.map((entry, yi) => {
              const hex = DECADE_HEX[yi % DECADE_HEX.length];
              const isYearExp = expanded[`yb-${entry.year}`];
              return (
                <div key={entry.year} className="relative pl-11 pb-3">
                  <div className={DIAMOND} style={{ top: "11px", background: hex }} />
                  <div className="space-y-1.5">
                    <button
                      onClick={() => toggle(`yb-${entry.year}`)}
                      className="w-full flex items-center justify-between gap-2 px-1 py-1.5 hover:opacity-80 transition-opacity"
                      style={{ borderBottom: "1px solid rgba(200,160,46,0.2)" }}
                    >
                      <span className="font-body font-bold" style={{ color: hex, fontSize: "12px" }}>{entry.year}</span>
                      {isYearExp ? <ChevronUp className="w-3 h-3 text-muted-foreground flex-shrink-0" /> : <ChevronDown className="w-3 h-3 text-muted-foreground flex-shrink-0" />}
                    </button>
                    {isYearExp && <div className="space-y-0 pl-1">
                       {entry.perfumes.length === 0 ? (
                         <p className="text-base px-2 py-1">🤔</p>
                       ) : entry.perfumes.map((pf, pi) => {
                          // معرّف العطر في الكتالوج: جاهز (pf.id) أو محلول عبر فهرس الاسم.
                          const linkedId = pf.id || resolvedIds[resolveKey(pf.name, pf.brand)] || null;
                          const fam = pf.odor_family || pf.notes;
                          const famAr = pf.notes_ar || pf.odor_family || pf.notes;
                          return (
                            <Link key={pi} to={linkedId ? `/perfume?id=${linkedId}` : "#"}
                              className={`block px-1 py-2 space-y-0.5 transition-opacity ${linkedId ? 'hover:opacity-70' : 'opacity-60'}`}
                              style={{ borderBottom: "1px solid rgba(200,160,46,0.16)" }}>
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <p className="text-xs font-body font-semibold" style={{ color: "#2E7D32" }}>{pf.name}</p>
                                  <p className="text-[10px] text-muted-foreground font-body">{pf.brand}</p>
                                </div>
                                <Star className={`w-3 h-3 flex-shrink-0 mt-1 ${linkedId ? 'text-amber-400' : 'text-muted-foreground/30'}`} />
                              </div>
                              {/* الوردة مرّة واحدة، ثمّ الإنجليزي LTR بلا أيقونة، ثمّ العربي RTL */}
                              {(fam || famAr) && <p className="text-[10px] text-muted-foreground font-body">🌸</p>}
                              {fam && <p className="text-[10px] text-muted-foreground font-body" dir="ltr">{fam}</p>}
                              {famAr && famAr !== fam && <p className="text-[10px] text-muted-foreground font-body" dir="rtl">{famAr}</p>}
                            </Link>
                          );
                        })}
                      </div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── MY COLLECTION TAB ── */}
      {activeTab === "mycollection" && (
        <div>
          {sortedYears.length === 0 ? (
            <div className="text-center py-16 space-y-2">
              <Droplets className="w-10 h-10 text-primary/20 mx-auto" />
              <p className="text-sm font-body text-muted-foreground">لا عطور في قاعدتك بعد No perfumes in your database yet.</p>
              <Link to="/add" className="text-xs text-primary font-body underline">أضف أول عطر لك Add your first perfume</Link>
            </div>
          ) : (
            <div className="relative">
              <div className={GOLD_LINE} style={{ background: GOLD_LINE_BG }} />

              <div className="space-y-0">
                {sortedYears.map((year, yi) => {
                  const items = perfumesByYear[year];
                  const isExp = expanded[`y-${year}`];
                  const hex = DECADE_HEX[yi % DECADE_HEX.length];
                  return (
                    <div key={year} className="relative pl-11 pb-3">
                      <div className={DIAMOND} style={{ top: "11px", background: hex }} />

                      <button
                        onClick={() => toggle(`y-${year}`)}
                        className="w-full text-left"
                      >
                        <div className="flex items-center justify-between px-1 py-2 hover:opacity-80 transition-opacity" style={{ borderBottom: "1px solid rgba(200,160,46,0.2)" }}>
                          <div className="flex items-center gap-2">
                            <span className="font-body font-bold" style={{ color: hex, fontSize: "12px" }}>
                              {year}
                            </span>
                            <span className="text-xs font-body text-muted-foreground">
                              {items.length} {items.length === 1 ? "perfume" : "perfumes"} added
                            </span>
                          </div>
                          {isExp ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />}
                        </div>
                      </button>

                      {isExp && (
                        <div className="mt-1 space-y-0 pl-1">
                          {items.map((p) => (
                            <Link
                              key={p.id}
                              to={`/perfume?id=${p.id}`}
                              className="flex items-center gap-3 px-1 py-2.5 hover:opacity-70 transition-opacity"
                              style={{ borderBottom: "1px solid rgba(200,160,46,0.16)" }}
                            >
                              {p.image_url ? (
                                <img src={p.image_url} alt={p.name} className="w-9 h-9 rounded-none object-cover flex-shrink-0" />
                              ) : (
                                <div className="w-9 h-9 rounded-none bg-primary/10 flex items-center justify-center flex-shrink-0">
                                  <Droplets className="w-4 h-4 text-primary/50" />
                                </div>
                              )}
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-body font-semibold truncate" style={{ color: "#2E7D32" }}>{p.name}</p>
                                <p className="text-[10px] text-muted-foreground font-body truncate">{p.brand_name}</p>
                                {p.top_notes && (
                                  <p className="text-[10px] text-muted-foreground font-body italic truncate">🌸 {p.top_notes}</p>
                                )}
                              </div>
                              {p.rating > 0 && (
                                <div className="flex-shrink-0 text-[10px] font-body font-bold" style={{ color: "var(--brand)" }}>{"■".repeat(Math.round(p.rating))}{"□".repeat(Math.max(0, 5 - Math.round(p.rating)))}</div>
                              )}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {(activeTab === "pehistory" || activeTab === "mycollection") && (
        <p className="text-center text-[10px] text-muted-foreground font-body pb-2">
          You Can Make Something Great — تستطيع خلق أشياء عظيمة
        </p>
      )}
    </div>
  );
}