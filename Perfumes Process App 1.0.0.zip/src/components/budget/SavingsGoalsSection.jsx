import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { X, Pencil, PiggyBank } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const GOAL_ICONS = {
  vacation: "✈️", emergency: "🚨", investment: "📈", purchase: "🛍",
  education: "🎓", home: "🏠", car: "🚗", other: "🎯",
};

export default function SavingsGoalsSection({ selectedPerson, isAr, currency, names, currentBalance = 0 }) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({});
  const [addAmountFor, setAddAmountFor] = useState(null);
  const [addAmountValue, setAddAmountValue] = useState("");
  const qc = useQueryClient();

  const { data: goals = [] } = useQuery({
    queryKey: ["savings-goals"],
    queryFn: () => apphost.entities.SavingsGoal.list("-target_date"),
  });

  const invalidate = () => qc.invalidateQueries({ queryKey: ["savings-goals"] });

  const createGoal = useMutation({
    mutationFn: (data) => apphost.entities.SavingsGoal.create(data),
    onSuccess: () => { invalidate(); setDialogOpen(false); setFormData({}); setEditingId(null); toast.success(isAr ? "\u2705 \u062a\u0645\u062a \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0647\u062f\u0641" : "\u2705 Goal added"); },
    onError: (e) => toast.error((isAr ? "\u0641\u0634\u0644: " : "Failed: ") + (e?.message || "")),
  });

  const updateGoal = useMutation({
    mutationFn: ({ id, data }) => apphost.entities.SavingsGoal.update(id, data),
    onSuccess: () => { invalidate(); setDialogOpen(false); setFormData({}); setEditingId(null); setAddAmountFor(null); setAddAmountValue(""); toast.success(isAr ? "\u2705 \u062a\u0645 \u0627\u0644\u062a\u062d\u062f\u064a\u062b" : "\u2705 Updated"); },
    onError: (e) => toast.error((isAr ? "\u0641\u0634\u0644: " : "Failed: ") + (e?.message || "")),
  });

  const deleteGoal = useMutation({
    mutationFn: (id) => apphost.entities.SavingsGoal.delete(id),
    onSuccess: () => { invalidate(); toast.success(isAr ? "\u062d\u064f\u0630\u0641 \u0627\u0644\u0647\u062f\u0641" : "Goal removed"); },
  });

  const filteredGoals = goals.filter(
    (g) => (selectedPerson === "all" || g.person === selectedPerson) && g.is_active
  );

  const openNew = () => { setEditingId(null); setFormData({}); setDialogOpen(true); };

  const openEdit = (g) => {
    setEditingId(g.id);
    setFormData({
      title: g.title,
      target_amount: String(g.target_amount ?? ""),
      current_amount: String(g.current_amount ?? ""),
      target_date: g.target_date,
      category: g.category || "other",
      description: g.description || "",
    });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!formData.title || !formData.target_amount || !formData.target_date) {
      toast.error(isAr ? "\u0623\u0643\u0645\u0644 \u0627\u0644\u0639\u0646\u0648\u0627\u0646 \u0648\u0627\u0644\u0645\u0628\u0644\u063a \u0648\u0627\u0644\u062a\u0627\u0631\u064a\u062e" : "Fill title, amount and date");
      return;
    }
    const payload = {
      title: formData.title,
      person: formData.person || (selectedPerson === "all" ? "family" : selectedPerson),
      target_amount: parseFloat(formData.target_amount),
      current_amount: parseFloat(formData.current_amount) || 0,
      target_date: formData.target_date,
      category: formData.category || "other",
      icon: GOAL_ICONS[formData.category || "other"],
      description: formData.description || "",
      is_active: true,
    };
    if (editingId) updateGoal.mutate({ id: editingId, data: payload });
    else createGoal.mutate(payload);
  };

  const handleAddAmount = (goal) => {
    const add = parseFloat(addAmountValue);
    if (!add || add <= 0) {
      toast.error(isAr ? "\u0623\u062f\u062e\u0644 \u0645\u0628\u0644\u063a\u0627\u064b \u0635\u062d\u064a\u062d\u0627\u064b" : "Enter a valid amount");
      return;
    }
    updateGoal.mutate({ id: goal.id, data: { current_amount: (goal.current_amount || 0) + add } });
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-heading font-semibold">{isAr ? "\u0623\u0647\u062f\u0627\u0641 \u0627\u0644\u0627\u062f\u062e\u0627\u0631" : "Savings Goals"}</p>
        <Button size="sm" variant="ghost" className="h-7 px-2.5 text-xs rounded-none text-primary hover:text-primary" onClick={openNew}>
          {"Add \u0625\u0636\u0627\u0641\u0629"}
        </Button>
      </div>

      {filteredGoals.length === 0 ? (
        <div className="text-center py-5">
          <p className="text-xs text-muted-foreground font-body">{isAr ? "\u0644\u0627 \u062a\u0648\u062c\u062f \u0623\u0647\u062f\u0627\u0641 \u0627\u062f\u062e\u0627\u0631" : "No savings goals yet"}</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filteredGoals.map((goal) => {
            const daysLeft = Math.ceil((new Date(goal.target_date) - new Date()) / (1000 * 60 * 60 * 24));
            const progress = goal.target_amount > 0 ? (goal.current_amount / goal.target_amount) * 100 : 0;
            const isCompleted = progress >= 100;
            const isAdding = addAmountFor === goal.id;
            return (
              <div key={goal.id} className="py-3 border-b border-border/40 last:border-b-0 space-y-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-2 flex-1 min-w-0">
                    <span className="text-lg">{goal.icon || GOAL_ICONS[goal.category] || "\ud83c\udfaf"}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-body font-semibold truncate">{goal.title}</p>
                      <p className="text-[10px] text-muted-foreground">
                        {isAr ? "\u0627\u0644\u0647\u062f\u0641:" : "Target:"} {(goal.target_amount || 0).toFixed(0)} {currency}
                        {daysLeft > 0 && ` | ${daysLeft} ${isAr ? "\u064a\u0648\u0645" : "days"}`}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0">
                    <button onClick={() => openEdit(goal)} className="w-6 h-6 rounded-none flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-secondary/60 transition-colors">
                      <Pencil className="w-3 h-3" />
                    </button>
                    <button onClick={() => deleteGoal.mutate(goal.id)} className="w-6 h-6 rounded-none flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="w-full h-2 bg-secondary rounded-none overflow-hidden">
                    <div className={cn("h-full transition-all duration-500", isCompleted ? "bg-gradient-to-r from-emerald-400 to-emerald-600" : "bg-gradient-to-r from-primary to-primary/60")} style={{ width: `${Math.min(progress, 100)}%` }} />
                  </div>
                  <div className="flex justify-between text-[10px] text-muted-foreground font-body">
                    <span>{(goal.current_amount || 0).toFixed(0)} {currency}</span>
                    <span>{progress.toFixed(0)}%</span>
                  </div>
                </div>

                {isAdding ? (
                  <div className="flex items-center gap-2">
                    <Input type="number" autoFocus placeholder={isAr ? "\u0627\u0644\u0645\u0628\u0644\u063a \u0627\u0644\u0645\u064f\u062f\u062e\u0631" : "Saved amount"} value={addAmountValue} onChange={(e) => setAddAmountValue(e.target.value)} className="rounded-none h-8 text-xs flex-1" />
                    <Button size="sm" className="h-8 rounded-none text-xs px-3" onClick={() => handleAddAmount(goal)} disabled={updateGoal.isPending}>
                      {isAr ? "\u0625\u0636\u0627\u0641\u0629" : "Add"}
                    </Button>
                    <Button size="sm" variant="ghost" className="h-8 rounded-none text-xs px-2" onClick={() => { setAddAmountFor(null); setAddAmountValue(""); }}>
                      {isAr ? "\u0625\u0644\u063a\u0627\u0621" : "Cancel"}
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 flex-wrap">
                    <button onClick={() => { setAddAmountFor(goal.id); setAddAmountValue(""); }} className="flex items-center gap-1 text-[11px] font-body font-medium text-primary hover:underline">
                      <PiggyBank className="w-3.5 h-3.5" /> {isAr ? "\u0623\u0636\u0641 \u0645\u0628\u0644\u063a\u0627\u064b \u0645\u064f\u062f\u062e\u0631\u0627\u064b" : "Add saved amount"}
                    </button>
                    {currentBalance > 0 && (
                      <button
                        onClick={() => updateGoal.mutate({ id: goal.id, data: { current_amount: (goal.current_amount || 0) + currentBalance } })}
                        className="text-[10px] font-body text-muted-foreground hover:text-primary"
                      >
                        +{currentBalance.toFixed(0)} {currency}
                      </button>
                    )}
                  </div>
                )}

                {isCompleted && (
                  <div className="bg-emerald-50 dark:bg-emerald-900/20 rounded px-2 py-1">
                    <p className="text-[10px] font-body text-emerald-700 dark:text-emerald-300 text-center">✓ {isAr ? "تم تحقيق الهدف" : "Goal Achieved"}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={(o) => { setDialogOpen(o); if (!o) { setEditingId(null); setFormData({}); } }}>
        <DialogContent className="max-w-sm w-[calc(100vw-2rem)] rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {editingId ? (isAr ? "\ud83c\udfaf \u062a\u0639\u062f\u064a\u0644 \u0627\u0644\u0647\u062f\u0641" : "\ud83c\udfaf Edit Goal") : (isAr ? "\ud83c\udfaf \u0625\u0636\u0627\u0641\u0629 \u0647\u062f\u0641 \u0627\u062f\u062e\u0627\u0631" : "\ud83c\udfaf Add Savings Goal")}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {/* محدّد الشخص — أول خيار */}
            <div>
              <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">{isAr ? "لِمَن" : "For"}</p>
              <div className="grid grid-cols-3 gap-1">
                {[
                  { val: "family", label: isAr ? "العائلة" : "Family" },
                  { val: "person1", label: names?.person1 || (isAr ? "أنا" : "User A") },
                  { val: "person2", label: names?.person2 || (isAr ? "الشريك" : "User B") },
                ].map(({ val, label }) => {
                  const cur = formData.person || (selectedPerson === "all" ? "family" : selectedPerson);
                  const active = cur === val;
                  return (
                    <button key={val} type="button" onClick={() => setFormData({ ...formData, person: val })}
                      className={`py-1.5 text-xs font-body rounded-none transition-colors ${active ? "bg-primary/15 text-primary font-semibold" : "bg-transparent text-muted-foreground hover:text-foreground"}`}>
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>
            <Input placeholder={isAr ? "\u0639\u0646\u0648\u0627\u0646 \u0627\u0644\u0647\u062f\u0641" : "Goal title"} value={formData.title || ""} onChange={(e) => setFormData({ ...formData, title: e.target.value })} className="rounded-none h-10 font-body text-sm" />
            <Input type="number" placeholder={isAr ? "\u0627\u0644\u0645\u0628\u0644\u063a \u0627\u0644\u0645\u0633\u062a\u0647\u062f\u0641" : "Target amount"} value={formData.target_amount || ""} onChange={(e) => setFormData({ ...formData, target_amount: e.target.value })} className="rounded-none h-10 font-body text-sm" />
            <Input type="number" placeholder={isAr ? "\u0627\u0644\u0645\u0628\u0644\u063a \u0627\u0644\u0645\u064f\u062f\u062e\u0631 \u062d\u0627\u0644\u064a\u0627\u064b" : "Current saved amount"} value={formData.current_amount || ""} onChange={(e) => setFormData({ ...formData, current_amount: e.target.value })} className="rounded-none h-10 font-body text-sm" />
            <Input type="date" value={formData.target_date || ""} onChange={(e) => setFormData({ ...formData, target_date: e.target.value })} className="rounded-none h-10 font-body text-sm" />
            <Select value={formData.category || "other"} onValueChange={(v) => setFormData({ ...formData, category: v })}>
              <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(GOAL_ICONS).map(([key, icon]) => (
                  <SelectItem key={key} value={key}>{icon} {key}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input placeholder={isAr ? "\u0645\u0644\u0627\u062d\u0638\u0627\u062a (\u0627\u062e\u062a\u064a\u0627\u0631\u064a)" : "Notes (optional)"} value={formData.description || ""} onChange={(e) => setFormData({ ...formData, description: e.target.value })} className="rounded-none h-10 font-body text-sm" />
            <Button className="w-full h-10 rounded-none" onClick={handleSave} disabled={createGoal.isPending || updateGoal.isPending}>
              {(createGoal.isPending || updateGoal.isPending) ? (isAr ? "\u062c\u0627\u0631\u064d.." : "Saving..") : (editingId ? (isAr ? "\u062d\u0641\u0638 \u0627\u0644\u062a\u0639\u062f\u064a\u0644" : "Save Changes") : (isAr ? "\u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0647\u062f\u0641" : "Add Goal"))}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
