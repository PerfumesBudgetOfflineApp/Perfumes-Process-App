import { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { computeBrandEssence } from "@/lib/brandEssence";
import { occasionInfo } from "@/lib/occasions";
import { MECH, isHealthNote } from "@/lib/headacheRisk";

// خلاصة Essence — كود المكوّن «جوهر/Core». تُعرض داخل جدول وصف البراند، بألوان
// التطبيق و خطوطه و إطاراته (تحترم تخصيص المستخدم). أسماء الصور إنجليزية دائما.
const LEAN_COLOR = { bright: "#E0A82E", dusk: "#5B6CB0", undef: "#C9C3B6" };
// تعتيم أطراف بأسلوب ترجمة الأفلام/CC: هالة بيضاء + حافة سوداء 25% — لقراءة الألوان الفاتحة على أي خلفية
const CC = "0 0 1px rgba(0,0,0,.25), 0 0 2px #fff, 0 0 3px #fff";

// إطار صورة فارغ: خلفية لون التطبيق شفافة + إطار ذهبي يتبع لون التطبيق، بلا حرف/أيقونة
const PLACE = { background: "color-mix(in srgb, var(--brand) 6%, transparent)", borderColor: "color-mix(in srgb, var(--brand) 55%, transparent)" };

function Bar({ label, sub, pct, barColor, textColor, icons, hidePct }) {
  const tc = textColor ? { color: textColor, textShadow: CC } : undefined;
  return (
    <div className="space-y-1">
      <div className="flex items-baseline gap-1.5">
        {!hidePct && <span className={"font-body text-[9px] tabular-nums shrink-0 " + (textColor ? "" : "text-muted-foreground")} style={tc}>{pct}%</span>}
        {icons}
        <span className="font-body text-[13px]" style={tc}>{label}{sub ? <span className="text-muted-foreground text-[10px]"> {sub}</span> : null}</span>
      </div>
      <div className="h-2" style={{ background: "color-mix(in srgb, var(--brand) 10%, transparent)" }}>
        <div className="h-2" style={{ width: `${Math.max(3, pct)}%`, background: barColor || "var(--brand)" }} />
      </div>
    </div>
  );
}

// مؤشّر ملوّن مجزّأ (كثافة/ثبات)
function Gauge({ level, max, color }) {
  return (
    <div className="flex gap-1 flex-1 max-w-[140px]">
      {Array.from({ length: max }).map((_, i) => (
        <div key={i} className="h-2.5 flex-1" style={{ background: i < level ? color : "color-mix(in srgb, var(--brand) 10%, transparent)" }} />
      ))}
    </div>
  );
}

const Label = ({ ar, en, isAr }) => (
  <p className="text-[10px] font-body font-semibold uppercase tracking-widest" style={{ color: "var(--brand)" }}>
    {isAr ? ar : en} <span className="text-muted-foreground">{isAr ? en : ar}</span>
  </p>
);

const Tile = ({ img, name, onClick, risk }) => (
  <button onClick={onClick} className="flex flex-col gap-0.5 text-center hover:opacity-80 transition-opacity group">
    <div className="w-full aspect-square rounded-none overflow-hidden flex items-center justify-center border" style={{ ...(img ? { borderColor: "var(--border)" } : PLACE), ...(risk ? { borderLeft: "3px solid #6b3f1d" } : {}) }}>
      {img ? <img src={img} alt={name} loading="lazy" className="w-full h-full object-cover" /> : null}
    </div>
    <p className="text-[9px] font-body font-semibold leading-tight line-clamp-2 text-foreground/80 group-hover:underline" dir="ltr">{name}</p>
  </button>
);

export default function BrandCore({ perfumes, allNotes, perfumers }) {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const E = useMemo(() => computeBrandEssence(perfumes, allNotes, perfumers), [perfumes, allNotes, perfumers]);
  if (!E) return null;
  // حماية: إن لم تتوفر بيانات كافية لأي محور، نخفي الخلاصة كاملةً (لا تتعطل الصفحة)
  const leanHasData = (E.lean.bright + E.lean.dusk) > 0;
  const hasContent = E.perfumers.length || E.topNotes.length || E.families.length || E.health.length ||
    E.accords.length || E.occasions.length || E.decades.length || E.density || E.longevity || leanHasData;
  if (!hasContent) return null;

  return (
    <div className="space-y-5 pt-4 mt-1 border-t border-border">
      <h2 className="font-heading text-base font-bold" style={{ color: "var(--brand)" }}>{isAr ? "خلاصة" : "Essence"} <span className="text-muted-foreground font-body text-[11px] font-normal">{isAr ? "Essence" : "خلاصة"}</span></h2>

      {/* مصممي عطور — قبل النوتات */}
      {E.perfumers.length > 0 && (
        <div className="space-y-2">
          <Label ar="مصممي عطور" en="Perfumers" isAr={isAr} />
          <div className="grid grid-cols-5 gap-1.5">
            {E.perfumers.map((p) => <Tile key={p.en} img={p.photo_url} name={p.en} onClick={() => navigate(`/search-results?type=perfumers&q=${encodeURIComponent(p.en)}`)} />)}
          </div>
        </div>
      )}

      {/* نوتات */}
      {E.topNotes.length > 0 && (
        <div className="space-y-2">
          <Label ar="نوتات" en="Notes" isAr={isAr} />
          <div className="grid grid-cols-5 gap-1.5">
            {E.topNotes.map((n) => <Tile key={n.en} img={n.image_url} name={n.en} risk={isHealthNote(n.en)} onClick={() => navigate(`/search-results?type=notes&q=${encodeURIComponent(n.en)}`)} />)}
          </div>
        </div>
      )}

      {/* عائلة عطرية */}
      {E.families.length > 0 && (
        <div className="space-y-2">
          <Label ar="عائلة عطرية" en="Families" isAr={isAr} />
          <div className="flex flex-wrap gap-x-3 gap-y-1.5">{E.families.map((f) => (
            <span key={f.en} className="inline-flex items-baseline gap-1">
              <span className="font-body text-[13px]">{isAr ? (f.ar || f.en) : f.en}</span>
              <span className="font-body text-muted-foreground text-[10px]">{isAr ? f.en : (f.ar || "")}</span>
            </span>
          ))}</div>
        </div>
      )}

      {/* مؤشر صحة — أيقونات الآليات بجانب النسبة */}
      {E.health.length > 0 && (
        <div className="space-y-2">
          <Label ar="مؤشر صحة" en="Health" isAr={isAr} />
          <div className="space-y-2">{E.health.map((h) => (
            <Bar key={h.id} label={isAr ? h.ar : h.en} sub={isAr ? h.en : h.ar} pct={h.pct} barColor="#C2604F" textColor={h.accordColor} hidePct
              icons={(h.mech || []).map((m) => <span key={m} title={isAr ? MECH[m].ar : MECH[m].en} className="text-[10px] leading-none">{MECH[m].emoji}</span>)} />
          ))}</div>
          <p className="font-body text-[10px] text-muted-foreground">{isAr ? "مؤشر توعوي لا طبي" : "Awareness, not medical"}</p>
        </div>
      )}

      {/* مؤشر متشدد — نسبة عطور البراند المُثيرة (صفر تسامح) */}
      {E.strict && E.strict.total > 0 && (
        <div className="flex items-center justify-between gap-2">
          <Label ar="مؤشر متشدد" en="Strict" isAr={isAr} />
          <span className="font-body text-[12px] font-semibold" style={{ color: E.strict.pct >= 50 ? "#C0392B" : E.strict.pct > 0 ? "#8B5E3C" : "#3B6D11", textShadow: CC }}>
            {E.strict.pct > 0 ? (isAr ? "مُثير" : "Flagged") : (isAr ? "آمن" : "Clear")}
          </span>
        </div>
      )}

      {/* كثافة — مؤشّر ملوّن */}
      {E.density && (
        <div className="flex items-center justify-between gap-3">
          <Label ar="كثافة" en="Density" isAr={isAr} />
          <span className="font-body text-[12px] font-semibold" style={{ color: E.density.color, textShadow: CC }}>{isAr ? E.density.ar : E.density.en}</span>
          <Gauge level={E.density.level} max={E.density.max} color={E.density.color} />
        </div>
      )}

      {/* ثبات — مؤشّر ملوّن */}
      {E.longevity && (
        <div className="flex items-center justify-between gap-3">
          <Label ar="ثبات" en="Longevity" isAr={isAr} />
          <span className="font-body text-[12px] font-semibold" style={{ color: E.longevity.color, textShadow: CC }}>{isAr ? E.longevity.ar : E.longevity.en}</span>
          <Gauge level={E.longevity.level} max={E.longevity.max} color={E.longevity.color} />
        </div>
      )}

      {/* ميل — إشراق / غسق / غير محدد (يظهر فقط عند توفر بيانات وقت اليوم) */}
      {leanHasData && (
      <div className="space-y-2">
        <Label ar="ميل" en="Lean" isAr={isAr} />
        <div className="flex h-2.5 w-full overflow-hidden">
          {["bright", "dusk", "undef"].map((k) => E.lean[k] > 0 && <div key={k} style={{ width: `${E.lean[k]}%`, background: LEAN_COLOR[k] }} />)}
        </div>
        <div className="flex flex-wrap gap-x-4 gap-y-1 text-[11px] font-body text-muted-foreground">
          <span style={{ color: LEAN_COLOR.bright, textShadow: CC }}>{isAr ? "إشراق" : "Bright"} {E.lean.bright}%</span>
          <span style={{ color: LEAN_COLOR.dusk, textShadow: CC }}>{isAr ? "غسق" : "Dusk"} {E.lean.dusk}%</span>
          <span>{isAr ? "غير محدد" : "Undefined"} {E.lean.undef}%</span>
        </div>
      </div>
      )}

      {/* أكوردات */}
      {E.accords.length > 0 && (
        <div className="space-y-2">
          <Label ar="أكوردات" en="Accords" isAr={isAr} />
          {/* صندوق الأكورد المسيطر — مطابق لصفحة العطر: حدّ بلون المسيطر، تعبئة خفيفة، الباقي نصّ ملوّن */}
          <div style={{ border: `1.5px solid ${E.accords[0].barColor}`, background: E.accords[0].barColor + "14", padding: "8px 12px" }}>
            <div className="font-body text-[13px] font-bold" style={{ color: E.accords[0].barColor, textShadow: CC }}>
              {String(E.accords[0].en || "").toUpperCase()}{isAr && E.accords[0].ar ? <span style={{ marginInlineStart: 6 }}>{E.accords[0].ar}</span> : null}
            </div>
            {E.accords.length > 1 && (
              <div className="flex flex-wrap gap-x-3.5 gap-y-1 mt-2">
                {E.accords.slice(1).map((a) => (
                  <span key={a.id} className="text-[11px] font-body font-semibold" style={{ color: a.barColor, textShadow: CC }}>
                    {String(a.en || "").toUpperCase()}{isAr && a.ar ? <span style={{ marginInlineStart: 4 }}>{a.ar}</span> : null}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* مناسبات — كاملة بأيقوناتها */}
      {E.occasions.length > 0 && (
        <div className="space-y-2">
          <Label ar="مناسبات" en="Occasions" isAr={isAr} />
          <div className="flex flex-wrap gap-x-4 gap-y-2">
            {E.occasions.map((o) => {
              const info = occasionInfo(o.en || o.ar);
              return (
                <button key={o.en || o.ar} onClick={() => navigate(`/occasion?o=${encodeURIComponent(o.en || o.ar)}`)}
                  className="inline-flex items-center gap-1 text-xs font-body font-medium hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
                  {info && info.emoji && <span className="text-[12px] leading-none">{info.emoji}</span>}
                  <span>{isAr ? (info ? info.ar : (o.ar || o.en)) : (info ? info.en : o.en)}</span>
                  <span className="text-muted-foreground text-[8px]">{o.count}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* عقد */}
      {E.decades.length > 0 && (
        <div className="space-y-2">
          <Label ar="عقد" en="Decade" isAr={isAr} />
          <div className="flex flex-wrap gap-3">
            {E.decades.map((d) => (
              <span key={d.decade} className="inline-flex items-baseline gap-1 font-body text-[13px] font-semibold" style={{ color: "var(--brand)" }}>
                {d.decade}s <span className="text-muted-foreground text-[8px]">{d.pct}%</span>
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
