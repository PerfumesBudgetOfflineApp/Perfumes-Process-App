import { useNavigate } from 'react-router-dom';
import { processes } from '@/lib/indexedDB';

export default function ProcessCard({ process }) {
  const navigate = useNavigate();

  const openProcess = () => {
    navigate(`/process/${process.id}?id=${process.id}`);
  };

  const getStatusStyle = (status) => {
    switch (status) {
      case 'active':
        return 'border-green-100 dark:border-green-900/50 bg-green-50 dark:bg-green-950/30 hover:bg-green-100 dark:hover:bg-green-900/40';
      case 'completed':
        return 'border-emerald-100 dark:border-emerald-900/50 bg-emerald-50 dark:bg-emerald-950/30 hover:bg-emerald-100 dark:hover:bg-emerald-900/40';
      case 'paused':
        return 'border-orange-100 dark:border-orange-900/50 bg-orange-50 dark:bg-orange-950/30 hover:bg-orange-100 dark:hover:bg-orange-900/40';
      default:
        return 'border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/20 hover:bg-slate-100 dark:hover:bg-slate-900/40';
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'text-green-700 dark:text-green-400';
      case 'completed':
        return 'text-emerald-700 dark:text-emerald-400';
      case 'paused':
        return 'text-orange-700 dark:text-orange-400';
      default:
        return 'text-slate-700 dark:text-slate-400';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'active': return '🟢 نشطة';
      case 'completed': return 'مكتملة';
      case 'paused': return '⏸️ موقوفة';
      default: return status;
    }
  };

  const handleDelete = async (e) => {
    e.preventDefault();
    if (window.confirm('هل أنت متأكد من حذف هذه العملية؟')) {
      try {
        await processes.delete(process.id);
        window.location.reload();
      } catch (error) {
        console.error('Failed to delete process:', error);
      }
    }
  };

  return (
    <div
      onClick={openProcess}
      className={`border rounded-none px-4 py-4 cursor-pointer transition-colors ${getStatusStyle(process.status)}`}
    >
      {/* Name and Status */}
      <h3 className="font-body font-semibold text-base mb-2 line-clamp-2">{process.name}</h3>
      <div className="flex items-center justify-between mb-3">
        <span className={`text-xs font-semibold ${getStatusColor(process.status)}`}>
          {getStatusText(process.status)}
        </span>
        <button
          onClick={handleDelete}
          className="text-xs text-red-600 dark:text-red-400 hover:underline font-medium"
        >
          حذف
        </button>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-200 dark:bg-slate-700 rounded-none h-1.5 overflow-hidden">
        <div
          className="bg-amber-500 h-full transition-all duration-300"
          style={{ width: `${process.progress || 0}%` }}
        />
      </div>
    </div>
  );
}