import { useState, useEffect, useRef } from "react";
import { SprayCan } from "lucide-react"; // أيقونة مؤكّدة في 1.16.0
import { Sheet, SheetContent, SheetTrigger, SheetTitle, SheetDescription, SheetClose } from "@/components/ui/sheet";
import { apphost } from "@/api/apphostClient";
import { isNativeTTS, nativeGetVoices } from "@/lib/tts";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { getSecureStorage, setSecureStorage } from "@/lib/storageEncryption";
import { ACCENT_COLORS, BG_COLORS, getAccentColor, getBgColor } from "@/lib/themeColor";
import EncOptionsBar from "@/components/encyclopedia/EncOptionsBar";
import { cn } from "@/lib/utils";
import { STORE_SORT_MODES, getStorePickSort, setStorePickSort, getStorePageSort, setStorePageSort } from "@/lib/storeSort";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Link } from "react-router-dom";
import { useCurrency } from "@/lib/useCurrency";
import { getThemePref, setThemePref } from "@/lib/theme";
import { DEFAULT_USER_MARK } from "@/lib/exportSettings";
import { getReadMode, setReadMode, applyReadMode } from "@/lib/readMode";
import { useOccasionMode } from "@/lib/useOccasionMode";
import { useFrames } from "@/lib/useFrames";
import { clearSearchHistory } from "@/lib/searchHistory";
import UserTotals from "@/components/perfume/UserTotals";
import CombinedTotals from "@/components/perfume/CombinedTotals";

const COLORS = [
  "#10b981", "#8b5cf6", "#f59e0b", "#ef4444", "#3b82f6",
  "#ec4899", "#14b8a6", "#f97316", "#6366f1", "#84cc16",
];

function PersonCard({ personKey, name, profile, onUpdateName, onUpdateProfile }) {
  const { isAr } = useLang();
  const fileRef = useRef();

  const handlePhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await apphost.integrations.Core.UploadFile({ file });
    onUpdateProfile(personKey, "photo", file_url);
  };

  return (
    <div className="py-2 space-y-3">
      <div className="flex items-center gap-3">
        <div className="relative flex-shrink-0">
          <button
            onClick={() => fileRef.current?.click()}
            className="w-14 h-14 rounded-none overflow-hidden flex items-center justify-center hover:opacity-80 transition-opacity"
            style={{ background: "#ffffff", borderBottom: "1.5px solid var(--brand)" }}
          >
            {profile.photo ? (
              <img src={profile.photo} alt={name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center" style={{ background: "#ffffff" }}>
                <SprayCan className="w-6 h-6" strokeWidth={1.6} style={{ color: "#B76E79" }} />
              </div>
            )}
          </button>
          <span className="absolute -bottom-1.5 -right-1.5 w-5 h-5 flex items-center justify-center pointer-events-none" style={{ background: "#ffffff", border: "1px solid var(--brand)" }} aria-hidden="true"><svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="3.2"/></svg></span>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhoto} />
        </div>
        <div className="flex-1 min-w-0">
          <Input
            value={name}
            onChange={(e) => onUpdateName(personKey, e.target.value)}
            className="h-8 rounded-none font-body text-sm"
            placeholder={personKey === "person1" ? "Profile A" : "Profile B"}
          />
        </div>
      </div>
      <div className="space-y-1.5">
        <p className="text-[10px] text-[#2E7D32] font-body">..</p>
        <Textarea
          value={profile.bio}
          onChange={(e) => onUpdateProfile(personKey, "bio", e.target.value)}
          className="min-h-[56px] rounded-none font-body text-xs resize-none"
          placeholder=".."
        />
      </div>
    </div>
  );
}

function Section({ title, open, onToggle, children }) {
  return (
    <div>
      <button type="button" onClick={onToggle} className="ss-grouphead" data-open={open ? "1" : "0"}>
        <span className="ss-gdia" aria-hidden="true" />
        <span className="ss-gtitle">{title}</span>
      </button>
      {open && <div className="space-y-2">{children}</div>}
    </div>
  );
}

// قسم فرعي مطوي داخل قسم رئيسي (A 1.812) — أخف و مزاح للداخل قليلا
function Subsection({ title, open, onToggle, children }) {
  return (
    <div className="ms-3 border-s border-[#e7dfc9] ps-2">
      <button type="button" onClick={onToggle} className="flex items-center gap-1.5 w-full text-start py-1.5 bg-transparent" style={{ border: "none" }}>
        <span className="text-xs font-body font-semibold" style={{ color: "#2E7D32" }}>{title}</span>
      </button>
      {open && <div className="space-y-2 pb-1">{children}</div>}
    </div>
  );
}

export default function SettingsSheet({ children }) {
  const { lang, toggle, setLang, isAr } = useLang();
  const { names, updateName, profiles, updateProfile } = usePersonNames();
  const { currency, setCurrency } = useCurrency();
  const [user, setUser] = useState(null);
  const [userPhoto, setUserPhoto] = useState(null);
  const [themePref, setThemePrefState] = useState(() => getThemePref());
  const [showTabLabels, setShowTabLabels] = useState(() => getSecureStorage("showTabLabels", false));
  // نافذة جلسة التجهيز — localStorage صرف (لا تشفير) لأن مسار الإقلاع يقرأها قبل React
  const [sessionWindow, setSessionWindow] = useState(() => { try { return localStorage.getItem("proc_session_window") || "week"; } catch { return "week"; } });
  // إعدادات المتاجر و المشتريات (A 1.808)
  const [pickSort, setPickSort] = useState(getStorePickSort());
  const [pageSortS, setPageSortS] = useState(getStorePageSort());
  const [readMode, setReadModeState] = useState(() => getReadMode());
  const toggleReadMode = () => { const v = !readMode; setReadModeState(v); setReadMode(v); applyReadMode(v); };
  const [themeColor, setThemeColor] = useState(() => getSecureStorage("themeColor", "default"));
  const [accent, setAccent] = useState(() => getAccentColor());
  const [bgColor, setBgColor] = useState(() => getBgColor());
  const [showMaestro, setShowMaestro] = useState(() => getSecureStorage("showMaestroNav", false));
  const [showActivity, setShowActivity] = useState(() => getSecureStorage("showActivityTimeline", true));
  const [showNavTabSettings, setShowNavTabSettings] = useState(false);
  const [navTabSettings, setNavTabSettings] = useState(() => {
    const defaults = { home: true, perfumes: true, explore: true, shopping: true, progress: true, goals: true, maestro: true };
    const stored = getSecureStorage("navTabSettings", {});
    return Object.fromEntries(Object.keys(defaults).map(k => [k, stored[k] !== false]));
  });
  const [showLinksSettings, setShowLinksSettings] = useState(false);
  const [showPbSettings, setShowPbSettings] = useState(false);
  const [perfOccMode, setPerfOccMode] = useOccasionMode("perfume");
  const [userOccMode, setUserOccMode] = useOccasionMode("user");
  const [frames, setFrame] = useFrames();
  // مجموعات قابلة للطيّ، مطويّة افتراضياً (بلا أسهم — المعيّن في الرأس هو المؤشّر)
  const [grpLinks, setGrpLinks] = useState(false);
  const [grpActions, setGrpActions] = useState(false);
  const [grpProfiles, setGrpProfiles] = useState(false);
  const [grpApp, setGrpApp] = useState(false);
  const [grpStores, setGrpStores] = useState(false);
  const __enc_get = (k, d) => { try { return (typeof localStorage !== "undefined" && localStorage.getItem(k)) || d; } catch { return d; } };
  const [encTitleOrder, setEncTitleOrderS] = useState(() => __enc_get("enc_title_order", "ar_en"));
  const [encSubOrder, setEncSubOrderS] = useState(() => __enc_get("enc_sub_title_order", "lang"));
  const [encSortMode, setEncSortModeS] = useState(() => __enc_get("enc_sort", "newest"));
  const setEncTitleOrder = (o) => { setEncTitleOrderS(o); try { localStorage.setItem("enc_title_order", o); } catch { /* */ } };
  const setEncSubOrder = (o) => { setEncSubOrderS(o); try { localStorage.setItem("enc_sub_title_order", o); } catch { /* */ } };
  const setEncSortMode = (o) => { setEncSortModeS(o); try { localStorage.setItem("enc_sort", o); } catch { /* */ } };
  // خيارات القراءة الصوتية للموسوعة — مرآة لشريط القراءة، تُحفظ كافتراضي.
  const [ttsReadLang, setTtsReadLang] = useState(() => { try { return localStorage.getItem("enc_tts_lang") || ""; } catch { return ""; } });
  const [ttsBi, setTtsBi] = useState(() => { try { return localStorage.getItem("enc_tts_bi") === "1"; } catch { return false; } });
  const [ttsRate, setTtsRate] = useState(() => { try { const n = Number(localStorage.getItem("enc_tts_rate")); return n >= 0.6 && n <= 1.4 ? n : 1; } catch { return 1; } });
  const [ttsVoices, setTtsVoices] = useState([]);
  const [voiceAr, setVoiceAr] = useState(() => { try { return localStorage.getItem("enc_tts_voice_ar") || ""; } catch { return ""; } });
  const [voiceEn, setVoiceEn] = useState(() => { try { return localStorage.getItem("enc_tts_voice_en") || ""; } catch { return ""; } });
  useEffect(() => {
    let cancelled = false;
    if (isNativeTTS()) {
      nativeGetVoices().then((vs) => { if (!cancelled) setTtsVoices(vs || []); });
      return () => { cancelled = true; };
    }
    if (typeof window === "undefined" || !window.speechSynthesis) return;
    const load = () => setTtsVoices(window.speechSynthesis.getVoices() || []);
    load(); try { window.speechSynthesis.onvoiceschanged = load; } catch { /* */ }
    return () => { try { window.speechSynthesis.onvoiceschanged = null; } catch { /* */ } };
  }, []);
  const applyReadLang = (v) => { setTtsBi(false); setTtsReadLang(v); try { localStorage.setItem("enc_tts_lang", v); localStorage.setItem("enc_tts_bi", "0"); } catch { /* */ } };
  const applyBi = () => { const nb = !ttsBi; setTtsBi(nb); try { localStorage.setItem("enc_tts_bi", nb ? "1" : "0"); } catch { /* */ } };
  const applyRate = (v) => { setTtsRate(v); try { localStorage.setItem("enc_tts_rate", String(v)); } catch { /* */ } };
  const applyVoice = (code, uri) => { if (code === "ar") setVoiceAr(uri); else setVoiceEn(uri); try { localStorage.setItem(`enc_tts_voice_${code}`, uri); } catch { /* */ } };
  const [linkSettings, setLinkSettings] = useState(() => {
    const defaults = { brands: true, mixer: true, culture: true, budget: true, stores: true, lists: true, blog: true, perfumers: true, notes: true, quotes: true, wisdom: true, samples: true, glossary: true };
    const stored = getSecureStorage("perfumeLinkSettings", {});
    // Merge: any key not explicitly set to false defaults to true
    return Object.fromEntries(Object.keys(defaults).map(k => [k, stored[k] !== false]));
  });
  const [showGlossarySettings, setShowGlossarySettings] = useState(false);
  const [glossarySettings, setGlossarySettings] = useState(() => {
    return getSecureStorage("glossarySettings", { sortOrder: "alpha_asc" });
  });
  const [markInput, setMarkInput] = useState({});
  const [displayName, setDisplayName] = useState(""); // shown in exports when "App Name + User" toggle is on
  const [showHomeSettings, setShowHomeSettings] = useState(false);
  const [showThoughtSettings, setShowThoughtSettings] = useState(false);
  const [filters, setFilters] = useState(() => {
    const defaults = { reviews: true, wishes: true, purchases: true, favorites: true, wearLogs: true, blogEntries: true, glossaryEntries: true, goals: true, budgetEntries: true, quotesActivity: true, moodEntries: true };
    return getSecureStorage("homeFilters", defaults);
  });
  const [sortOrder, setSortOrder] = useState(() => getSecureStorage("homeSortOrder", "newest"));
  const [thoughtSettings, setThoughtSettings] = useState(() => {
    const defaults = {
      sortOrder: "newest",
      show: { not_set: true, idea: true, poetry: true, thought: true, knowledge: true, concept: true, memo: true },
    };
    return getSecureStorage("thoughtSettings", defaults);
  });
  const photoRef = useRef();

  useEffect(() => {
    apphost.auth.me().then((u) => {
      setUser(u);
      // Show the default mark (🧴) in the field so the user can see & change it.
      setMarkInput({ person1: u?.mark || DEFAULT_USER_MARK });
      setUserPhoto(u?.profile_photo || null);
      // Show the default name ("Name") in the field so the user can see & change it.
      // Ignore the technical offline default ("Local User") — treat it as unset.
      const resolvedName = u?.display_name?.trim()
        || (u?.full_name && u.full_name !== "Local User" ? u.full_name : "")
        || "Name";
      setDisplayName(resolvedName);
    }).catch(() => {});
  }, []);

  const handleUserPhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await apphost.integrations.Core.UploadFile({ file });
    setUserPhoto(file_url);
    await apphost.auth.updateMe({ profile_photo: file_url });
    // Notify all UserAvatarButton instances and other listeners that
    // the profile has changed so they re-fetch.
    window.dispatchEvent(new CustomEvent("userProfileChanged"));
  };

  const chooseTheme = (pref) => {
    setThemePrefState(pref);
    setThemePref(pref); // saves + applies (handles system follow)
  };

  const toggleTabLabels = () => {
    const newVal = !showTabLabels;
    setShowTabLabels(newVal);
    setSecureStorage("showTabLabels", newVal);
    window.dispatchEvent(new Event("tabLabelsChanged"));
  };

  const toggleMaestro = () => {
    const newVal = !showMaestro;
    setShowMaestro(newVal);
    setSecureStorage("showMaestroNav", newVal);
    if (!newVal) { try { sessionStorage.removeItem("maestro_auth"); } catch { /* تجاهل */ } }
    window.dispatchEvent(new Event("maestroNavChanged"));
  };

  const toggleActivity = () => {
    const newVal = !showActivity;
    setShowActivity(newVal);
    setSecureStorage("showActivityTimeline", newVal);
    window.dispatchEvent(new Event("activitySectionChanged"));
  };

  const toggleLinkSetting = (key) => {
    const newSettings = { ...linkSettings, [key]: !linkSettings[key] };
    setLinkSettings(newSettings);
    // Only persist the false values so new keys always default to true
    const toStore = Object.fromEntries(Object.entries(newSettings).filter(([, v]) => v === false));
    setSecureStorage("perfumeLinkSettings", toStore);
    window.dispatchEvent(new CustomEvent("perfumeLinkSettingsChanged"));
  };

  const toggleFilter = (key) => {
    const newFilters = { ...filters, [key]: !filters[key] };
    setFilters(newFilters);
    setSecureStorage("homeFilters", newFilters);
    window.dispatchEvent(new Event("homeSettingsChanged"));
  };

  const handleSortChange = (order) => {
    setSortOrder(order);
    setSecureStorage("homeSortOrder", order);
    window.dispatchEvent(new Event("homeSettingsChanged"));
  };

  return (
    <Sheet>
      <SheetTrigger asChild>{children}</SheetTrigger>
      <SheetContent side="right" dir={isAr ? "rtl" : "ltr"} className="w-[85vw] max-w-sm p-0 h-full overflow-y-auto">
        <SheetTitle className="sr-only">{isAr ? 'القائمة' : 'Menu'}</SheetTitle>
        <SheetDescription className="sr-only">{isAr ? 'إعدادات وروابط التطبيق' : 'App settings and links'}</SheetDescription>
        {/* User profile header: Photo on top (alone), then Name + Mark below */}
        <div className="px-6 py-5" style={{ background: "#F3EEE2" }}>
          <div className="flex flex-col items-center gap-3">
            <div className="relative flex-shrink-0">
              <button
                onClick={() => photoRef.current?.click()}
                className="w-20 h-20 overflow-hidden flex items-center justify-center hover:opacity-80 transition-opacity"
                style={{ background: "#ffffff", borderRadius: 0, borderBottom: "1.5px solid var(--brand)" }}
              >
                {userPhoto && (
                  <img src={userPhoto} alt="" className="w-full h-full object-cover" />
                )}
              </button>
              <span className="absolute -bottom-1.5 -right-1.5 w-5 h-5 flex items-center justify-center pointer-events-none" style={{ background: "#ffffff", border: "1px solid var(--brand)" }} aria-hidden="true"><svg viewBox="0 0 24 24" width="11" height="11" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="3.2"/></svg></span>
              <input ref={photoRef} type="file" accept="image/*" className="hidden" onChange={handleUserPhoto} />
            </div>
            <div className="w-full max-w-[260px] space-y-2">
              {/* Name — type directly in the box to edit */}
              <Input
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                onBlur={() => {
                  const val = displayName.trim();
                  apphost.auth.updateMe({ display_name: val === "Name" ? "" : val });
                  window.dispatchEvent(new CustomEvent("userProfileChanged"));
                }}
                placeholder={isAr ? "الاسم" : "Name"}
                maxLength="40"
                className="h-10 w-full rounded-none font-body text-base bg-white/70 dark:bg-black/20 border-0 text-center"
              />
              {/* Mark — gold (matches export cards). Shows default; editable. */}
              <Input
                value={markInput.person1 || ""}
                onChange={(e) => {
                  const val = e.target.value;
                  setMarkInput({ ...markInput, person1: val });
                  apphost.auth.updateMe({ mark: val });
                  window.dispatchEvent(new CustomEvent("userProfileChanged"));
                }}
                maxLength="8"
                style={{ color: "var(--brand)" }}
                className="h-10 w-full rounded-none font-body text-xl bg-white/70 dark:bg-black/20 border-0 text-center font-bold"
              />
            </div>
          </div>
        </div>

        {/* Settings */}
        <style>{`
.ss-menu .ss-row{display:flex;align-items:center;gap:10px;background:transparent;border:0;border-radius:0;padding:9px 4px;color:#2E7D32;}
.ss-menu .ss-row:hover{background:#FBF6E6;}
.ss-menu .ss-grouphead{display:flex;align-items:center;gap:10px;width:100%;background:transparent;border:0;padding:12px 2px 8px;cursor:pointer;}
.ss-menu .ss-gdia{width:9px;height:9px;background:transparent;border:1.6px solid var(--brand);flex:none;}
.ss-menu .ss-gtitle{font-size:12px;letter-spacing:.10em;color:var(--brand);text-transform:uppercase;font-weight:700;}
`}</style>
        <div className="px-4 py-5 space-y-4 pb-20 ss-menu">

          <Section title={lang === "ar" ? "الروابط" : "Links"} open={grpLinks} onToggle={() => setGrpLinks((o) => !o)}>
          <Link to="/notebook" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "مفكرة" : "Notebook"}</span>
          </Link>

          <Link to="/cast-away" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "مهملات" : "Cast Away"}</span>
          </Link>

          <SheetClose asChild><Link to="/reading-guide" className="ss-row">
            <span className="text-xs font-body font-medium" style={{ color: "#14532D" }}>— {lang === "ar" ? "موجِّهة قراءة" : "Reading Guide"}</span>
          </Link></SheetClose>
          <SheetClose asChild><Link to="/encyclopedia/timelines" className="ss-row">
            <span className="text-xs font-body font-medium" style={{ color: "#14532D" }}>— {lang === "ar" ? "مصنّفات قراءة" : "Reading Classifications"}</span>
          </Link></SheetClose>
          <SheetClose asChild><Link to="/encyclopedia" className="ss-row">
            <span className="text-xs font-body font-medium" style={{ color: "#14532D" }}>— {lang === "ar" ? "موسوعة" : "Encyclopedia"}</span>
          </Link></SheetClose>
          <Link to="/guide" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "شرح المميزات" : "Features Definition"}</span>
          </Link>
          <Link to="/accords-guide" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "التناغمات العطرية" : "Perfume Accords"}</span>
          </Link>
          <Link to="/accord-table" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "جدول التناغمات" : "Accord Table"}</span>
          </Link>
          <Link to="/headache-guide" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "صداع و حساسية" : "Headache & Sensitivity"}</span>
          </Link>
          <Link to="/care-guide" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "دليل العناية الشخصية" : "Personal Care Guide"}</span>
          </Link>
          </Section>

          <Section title={lang === "ar" ? "إجراءات" : "Actions"} open={grpActions} onToggle={() => setGrpActions((o) => !o)}>
          <UserTotals person="person1" label={names.person1 || "Profile A"} />
          <UserTotals person="person2" label={names.person2 || "Profile B"} />
          <CombinedTotals />

          <Link to="/add" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "إضافة & عطر" : "Add & Perfume"}</span>
          </Link>

          {/* Lists & Samples */}
           <Link to="/lists" className="ss-row">
             <span className="text-xs font-body font-medium">{lang === "ar" ? "إدارة المجموعات" : "Manage Sets"}</span>
           </Link>
           <Link to="/samples" className="ss-row">
             <span className="text-xs font-body font-medium">{lang === "ar" ? "قائمة العينات" : "Sample List"}</span>
           </Link>
           <Link to="/wishlist" className="ss-row">
             <span className="text-xs font-body font-medium">{lang === "ar" ? "قائمة الرغبات" : "Wishlist"}</span>
           </Link>
           <Link to="/marketing-card" className="ss-row">
             <span className="text-xs font-body font-medium">{lang === "ar" ? "بطاقة تسويق" : "Marketing Card"}</span>
           </Link>
           <Link to="/compare-card" className="ss-row">
             <span className="text-xs font-body font-medium">{lang === "ar" ? "بطاقة مقارنة عطور" : "Comparison Card"}</span>
           </Link>
           <Link to="/progress" className="ss-row">
             <span className="text-xs font-body font-medium">{lang === "ar" ? "تقدم" : "Progress"}</span>
           </Link>
           <Link to="/budget" className="ss-row">
             <span className="text-xs font-body font-medium">{lang === "ar" ? "ميزانية" : "Budget"}</span>
           </Link>
          </Section>

          <Section title={lang === "ar" ? "المستخدمين و الشاشة" : "Profiles & Display"} open={grpProfiles} onToggle={() => setGrpProfiles((o) => !o)}>

          {/* Profile A */}
          <PersonCard personKey="person1" name={names.person1} profile={profiles.person1} onUpdateName={updateName} onUpdateProfile={updateProfile} />

          {/* Profile B */}
          <PersonCard personKey="person2" name={names.person2} profile={profiles.person2} onUpdateName={updateName} onUpdateProfile={updateProfile} />

          {/* إدارة مدخلات الموسوعة — بعد مربعات المستخدمين */}
          <Link to="/encyclopedia/setup" className="ss-row">
            <span className="text-xs font-body font-medium" style={{ color: "var(--brand)" }}>{lang === "ar" ? "إدارة الموسوعة" : "Manage Encyclopedia"}</span>
          </Link>

          {/* الألوان — القسم كما هو، داخل القائمة */}
          <div className="px-1 py-2 space-y-3">
            <span className="text-xs font-body font-medium">{isAr ? "الألوان" : "Colors"}</span>
            {["person1", "person2"].map((pk) => (
              <div key={pk} className="space-y-1.5">
                <p className="text-[10px] text-[#2E7D32] font-body">{names[pk]}</p>
                <div className="flex gap-2 flex-wrap">
                  {COLORS.map((c) => (
                    <button
                      key={c}
                      onClick={() => updateProfile(pk, "color", c)}
                      className="w-6 h-6 rounded-none transition-transform hover:scale-110"
                      style={{ background: c, outline: profiles[pk].color === c ? `3px solid ${c}` : "none", outlineOffset: "2px" }}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div aria-hidden="true" style={{ borderTop: "1px solid var(--brand)", margin: "6px 0" }} />

          <div className="py-2 space-y-3">
            <p className="text-xs font-body font-medium">{isAr ? "العملة" : "Currency"}</p>
            <div className="flex gap-2 flex-wrap">
              {["USD", "SAR"].map((code) => (
                <button
                  key={code}
                  onClick={() => setCurrency(code)}
                  className={cn("px-3 py-2 rounded-none text-xs font-body font-medium transition-all", currency === code ? "bg-[var(--brand)] text-white shadow" : "bg-background border border-border text-[#2E7D32]")}
                >
                  {code}
                </button>
              ))}
            </div>
            <Input
              placeholder="عملة مخصصة (مثل EUR) Custom currency"
              defaultValue={!["USD", "SAR"].includes(currency) ? currency : ""}
              onBlur={(e) => { const val = e.target.value.toUpperCase().trim(); if (val) setCurrency(val); }}
              className="h-8 rounded-none font-body text-xs"
            />
          </div>

          {/* الموسوعة — نفس خيارات الموسوعة، معروضة هنا بلا طيّ */}
          <div className="px-2 py-3 space-y-2">
            <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider">{isAr ? "الموسوعة" : "Encyclopedia"}</p>
            <EncOptionsBar isAr={isAr} titleOrder={encTitleOrder} setTitleOrder={setEncTitleOrder} subTitleOrder={encSubOrder} setSubTitleOrder={setEncSubOrder} sortMode={encSortMode} setSortMode={setEncSortMode} showSubTitle={true} alwaysOpen={true} />
            {/* القراءة الصوتية — لغة و سرعة و صوت، تُحفظ كافتراضي */}
            <div className="space-y-2 pt-2">
              <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider">{isAr ? "القراءة الصوتية" : "Audio Reading"}</p>
              <div className="flex gap-1.5 flex-wrap" dir="ltr">
                {[["", isAr ? "حسب العرض" : "Display"], ["ar", "AR"], ["en", "EN"]].map(([v, l]) => (
                  <button key={v || "d"} onClick={() => applyReadLang(v)}
                    className={cn("px-2.5 py-1 text-[10.5px] font-body rounded-none border transition-colors", (!ttsBi && ttsReadLang === v) ? "border-[var(--brand)] bg-[var(--brand)] text-white" : "border-[#e7dfc9] text-muted-foreground")}>{l}</button>
                ))}
                <button onClick={applyBi}
                  className={cn("px-2.5 py-1 text-[10.5px] font-body rounded-none border transition-colors", ttsBi ? "border-[var(--brand)] bg-[var(--brand)] text-white" : "border-[#e7dfc9] text-muted-foreground")}>AR EN</button>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-[#2E7D32] font-body">{isAr ? "السرعة" : "Speed"}</span>
                <input type="range" min="0.6" max="1.4" step="0.1" value={ttsRate} onChange={(e) => applyRate(Number(e.target.value))} className="w-28 sharp-range" aria-label={isAr ? "سرعة" : "Speed"} />
                <span className="text-[10px] text-muted-foreground font-body">{ttsRate.toFixed(1)}</span>
              </div>
              {["ar", "en"].map((code) => {
                const list = ttsVoices.filter((v) => String(v.lang || "").toLowerCase().startsWith(code));
                if (!list.length) return null;
                const val = code === "ar" ? voiceAr : voiceEn;
                return (
                  <div key={code} className="flex items-center gap-2" dir="ltr">
                    <span className="text-[10px] text-[#2E7D32] font-body w-7">{code.toUpperCase()}</span>
                    <select value={val} onChange={(e) => applyVoice(code, e.target.value)}
                      className="flex-1 bg-transparent outline-none border border-[#e7dfc9] text-[11px] font-body py-1 px-1 max-w-[180px] truncate" style={{ color: "var(--brand)" }}>
                      <option value="">{isAr ? "تلقائي" : "Auto"}</option>
                      {list.map((v) => <option key={v.voiceURI} value={v.voiceURI}>{v.name}</option>)}
                    </select>
                  </div>
                );
              })}
              {isNativeTTS() && ttsVoices.length === 0 && (
                <p className="text-[9.5px] text-muted-foreground font-body leading-snug" dir={isAr ? "rtl" : "ltr"}>
                  {isAr ? "يُستعمل صوت النظام الافتراضي للقراءة. لاختيار صوت محدد ثبّت بيانات صوت اللغة من إعدادات النظام." : "Using the system default voice. To pick a specific voice, install the language voice data from system settings."}
                </p>
              )}
            </div>
          </div>

          {/* Home Settings */}
          <button
            onClick={() => setShowHomeSettings(!showHomeSettings)}
            className="w-full ss-row"
          >
            <span className="text-xs font-body font-medium">{lang === "ar" ? "إعدادات الرئيسية" : "Home Settings"}</span>
          </button>

          {showHomeSettings && (
            <div className="py-2 space-y-3">
              <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider">{isAr ? "مرشّحات النشاط" : "Activity Filters"}</p>
              {[
                 { key: "reviews", label: "Reviews" },
                 { key: "wishes", label: "Wish List" },
                 { key: "purchases", label: "Purchases" },
                 { key: "favorites", label: "Favorites" },
                 { key: "goals", label: "Goals" },
                 { key: "wearLogs", label: "Wear Logs" },
                 { key: "blogEntries", label: "Blog Entries" },
                 { key: "budgetEntries", label: "Budget Entries" },
                 { key: "moodEntries", label: "Mood Entries" },
               ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => toggleFilter(key)}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-3.5 h-3.5 border flex items-center justify-center transition-colors", filters[key] ? "bg-[var(--brand)] border-[var(--brand)]" : "border-border")}>
                    
                  </div>
                  <span className={filters[key] ? "text-foreground" : "text-[#2E7D32]"}>{label}</span>
                </button>
              ))}
              <div className="pt-2 space-y-1.5">
                <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider">{isAr ? "ترتيب العرض" : "Sort Order"}</p>
                <div className="flex gap-2 flex-wrap">
                  {[
                    { value: "newest", label: "Newest" },
                    { value: "oldest", label: "Oldest" },
                    { value: "alpha_asc", label: "Alphabetical" },
                    { value: "alpha_desc", label: "Reversed" },
                  ].map(({ value, label }) => (
                    <button
                      key={value}
                      onClick={() => handleSortChange(value)}
                      className={cn("flex-1 py-1.5 rounded-none text-[10px] font-body font-medium transition-all min-w-[60px]", sortOrder === value ? "bg-[var(--brand)] text-white" : "bg-transparent text-[#2E7D32]")}
                    >
                      {label}
                    </button>
                  ))}
                </div>
                <div className="border-t border-border/40 mt-2" />
              </div>
            </div>
          )}

          {/* Thoughts Settings */}
          <button
            onClick={() => setShowThoughtSettings(!showThoughtSettings)}
            className="w-full ss-row"
          >
            <span className="text-xs font-body font-medium">{lang === "ar" ? "إعدادات المدونة" : "Blogs Settings"}</span>
          </button>

          {showThoughtSettings && (
            <div className="py-2 space-y-3">
              <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider">{isAr ? "إظهار أنواع المدخلات" : "Show Blog Entry Types"}</p>
              {[
                { key: "not_set", label: "Not Set" },
                { key: "idea", label: "Idea" },
                { key: "poetry", label: "Poetry" },
                { key: "thought", label: "Thought" },
                { key: "knowledge", label: "Knowledge" },
                { key: "concept", label: "Concept" },
              ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => {
                    const newSettings = {
                      ...thoughtSettings,
                      show: { ...thoughtSettings.show, [key]: !thoughtSettings.show[key] },
                    };
                    setThoughtSettings(newSettings);
                    setSecureStorage("thoughtSettings", newSettings);
                    window.dispatchEvent(new Event("thoughtSettingsChanged"));
                  }}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-3.5 h-3.5 border flex items-center justify-center transition-colors", thoughtSettings.show[key] !== false ? "bg-[var(--brand)] border-[var(--brand)]" : "border-border")}>
                    
                  </div>
                  <span className={thoughtSettings.show[key] !== false ? "text-foreground" : "text-[#2E7D32]"}>{label}</span>
                </button>
              ))}
              <div className="pt-2 space-y-1.5">
                <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider">{isAr ? "ترتيب العرض" : "Sort Order"}</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const newSettings = { ...thoughtSettings, sortOrder: "newest" };
                      setThoughtSettings(newSettings);
                      setSecureStorage("thoughtSettings", newSettings);
                      window.dispatchEvent(new Event("thoughtSettingsChanged"));
                    }}
                    className={cn("flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all", thoughtSettings.sortOrder === "newest" ? "bg-[var(--brand)] text-white" : "bg-background border border-border text-[#2E7D32]")}
                  >
                    Newest
                  </button>
                  <button
                    onClick={() => {
                      const newSettings = { ...thoughtSettings, sortOrder: "oldest" };
                      setThoughtSettings(newSettings);
                      setSecureStorage("thoughtSettings", newSettings);
                      window.dispatchEvent(new Event("thoughtSettingsChanged"));
                    }}
                    className={cn("flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all", thoughtSettings.sortOrder === "oldest" ? "bg-[var(--brand)] text-white" : "bg-background border border-border text-[#2E7D32]")}
                  >
                    Oldest
                  </button>
                </div>
                <div className="border-t border-border/40 mt-2" />
              </div>
            </div>
          )}

          {/* Nav Tabs Settings */}
          <button
            onClick={() => setShowNavTabSettings(!showNavTabSettings)}
            className="w-full ss-row"
          >
            <span className="text-xs font-body font-medium">{lang === "ar" ? "إعدادات أشرطة التنقل" : "Nav Tabs Settings"}</span>
          </button>
          {showNavTabSettings && (
            <div className="py-2 space-y-3">
              <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider">Show / Hide Nav Tabs</p>
              {[
                { key: "home", label: "Home" },
                { key: "perfumes", label: "Main" },
                { key: "explore", label: "Explore" },
                { key: "shopping", label: "Shopping" },
                { key: "progress", label: "Statistics" },
                { key: "goals", label: "Goals" },
                { key: "maestro", label: "Maestro" },
              ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => {
                    const newSettings = { ...navTabSettings, [key]: !navTabSettings[key] };
                    setNavTabSettings(newSettings);
                    setSecureStorage("navTabSettings", newSettings);
                    window.dispatchEvent(new Event("navTabSettingsChanged"));
                  }}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-4 h-4 border flex items-center justify-center transition-colors", navTabSettings[key] !== false ? "bg-[var(--brand)] border-[var(--brand)]" : "border-border")}>
                  </div>
                  <span className={navTabSettings[key] !== false ? "text-foreground" : "text-[#2E7D32]"}>{label}</span>
                </button>
              ))}
            </div>
          )}

          {/* Links Settings */}
          <button
            onClick={() => setShowLinksSettings(!showLinksSettings)}
            className="w-full ss-row"
          >
            <span className="text-xs font-body font-medium">{lang === "ar" ? "إعدادات الروابط" : "Links Settings"}</span>
          </button>

          {showLinksSettings && (
            <div className="py-2 space-y-3">
              <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider">{isAr ? "روابط تبويب العطر" : "Perfume Tab Links"}</p>
              {[
                { key: "brands", label: "Brands" },
                { key: "mixer", label: isAr ? "مزج" : "Blend" },
                { key: "culture", label: "Culture & Courtesy" },
                { key: "budget", label: "Budget" },
                { key: "stores", label: "Shops & Stores" },
                { key: "lists", label: "Manage" },
                { key: "blog", label: "Blog" },
                { key: "perfumers", label: "Perfumers" },
                { key: "notes", label: "Notes" },
                { key: "quotes", label: isAr ? "متاجر" : "Store" },
                { key: "wisdom", label: isAr ? "عطور" : "Perfumes" },
                { key: "samples", label: isAr ? "عينات" : "Samples" },
                { key: "glossary", label: isAr ? "موسوعة" : "Encyclopedia" },
              ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => toggleLinkSetting(key)}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-4 h-4 border flex items-center justify-center transition-colors", linkSettings[key] ? "bg-[var(--brand)] border-[var(--brand)]" : "border-border")}>
                    
                  </div>
                  <span className={linkSettings[key] ? "text-foreground" : "text-[#2E7D32]"}>{label}</span>
                </button>
              ))}
            </div>
          )}

          {/* Perfume & Brand Settings */}
          <button
            onClick={() => setShowPbSettings(!showPbSettings)}
            className="w-full ss-row"
          >
            <span className="text-xs font-body font-medium">{lang === "ar" ? "إعدادات صفحة العطر و البراند" : "Perfume & Brand Settings"}</span>
          </button>

          {showPbSettings && (
            <div className="py-2 space-y-3">
              <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider">{isAr ? "مناسبات العطر" : "Perfume Occasions"}</p>
              {[
                { val: "text", label: isAr ? "نص" : "Text" },
                { val: "emoji", label: isAr ? "ايقونة" : "Icon" },
                { val: "both", label: isAr ? "نص & ايقونة" : "Text & Icon" },
              ].map(({ val, label }) => (
                <button
                  key={val}
                  onClick={() => setPerfOccMode(val)}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-4 h-4 border flex items-center justify-center transition-colors", perfOccMode === val ? "bg-[var(--brand)] border-[var(--brand)]" : "border-border")}>
                  </div>
                  <span className={perfOccMode === val ? "text-foreground" : "text-[#2E7D32]"}>{label}</span>
                </button>
              ))}
              <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider pt-1">{isAr ? "مناسبات المستخدم" : "User Occasions"}</p>
              {[
                { val: "text", label: isAr ? "نص" : "Text" },
                { val: "emoji", label: isAr ? "ايقونة" : "Icon" },
                { val: "both", label: isAr ? "نص & ايقونة" : "Text & Icon" },
              ].map(({ val, label }) => (
                <button
                  key={val}
                  onClick={() => setUserOccMode(val)}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-4 h-4 border flex items-center justify-center transition-colors", userOccMode === val ? "bg-[var(--brand)] border-[var(--brand)]" : "border-border")}>
                  </div>
                  <span className={userOccMode === val ? "text-foreground" : "text-[#2E7D32]"}>{label}</span>
                </button>
              ))}
              <p className="text-[10px] text-[#2E7D32] font-body uppercase tracking-wider pt-1">{isAr ? "الإطارات" : "Frames"}</p>
              <button onClick={() => setFrame("table", !frames.tableFrames)} className="w-full flex items-center gap-2 text-xs font-body">
                <div className={cn("w-4 h-4 border flex items-center justify-center transition-colors", frames.tableFrames ? "bg-[var(--brand)] border-[var(--brand)]" : "border-border")} />
                <span className={frames.tableFrames ? "text-foreground" : "text-[#2E7D32]"}>{isAr ? "اطارات الجداول" : "Table frames"}</span>
              </button>
              <button onClick={() => setFrame("img", !frames.imageFrames)} className="w-full flex items-center gap-2 text-xs font-body">
                <div className={cn("w-4 h-4 border flex items-center justify-center transition-colors", frames.imageFrames ? "bg-[var(--brand)] border-[var(--brand)]" : "border-border")} />
                <span className={frames.imageFrames ? "text-foreground" : "text-[#2E7D32]"}>{isAr ? "اطارات الصور" : "Image frames"}</span>
              </button>
            </div>
          )}

          {/* Tab Labels */}
          <button
            onClick={toggleTabLabels}
            className="w-full ss-row"
          >
            <span className="text-xs font-body font-medium">{lang === "ar" ? "تسميات الأشرطة" : "Tab Labels"}</span>
            <div className={cn("w-9 h-5 rounded-none transition-colors relative ms-auto flex-shrink-0", showTabLabels ? "bg-[var(--brand)]" : "bg-[#e7dfc9]")}>
              <div className={cn("absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all", showTabLabels ? "left-4" : "left-0.5")} />
            </div>
          </button>

          {/* Read Mode: ON = غامر (الوضع الحالي)، OFF = إظهار شريط الحالة العلوي */}
          <button onClick={toggleReadMode} className="w-full ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "وضع القراءة" : "Read Mode"}</span>
            <div className={cn("w-9 h-5 rounded-none transition-colors relative ms-auto flex-shrink-0", readMode ? "bg-[var(--brand)]" : "bg-[#e7dfc9]")}>
              <div className={cn("absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all", readMode ? "left-4" : "left-0.5")} />
            </div>
          </button>

          {/* لون الخط (التمييز) — ٧ ألوان، الافتراضي ذهبي؛ يُطبَّق على var(--brand) */}
          <div className="px-2 py-3 space-y-2">
            <span className="text-xs font-body font-medium">{isAr ? "لون الخط" : "Font colour"}</span>
            <div className="flex items-center gap-2.5 flex-wrap">
              {ACCENT_COLORS.map((c) => (
                <button key={c.key} type="button"
                  onClick={() => { setAccent(c.key); setSecureStorage("themeAccent", c.key); window.dispatchEvent(new Event("themeColorChanged")); }}
                  className="w-8 h-8 transition-all" title={isAr ? c.ar : c.en} aria-label={isAr ? c.ar : c.en}
                  style={{ background: c.hex, outline: accent === c.key ? "2px solid var(--brand)" : "none", outlineOffset: "2px", border: "1px solid rgba(0,0,0,0.12)" }} />
              ))}
            </div>
          </div>

          {/* لون خلفية التطبيق — ٧ خيارات، الافتراضي أبيض؛ يُطبَّق على --page-bg */}
          <div className="px-2 py-3 space-y-2">
            <span className="text-xs font-body font-medium">{isAr ? "لون خلفية التطبيق" : "App background"}</span>
            <div className="flex items-center gap-2.5 flex-wrap">
              {BG_COLORS.map((c) => (
                <button key={c.key} type="button"
                  onClick={() => { setBgColor(c.key); setSecureStorage("themeBg", c.key); window.dispatchEvent(new Event("themeColorChanged")); }}
                  className="w-8 h-8 transition-all" title={isAr ? c.ar : c.en} aria-label={isAr ? c.ar : c.en}
                  style={{ background: c.hex, outline: bgColor === c.key ? "2px solid var(--brand)" : "none", outlineOffset: "2px", border: "1px solid rgba(0,0,0,0.18)" }} />
              ))}
            </div>
          </div>

          {/* المظهر — نُقل بعد الألوان (طلب A) */}
          <div className="px-1 py-2 space-y-2">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "المظهر" : "Appearance"}</span>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { pref: "light", en: "Light", ar: "فاتح" },
                { pref: "dark", en: "Dark", ar: "داكن" },
                { pref: "system", en: "System", ar: "الجهاز" },
              ].map(({ pref, en, ar }) => (
                <button key={pref} onClick={() => chooseTheme(pref)} className={cn("py-2 rounded-none text-[11px] font-body transition-all", themePref === pref ? "bg-[var(--brand)] text-white font-semibold" : "bg-white text-[#2E7D32]")}>
                  {lang === "ar" ? ar : en}
                </button>
              ))}
            </div>
          </div>

          {/* Language — نُقل بعد الألوان (طلب A) */}
          <div className="py-2 space-y-2">
            <p className="text-[11px] font-body font-medium">Language اللغة</p>
            <div className="flex gap-2">
              <button onClick={() => setLang("en")} className={cn("px-4 py-1 rounded-none text-xs font-body font-medium transition-all", lang === "en" ? "bg-[var(--brand)] text-white shadow" : "bg-background border border-border text-[#2E7D32]")}>English</button>
              <button onClick={() => setLang("ar")} className={cn("px-4 py-1 rounded-none text-xs font-body font-medium transition-all", lang === "ar" ? "bg-[var(--brand)] text-white shadow" : "bg-background border border-border text-[#2E7D32]")}>العربية</button>
            </div>
          </div>


          {/* المتاجر و المشتريات — مطوية داخل «الملفات و العرض» (A 1.812) */}
          <Subsection title={lang === "ar" ? "المتاجر و المشتريات" : "Stores & Purchases"} open={grpStores} onToggle={() => setGrpStores((o) => !o)}>
            {/* فرز الخيارات الخمسة في نافذة شراء عطر/سامبل */}
            <div className="ss-row flex-col items-stretch gap-1.5">
              <div className="text-left">
                <span className="text-xs font-body font-medium">{lang === "ar" ? "خيارات المتجر عند الشراء" : "Store options when buying"}</span>
                <p className="text-[10px] text-[#2E7D32]">{lang === "ar" ? "أي خمسة متاجر تظهر أولا في نافذة إضافة مشترى" : "Which five stores appear first in the purchase dialog"}</p>
              </div>
              <div className="flex gap-1.5 flex-wrap" dir={lang === "ar" ? "rtl" : "ltr"}>
                {STORE_SORT_MODES.map((m) => (
                  <button key={m.value}
                    onClick={() => { setPickSort(m.value); setStorePickSort(m.value); }}
                    className={cn("px-2.5 py-1 text-[10.5px] font-body rounded-none border transition-colors", pickSort === m.value ? "border-[var(--brand)] bg-[var(--brand)] text-white" : "border-[#e7dfc9] text-muted-foreground")}>
                    {lang === "ar" ? m.ar : m.en}
                  </button>
                ))}
              </div>
            </div>
            {/* ترتيب المتاجر في صفحة التسوق */}
            <div className="ss-row flex-col items-stretch gap-1.5">
              <div className="text-left">
                <span className="text-xs font-body font-medium">{lang === "ar" ? "ترتيب المتاجر في صفحة التسوق" : "Store order in Shopping page"}</span>
              </div>
              <div className="flex gap-1.5 flex-wrap" dir={lang === "ar" ? "rtl" : "ltr"}>
                {STORE_SORT_MODES.map((m) => (
                  <button key={m.value}
                    onClick={() => { setPageSortS(m.value); setStorePageSort(m.value); }}
                    className={cn("px-2.5 py-1 text-[10.5px] font-body rounded-none border transition-colors", pageSortS === m.value ? "border-[var(--brand)] bg-[var(--brand)] text-white" : "border-[#e7dfc9] text-muted-foreground")}>
                    {lang === "ar" ? m.ar : m.en}
                  </button>
                ))}
              </div>
            </div>
          </Subsection>

          </Section>

          <Section title={lang === "ar" ? "التطبيق" : "App"} open={grpApp} onToggle={() => setGrpApp((o) => !o)}>


          <Link to="/backup" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "النسخ و الاستعادة" : "Backup / Restore"}</span>
          </Link>

          <button
            onClick={() => window.location.reload()}
            className="w-full ss-row"
          >
            <span className="text-xs font-body font-medium">{lang === "ar" ? "تحديث التطبيق" : "Refresh App"}</span>
          </button>

          {/* جلسة التجهيز (طلب A 1.807): ضمن النافذة المختارة يدخل التطبيق فورا بعد
              الركود بلا أي فحص أو تجهيز خلفي — تغيّر نسخة التطبيق يفتح التجهيز دائما */}
          <div className="ss-row flex-col items-stretch gap-1.5">
            <div className="text-left">
              <span className="text-xs font-body font-medium">{lang === "ar" ? "جلسة التجهيز" : "Prep Session"}</span>
              <p className="text-[10px] text-[#2E7D32]">{lang === "ar" ? "ضمن المدة المختارة: دخول فوري بلا تجهيز بعد الركود" : "Within the window: instant entry, no background prep"}</p>
            </div>
            <div className="flex gap-1.5 flex-wrap" dir={lang === "ar" ? "rtl" : "ltr"}>
              {[
                ["always", lang === "ar" ? "كل إقلاع" : "Every launch"],
                ["day", lang === "ar" ? "يوم" : "Day"],
                ["week", lang === "ar" ? "أسبوع" : "Week"],
                ["month", lang === "ar" ? "شهر" : "Month"],
              ].map(([val, label]) => (
                <button
                  key={val}
                  onClick={() => { setSessionWindow(val); try { localStorage.setItem("proc_session_window", val); } catch { /* تجاهل */ } }}
                  className={cn("px-2.5 py-1 text-[10.5px] font-body rounded-none border transition-colors", sessionWindow === val ? "border-[var(--brand)] bg-[var(--brand)] text-white" : "border-[#e7dfc9] text-muted-foreground")}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          <button onClick={() => { clearSearchHistory(); }} className="ss-row w-full text-start">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "تنظيف حقول البحث" : "Clear search fields"}</span>
          </button>

          {/* Sections — إظهار/إخفاء أقسام التطبيق (مثل المايسترو) */}
          <button
            onClick={toggleActivity}
            className="w-full ss-row"
          >
            <div className="flex items-center gap-2.5">
              <div className="text-left">
                <span className="text-xs font-body font-medium">{lang === "ar" ? "قسم النشاطات" : "Activities Section"}</span>
                <p className="text-[10px] text-[#2E7D32]">{showActivity ? (lang === "ar" ? "ظاهر — اضغط للإخفاء" : "Visible — tap to hide") : (lang === "ar" ? "مخفي — اضغط للإظهار" : "Hidden — tap to show")}</p>
              </div>
            </div>
            <div className={cn("w-9 h-5 rounded-none transition-colors relative ms-auto flex-shrink-0", showActivity ? "bg-[var(--brand)]" : "bg-[#e7dfc9]")}>
              <div className={cn("absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all", showActivity ? "left-4" : "left-0.5")} />
            </div>
          </button>

          {/* Maestro Mode */}
          <button
            onClick={toggleMaestro}
            className="w-full ss-row"
          >
            <div className="flex items-center gap-2.5">
              <div className="text-left">
                <span className="text-xs font-body font-medium">{lang === "ar" ? "وضع المايسترو" : "Maestro Mode"}</span>
                <p className="text-[10px] text-[#2E7D32]">{showMaestro ? "Active — DB management enabled" : "Hidden — tap to enable"}</p>
              </div>
            </div>
            <div className={cn("w-9 h-5 rounded-none transition-colors relative ms-auto flex-shrink-0", showMaestro ? "bg-[var(--brand)]" : "bg-[#e7dfc9]")}>
              <div className={cn("absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all", showMaestro ? "left-4" : "left-0.5")} />
            </div>
          </button>

          {/* App Info — بعد وضع المايسترو */}
          <Link to="/app-info" className="ss-row">
            <span className="text-xs font-body font-medium">{lang === "ar" ? "عن التطبيق" : "App Info"}</span>
          </Link>
          </Section>

        </div>
      </SheetContent>
    </Sheet>
  );
}