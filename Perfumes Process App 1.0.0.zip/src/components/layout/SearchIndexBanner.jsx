import { useEffect, useState } from "react";
import { searchIndexBuildState } from "@/lib/searchIndex";
import { useLang } from "@/lib/LanguageContext";

// سطرٌ نصّيّ صغير بخلفية شفافة فوق أزرار التنقّل السفلية — يظهر فقط أثناء بناء
// فهرس البحث، لا يغطّي الأزرار ولا يعترض أيّ لمسة (pointer-events: none).
export default function SearchIndexBanner() {
  const { isAr } = useLang();
  const [st, setSt] = useState({ building: false, percent: 0 });

  useEffect(() => {
    const tick = () => setSt(searchIndexBuildState());
    tick();
    const id = setInterval(tick, 700);
    return () => clearInterval(id);
  }, []);

  if (!st.building) return null;

  return (
    <div
      dir={isAr ? "rtl" : "ltr"}
      style={{
        // فوق أزرار التنقّل السفلية (ارتفاعها + منطقة الأمان) — لا يغطّيها أبداً
        position: "fixed", insetInlineStart: 0, insetInlineEnd: 0,
        bottom: "calc(60px + env(safe-area-inset-bottom, 0px))",
        zIndex: 49, // أدنى من شريط التنقّل (z-50) فلا يحجبه إطلاقاً
        display: "flex", justifyContent: "center",
        pointerEvents: "none", // لا يعترض أيّ لمسة — تصفّح حرّ
        background: "transparent",
      }}
    >
      <span
        style={{
          fontSize: 9.5, lineHeight: 1.4, fontFamily: "var(--font-body)",
          color: "#8a6d1f", background: "transparent",
          textShadow: "0 0 4px rgba(255,255,255,0.95), 0 0 8px rgba(255,255,255,0.85)",
          padding: "1px 8px", whiteSpace: "nowrap",
        }}
      >
        {isAr
          ? `بناء الفهرس قائم — يمكنك التصفح ${st.percent}%`
          : `Index building — you can keep browsing ${st.percent}%`}
      </span>
    </div>
  );
}
