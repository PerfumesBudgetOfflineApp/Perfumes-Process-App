import { useEffect, useState } from "react";
import { prepState } from "@/lib/prepProgress";
import { tagIndexBuildState } from "@/lib/perfumeTagIndex";
import { useLang } from "@/lib/LanguageContext";

// سطر «جاري تجهيز التطبيق ٪X» — بنمط سطر بناء الفهرس نفسه: صغير شفاف فوق
// أزرار التنقل، لا يعترض أي لمسة، يظهر فقط أثناء التجهيز الخلفي بعد تحديث
// بذرة التطبيق (بدل التجمد الصامت — قاعدة A 1.802).
export default function PrepBanner() {
  const { isAr } = useLang();
  const [st, setSt] = useState({ active: false, percent: 0 });

  useEffect(() => {
    // يقرأ حالتي التجهيز (top-ups) و بناء فهرس الوسوم معا — أيهما نشط يظهر بنسبته
    const tick = () => {
      const a = prepState();
      const b = tagIndexBuildState();
      setSt(a.active ? a : { active: b.building, percent: b.percent });
    };
    tick();
    const id = setInterval(tick, 600);
    return () => clearInterval(id);
  }, []);

  if (!st.active) return null;

  return (
    <div
      dir={isAr ? "rtl" : "ltr"}
      style={{
        position: "fixed", insetInlineStart: 0, insetInlineEnd: 0,
        bottom: "calc(74px + env(safe-area-inset-bottom, 0px))", // فوق سطر الفهرس إن ظهرا معاً
        zIndex: 49,
        display: "flex", justifyContent: "center",
        pointerEvents: "none",
        background: "transparent",
      }}
    >
      <span
        style={{
          fontSize: 9.5, lineHeight: 1.4, fontFamily: "var(--font-body)",
          color: "#8a6d1f", background: "transparent",
          textShadow: "0 0 4px rgba(255,255,255,0.95), 0 0 8px rgba(255,255,255,0.85)",
          padding: "1px 8px", whiteSpace: "nowrap",
        }}
      >
        {isAr
          ? `جاري تجهيز التطبيق ${st.percent}% — يمكنك التصفح`
          : `Preparing the app ${st.percent}% — you can keep browsing`}
      </span>
    </div>
  );
}
