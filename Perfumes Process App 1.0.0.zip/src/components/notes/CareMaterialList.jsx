import { useMemo } from "react";
import { useLang } from "@/lib/LanguageContext";
import { materialsByStatus, STATUS_COLOR } from "@/lib/careMaterials";

// CareMaterialList — يعرض مواد العناية المنظَّمة كبطاقات شبيهة بالنوتة داخل /notes.
// status: banned | restricted | allowed. بحث بنفس حقل النوتات. إطار سفلي فقط.
export default function CareMaterialList({ status, search = "" }) {
  const { isAr } = useLang();
  const q = (search || "").trim().toLowerCase();
  const items = useMemo(() => {
    const list = materialsByStatus(status);
    if (!q) return list;
    return list.filter((m) =>
      [m.ar, m.en, m.inci].some((v) => String(v || "").toLowerCase().includes(q))
    );
  }, [status, q]);

  const color = STATUS_COLOR[status];
  const titleAr = { banned: "المواد المحظورة", restricted: "المواد المقيّدة", allowed: "المواد المسموحة" }[status];
  const titleEn = { banned: "Banned Care Materials", restricted: "Restricted Care Materials", allowed: "Allowed Care Materials" }[status];
  // خط ملوّن على الاسم بدل تكرار نصّ الحالة: محظور أحمر · مقيّد بني · مسموح بلا خط
  const NAME_LINE = { banned: "#C0392B", restricted: "#8B5E3C" };
  const nameLine = NAME_LINE[status];
  const nameStyle = nameLine ? { textDecoration: "underline", textDecorationColor: nameLine, textDecorationThickness: "2px", textUnderlineOffset: "3px" } : undefined;

  return (
    <div className="space-y-2 pt-1">
      <div className="flex items-baseline justify-between border-b pb-1" style={{ borderColor: color }}>
        <span className="font-body text-sm font-semibold" style={{ color }}>
          {isAr ? titleAr : titleEn}
          <span className="text-muted-foreground font-normal" style={{ fontSize: 11, marginInlineStart: 6 }}>
            {isAr ? titleEn : titleAr}
          </span>
        </span>
        <span className="font-body text-[11px]" style={{ color }}>{items.length}</span>
      </div>

      {items.length === 0 ? (
        <p className="text-xs text-muted-foreground font-body text-center py-4">{isAr ? "لا نتائج" : "No results"}</p>
      ) : (
        items.map((m) => (
          <div key={m.id} className="border-b pb-2.5 pt-1" style={{ borderColor: "var(--rule,#E7E3DA)" }} dir={isAr ? "rtl" : "ltr"}>
            <div className="flex items-center justify-between gap-2">
              <span className="font-body text-sm font-semibold">
                <span style={nameStyle}>{m.ar} <span className="text-muted-foreground font-normal" style={{ fontSize: 11 }}>{m.en}</span></span>
                {m.is_note && <span className="font-body" style={{ fontSize: 10, color: "var(--brand)", marginInlineStart: 6 }}>{isAr ? "نوتة أيضا" : "also a note"}</span>}
              </span>
            </div>
            <p className="font-body text-[11px] mt-0.5" style={{ color: "#A8A39A", direction: "ltr", textAlign: "start" }}>{m.inci}</p>
            <p className="font-body text-[12.5px] mt-1" style={{ lineHeight: 1.7 }}>{m.reason_ar}</p>
            <p className="font-body text-[11px]" style={{ color: "var(--mut,#6B6760)", direction: "ltr", textAlign: "left", marginTop: 2 }}>{m.reason_en}</p>
            {(m.max_pct || m.ref) && (
              <p className="font-body text-[10.5px] mt-1" style={{ color: "#A8A39A" }}>
                {m.max_pct ? <span>{isAr ? "الحدّ" : "Limit"}: {m.max_pct}</span> : null}
                {m.max_pct && m.ref ? " — " : ""}
                {m.ref ? <span style={{ direction: "ltr" }}>{m.ref}</span> : null}
              </p>
            )}
          </div>
        ))
      )}
    </div>
  );
}
