import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { ENC, dispName, dispNameOrdered } from "@/lib/encyclopedia";
import EncOptionsBar from "@/components/encyclopedia/EncOptionsBar";
import { usePersonNames } from "@/lib/usePersonNames";

// تنسيق السنة: سالب = ق.م، البعيد جداً نصّاً، الافتراضي بعد 2040.
function fmtYear(y, isAr) {
  if (y == null || y === "") return "";
  const n = typeof y === "number" ? y : parseInt(y, 10);
  if (!Number.isFinite(n)) return "";
  if (n < -6000) return isAr ? "التاريخ البعيد" : "The Distant Past";
  if (n < 0) return `${-n}${isAr ? " ق.م" : " BC"}`;
  if (n >= 2040) return isAr ? `${n} افتراضي` : `${n} notional`;
  return String(n);
}

// صفحة الخطوط الزمنية و المصنّفات للموسوعة — منفصلة عن التصفّح الرئيسي.
// التاريخ يظهر هنا فقط. موجّهة القراءة تتولّد تلقائياً من محتوى الموسوعة.
export default function EncyclopediaTimelines() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const { profiles } = usePersonNames();
  const activePerson = (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1";
  const userColor = profiles[activePerson]?.color || "var(--brand)";

  const { data: langs = [] } = useQuery({ queryKey: ["enc-langs"], queryFn: () => ENC.Language().list("order", 50), staleTime: 1000 * 30 });
  const { data: sections = [] } = useQuery({ queryKey: ["enc-sections"], queryFn: () => ENC.Section().list("order", 200), staleTime: 1000 * 30 });
  const { data: subs = [] } = useQuery({ queryKey: ["enc-subs-all"], queryFn: () => ENC.Subclass().list("order", 2000), staleTime: 1000 * 30 });
  const { data: lines = [] } = useQuery({ queryKey: ["enc-lines-all"], queryFn: () => ENC.Timeline().list("order", 2000), staleTime: 1000 * 30 });
  const { data: entries = [] } = useQuery({ queryKey: ["enc-fav-entries"], queryFn: () => ENC.Entry().list("-updated_date", 20000), staleTime: 1000 * 10 });
  const [titleOrder, setTitleOrderRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_title_order")) || "ar_en");
  const setTitleOrder = (o) => { setTitleOrderRaw(o); try { localStorage.setItem("enc_title_order", o); } catch { /* تجاهل */ } };
  const [subTitleOrder, setSubTitleOrderRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_sub_title_order")) || "lang");
  const setSubTitleOrder = (o) => { setSubTitleOrderRaw(o); try { localStorage.setItem("enc_sub_title_order", o); } catch { /* تجاهل */ } };
  const [encAccent, setEncAccent] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_accent_color")) || "");
  useEffect(() => {
    const h = () => setEncAccent(localStorage.getItem("enc_accent_color") || "");
    window.addEventListener("enc-accent-change", h);
    return () => window.removeEventListener("enc-accent-change", h);
  }, []);
  const [subSel, setSubSel] = useState({});
  const [clsPage, setClsPage] = useState(0);
  useEffect(() => { setClsPage(0); }, [JSON.stringify(subSel)]);

  const code = isAr ? "ar" : "en";

  // موجّهة القراءة + الخطوط — مرور واحد على المدخلات، محفوظ (أداء: لا إعادة حساب كل رندر).
  const { lineData, sectionData, subCount } = useMemo(() => {
    const byTimeline = {}, bySection = {}, bySub = {};
    for (const e of entries) {
      const tl = e.timeline_id; if (tl != null && tl !== "") (byTimeline[String(tl)] = byTimeline[String(tl)] || []).push(e);
      const sc = e.section_id; if (sc != null && sc !== "") (bySection[String(sc)] = bySection[String(sc)] || []).push(e);
      const s1 = e.subclass_id; if (s1 != null && s1 !== "") bySub[String(s1)] = (bySub[String(s1)] || 0) + 1;
      const s2 = e.subclass2_id; if (s2 != null && s2 !== "" && String(s2) !== String(s1)) bySub[String(s2)] = (bySub[String(s2)] || 0) + 1;
    }
    const vis = lines.filter((t) => !t.hidden);
    const tlPriority = (t) => {
      const nm = `${t.name_ar || t.title_ar || ""} ${t.name_en || t.title_en || ""}`.toLowerCase();
      if (nm.includes("معمورة") || nm.includes("world time") || nm.includes("world-time")) return 0;
      if (nm.includes("بيوت") || nm.includes("house")) return 1;
      return 2;
    };
    const ld = vis.map((t) => ({
      t,
      items: (byTimeline[String(t.id)] || [])
        .map((e) => ({ e, y: parseInt(e.year, 10) }))
        .sort((a, b) => (Number.isFinite(a.y) ? a.y : 9e9) - (Number.isFinite(b.y) ? b.y : 9e9)),
    })).filter((l) => l.items.length > 0)
      .sort((a, b) => tlPriority(a.t) - tlPriority(b.t));
    const sd = sections.map((s) => ({
      s,
      count: (bySection[String(s.id)] || []).length,
      subs: subs.filter((c) => String(c.section_id) === String(s.id)),
    })).filter((x) => x.count > 0 || x.subs.length > 0);
    return { lineData: ld, sectionData: sd, subCount: bySub };
  }, [entries, lines, sections, subs]);

  const empty = entries.length === 0;

  return (
    <div className="px-5 page-top pb-24 space-y-6" style={encAccent ? { "--brand": encAccent } : undefined}>
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-bold" style={{ color: "var(--brand)" }}>{isAr ? "خطوط و مصنّفات" : "Timelines & Classifications"}</h1>
        <button type="button" onClick={() => navigate("/encyclopedia")}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity" aria-label={isAr ? "رجوع" : "Back"}>
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} style={{ color: "var(--brand)" }} />
        </button>
      </div>

      {empty ? (
        <p className="text-sm text-muted-foreground font-body py-10 text-center">{isAr ? "الموسوعة فارغة بعد" : "The encyclopedia is empty yet"}</p>
      ) : (
        <>
          {/* الخطوط الزمنية — كل خطّ تقسيمة رئيسة بصفحته الخاصة (لا تكديس) */}
          {lineData.length > 0 && (
            <section className="space-y-1">
              <h2 className="font-heading text-base font-semibold mb-2" style={{ color: "var(--brand)" }}>{isAr ? "خطوط زمنية" : "Timelines"}</h2>
              {lineData.map(({ t, items }) => (
                <button key={t.id} type="button" onClick={() => navigate(`/encyclopedia?tl=${t.id}`)}
                  className="w-full flex items-baseline justify-between gap-3 py-1.5 text-start hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
                  <span className="font-body text-xs min-w-0 truncate" style={{ color: "var(--brand)" }}>{dispNameOrdered(t, titleOrder, isAr)}</span>
                </button>
              ))}
            </section>
          )}

          {/* موجّهة القراءة — مدمجة في الموسوعة: ملخّص + رابط للموجِّهة الكاملة */}
          <section className="space-y-2" dir={isAr ? "rtl" : "ltr"}>
            <button type="button" onClick={() => navigate("/reading-guide")}
              className="flex items-baseline gap-2 hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
              <h2 className="font-heading text-base font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "موجّهة القراءة" : "Reading Guide"}</h2>
              <span className="font-body text-xs" style={{ color: "var(--brand)", opacity: 0.7 }}>{isAr ? "الكاملة ←" : "full →"}</span>
            </button>
            <p className="font-body text-sm leading-relaxed text-muted-foreground">
              {isAr
                ? "ابدأ من القسم الذي يناسبك، أو اتبع خطّاً زمنياً لتقرأ المحطات بترتيبها"
                : "Start from the section that suits you, or follow a timeline to read its stations in order"}
            </p>
            <div className="space-y-1 pt-1">
              {sectionData.map(({ s, count, subs: sc }) => (
                <p key={s.id} className="font-body text-sm">
                  <span className="font-semibold" style={{ color: "var(--brand)" }}>{dispName(s, isAr)}</span>
                  {sc.length > 0 && <span className="text-muted-foreground text-xs"> — {sc.map((c) => dispName(c, isAr)).join(isAr ? "، " : ", ")}</span>}
                </p>
              ))}
            </div>
          </section>

          {/* المصنّفات — كل محور كتلة أنيقة: خطّ بلون المستخدم تحت العنوان + عدّ لطيف لكل فرعيّة */}
          <section className="space-y-4">
            <h2 className="font-heading text-base font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "مصنّفات" : "Classifications"}</h2>
            {(() => {
              const AXIS = [
                { key: "kind", label: isAr ? "النوع" : "Kind" },
                { key: "region", label: isAr ? "المنطقة" : "Region" },
                { key: "category", label: isAr ? "الفئة" : "Category" },
                { key: "field", label: isAr ? "الحقل" : "Field" },
              ];
              const byAxis = {};
              subs.forEach((c) => { const a = c.axis || "other"; (byAxis[a] = byAxis[a] || []).push(c); });
              const present = AXIS.filter((a) => byAxis[a.key] && byAxis[a.key].length);
              return present.map((a) => (
                <div key={a.key} className="space-y-1.5">
                  <div className="space-y-1">
                    <p className="text-[11px] font-body font-semibold uppercase tracking-wider" style={{ color: "var(--brand)" }}>{a.label}</p>
                    <div style={{ height: 2, width: 28, background: userColor, opacity: 0.6, borderRadius: 1 }} />
                  </div>
                  <div className="flex flex-wrap gap-x-4 gap-y-1.5" dir={isAr ? "rtl" : "ltr"}>
                    {byAxis[a.key].map((c) => {
                      return (
                        <button key={c.id} type="button" onClick={() => navigate(`/encyclopedia?sub=${c.id}`)}
                          className="font-body text-xs hover:opacity-70 transition-opacity inline-flex items-baseline gap-1" style={{ color: "var(--brand)" }}>
                          <span>{dispNameOrdered(c, subTitleOrder, isAr)}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              ));
            })()}
          </section>



          <EncOptionsBar isAr={isAr} titleOrder={titleOrder} setTitleOrder={setTitleOrder} subTitleOrder={subTitleOrder} setSubTitleOrder={setSubTitleOrder} sortMode="newest" setSortMode={() => {}} showSort={false} showSubTitle={true} />
        </>
      )}
    </div>
  );
}
