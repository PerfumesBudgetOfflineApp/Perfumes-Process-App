import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link, useNavigate} from "react-router-dom";
import { ArrowLeft, Download, SaudiRiyal, Trash2, Pencil, ArrowDownCircle, ArrowUpCircle, FileText, Landmark, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import AlertsPanel from "@/components/budget/AlertsPanel";
import SavingsGoalsSection from "@/components/budget/SavingsGoalsSection";
import BudgetCharts from "@/components/budget/BudgetCharts";
import StoreSelector from "@/components/store/StoreSelector";
import StoreManager from "@/components/budget/StoreManager";
import BrandServiceManager from "@/components/budget/BrandServiceManager";
import SpendingVisuals from "@/components/budget/SpendingVisuals";
import { usePagedList, SimplePager } from "@/components/shared/usePagedList";
import SectionDivider from "@/components/shared/SectionDivider";
import { toast } from "sonner";

// تحويل أي تكرار إلى مكافئ شهري — يُستخدم في "الوضع الفعلي" لينعكس على الإجماليات الشهرية بدقّة
const FREQ_TO_MONTHLY = { once: 1, daily: 30.4, weekly: 4.345, biweekly: 2.1725, monthly: 1, quarterly: 1 / 3, semiannual: 1 / 6, yearly: 1 / 12 };
function toMonthly(amount, freq) {
  const a = parseFloat(amount) || 0;
  return a * (FREQ_TO_MONTHLY[freq] ?? 1);
}
const FREQ_LABELS = {
  once: { en: "Once", ar: "مرة" }, daily: { en: "Daily", ar: "يومي" },
  weekly: { en: "Weekly", ar: "أسبوعي" }, biweekly: { en: "Every 2 weeks", ar: "كل أسبوعين" },
  monthly: { en: "Monthly", ar: "شهري" }, quarterly: { en: "Quarterly", ar: "ربع سنوي" },
  semiannual: { en: "Every 6 months", ar: "نصف سنوي" }, yearly: { en: "Yearly", ar: "سنوي" },
};

const TRANSLATIONS = {
  en: {
    title: "Budget",
    income: "Income",
    expenses: "Expenses",
    balance: "Balance",
    addIncome: "Add Income",
    adding: "Adding..",
    addExpense: "Add Expense",
    addObligation: "Add Obligation",
    addRecurring: "Add Recurring",
    overview: "📊 Overview",
    incomeTab: "💵 Income",
    expensesTab: "💸 Expenses",
    obligationsTab: "📋 Obligations",
    recurringTab: "🔄 Budget Log",
    analysis: "📊 Stats",
    noData: "No data",
    salary: "Salary",
    business: "Business Income",
    investment: "Investment",
    other: "Other",
    food: "Food",
    transportation: "Transportation",
    utilities: "Utilities",
    shopping: "Shopping",
    entertainment: "Entertainment",
    health: "Health",
    education: "Education",
    perfume: "Perfume",
    insurance: "Insurance",
    subscription: "Subscription",
    obligation: "Obligation",
    monthlyPayment: "Monthly Payment",
    endDate: "End Date",
    remaining: "Remaining",
    paid: "Paid",
    dailyExpenses: "Daily Expenses",
    monthlyBudget: "Monthly Budget",
    forecast: "Forecast",
    current: "Current Month",
    nextMonth: "Next Month",
    sixMonths: "6 Months",
    oneYear: "1 Year"
  },
  ar: {
    title: "ميزانية",
    income: "الدخل",
    expenses: "المصاريف",
    balance: "الرصيد",
    addIncome: "إضافة دخل",
    adding: "جارٍ الإضافة..",
    addExpense: "إضافة مصروف",
    addObligation: "إضافة التزام",
    addRecurring: "إضافة مصروف دوري",
    overview: "📊 نظرة عامة",
    incomeTab: "💵 الدخل",
    expensesTab: "💸 المصاريف",
    obligationsTab: "📋 الالتزامات",
    recurringTab: "🔄 سجل الميزانية",
    analysis: "📊 الإحصائيات",
    noData: "لا توجد بيانات",
    salary: "الراتب",
    business: "دخل تجارة",
    investment: "استثمار",
    other: "آخر",
    food: "الطعام",
    transportation: "التنقل",
    utilities: "الفواتير",
    shopping: "مشتريات",
    entertainment: "ترفيه",
    health: "صحة",
    education: "تعليم",
    perfume: "عطور",
    insurance: "تأمين",
    subscription: "اشتراك",
    obligation: "التزام",
    monthlyPayment: "القسط الشهري",
    endDate: "تاريخ الانتهاء",
    remaining: "المتبقي",
    paid: "المدفوع",
    dailyExpenses: "مصاريف يومية",
    monthlyBudget: "الميزانية الشهرية",
    forecast: "التوقعات",
    current: "الشهر الحالي",
    nextMonth: "الشهر التالي",
    sixMonths: "6 أشهر",
    oneYear: "سنة واحدة"
  }
};

export default function Budget() {
  const { lang, isAr } = useLang();
  const { names } = usePersonNames();
  const { currency } = useCurrency();
  const qc = useQueryClient();
  const t = TRANSLATIONS[lang === "ar" ? "ar" : "en"];

  const [activeTab, setActiveTab] = useState("overview");
  const [selectedPerson, setSelectedPerson] = useState("all");
  const [isManageMode, setIsManageMode] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7));
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("income");
  const [formData, setFormData] = useState({});
  const navigate = useNavigate();
  const [selectedStores, setSelectedStores] = useState({});
  const [expensesSortOrder, setExpensesSortOrder] = useState("newest");
  const [incomesSortOrder, setIncomesSortOrder] = useState("newest");

  // Queries
  const { data: incomes = [] } = useQuery({
    queryKey: ["budget-incomes"],
    queryFn: () => apphost.entities.BudgetIncome.list("-date"),
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ["budget-expenses"],
    queryFn: () => apphost.entities.BudgetExpense.list("-date"),
  });

  const { data: obligations = [] } = useQuery({
    queryKey: ["budget-obligations"],
    queryFn: () => apphost.entities.BudgetObligation.list("-end_date"),
  });

  const { data: recurring = [] } = useQuery({
    queryKey: ["recurring-expenses"],
    queryFn: () => apphost.entities.RecurringExpense.list("-start_date"),
  });

  const { data: purchases = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-purchase_date"),
  });

  const { data: shopProducts = [] } = useQuery({
    queryKey: ["shop-products"],
    queryFn: () => apphost.entities.ShopProduct.list("-purchase_date"),
  });

  const { data: shopBrands = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list(),
  });

  // المتاجر موحّدة على ShopBrand (أُزيل كيان Store القديم).
  const allStores = useMemo(() => shopBrands, [shopBrands]);

  const { data: assetsList = [] } = useQuery({
    queryKey: ["budget-assets"],
    queryFn: () => apphost.entities.Asset.list(),
  });

  const { data: savingsGoals = [] } = useQuery({
    queryKey: ["savings-goals"],
    queryFn: () => apphost.entities.SavingsGoal.list("-target_date"),
  });

  // Mutations
  const incomeM = useMutation({
    mutationFn: async (data) => {
      return apphost.entities.BudgetIncome.create(data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["budget-incomes"] });
      setDialogOpen(false);
      setFormData({});
      toast.success((isAr ? "تم الحفظ" : "Saved"));
    },
    onError: (err) => toast.error(err?.message || "Error saving"),
  });

  const expenseM = useMutation({
    mutationFn: async (data) => {
      return apphost.entities.BudgetExpense.create(data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["budget-expenses"] });
      setDialogOpen(false);
      setFormData({});
      toast.success((isAr ? "تم الحفظ" : "Saved"));
    },
    onError: (err) => toast.error(err?.message || "Error saving"),
  });

  const obligationM = useMutation({
    mutationFn: async (data) => {
      return apphost.entities.BudgetObligation.create(data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["budget-obligations"] });
      setDialogOpen(false);
      setFormData({});
      toast.success((isAr ? "تم الحفظ" : "Saved"));
    },
    onError: (err) => toast.error(err?.message || "Error saving"),
  });

  const recurringM = useMutation({
    mutationFn: async (data) => {
      return apphost.entities.RecurringExpense.create(data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["recurring-expenses"] });
      setDialogOpen(false);
      setFormData({});
      toast.success((isAr ? "تم الحفظ" : "Saved"));
    },
    onError: (err) => toast.error(err?.message || "Error saving"),
  });

  const assetM = useMutation({
    mutationFn: async (data) => {
      return apphost.entities.Asset.create(data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["budget-assets"] });
      setDialogOpen(false);
      setFormData({});
      toast.success((isAr ? "تم الحفظ" : "Saved"));
    },
    onError: (err) => toast.error(err?.message || "Error saving"),
  });

  // Helper function to get filtered data
  const getFilteredData = (person) => {
    // Combine PurchaseRecord and ShopProduct data
    const allPurchases = [
      ...purchases.filter((p) => p.person === person && p.purchase_date.startsWith(selectedMonth)),
      ...shopProducts.filter((p) => p.person === person && p.purchase_date.startsWith(selectedMonth)).map(sp => ({
        ...sp,
        perfume_name: sp.linked_perfume_name || sp.name,
        cost: sp.cost || 0,
        store_id: sp.brand_id || null,
        store_name: sp.brand_name || null,
      })),
    ];
    
    return {
      incomes: incomes.filter((i) => i.person === person && i.date.startsWith(selectedMonth)),
      expenses: expenses.filter((e) => e.person === person && e.date.startsWith(selectedMonth)),
      purchases: allPurchases,
      obligations: obligations.filter((o) => o.person === person && o.status === "active"),
      recurring: recurring.filter((r) => r.person === person && r.is_active),
    };
  };

  // Helper to sort data
  const sortData = (data, dateField, order) => {
    const sorted = [...data];
    if (order === "newest") {
      sorted.sort((a, b) => new Date(b[dateField]) - new Date(a[dateField]));
    } else if (order === "oldest") {
      sorted.sort((a, b) => new Date(a[dateField]) - new Date(b[dateField]));
    } else if (order === "highest") {
      sorted.sort((a, b) => (b.amount || b.cost || 0) - (a.amount || a.cost || 0));
    } else if (order === "lowest") {
      sorted.sort((a, b) => (a.amount || a.cost || 0) - (b.amount || b.cost || 0));
    }
    return sorted;
  };

  // Filters
  let monthIncomes, monthExpenses, monthPurchases, personObligations, personRecurring;
  
  if (selectedPerson === "all") {
    // Combine all people's data
    const person1Data = getFilteredData("person1");
    const person2Data = getFilteredData("person2");
    const familyData = getFilteredData("family");

    // إزالة التكرار بالمعرّف — قد تتداخل قوائم الأشخاص/العائلة فيظهر السجل
    // مرّتين (مفتاح React مكرّر + مجاميع منتفخة).
    const dedupeById = (arr) => {
      const seen = new Set();
      return arr.filter((x) => {
        const k = x && x.id != null ? String(x.id) : JSON.stringify(x);
        if (seen.has(k)) return false;
        seen.add(k); return true;
      });
    };

    monthIncomes = sortData(dedupeById([...person1Data.incomes, ...person2Data.incomes, ...familyData.incomes]), "date", incomesSortOrder);
    monthExpenses = sortData(dedupeById([...person1Data.expenses, ...person2Data.expenses, ...familyData.expenses]), "date", expensesSortOrder);
    monthPurchases = sortData(dedupeById([...person1Data.purchases, ...person2Data.purchases, ...familyData.purchases]), "purchase_date", expensesSortOrder);
    personObligations = dedupeById([...person1Data.obligations, ...person2Data.obligations, ...familyData.obligations]);
    personRecurring = dedupeById([...person1Data.recurring, ...person2Data.recurring, ...familyData.recurring]);
  } else {
    const data = getFilteredData(selectedPerson);
    monthIncomes = sortData(data.incomes, "date", incomesSortOrder);
    monthExpenses = sortData(data.expenses, "date", expensesSortOrder);
    monthPurchases = sortData(data.purchases, "purchase_date", expensesSortOrder);
    personObligations = data.obligations;
    personRecurring = data.recurring;
  }

  // Calculations
  const totalIncome = monthIncomes.reduce((sum, i) => sum + (i.amount || 0), 0);
  const totalExpense = monthExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const totalPurchases = monthPurchases.reduce((sum, p) => sum + (p.cost || 0), 0);
  const totalObligations = personObligations.reduce((sum, o) => sum + (o.monthly_payment || 0), 0);
  const totalRecurring = personRecurring.reduce((sum, r) => sum + (r.amount || 0), 0);

  // Filter assets
  const personAssets = selectedPerson === "all" 
    ? assetsList.filter(a => a.is_active)
    : assetsList.filter(a => a.person === selectedPerson && a.is_active);

  // Calculate assets metrics
  const totalAssetValue = personAssets.reduce((sum, a) => sum + (a.current_value || 0), 0);
  const totalAssetsCost = personAssets.reduce((sum, a) => sum + (a.annual_cost || 0), 0);
  const totalAssetsReturns = personAssets.reduce((sum, a) => {
    const annualReturn = (a.current_value || 0) * (a.annual_return_rate || 0) / 100;
    return sum + annualReturn;
  }, 0);
  const monthlyAssetsReturns = totalAssetsReturns / 12;
  const monthlyAssetsCost = totalAssetsCost / 12;

  // إجمالي المُدخر والمستهدف من أهداف الادخار (للشخص المختار)
  const personSavings = selectedPerson === "all"
    ? savingsGoals.filter((g) => g.is_active)
    : savingsGoals.filter((g) => g.is_active && g.person === selectedPerson);
  const totalSaved = personSavings.reduce((sum, g) => sum + (g.current_amount || 0), 0);
  const totalSavingsTarget = personSavings.reduce((sum, g) => sum + (g.target_amount || 0), 0);

  const balance = totalIncome - (totalExpense + totalPurchases + totalObligations + totalRecurring) + monthlyAssetsReturns - monthlyAssetsCost;

  const expensesByCategory = useMemo(() => {
    const cats = {};
    monthExpenses.forEach((e) => {
      const cat = e.category || "other";
      cats[cat] = (cats[cat] || 0) + (e.amount || 0);
    });
    return cats;
  }, [monthExpenses]);

  // Handlers
  // الشخص الافتراضي للمدخلات الجديدة: family عند عرض "الكل"، وإلا الشخص المختار
  const entryPerson = formData.person || (selectedPerson === "all" ? "family" : selectedPerson);

  const handleAddIncome = () => {
    if (!formData.amount || !formData.date) {
      toast.error((isAr ? "املأ كل الحقول" : "Fill all fields"));
      return;
    }
    const actual = formData.recurring_mode === "actual";
    const freq = formData.frequency || "once";
    const entered = parseFloat(formData.amount);
    incomeM.mutate({
      date: formData.date,
      amount: actual ? toMonthly(entered, freq) : entered,
      orig_amount: entered,
      type: formData.type || "salary",
      person: entryPerson,
      description: formData.description,
      recurring: actual,
      recurring_mode: actual ? "actual" : "doc",
      frequency: freq,
    });
  };

  const handleAddExpense = () => {
    if (!formData.amount || !formData.date) {
      toast.error((isAr ? "املأ كل الحقول" : "Fill all fields"));
      return;
    }
    const actual = formData.recurring_mode === "actual";
    const freq = formData.frequency || "once";
    const entered = parseFloat(formData.amount);
    expenseM.mutate({
      date: formData.date,
      amount: actual ? toMonthly(entered, freq) : entered,
      orig_amount: entered,
      category: formData.category || "other",
      person: entryPerson,
      description: formData.description,
      recurring: actual,
      recurring_mode: actual ? "actual" : "doc",
      frequency: freq,
      type: formData.type || "essential",
      store_id: formData.store_id || null,
      store_name: formData.store_name || null,
    });
  };

  const handleAddObligation = () => {
    if (!formData.title || !formData.total_amount || !formData.monthly_payment || !formData.end_date) {
      toast.error((isAr ? "املأ كل الحقول المطلوبة" : "Fill all required fields"));
      return;
    }
    const actual = formData.recurring_mode === "actual";
    const freq = formData.frequency || "monthly";
    const enteredPayment = parseFloat(formData.monthly_payment);
    obligationM.mutate({
      title: formData.title,
      person: entryPerson,
      total_amount: parseFloat(formData.total_amount),
      paid_amount: parseFloat(formData.paid_amount) || 0,
      monthly_payment: actual ? toMonthly(enteredPayment, freq) : enteredPayment,
      orig_payment: enteredPayment,
      frequency: freq,
      recurring_mode: actual ? "actual" : "doc",
      start_date: formData.start_date || new Date().toISOString().slice(0, 10),
      end_date: formData.end_date,
      interest_rate: parseFloat(formData.interest_rate) || 0,
      category: formData.obligation_category || "other",
      notes: formData.notes,
      status: "active",
    });
  };

  const handleAddRecurring = () => {
    if (!formData.title || !formData.amount || !formData.start_date) {
      toast.error((isAr ? "املأ كل الحقول المطلوبة" : "Fill all required fields"));
      return;
    }
    recurringM.mutate({
      title: formData.title,
      amount: parseFloat(formData.amount),
      person: entryPerson,
      frequency: formData.frequency || "monthly",
      category: formData.category || "other",
      start_date: formData.start_date,
      end_date: formData.end_date || null,
      day_of_month: parseInt(formData.day_of_month) || 1,
      is_active: true,
      auto_generate: true,
    });
  };

  return (
    <div className={`px-4 page-top pb-4 space-y-4 ${isAr ? "rtl" : ""}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <Link to="/goals" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="font-heading text-2xl font-bold flex items-center gap-2" style={{ color: "var(--brand)" }}><SaudiRiyal className="w-6 h-6 text-primary" />{t.title}</h1>
        <div className="flex gap-2">
          <button
            onClick={() => navigate("/export?type=budget")}
            className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors"
          >
            <Download className="w-4 h-4 text-foreground/60 hover:text-foreground transition-colors" />
          </button>
          <SettingsSheet>
            <UserAvatarButton size={30} />
          </SettingsSheet>
        </div>
      </div>

      {/* Person Selector — صف واحد: العائلة A B الكل */}
      <div className="grid grid-cols-4 gap-1.5">
        {[
          { val: "family", label: isAr ? "🏠 العائلة" : "🏠 Family" },
          { val: "person1", label: names.person1 || "A" },
          { val: "person2", label: names.person2 || "B" },
          { val: "all", label: isAr ? "👥 الكل" : "👥 All" },
        ].map(({ val, label }) => (
          <button
            key={val}
            onClick={() => setSelectedPerson(val)}
            className={`w-full px-1.5 py-2 text-xs sm:text-sm font-body transition-colors truncate ${
              selectedPerson === val
                ? "text-primary font-semibold"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <SectionDivider />

      {/* أرغب بالشراء + مجموعتي — نُقلت لأسفل الصفحة */}

      <SectionDivider />

      {/* Manage Budget — clean toggle, no box */}
      <button
       onClick={() => setIsManageMode(!isManageMode)}
       className={`w-full flex items-center justify-between bg-transparent px-1 py-2 transition-colors font-body text-sm font-semibold ${
         isManageMode ? "text-primary" : "text-muted-foreground hover:text-foreground"
       }`}
      >
       <span>{isAr ? "إدارة الميزانية" : "Manage Budget"}</span>
       <span className="text-xs opacity-70">{isManageMode ? (isAr ? "▲ إنهاء" : "▲ End") : (isAr ? "▼ بدء" : "▼ Begin")}</span>
      </button>

      <SectionDivider />

      {/* Month Selector */}
      <Input
        type="month"
        value={selectedMonth}
        onChange={(e) => setSelectedMonth(e.target.value)}
        className="rounded-none h-10 font-body"
      />

      <SectionDivider />

      {/* Tabs — clean, transparent, fit-to-screen (two rows of four) */}
      <div className="grid grid-cols-4 gap-x-2 gap-y-1">
        {[
          { id: "overview",    en: "Overview",      ar: "نظرة عامة" },
          { id: "income",      en: "Income",        ar: "الدخل" },
          { id: "expenses",    en: "Expenses",      ar: "المصاريف" },
          { id: "obligations", en: "Obligations",   ar: "الالتزامات" },
          { id: "assets",      en: "Assets",        ar: "الأصول" },
          { id: "savings",     en: "Savings Goals", ar: "أهداف الادخار" },
          { id: "recurring",   en: "Budget Log",    ar: "سجل الميزانية" },
          { id: "analysis",    en: "Stats",         ar: "الإحصائيات" },
        ].map(({ id, en, ar }) => {
          const active = activeTab === id;
          return (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`relative bg-transparent py-2 px-1 text-center leading-tight text-[10px] font-body transition-colors ${
                active ? "text-primary font-semibold" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {isAr ? ar : en}
              <span className={`block mx-auto mt-1 h-0.5 rounded-none transition-all ${active ? "w-5 bg-primary" : "w-0 bg-transparent"}`} />
            </button>
          );
        })}
      </div>

      <SectionDivider />

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-none p-3">
          <p className="text-[10px] text-emerald-700 dark:text-emerald-300 font-body">{t.income}</p>
          <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">
            {totalIncome.toFixed(0)} {currency}
          </p>
        </div>
        <div className="rounded-none p-3">
          <p className="text-[10px] text-red-700 dark:text-red-300 font-body">{t.expenses}</p>
          <p className="text-sm font-bold text-red-600 dark:text-red-400">
            {(totalExpense + totalPurchases + totalObligations + totalRecurring).toFixed(0)} {currency}
          </p>
        </div>
        {totalAssetValue > 0 && (
          <div className="rounded-none p-3">
            <p className="text-[10px] text-blue-700 dark:text-blue-300 font-body">🏦 Assets Value</p>
            <p className="text-sm font-bold text-blue-600 dark:text-blue-400">
              {totalAssetValue.toFixed(0)} {currency}
            </p>
          </div>
        )}
        {(monthlyAssetsReturns - monthlyAssetsCost) !== 0 && (
          <div className={`rounded-none p-3`}>
            <p className={`text-[10px] font-body ${(monthlyAssetsReturns - monthlyAssetsCost) >= 0 ? "text-emerald-700 dark:text-emerald-300" : "text-red-700 dark:text-red-300"}`}>📊 Assets Net</p>
            <p className={`text-sm font-bold ${(monthlyAssetsReturns - monthlyAssetsCost) >= 0 ? "text-emerald-600 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`}>
              {(monthlyAssetsReturns - monthlyAssetsCost) >= 0 ? "+" : ""}{(monthlyAssetsReturns - monthlyAssetsCost).toFixed(0)} {currency}
            </p>
          </div>
        )}
        <div className={`col-span-2 rounded-none p-3`}>
          <p className={`text-[10px] font-body ${balance >= 0 ? "text-blue-700 dark:text-blue-300" : "text-orange-700 dark:text-orange-300"}`}>
            {t.balance}
          </p>
          <p className={`text-lg font-bold ${balance >= 0 ? "text-blue-600 dark:text-blue-400" : "text-orange-600 dark:text-orange-400"}`}>
            {balance.toFixed(0)} {currency}
          </p>
        </div>
      </div>

      <SectionDivider />

      {/* Alerts Panel */}
      {activeTab === "overview" && (
        <AlertsPanel
          obligations={personObligations}
          recurring={personRecurring}
          balance={balance}
          selectedPerson={selectedPerson}
          isAr={isAr}
          currency={currency}
        />
      )}

      <SectionDivider />

      {/* Content */}
      <div className="space-y-3 pb-20">
        {activeTab === "overview" && (
          <OverviewTab
            t={t}
            currency={currency}
            monthIncomes={monthIncomes}
            monthPurchases={monthPurchases}
            expensesByCategory={expensesByCategory}
            personObligations={personObligations}
            totalExpense={totalExpense}
            totalPurchases={totalPurchases}
            totalObligations={totalObligations}
            setDialogType={setDialogType}
            setFormData={setFormData}
            setDialogOpen={setDialogOpen}
            stores={allStores}
          />
        )}

        {activeTab === "income" && (
          <IncomeTab
            t={t}
            monthIncomes={monthIncomes}
            currency={currency}
            setDialogType={setDialogType}
            setFormData={setFormData}
            setDialogOpen={setDialogOpen}
            incomesSortOrder={incomesSortOrder}
            setIncomesSortOrder={setIncomesSortOrder}
          />
        )}

        {activeTab === "expenses" && (
          <ExpensesTab
            t={t}
            monthExpenses={monthExpenses}
            monthPurchases={monthPurchases}
            currency={currency}
            setDialogType={setDialogType}
            setFormData={setFormData}
            setDialogOpen={setDialogOpen}
            stores={allStores}
            expensesSortOrder={expensesSortOrder}
            setExpensesSortOrder={setExpensesSortOrder}
          />
        )}

        {activeTab === "obligations" && (
          <ObligationsTab
            t={t}
            obligations={personObligations}
            currency={currency}
            setDialogType={setDialogType}
            setFormData={setFormData}
            setDialogOpen={setDialogOpen}
          />
        )}

        {activeTab === "recurring" && (
          <RecurringTab
            t={t}
            isAr={isAr}
            recurring={personRecurring}
            incomes={monthIncomes}
            expenses={monthExpenses}
            obligations={personObligations}
            assets={personAssets}
            currency={currency}
            names={names}
            setDialogType={setDialogType}
            setFormData={setFormData}
            setDialogOpen={setDialogOpen}
            onDeleteIncome={(id) => { apphost.entities.BudgetIncome.delete(id).then(() => qc.invalidateQueries({ queryKey: ["budget-incomes"] })); }}
            onDeleteExpense={(id) => { apphost.entities.BudgetExpense.delete(id).then(() => qc.invalidateQueries({ queryKey: ["budget-expenses"] })); }}
            onDeleteRecurring={(id) => { apphost.entities.RecurringExpense.delete(id).then(() => qc.invalidateQueries({ queryKey: ["recurring-expenses"] })); }}
            onEditIncome={(rec) => { setDialogType("income"); setFormData({ ...rec, amount: rec.orig_amount ?? rec.amount }); setDialogOpen(true); }}
            onEditExpense={(rec) => { setDialogType("expense"); setFormData({ ...rec, amount: rec.orig_amount ?? rec.amount }); setDialogOpen(true); }}
          />
        )}

        {/* أهداف الادخار — تبويب مستقلّ */}
        {activeTab === "savings" && (
          <SavingsGoalsSection
            selectedPerson={selectedPerson}
            isAr={isAr}
            currency={currency}
            names={names}
            currentBalance={balance}
          />
        )}

        {activeTab === "assets" && (
          <AssetsTab
            assets={personAssets}
            currency={currency}
            setDialogType={setDialogType}
            setFormData={setFormData}
            setDialogOpen={setDialogOpen}
          />
        )}

        {activeTab === "analysis" && (
          <>
            <div className="space-y-4">
              <Link
                to="/monthly-analysis"
                className="flex items-center justify-between bg-transparent px-1 py-2 hover:opacity-80 transition-opacity"
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg">📈</span>
                  <div>
                    <p className="text-sm font-body font-semibold">{isAr ? "إحصائيات الاتجاهات الشهرية" : "Monthly Trends Stats"}</p>
                    <p className="text-xs text-muted-foreground">{isAr ? "رسوم بيانية مقارنة شاملة" : "Comprehensive comparison charts"}</p>
                  </div>
                </div>
              </Link>
              <AnalysisTab
              t={t}
              totalIncome={totalIncome}
              totalExpense={totalExpense}
              totalPurchases={totalPurchases}
              totalObligations={totalObligations}
              totalRecurring={totalRecurring}
              totalSaved={totalSaved}
              totalSavingsTarget={totalSavingsTarget}
              savingsGoals={personSavings}
              balance={balance}
              currency={currency}
              incomes={monthIncomes}
              personObligations={personObligations}
              selectedPerson={selectedPerson}
              getFilteredData={getFilteredData}
              names={names}
              monthExpenses={monthExpenses}
              monthPurchases={monthPurchases}
              totalAssetValue={totalAssetValue}
              monthlyAssetsReturns={monthlyAssetsReturns}
              monthlyAssetsCost={monthlyAssetsCost}
              personAssets={personAssets}
            />
            </div>
            <BudgetCharts
              expenses={monthExpenses}
              incomes={monthIncomes}
              isAr={isAr}
              currency={currency}
            />
          </>
        )}

        {isManageMode && (
          <>
            <Link
              to="/budget-entries"
              className="flex items-center justify-between bg-transparent px-1 py-2 hover:opacity-80 transition-opacity"
            >
              <span className="text-sm font-body font-semibold text-primary">{isAr ? "إضافة و تعديل مدخلات الميزانية" : "Add & Edit Budget Entries"}</span>
            </Link>
            <StoreManager />
            <BrandServiceManager />
          </>
        )}
      </div>

      {/* Dialog */}
      <FormDialog
        t={t}
        dialogOpen={dialogOpen}
        setDialogOpen={setDialogOpen}
        dialogType={dialogType}
        formData={formData}
        setFormData={setFormData}
        onAddIncome={handleAddIncome}
        onAddExpense={handleAddExpense}
        onAddObligation={handleAddObligation}
        onAddRecurring={handleAddRecurring}
        onAddAsset={() => {
          if (!formData.name || !formData.initial_cost || !formData.current_value) {
            toast.error((isAr ? "املأ كل الحقول المطلوبة" : "Fill all required fields"));
            return;
          }
          assetM.mutate({
            name: formData.name,
            person: selectedPerson,
            type: formData.asset_type || "other",
            initial_cost: parseFloat(formData.initial_cost),
            current_value: parseFloat(formData.current_value),
            purchase_date: formData.purchase_date || new Date().toISOString().slice(0, 10),
            annual_return_rate: parseFloat(formData.annual_return_rate) || 0,
            annual_cost: parseFloat(formData.annual_cost) || 0,
            is_active: true,
            notes: formData.notes,
          });
        }}
        incomeM={incomeM}
        expenseM={expenseM}
        obligationM={obligationM}
        recurringM={recurringM}
        assetM={assetM}
        stores={allStores}
        names={names}
        selectedPerson={selectedPerson}
        currency={currency}
      />
    </div>
  );
}

// Tab Components
function OverviewTab({ t, currency, monthIncomes, monthPurchases, expensesByCategory, personObligations, totalExpense, totalPurchases, totalObligations, setDialogType, setFormData, setDialogOpen, stores }) {
  const { isAr } = useLang();
  const storesByExpense = {};
  monthPurchases.forEach((p) => {
    if (p.store_id) {
      storesByExpense[p.store_id] = (storesByExpense[p.store_id] || 0) + p.cost;
    }
  });

  return (
    <>
      <div className="flex gap-2">
        <Button size="sm" className="flex-1 h-9 rounded-none text-xs" onClick={() => { setDialogType("income"); setFormData({}); setDialogOpen(true); }}>
          {t.addIncome}
        </Button>
        <Button size="sm" variant="outline" className="flex-1 h-9 rounded-none text-xs" onClick={() => { setDialogType("expense"); setFormData({}); setDialogOpen(true); }}>
          {t.addExpense}
        </Button>
      </div>

      {/* Top Stores */}
      {Object.keys(storesByExpense).length > 0 && (
        <div className="space-y-2 rounded-none p-3">
          <p className="text-xs font-heading font-semibold">{isAr ? "أبرز المتاجر" : "Top Stores"}</p>
          {Object.entries(storesByExpense)
            .sort(([, a], [, b]) => b - a)
            .slice(0, 3)
            .map(([storeId, amount]) => {
              const store = stores.find((s) => String(s.id) === String(storeId));
              return (
                <Link
                  key={storeId}
                  to={`/store?id=${storeId}`}
                  className="flex items-center justify-between py-2 border-b border-border/30 hover:bg-secondary/30 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    {store?.logo_url && (
                      <img
                        src={store.logo_url}
                        alt={store.name}
                        className="w-4 h-4 rounded"
                      />
                    )}
                    <span className="text-xs font-body">{store?.name}</span>
                  </div>
                  <span className="text-xs font-semibold">{amount.toFixed(0)} {currency}</span>
                </Link>
              );
            })}
        </div>
      )}

      <div className="space-y-2">
        <h3 className="text-sm font-heading font-semibold">{isAr ? "أبرز العناصر" : "Top Items"}</h3>
        {monthPurchases.slice(0, 3).map((p, i) => (
          <div key={`${p.id ?? "p"}-${i}`} className="flex items-center justify-between py-2">
            <span className="text-xs font-body">{p.perfume_name}</span>
            <span className="text-xs font-semibold">{p.cost.toFixed(0)} {currency}</span>
          </div>
        ))}
      </div>


    </>
  );
}

function IncomeTab({ t, monthIncomes, currency, setDialogType, setFormData, setDialogOpen, incomesSortOrder, setIncomesSortOrder }) {
  const incomesPager = usePagedList(monthIncomes, 50);
  const getIncomeType = (type) => {
    const types = {
      salary: "👨‍💼",
      business: "🏢",
      investment: "📈",
      other: "💰"
    };
    return types[type] || "💰";
  };

  return (
    <>
      <div className="space-y-2">
        <Button size="sm" className="w-full h-9 rounded-none text-xs" onClick={() => { setDialogType("income"); setFormData({}); setDialogOpen(true); }}>
          {t.addIncome}
        </Button>
        <div className="grid grid-cols-4 gap-1">
          {[
            { val: "newest", label: "🆕" },
            { val: "oldest", label: "🕰️" },
            { val: "highest", label: "📈" },
            { val: "lowest", label: "📉" },
          ].map(({ val, label }) => (
            <button
              key={val}
              onClick={() => setIncomesSortOrder(val)}
              className={`px-2 py-1 rounded text-xs font-body ${
                incomesSortOrder === val
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      {monthIncomes.length === 0 ? (
        <p className="text-center text-xs text-muted-foreground py-4">{t.noData}</p>
      ) : (
        <>
        {incomesPager.pageItems.map((inc) => (
          <div key={inc.id} className="py-2.5 border-b border-border/40">
            <div className="flex justify-between items-start">
              <div className="flex gap-2">
                <span className="text-lg">{getIncomeType(inc.type)}</span>
                <div>
                  <p className="text-sm font-body font-semibold">{inc.type}</p>
                  {inc.description && <p className="text-xs text-muted-foreground">{inc.description}</p>}
                  <p className="text-[10px] text-muted-foreground mt-1">{inc.date}</p>
                </div>
              </div>
              <p className="text-sm font-bold text-emerald-600">{inc.amount.toFixed(0)} {currency}</p>
            </div>
          </div>
        ))}
        <SimplePager page={incomesPager.page} setPage={incomesPager.setPage} totalPages={incomesPager.totalPages} />
        </>
      )}
    </>
  );
}

function ExpensesTab({ t, monthExpenses, monthPurchases, currency, setDialogType, setFormData, setDialogOpen, stores, expensesSortOrder, setExpensesSortOrder }) {
  const { isAr } = useLang();
  const allExpenses = [...monthExpenses, ...monthPurchases.map(p => ({ ...p, amount: p.cost, category: "perfume", date: p.purchase_date, type: "purchase" }))];
  const totalPurchasesAmount = monthPurchases.reduce((sum, p) => sum + (p.cost || 0), 0);

  // Paginate the two lists (50 each) — daily expenses pile up fast.
  const purchasesPager = usePagedList(monthPurchases, 50);
  const expensesPager = usePagedList(monthExpenses, 50);

  return (
    <>
      <div className="space-y-2">
        <Button size="sm" className="w-full h-9 rounded-none text-xs" onClick={() => { setDialogType("expense"); setFormData({}); setDialogOpen(true); }}>
          {t.addExpense}
        </Button>
        <div className="grid grid-cols-4 gap-1">
          {[
            { val: "newest", label: "🆕" },
            { val: "oldest", label: "🕰️" },
            { val: "highest", label: "📈" },
            { val: "lowest", label: "📉" },
          ].map(({ val, label }) => (
            <button
              key={val}
              onClick={() => setExpensesSortOrder(val)}
              className={`px-2 py-1 rounded text-xs font-body ${
                expensesSortOrder === val
                  ? "bg-primary text-primary-foreground"
                  : "bg-secondary text-muted-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      
      {/* Purchases Log Section */}
      {monthPurchases.length > 0 && (
        <div className="space-y-2 mt-3">
          <h3 className="text-xs font-heading font-semibold text-primary">🛍️ Purchases Log</h3>
          <div className="space-y-1">
            {purchasesPager.pageItems.map((p, idx) => {
              const storeInfo = p.store_id ? stores.find((s) => String(s.id) === String(p.store_id)) : null;
              return (
                <div
                  key={p.id || idx}
                  className={`py-2.5 border-b border-border/40 cursor-pointer hover:bg-accent/30 transition-colors ${
                    storeInfo ? "border-primary/30" : ""
                  }`}
                  onClick={() =>
                    storeInfo && window.location.assign(`/store?id=${storeInfo.id}`)
                  }
                >
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-body font-semibold">{p.perfume_name}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        {p.purchase_date} • {p.type} • {p.ml}ml
                      </p>
                      {storeInfo && (
                        <p className="text-[10px] text-primary mt-0.5 font-semibold">
                          🏪 {storeInfo.name}
                        </p>
                      )}
                    </div>
                    <p className="text-sm font-bold text-red-600 flex-shrink-0">
                      {p.cost.toFixed(0)} {currency}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
          <SimplePager page={purchasesPager.page} setPage={purchasesPager.setPage} totalPages={purchasesPager.totalPages} />
          {/* Total Amount */}
          <div className="rounded-none p-3">
            <div className="flex justify-between items-center">
              <span className="text-sm font-heading font-semibold text-primary">{isAr ? "إجمالي المشتريات" : "Total Purchases"}</span>
              <span className="text-lg font-bold text-primary">{totalPurchasesAmount.toFixed(0)} {currency}</span>
            </div>
          </div>
        </div>
      )}

      {/* Regular Expenses */}
      {monthExpenses.length > 0 && (
        <div className="space-y-2 mt-3">
          <h3 className="text-xs font-heading font-semibold">📋 Other Expenses</h3>
          <div className="space-y-1">
            {expensesPager.pageItems.map((exp, idx) => {
              const storeInfo = exp.store_id ? stores.find((s) => String(s.id) === String(exp.store_id)) : null;
              return (
                <div
                  key={exp.id || idx}
                  className={`py-2.5 border-b border-border/40 cursor-pointer hover:bg-accent/30 transition-colors ${
                    storeInfo ? "border-primary/30" : ""
                  }`}
                  onClick={() =>
                    storeInfo && window.location.assign(`/store?id=${storeInfo.id}`)
                  }
                >
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-body font-semibold">{exp.category}</p>
                      {exp.description && (
                        <p className="text-xs text-muted-foreground">{exp.description}</p>
                      )}
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {exp.date}
                      </p>
                      {storeInfo && (
                        <p className="text-[10px] text-primary mt-1 font-semibold">
                          🏪 {storeInfo.name}
                        </p>
                      )}
                    </div>
                    <p className="text-sm font-bold text-red-600 flex-shrink-0">
                      {exp.amount.toFixed(0)} {currency}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
          <SimplePager page={expensesPager.page} setPage={expensesPager.setPage} totalPages={expensesPager.totalPages} />
        </div>
      )}

      {allExpenses.length === 0 && (
        <p className="text-center text-xs text-muted-foreground py-4">{t.noData}</p>
      )}
    </>
  );
}

function ObligationsTab({ t, obligations, currency, setDialogType, setFormData, setDialogOpen }) {
  const { isAr } = useLang();
  return (
    <>
      <Button size="sm" className="w-full h-9 rounded-none text-xs" onClick={() => { setDialogType("obligation"); setFormData({}); setDialogOpen(true); }}>
        {t.addObligation}
      </Button>
      {obligations.length === 0 ? (
        <p className="text-center text-xs text-muted-foreground py-4">{isAr ? "لا التزامات نشطة" : "No active obligations"}</p>
      ) : (
        obligations.map((obl) => {
          const remaining = obl.total_amount - obl.paid_amount;
          const progress = (obl.paid_amount / obl.total_amount) * 100;
          return (
            <div key={obl.id} className="py-2.5 border-b border-border/40">
              <div className="space-y-2">
                <div className="flex justify-between">
                  <p className="text-sm font-body font-semibold">{obl.title}</p>
                  <p className="text-xs font-bold">{progress.toFixed(0)}%</p>
                </div>
                <div className="w-full h-1.5 bg-secondary rounded-none overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-orange-400 to-red-500" style={{ width: `${progress}%` }} />
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <p className="text-muted-foreground">{isAr ? "الدفعة" : "Payment"}</p>
                    <p className="font-semibold">{obl.monthly_payment.toFixed(0)} {currency}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "المتبقّي" : "Remaining"}</p>
                    <p className="font-semibold text-red-600">{remaining.toFixed(0)} {currency}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "حتى" : "Until"}</p>
                    <p className="font-semibold text-xs">{obl.end_date}</p>
                  </div>
                </div>
              </div>
            </div>
          );
        })
      )}
    </>
  );
}

function RecurringTab({ t, isAr, recurring = [], incomes = [], expenses = [], obligations = [], assets = [], currency, names, setDialogType, setFormData, setDialogOpen, onDeleteIncome, onDeleteExpense, onDeleteRecurring, onEditIncome, onEditExpense }) {
  // سجل الميزانية الشامل: يجمع كل العمليات (دخل/مصاريف/التزامات/أصول/دورية) في قائمة موحّدة قابلة للتعديل
  const freqLabel = (f) => {
    const map = {
      once: isAr ? "مرة" : "Once", daily: isAr ? "يومي" : "Daily",
      weekly: isAr ? "أسبوعي" : "Weekly", monthly: isAr ? "شهري" : "Monthly",
      quarterly: isAr ? "ربعي" : "Quarterly", yearly: isAr ? "سنوي" : "Yearly",
    };
    return f ? (map[f] || f) : "";
  };

  const rows = [];
  incomes.forEach((i) => rows.push({
    kind: "income", id: i.id, raw: i,
    title: isAr ? "دخل" : "Income", sub: `${i.type || ""}${i.description ? ` ${i.description}` : ""}`,
    amount: i.amount, date: i.date, freq: i.frequency, person: i.person, sign: "+",
  }));
  expenses.forEach((e) => rows.push({
    kind: "expense", id: e.id, raw: e,
    title: isAr ? "مصروف" : "Expense", sub: `${e.category || ""}${e.description ? ` ${e.description}` : ""}`,
    amount: e.amount, date: e.date, freq: e.frequency, person: e.person, sign: "−",
  }));
  obligations.forEach((o) => rows.push({
    kind: "obligation", id: o.id, raw: o,
    title: isAr ? "التزام" : "Obligation", sub: o.title || "",
    amount: o.monthly_payment, date: o.start_date, freq: "monthly", person: o.person, sign: "−",
  }));
  recurring.forEach((r) => rows.push({
    kind: "recurring", id: r.id, raw: r,
    title: isAr ? "دوري" : "Recurring", sub: r.title || "",
    amount: r.amount, date: r.start_date, freq: r.frequency, person: r.person, sign: "−",
  }));
  assets.forEach((a) => rows.push({
    kind: "asset", id: a.id, raw: a,
    title: isAr ? "أصل" : "Asset", sub: a.name || a.type || "",
    amount: a.current_value, date: a.created_date?.slice(0, 10), freq: "", person: a.person, sign: "",
  }));

  // ترتيب بالأحدث
  rows.sort((a, b) => String(b.date || "").localeCompare(String(a.date || "")));

  const KIND_STYLE = {
    income:     { color: "#16a34a", bg: "bg-emerald-50 dark:bg-emerald-950/20", icon: <ArrowUpCircle className="w-4 h-4" /> },
    expense:    { color: "#dc2626", bg: "bg-red-50 dark:bg-red-950/20",         icon: <ArrowDownCircle className="w-4 h-4" /> },
    obligation: { color: "#d97706", bg: "bg-amber-50 dark:bg-amber-950/20",    icon: <FileText className="w-4 h-4" /> },
    recurring:  { color: "#7c3aed", bg: "bg-violet-50 dark:bg-violet-950/20",   icon: <RefreshCw className="w-4 h-4" /> },
    asset:      { color: "#0c447c", bg: "bg-blue-50 dark:bg-blue-950/20",       icon: <Landmark className="w-4 h-4" /> },
  };

  const canEdit = (k) => k === "income" || k === "expense";
  const onEdit = (row) => {
    if (row.kind === "income") onEditIncome?.(row.raw);
    else if (row.kind === "expense") onEditExpense?.(row.raw);
  };
  const onDelete = (row) => {
    if (row.kind === "income") onDeleteIncome?.(row.id);
    else if (row.kind === "expense") onDeleteExpense?.(row.id);
    else if (row.kind === "recurring") onDeleteRecurring?.(row.id);
  };

  return (
    <div className="space-y-3">
      <div className="py-2">
        <p className="text-xs font-heading font-semibold">{isAr ? "📒 سجل الميزانية" : "📒 Budget Log"}</p>
        <p className="text-[10px] text-muted-foreground font-body">
          {isAr ? "كل العمليات: دخل ومصاريف والتزامات وأصول ودورية — قابلة للتعديل" : "All operations: income, expenses, obligations, assets & recurring — editable"}
        </p>
      </div>

      {/* أزرار إضافة سريعة */}
      <div className="grid grid-cols-3 gap-2">
        <Button size="sm" variant="ghost" className="rounded-none text-xs h-9 text-primary hover:text-primary" onClick={() => { setDialogType("income"); setFormData({ date: new Date().toISOString().slice(0,10) }); setDialogOpen(true); }}>
          {isAr ? "إضافة دخل" : "Add Income"}
        </Button>
        <Button size="sm" variant="ghost" className="rounded-none text-xs h-9 text-primary hover:text-primary" onClick={() => { setDialogType("expense"); setFormData({ date: new Date().toISOString().slice(0,10) }); setDialogOpen(true); }}>
          {isAr ? "إضافة مصروف" : "Add Expense"}
        </Button>
        <Button size="sm" variant="ghost" className="rounded-none text-xs h-9 text-primary hover:text-primary" onClick={() => { setDialogType("obligation"); setFormData({}); setDialogOpen(true); }}>
          {isAr ? "إضافة التزام" : "Add Obligation"}
        </Button>
      </div>

      {rows.length === 0 ? (
        <p className="text-center text-xs text-muted-foreground py-6">{t.noData}</p>
      ) : (
        <div className="space-y-2">
          {rows.map((row) => {
            const st = KIND_STYLE[row.kind];
            return (
              <div key={`${row.kind}-${row.id}`} className="py-2.5 border-b border-border/40">
                <div className="flex items-center gap-2.5">
                  <span style={{ color: st.color }} className="flex-shrink-0">{st.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-body font-semibold" style={{ color: st.color }}>{row.title}</p>
                      {row.freq && <span className="text-[9px] rounded-none text-muted-foreground">{freqLabel(row.freq)}</span>}
                    </div>
                    {row.sub && <p className="text-[10px] text-muted-foreground font-body truncate">{row.sub}</p>}
                    {row.date && <p className="text-[9px] text-muted-foreground/70 font-body">{row.date}</p>}
                  </div>
                  <p className="text-sm font-bold flex-shrink-0" style={{ color: st.color }}>
                    {row.sign}{(row.amount || 0).toFixed(0)} {currency}
                  </p>
                  {/* تعديل/حذف */}
                  <div className="flex items-center gap-1 flex-shrink-0">
                    {canEdit(row.kind) && (
                      <button onClick={() => onEdit(row)} className="w-7 h-7 rounded-none flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-background/60 transition-colors">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                    )}
                    {row.kind !== "asset" && row.kind !== "obligation" && (
                      <button onClick={() => onDelete(row)} className="w-7 h-7 rounded-none flex items-center justify-center text-muted-foreground hover:text-destructive hover:bg-background/60 transition-colors">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function AnalysisTab({ t, totalIncome, totalExpense, totalPurchases, totalObligations, totalRecurring, totalSaved = 0, totalSavingsTarget = 0, savingsGoals = [], balance, currency, incomes, personObligations, selectedPerson, getFilteredData, names, monthExpenses, monthPurchases, totalAssetValue, monthlyAssetsReturns, monthlyAssetsCost, personAssets }) {
  const { isAr } = useLang();
  const totalOut = totalExpense + totalPurchases + totalObligations + totalRecurring;

  // Forecast calculations
  const monthlyExpenses = totalExpense + totalPurchases;
  const monthlyFixed = totalObligations + totalRecurring;
  const netMonthly = totalIncome - monthlyExpenses - monthlyFixed;

  const forecast = {
    current: { income: totalIncome, expense: totalOut, balance },
    nextMonth: { income: totalIncome, expense: totalOut, balance: netMonthly },
    sixMonths: { income: totalIncome * 6, expense: totalOut * 6, balance: netMonthly * 6 },
    oneYear: { income: totalIncome * 12, expense: totalOut * 12, balance: netMonthly * 12 },
  };

  // If "All" selected, show individual summaries too
  const showIndividual = selectedPerson === "all";

  return (
    <div className="space-y-4">
      {/* ملخص الادخار — ينعكس من أهداف الادخار */}
      {(totalSavingsTarget > 0 || totalSaved > 0) && (
        <div className="rounded-none p-4 space-y-2">
          <p className="text-sm font-heading font-semibold text-emerald-800 dark:text-emerald-300">
            {isAr ? "🎯 ملخص الادخار" : "🎯 Savings Summary"}
          </p>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <p className="text-[10px] text-muted-foreground font-body">{isAr ? "المُدخر" : "Saved"}</p>
              <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{totalSaved.toFixed(0)} {currency}</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground font-body">{isAr ? "المستهدف" : "Target"}</p>
              <p className="text-sm font-bold text-foreground">{totalSavingsTarget.toFixed(0)} {currency}</p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground font-body">{isAr ? "المتبقي" : "Remaining"}</p>
              <p className="text-sm font-bold text-amber-600 dark:text-amber-400">{Math.max(0, totalSavingsTarget - totalSaved).toFixed(0)} {currency}</p>
            </div>
          </div>
          {totalSavingsTarget > 0 && (
            <div className="w-full h-2 bg-secondary rounded-none overflow-hidden">
              <div className="h-full bg-gradient-to-r from-emerald-400 to-emerald-600 transition-all" style={{ width: `${Math.min(100, (totalSaved / totalSavingsTarget) * 100)}%` }} />
            </div>
          )}
        </div>
      )}

      {/* Spending Visuals */}
      <SpendingVisuals
        monthExpenses={monthExpenses || []}
        monthPurchases={monthPurchases || []}
        monthIncomes={incomes || []}
        totalIncome={totalIncome}
        totalExpense={totalExpense}
        totalPurchases={totalPurchases}
        totalObligations={totalObligations}
        totalRecurring={totalRecurring}
        currency={currency}
      />

      {/* Combined Status */}
      <div className="rounded-none p-4 space-y-3">
        <h3 className="text-sm font-heading font-semibold">📊 {showIndividual ? (isAr ? "الحالة المجمّعة Combined Status" : "Combined Status") : (isAr ? "الحالة الراهنة Current Status" : "Current Status")}</h3>
        <div className="space-y-2 text-xs">
          <div className="flex justify-between">
            <span>{isAr ? "الدخل الشهري" : "Monthly Income"}</span>
            <span className="font-bold text-emerald-600">{totalIncome.toFixed(0)} {currency}</span>
          </div>
          <div className="flex justify-between">
            <span>{isAr ? "إجمالي المصاريف" : "Total Expenses"}</span>
            <span className="font-bold text-red-600">{monthlyExpenses.toFixed(0)} {currency}</span>
          </div>
          <div className="flex justify-between">
            <span>{isAr ? "الالتزامات الثابتة" : "Fixed Obligations"}</span>
            <span className="font-bold text-orange-600">{monthlyFixed.toFixed(0)} {currency}</span>
          </div>
          {monthlyAssetsReturns !== 0 && (
            <div className="flex justify-between">
              <span>Assets Returns (Monthly)</span>
              <span className={`font-bold ${monthlyAssetsReturns >= 0 ? "text-blue-600" : "text-red-600"}`}>
                {monthlyAssetsReturns >= 0 ? "+" : ""}{monthlyAssetsReturns.toFixed(0)} {currency}
              </span>
            </div>
          )}
          {monthlyAssetsCost !== 0 && (
            <div className="flex justify-between">
              <span>Assets Costs (Monthly)</span>
              <span className="font-bold text-red-600">-{monthlyAssetsCost.toFixed(0)} {currency}</span>
            </div>
          )}
          <div className="border-t border-border/50 pt-2 mt-2 flex justify-between">
            <span className="font-semibold">{isAr ? "الصافي الشهري" : "Net Monthly"}</span>
            <span className={`font-bold ${netMonthly >= 0 ? "text-emerald-600" : "text-red-600"}`}>
              {netMonthly.toFixed(0)} {currency}
            </span>
          </div>
        </div>
      </div>

      {/* Individual Breakdown if Together */}
      {showIndividual && (
        <div className="space-y-3">
          <h3 className="text-sm font-heading font-semibold">👥 {isAr ? "تفصيل الأفراد Individual Breakdown" : "Individual Breakdown"}</h3>
          {["person1", "person2", "family"].map((person) => {
            const pData = getFilteredData(person);
            const pIncome = pData.incomes.reduce((sum, i) => sum + (i.amount || 0), 0);
            const pExpense = pData.expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
            const pPurchase = pData.purchases.reduce((sum, p) => sum + (p.cost || 0), 0);
            const pOblig = pData.obligations.reduce((sum, o) => sum + (o.monthly_payment || 0), 0);
            const pRecur = pData.recurring.reduce((sum, r) => sum + (r.amount || 0), 0);
            const pOut = pExpense + pPurchase + pOblig + pRecur;
            const pBalance = pIncome - pOut;

            const personLabel = person === "person1" ? names.person1 || "A" : person === "person2" ? names.person2 || "B" : "Family";
            
            return (
              <div key={person} className="py-2 space-y-2">
                <p className="text-sm font-body font-semibold">{personLabel}</p>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <p className="text-muted-foreground">{isAr ? "الدخل" : "Income"}</p>
                    <p className="font-bold text-emerald-600">{pIncome.toFixed(0)} {currency}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "صرف" : "Out"}</p>
                    <p className="font-bold text-red-600">{pOut.toFixed(0)} {currency}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "الرصيد" : "Balance"}</p>
                    <p className={`font-bold ${pBalance >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                      {pBalance.toFixed(0)} {currency}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <div className="space-y-2">
        <h3 className="text-sm font-heading font-semibold">🔮 {isAr ? "توقّع ٦ و١٢ شهراً 6 & 12-Month Forecast" : "6 & 12-Month Forecast"}</h3>
        <div className="grid grid-cols-2 gap-2">
          <ForecastCard label={isAr ? "٦ أشهر" : "6 Months"} data={forecast.sixMonths} currency={currency} isAr={isAr} />
          <ForecastCard label={isAr ? "سنة" : "1 Year"} data={forecast.oneYear} currency={currency} isAr={isAr} />
        </div>
        {/* توقع نمو الادخار: المُدخر الحالي + الفائض الشهري */}
        {(totalSavingsTarget > 0 || totalSaved > 0) && (
          <div className="py-2 space-y-1.5">
            <p className="text-[11px] font-body font-semibold text-muted-foreground">{isAr ? "توقع الادخار (المُدخر + الفائض الشهري)" : "Savings forecast (saved + monthly surplus)"}</p>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-[9px] text-muted-foreground">{isAr ? "الآن" : "Now"}</p>
                <p className="text-xs font-bold text-emerald-600">{totalSaved.toFixed(0)}</p>
              </div>
              <div>
                <p className="text-[9px] text-muted-foreground">{isAr ? "6 أشهر" : "6 Mo"}</p>
                <p className="text-xs font-bold text-emerald-600">{(totalSaved + Math.max(0, netMonthly) * 6).toFixed(0)}</p>
              </div>
              <div>
                <p className="text-[9px] text-muted-foreground">{isAr ? "سنة" : "1 Yr"}</p>
                <p className="text-xs font-bold text-emerald-600">{(totalSaved + Math.max(0, netMonthly) * 12).toFixed(0)}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {personObligations.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-heading font-semibold">📋 Debt Payoff Timeline</h3>
          {personObligations.map((obl) => {
            const remaining = obl.total_amount - obl.paid_amount;
            const monthsLeft = Math.ceil(remaining / obl.monthly_payment);
            const payoffDate = new Date();
            payoffDate.setMonth(payoffDate.getMonth() + monthsLeft);
            
            return (
              <div key={obl.id} className="py-2.5 border-b border-border/40">
                <p className="text-sm font-body font-semibold mb-1">{obl.title}</p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <p className="text-muted-foreground">{isAr ? "المتبقّي" : "Remaining"}</p>
                    <p className="font-bold">{remaining.toFixed(0)} {currency}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "يُسدّد خلال" : "Payoff In"}</p>
                    <p className="font-bold">{monthsLeft} months</p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* أرغب بالشراء + مجموعتي — منقولة لأسفل الصفحة */}
      <div className="flex flex-wrap gap-x-5 gap-y-1 px-1 pt-2">
        <Link to="/wishlist" className="text-sm font-body font-semibold text-pink-600 dark:text-pink-400 py-2 hover:opacity-70 transition-opacity">
         {isAr ? "أرغب بالشراء" : "I Want To Buy"}
        </Link>
        <Link to="/my-perfumes" className="text-sm font-body font-semibold text-emerald-600 dark:text-emerald-400 py-2 hover:opacity-70 transition-opacity">
         {isAr ? "مجموعتي من العطور" : "My Perfume Collection"}
        </Link>
      </div>
    </div>
  );
}

function ForecastCard({ label, data, currency, isAr }) {
  const { income, expense, balance } = data;
  return (
    <div className="py-2.5 border-b border-border/40 space-y-1">
      <p className="text-xs font-body font-semibold text-muted-foreground">{label}</p>
      <div className="text-xs space-y-0.5">
        <div className="flex justify-between">
          <span className="text-muted-foreground">{isAr ? "دخل" : "In"}</span>
          <span className="text-emerald-600 font-semibold">{income.toFixed(0)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">{isAr ? "صرف" : "Out"}</span>
          <span className="text-red-600 font-semibold">{expense.toFixed(0)}</span>
        </div>
      </div>
      <div className="border-t border-border/50 pt-1 flex justify-between text-xs">
        <span className="font-semibold">{isAr ? "الصافي" : "Net"}</span>
        <span className={`font-bold ${balance >= 0 ? "text-emerald-600" : "text-red-600"}`}>
          {balance.toFixed(0)} {currency}
        </span>
      </div>
    </div>
  );
}

function AssetsTab({ assets, currency, setDialogType, setFormData, setDialogOpen }) {
  const { isAr } = useLang();
  const getAssetType = (type) => {
    const types = {
      real_estate: "🏠",
      vehicle: "🚗",
      investment: "📈",
      savings: "💰",
      cryptocurrency: "₿",
      equipment: "⚙️",
      other: "📦"
    };
    return types[type] || "📦";
  };

  return (
    <>
      <Button size="sm" className="w-full h-9 rounded-none text-xs" onClick={() => { setDialogType("asset"); setFormData({}); setDialogOpen(true); }}>
        Add Asset
      </Button>
      {assets.length === 0 ? (
        <p className="text-center text-xs text-muted-foreground py-4">{isAr ? "لا أصول مسجّلة" : "No assets tracked"}</p>
      ) : (
        assets.map((asset) => {
          const netReturn = ((asset.current_value - asset.initial_cost) / asset.initial_cost) * 100;
          const monthlyReturn = ((asset.current_value || 0) * (asset.annual_return_rate || 0) / 100) / 12;
          const monthlyCost = (asset.annual_cost || 0) / 12;
          const monthlyNet = monthlyReturn - monthlyCost;
          
          return (
            <div key={asset.id} className="py-2.5 border-b border-border/40">
              <div className="space-y-2">
                <div className="flex justify-between items-start">
                  <div className="flex gap-2">
                    <span className="text-lg">{getAssetType(asset.type)}</span>
                    <div>
                      <p className="text-sm font-body font-semibold">{asset.name}</p>
                      <p className="text-[10px] text-muted-foreground capitalize">{asset.type.replace(/_/g, " ")}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-blue-600">{asset.current_value.toFixed(0)} {currency}</p>
                    <p className={`text-[10px] font-semibold ${netReturn >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                      {netReturn >= 0 ? "+" : ""}{netReturn.toFixed(1)}%
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-1 text-[10px]">
                  <div className="bg-secondary/50 rounded p-1.5">
                    <p className="text-muted-foreground mb-0.5">{isAr ? "البداية" : "Initial"}</p>
                    <p className="font-semibold">{asset.initial_cost.toFixed(0)}</p>
                  </div>
                  <div className="bg-secondary/50 rounded p-1.5">
                    <p className="text-muted-foreground mb-0.5">{isAr ? "قيّم" : "Rate"}</p>
                    <p className="font-semibold">{asset.annual_return_rate || 0}%</p>
                  </div>
                  <div className="bg-secondary/50 rounded p-1.5">
                    <p className="text-muted-foreground mb-0.5">{isAr ? "العائد" : "Return"}</p>
                    <p className={`font-semibold ${monthlyReturn >= 0 ? "text-emerald-600" : "text-red-600"}`}>
                      {monthlyReturn >= 0 ? "+" : ""}{monthlyReturn.toFixed(0)}
                    </p>
                  </div>
                  <div className="bg-secondary/50 rounded p-1.5">
                    <p className="text-muted-foreground mb-0.5">{isAr ? "التكلفة" : "Cost"}</p>
                    <p className="font-semibold text-red-600">{monthlyCost.toFixed(0)}</p>
                  </div>
                </div>
                {asset.notes && <p className="text-[10px] text-muted-foreground italic">{asset.notes}</p>}
              </div>
            </div>
          );
        })
      )}
    </>
  );
}

function FormDialog({ t, dialogOpen, setDialogOpen, dialogType, formData, setFormData, onAddIncome, onAddExpense, onAddObligation, onAddRecurring, onAddAsset, incomeM, expenseM, obligationM, recurringM, assetM, stores, names, selectedPerson, currency }) {
  const { isAr } = useLang();
  return (
    <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
      <DialogContent className="max-w-sm rounded-none max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading text-base">
            {dialogType === "income" && t.addIncome}
            {dialogType === "expense" && t.addExpense}
            {dialogType === "obligation" && t.addObligation}
            {dialogType === "recurring" && t.addRecurring}
            {dialogType === "asset" && "🏦 Add Asset"}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {/* محدّد الشخص — أول خيار دائماً */}
          <div>
            <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">{isAr ? "لِمَن" : "For"}</p>
            <div className="grid grid-cols-3 gap-1">
              {[
                { val: "family", label: isAr ? "العائلة" : "Family" },
                { val: "person1", label: names?.person1 || (isAr ? "أنا" : "User A") },
                { val: "person2", label: names?.person2 || (isAr ? "الشريك" : "User B") },
              ].map(({ val, label }) => {
                const cur = formData.person || (selectedPerson === "all" ? "family" : selectedPerson);
                const active = cur === val;
                return (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setFormData({ ...formData, person: val })}
                    className={`py-1.5 text-xs font-body rounded-none transition-colors ${
                      active ? "bg-primary/15 text-primary font-semibold" : "bg-transparent text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* تخصيص متقدّم — الافتراضي: إدخال اعتيادي بسيط. الخيارات المتقدّمة (طريقة الاحتساب) عند الطلب فقط */}
          {["income", "expense", "obligation"].includes(dialogType) && (
            <button type="button" onClick={() => setFormData({ ...formData, customize: !formData.customize })}
              className="text-[11px] font-body text-primary hover:opacity-70 transition-opacity">
              {formData.customize ? (isAr ? "إخفاء الخيارات المتقدّمة" : "Hide advanced") : (isAr ? "تخصيص متقدّم" : "Customize")}
            </button>
          )}

          {/* طريقة الاحتساب — توثيقي (كما هو) أو فعلي (مكافئ شهري ينعكس على الإجماليات) */}
          {formData.customize && ["income", "expense", "obligation"].includes(dialogType) && (
            <div>
              <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">{isAr ? "طريقة الاحتساب" : "How it counts"}</p>
              <div className="grid grid-cols-2 gap-1">
                {[
                  { val: "doc", label: isAr ? "توثيقي كما هو" : "As entered" },
                  { val: "actual", label: isAr ? "فعلي شهرياً" : "Real monthly" },
                ].map(({ val, label }) => {
                  const active = (formData.recurring_mode || "doc") === val;
                  return (
                    <button key={val} type="button" onClick={() => setFormData({ ...formData, recurring_mode: val })}
                      className={`py-1.5 text-xs font-body rounded-none transition-colors ${active ? "bg-primary/15 text-primary font-semibold" : "bg-transparent text-muted-foreground hover:text-foreground"}`}>
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {dialogType === "income" && (
            <>
              <Input
                type="date"
                value={formData.date || ""}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="rounded-none h-10 font-body text-sm"
              />
              <Input type="number" placeholder={isAr ? "المبلغ" : "Amount"} value={formData.amount || ""} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} className="rounded-none h-10" />
              <Select value={formData.type || "salary"} onValueChange={(v) => setFormData({ ...formData, type: v })}>
                <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="salary">{isAr ? "راتب" : "Salary"}</SelectItem>
                  <SelectItem value="business">{isAr ? "عمل" : "Business"}</SelectItem>
                  <SelectItem value="investment">{isAr ? "استثمار" : "Investment"}</SelectItem>
                  <SelectItem value="other">{isAr ? "أخرى" : "Other"}</SelectItem>
                </SelectContent>
              </Select>
              <Textarea placeholder={isAr ? "ملاحظات اختياري" : "Notes (optional)"} value={formData.description || ""} onChange={(e) => setFormData({ ...formData, description: e.target.value })} className="rounded-none text-xs resize-none min-h-[60px]" />
              <div>
                <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">{isAr ? "التكرار" : "Repeat"}</p>
                <Select value={formData.frequency || "once"} onValueChange={(v) => setFormData({ ...formData, frequency: v })}>
                  <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["once","daily","weekly","biweekly","monthly","quarterly","semiannual","yearly"].map((f) => (
                      <SelectItem key={f} value={f}>{isAr ? FREQ_LABELS[f].ar : FREQ_LABELS[f].en}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formData.recurring_mode === "actual" && formData.frequency && !["once","monthly"].includes(formData.frequency) && (
                  <p className="text-[10px] text-primary font-body mt-1">≈ {toMonthly(formData.amount, formData.frequency).toFixed(0)} {currency}{isAr ? " شهرياً" : "/mo"}</p>
                )}
              </div>
              <Button className="w-full h-10 rounded-none" onClick={onAddIncome} disabled={incomeM.isPending}>
                {incomeM.isPending ? (t.adding || "..") : t.addIncome}
              </Button>
            </>
          )}

          {dialogType === "expense" && (
            <>
              <Input type="date" value={formData.date || ""} onChange={(e) => setFormData({ ...formData, date: e.target.value })} className="rounded-none h-10" />
              <Input type="number" placeholder={isAr ? "المبلغ" : "Amount"} value={formData.amount || ""} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} className="rounded-none h-10" />
              <Select value={formData.category || "other"} onValueChange={(v) => setFormData({ ...formData, category: v })}>
                <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="food">{isAr ? "طعام" : "Food"}</SelectItem>
                  <SelectItem value="transportation">{isAr ? "النقل" : "Transportation"}</SelectItem>
                  <SelectItem value="utilities">{isAr ? "مرافق" : "Utilities"}</SelectItem>
                  <SelectItem value="shopping">{isAr ? "التسوّق" : "Shopping"}</SelectItem>
                  <SelectItem value="entertainment">{isAr ? "ترفيه" : "Entertainment"}</SelectItem>
                  <SelectItem value="perfume">{isAr ? "العطر" : "Perfume"}</SelectItem>
                  <SelectItem value="other">{isAr ? "أخرى" : "Other"}</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-[10px] text-muted-foreground font-body uppercase">Store (optional)</p>
              <StoreSelector
                value={formData.store_id || ""}
                onChange={(storeId) => {
                  const store = storeId ? stores?.find?.(s => String(s.id) === String(storeId)) : null;
                  setFormData({
                    ...formData,
                    store_id: storeId,
                    store_name: store?.name,
                  });
                }}
              />
              <Textarea placeholder={isAr ? "النوتات" : "Notes"} value={formData.description || ""} onChange={(e) => setFormData({ ...formData, description: e.target.value })} className="rounded-none text-xs resize-none min-h-[60px]" />
              <div>
                <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">{isAr ? "التكرار" : "Repeat"}</p>
                <Select value={formData.frequency || "once"} onValueChange={(v) => setFormData({ ...formData, frequency: v })}>
                  <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["once","daily","weekly","biweekly","monthly","quarterly","semiannual","yearly"].map((f) => (
                      <SelectItem key={f} value={f}>{isAr ? FREQ_LABELS[f].ar : FREQ_LABELS[f].en}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formData.recurring_mode === "actual" && formData.frequency && !["once","monthly"].includes(formData.frequency) && (
                  <p className="text-[10px] text-primary font-body mt-1">≈ {toMonthly(formData.amount, formData.frequency).toFixed(0)} {currency}{isAr ? " شهرياً" : "/mo"}</p>
                )}
              </div>
              <Button className="w-full h-10 rounded-none" onClick={onAddExpense} disabled={expenseM.isPending}>
                {expenseM.isPending ? (t.adding || "..") : t.addExpense}
              </Button>
            </>
          )}

          {dialogType === "obligation" && (
            <>
              <Input placeholder={isAr ? "عنوان الالتزام" : "Obligation Title"} value={formData.title || ""} onChange={(e) => setFormData({ ...formData, title: e.target.value })} className="rounded-none h-10" />
              <Input type="number" placeholder={isAr ? "المبلغ الكلي" : "Total Amount"} value={formData.total_amount || ""} onChange={(e) => setFormData({ ...formData, total_amount: e.target.value })} className="rounded-none h-10" />
              <Input type="number" placeholder={isAr ? "الدفعة الشهرية" : "Monthly Payment"} value={formData.monthly_payment || ""} onChange={(e) => setFormData({ ...formData, monthly_payment: e.target.value })} className="rounded-none h-10" />
              <Input type="number" placeholder={isAr ? "المدفوع سابقاً" : "Already Paid"} value={formData.paid_amount || ""} onChange={(e) => setFormData({ ...formData, paid_amount: e.target.value })} className="rounded-none h-10" />
              <Input type="date" value={formData.end_date || ""} onChange={(e) => setFormData({ ...formData, end_date: e.target.value })} className="rounded-none h-10" placeholder={isAr ? "تاريخ الانتهاء" : "End Date"} />
              <div>
                <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">{isAr ? "تكرار الدفعة" : "Payment frequency"}</p>
                <Select value={formData.frequency || "monthly"} onValueChange={(v) => setFormData({ ...formData, frequency: v })}>
                  <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {["daily","weekly","biweekly","monthly","quarterly","semiannual","yearly"].map((f) => (
                      <SelectItem key={f} value={f}>{isAr ? FREQ_LABELS[f].ar : FREQ_LABELS[f].en}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formData.recurring_mode === "actual" && formData.frequency && formData.frequency !== "monthly" && (
                  <p className="text-[10px] text-primary font-body mt-1">≈ {toMonthly(formData.monthly_payment, formData.frequency).toFixed(0)} {currency}{isAr ? " شهرياً" : "/mo"}</p>
                )}
              </div>
              <Button className="w-full h-10 rounded-none" onClick={onAddObligation} disabled={obligationM.isPending}>
                {obligationM.isPending ? (t.adding || "..") : t.addObligation}
              </Button>
            </>
          )}

          {dialogType === "recurring" && (
            <>
              <Input placeholder={isAr ? "عنوان المصروف" : "Expense Title"} value={formData.title || ""} onChange={(e) => setFormData({ ...formData, title: e.target.value })} className="rounded-none h-10" />
              <Input type="number" placeholder={isAr ? "المبلغ" : "Amount"} value={formData.amount || ""} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} className="rounded-none h-10" />
              <Input type="date" value={formData.start_date || ""} onChange={(e) => setFormData({ ...formData, start_date: e.target.value })} className="rounded-none h-10" />
              <Select value={formData.frequency || "monthly"} onValueChange={(v) => setFormData({ ...formData, frequency: v })}>
                <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">{isAr ? "يومي" : "Daily"}</SelectItem>
                  <SelectItem value="weekly">{isAr ? "أسبوعي" : "Weekly"}</SelectItem>
                  <SelectItem value="monthly">{isAr ? "شهري" : "Monthly"}</SelectItem>
                  <SelectItem value="quarterly">{isAr ? "ربع سنوي" : "Quarterly"}</SelectItem>
                  <SelectItem value="yearly">{isAr ? "سنوي" : "Yearly"}</SelectItem>
                </SelectContent>
              </Select>
              <Button className="w-full h-10 rounded-none" onClick={onAddRecurring} disabled={recurringM.isPending}>
                {recurringM.isPending ? "Adding.." : "Add Recurring"}
              </Button>
            </>
          )}

          {dialogType === "asset" && (
            <>
              <Input placeholder={isAr ? "اسم الأصل" : "Asset Name"} value={formData.name || ""} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="rounded-none h-10" />
              <Select value={formData.asset_type || "other"} onValueChange={(v) => setFormData({ ...formData, asset_type: v })}>
                <SelectTrigger className="rounded-none h-10"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="real_estate">🏠 Real Estate</SelectItem>
                  <SelectItem value="vehicle">🚗 Vehicle</SelectItem>
                  <SelectItem value="investment">📈 Investment</SelectItem>
                  <SelectItem value="savings">💰 Savings</SelectItem>
                  <SelectItem value="cryptocurrency">₿ Cryptocurrency</SelectItem>
                  <SelectItem value="equipment">⚙️ Equipment</SelectItem>
                  <SelectItem value="other">📦 Other</SelectItem>
                </SelectContent>
              </Select>
              <Input type="date" value={formData.purchase_date || ""} onChange={(e) => setFormData({ ...formData, purchase_date: e.target.value })} className="rounded-none h-10" placeholder={isAr ? "تاريخ الشراء" : "Purchase Date"} />
              <Input type="number" placeholder={isAr ? "التكلفة الأولية" : "Initial Cost"} value={formData.initial_cost || ""} onChange={(e) => setFormData({ ...formData, initial_cost: e.target.value })} className="rounded-none h-10" />
              <Input type="number" placeholder={isAr ? "القيمة الحالية" : "Current Value"} value={formData.current_value || ""} onChange={(e) => setFormData({ ...formData, current_value: e.target.value })} className="rounded-none h-10" />
              <Input type="number" placeholder={isAr ? "العائد السنوي %" : "Annual Return Rate (%)"} value={formData.annual_return_rate || ""} onChange={(e) => setFormData({ ...formData, annual_return_rate: e.target.value })} className="rounded-none h-10" />
              <Input type="number" placeholder={isAr ? "التكلفة السنوية" : "Annual Cost"} value={formData.annual_cost || ""} onChange={(e) => setFormData({ ...formData, annual_cost: e.target.value })} className="rounded-none h-10" />
              <Textarea placeholder={isAr ? "ملاحظات اختياري" : "Notes (optional)"} value={formData.notes || ""} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} className="rounded-none text-xs resize-none min-h-[60px]" />
              <Button className="w-full h-10 rounded-none" onClick={onAddAsset} disabled={assetM.isPending}>
                {assetM.isPending ? "Adding.." : "Add Asset"}
              </Button>
            </>
          )}
          </div>
          </DialogContent>
          </Dialog>
          );
          }