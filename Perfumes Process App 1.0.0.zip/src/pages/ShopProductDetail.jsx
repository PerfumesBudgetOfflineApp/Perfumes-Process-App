import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ArrowLeft, Square, Package, Edit3, Trash2, Check, X, Receipt, Pencil } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { useCurrency } from "@/lib/useCurrency";
import { usePersonNames } from "@/lib/usePersonNames";

function StarInput({ value, onChange }) {
  return (
    <div className="flex gap-1" dir="ltr">
      {[1,2,3,4,5].map(n => (
        <button key={n} type="button" onClick={() => onChange(n === value ? 0 : n)} className="active:scale-90 transition-transform">
          <Square className={`w-5 h-5 transition-colors ${n <= value ? "fill-[var(--brand)] text-[var(--brand)]" : "fill-none text-[var(--brand)]/30"}`} />
        </button>
      ))}
    </div>
  );
}

// Inline edit/delete for a single purchase log
function PurchaseLogRow({ log, onDelete, onUpdate, isAr, formatPrice }) {
  const [editing, setEditing] = useState(false);
  const [cost, setCost] = useState(log.cost || "");
  const [date, setDate] = useState(log.purchase_date || "");
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    await onUpdate(log.id, { cost: parseFloat(cost), purchase_date: date }, log.cost || 0);
    setEditing(false);
    setSaving(false);
  };

  return (
    <div className="flex flex-col gap-1.5 bg-secondary/40 rounded-none p-3">
      {editing ? (
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <p className="text-[9px] text-muted-foreground font-body uppercase mb-1">{isAr ? "التكلفة" : "Cost"}</p>
              <Input value={cost} onChange={e => setCost(e.target.value)} type="number" className="h-8 rounded-none font-body text-xs" />
            </div>
            <div>
              <p className="text-[9px] text-muted-foreground font-body uppercase mb-1">{isAr ? "التاريخ" : "Date"}</p>
              <Input value={date} onChange={e => setDate(e.target.value)} type="date" className="h-8 rounded-none font-body text-xs" />
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" className="flex-1 h-7 rounded-none font-body text-xs" onClick={handleSave} disabled={saving}>
              {saving ? ".." : <Check className="w-3.5 h-3.5" />}
            </Button>
            <Button size="sm" variant="ghost" className="flex-1 h-7 rounded-none" onClick={() => setEditing(false)}>
              <X className="w-3.5 h-3.5" />
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Receipt className="w-3 h-3 text-muted-foreground flex-shrink-0" />
            <span className="text-[10px] text-muted-foreground font-body">{log.purchase_date}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-primary font-heading">{formatPrice(log.cost)}</span>
            <button onClick={() => { setCost(log.cost); setDate(log.purchase_date); setEditing(true); }}
              className="p-1 hover:bg-secondary rounded-none transition-colors text-muted-foreground">
              <Pencil className="w-3 h-3" />
            </button>
            <button onClick={() => onDelete(log.id, log.cost || 0)}
              className="p-1 hover:bg-destructive/10 rounded-none transition-colors text-destructive">
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function ShopProductDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get("id");
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAr } = useLang();
  const { formatPrice, currency } = useCurrency();
  const { names } = usePersonNames();

  const [editMode, setEditMode] = useState(false);
  const [editForm, setEditForm] = useState(null);
  const [addPurchase, setAddPurchase] = useState(false);
  const [purchaseForm, setPurchaseForm] = useState({ cost: "", purchase_date: new Date().toISOString().slice(0,10) });

  const deleteMutation = useMutation({
    mutationFn: () => apphost.entities.ShopProduct.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["shop-products"] });
      toast.success(isAr ? "تم الحذف" : "Deleted");
      navigate("/shopping");
    },
  });

  const { data: product, isLoading } = useQuery({
    queryKey: ["shop-product", id],
    queryFn: async () => {
      const list = await apphost.entities.ShopProduct.filter({ id });
      return list?.[0] || null;
    },
    enabled: !!id,
  });

  // Purchase logs for this product
  const { data: purchaseLogs = [], refetch: refetchLogs } = useQuery({
    queryKey: ["shop-product-purchases", id],
    queryFn: () => apphost.entities.BudgetExpense.filter({ description: { $regex: `.*` } }, "-date", 200)
      .then(all => all.filter(e => e.category === "shopping" && e.description?.includes(product?.name || "NOMATCH") && e.description?.includes("re-purchase"))),
    enabled: !!product?.name,
    staleTime: 0,
  });

  const updateMutation = useMutation({
    mutationFn: (data) => apphost.entities.ShopProduct.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["shop-product", id] });
      queryClient.invalidateQueries({ queryKey: ["shop-products"] });
      setEditMode(false);
      toast.success(isAr ? "تم الحفظ" : "Saved!");
    },
  });

  const startEdit = () => {
    if (!product) return;
    setEditForm({ ...product });
    setEditMode(true);
  };

  const handleSaveEdit = () => {
    const data = { ...editForm, cost: editForm.cost ? Number(editForm.cost) : 0 };
    updateMutation.mutate(data);
  };

  const handleAddPurchase = async () => {
    if (!purchaseForm.cost) { toast.error(isAr ? "أدخل التكلفة" : "Enter cost"); return; }
    const costVal = Number(purchaseForm.cost);
    const newCost = (product?.cost || 0) + costVal;

    // Update product total cost
    await apphost.entities.ShopProduct.update(id, { cost: newCost, purchase_date: purchaseForm.purchase_date });

    // Add budget entry
    await apphost.entities.BudgetExpense.create({
      date: purchaseForm.purchase_date,
      amount: costVal,
      category: "shopping",
      description: `${product?.name} (re-purchase)`,
      person: product?.person === "family" ? "family" : (product?.person || "person1"),
      type: "essential",
    });

    queryClient.invalidateQueries({ queryKey: ["shop-product", id] });
    queryClient.invalidateQueries({ queryKey: ["shop-products"] });
    queryClient.invalidateQueries({ queryKey: ["shop-product-purchases", id] });
    setAddPurchase(false);
    setPurchaseForm({ cost: "", purchase_date: new Date().toISOString().slice(0,10) });
    toast.success(isAr ? "تمت الإضافة" : "Purchase added!");
  };

  const handleDeletePurchaseLog = async (logId, logCost) => {
    if (!confirm(isAr ? "حذف هذا السجل؟" : "Delete this purchase log?")) return;
    await apphost.entities.BudgetExpense.delete(logId);
    // Subtract from product cost
    const newCost = Math.max(0, (product?.cost || 0) - logCost);
    await apphost.entities.ShopProduct.update(id, { cost: newCost });
    queryClient.invalidateQueries({ queryKey: ["shop-product", id] });
    queryClient.invalidateQueries({ queryKey: ["shop-products"] });
    queryClient.invalidateQueries({ queryKey: ["shop-product-purchases", id] });
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleUpdatePurchaseLog = async (logId, updates, oldCost) => {
    await apphost.entities.BudgetExpense.update(logId, { amount: updates.cost, date: updates.purchase_date });
    const delta = updates.cost - oldCost;
    if (delta !== 0) {
      await apphost.entities.ShopProduct.update(id, { cost: Math.max(0, (product?.cost || 0) + delta) });
    }
    queryClient.invalidateQueries({ queryKey: ["shop-product", id] });
    queryClient.invalidateQueries({ queryKey: ["shop-products"] });
    queryClient.invalidateQueries({ queryKey: ["shop-product-purchases", id] });
    toast.success(isAr ? "تم التحديث" : "Updated");
  };

  if (isLoading) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  if (!product) return (
    <div className="px-5 page-top text-center">
      <p className="text-muted-foreground font-body">{isAr ? "المنتج غير موجود" : "Product not found"}</p>
      <Button variant="ghost" onClick={() => navigate(-1)} className="mt-4">{isAr ? "رجوع" : "Go Back"}</Button>
    </div>
  );

  const p = editMode ? editForm : product;

  return (
    <div className="min-h-screen bg-background pb-28">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b border-border px-4 py-3 flex items-center gap-3">
        <Button variant="ghost" size="icon" className="rounded-none" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="font-heading font-bold text-base flex-1 whitespace-nowrap overflow-hidden" style={{ textOverflow: "clip" }}>{(() => { const nm = (isAr ? (product.name_ar || product.name) : (product.name || product.name_ar)) || ""; return nm.length > 30 ? nm.slice(0, 30).trimEnd() + ".." : nm; })()}</h1>
        {!editMode ? (
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" onClick={startEdit} className="rounded-none">
              <Edit3 className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={() => deleteMutation.mutate()} className="rounded-none text-red-500 hover:text-red-600 hover:bg-red-50">
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        ) : (
          <div className="flex gap-1">
            <Button size="sm" className="h-8 rounded-none font-body text-xs" onClick={handleSaveEdit} disabled={updateMutation.isPending}>
              <Check className="w-3.5 h-3.5 mr-1" />{isAr ? "حفظ" : "Save"}
            </Button>
            <Button size="sm" variant="ghost" className="h-8 rounded-none" onClick={() => setEditMode(false)}>
              <X className="w-3.5 h-3.5" />
            </Button>
          </div>
        )}
      </div>

      <div className="px-4 py-4 space-y-4">
        {/* Product Image */}
        <div className="flex gap-4 items-start">
          {product.image_url ? (
            <img src={product.image_url} alt={product.name} className="w-24 h-24 rounded-none object-cover flex-shrink-0 shadow" />
          ) : (
            <div className="w-24 h-24 rounded-none bg-secondary flex items-center justify-center flex-shrink-0">
              <Package className="w-10 h-10 text-muted-foreground/40" />
            </div>
          )}
          <div className="flex-1 min-w-0 space-y-1">
            {editMode ? (
              <div className="space-y-2">
                <Input value={editForm.name} onChange={e => setEditForm(p => ({ ...p, name: e.target.value }))} className="h-9 rounded-none font-body text-sm" placeholder={isAr ? "الاسم بالإنجليزية" : "Name (EN)"} />
                <Input value={editForm.name_ar || ""} onChange={e => setEditForm(p => ({ ...p, name_ar: e.target.value }))} className="h-9 rounded-none font-body text-sm" placeholder="الاسم (AR)" dir="rtl" />
              </div>
            ) : (
              <>
                <h2 className="font-heading font-bold text-lg">{product.name}</h2>
                {product.name_ar && <p className="text-sm text-muted-foreground font-body" dir="rtl">{product.name_ar}</p>}
              </>
            )}
            <div className="flex flex-wrap gap-1.5 mt-2">
              {product.brand_name && (
                <Link to={`/brand?name=${encodeURIComponent(product.brand_name)}`}
                  className="text-[10px] text-primary rounded-none font-body font-bold underline-offset-2 hover:underline">
                  {product.brand_name}
                </Link>
              )}
              {product.category_name_en && (
                <span className="text-[10px] text-muted-foreground rounded-none font-body">{isAr ? product.category_name_ar : product.category_name_en}</span>
              )}
              {product.linked_perfume_name && (
                product.linked_perfume_id ? (
                  <Link to={`/perfume?id=${product.linked_perfume_id}`}
                    className="text-[10px] text-purple-600 rounded-none font-body underline-offset-2 hover:underline">
                    🌸 {product.linked_perfume_name}
                  </Link>
                ) : (
                  <span className="text-[10px] text-purple-600 rounded-none font-body">🌸 {product.linked_perfume_name}</span>
                )
              )}
            </div>
          </div>
        </div>

        {/* Cost & Date */}
        <div className="bg-card border border-border rounded-none p-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "التكلفة الكلية" : "Total Cost"}</p>
              {editMode ? (
                <Input value={editForm.cost} onChange={e => setEditForm(p => ({ ...p, cost: e.target.value }))} type="number" className="h-9 rounded-none font-body mt-1 text-sm" />
              ) : (
                <p className="font-bold text-primary text-lg">{formatPrice(product.cost)}</p>
              )}
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "آخر شراء" : "Last Purchase"}</p>
              {editMode ? (
                <Input value={editForm.purchase_date || ""} onChange={e => setEditForm(p => ({ ...p, purchase_date: e.target.value }))} type="date" className="h-9 rounded-none font-body mt-1 text-sm" />
              ) : (
                <p className="font-body text-sm font-semibold mt-1">{product.purchase_date || "—"}</p>
              )}
            </div>
          </div>
          {product.recurring && (
            <div className="mt-2 pt-2 border-t border-border/40">
              <span className="text-[10px] text-blue-600 dark:text-blue-400 rounded-none font-body font-bold">
                🔄 {isAr ? "متكرر" : "Recurring"} {product.recurring_frequency}
              </span>
            </div>
          )}
        </div>

        {/* Person */}
        {editMode && (
          <div className="bg-card border border-border rounded-none p-4">
            <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider mb-2">{isAr ? "لمن؟" : "For whom?"}</p>
            <div className="flex flex-wrap gap-2">
              {[
                { value: "person1", label: names.person1 || "Profile A" },
                { value: "person2", label: names.person2 || "Profile B" },
                { value: "family", label: isAr ? "العائلة" : "Family" },
              ].map(opt => (
                <button key={opt.value} onClick={() => setEditForm(p => ({ ...p, person: opt.value }))}
                  className={`flex-1 min-w-[60px] py-1.5 rounded-none text-xs font-body border transition-all ${editForm.person === opt.value ? "bg-primary text-primary-foreground border-primary" : "bg-secondary border-border"}`}>
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Ratings Section */}
        <div className="bg-card border border-border rounded-none p-4 space-y-4">
          <h3 className="font-heading font-semibold text-sm">{isAr ? "التقييم" : "Ratings"}</h3>
          <div className="grid grid-cols-3 gap-3">
            {[
              { key: "rating", label: isAr ? "عام" : "Overall" },
              { key: "quality_rating", label: isAr ? "الجودة" : "Quality" },
              { key: "value_rating", label: isAr ? "القيمة" : "Value" },
            ].map(({ key, label }) => (
              <div key={key} className="text-center space-y-1">
                <p className="text-[9px] text-muted-foreground font-body uppercase">{label}</p>
                <StarInput
                  value={(editMode ? editForm[key] : product[key]) || 0}
                  onChange={v => {
                    if (editMode) setEditForm(ef => ({ ...ef, [key]: v }));
                    else updateMutation.mutate({ [key]: v });
                  }}
                />
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                if (editMode) setEditForm(ef => ({ ...ef, repurchase: !ef.repurchase }));
                else updateMutation.mutate({ repurchase: !product.repurchase });
              }}
              className={`w-4 h-4 rounded border flex items-center justify-center transition-colors flex-shrink-0 ${(editMode ? editForm.repurchase : product.repurchase) ? "bg-primary border-primary" : "border-border"}`}>
              {(editMode ? editForm.repurchase : product.repurchase) && <div className="w-2 h-2 bg-white rounded-none" />}
            </button>
            <span className="text-xs font-body">{isAr ? "سأشتريه مرة أخرى" : "Would repurchase"}</span>
          </div>
        </div>

        {/* Review Section */}
        <div className="bg-card border border-border rounded-none p-4 space-y-3">
          <h3 className="font-heading font-semibold text-sm">{isAr ? "المراجعة" : "Review"}</h3>
          <Textarea
            value={(editMode ? editForm.review : product.review) || ""}
            onChange={e => {
              if (editMode) setEditForm(ef => ({ ...ef, review: e.target.value }));
              else updateMutation.mutate({ review: e.target.value });
            }}
            onBlur={e => { if (!editMode) updateMutation.mutate({ review: e.target.value }); }}
            className="rounded-none font-body min-h-[70px] text-sm"
            placeholder={isAr ? "اكتب مراجعتك.." : "Write your review.."}
          />
        </div>

        {/* Notes */}
        <div className="bg-card border border-border rounded-none p-4 space-y-2">
          <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "ملاحظات" : "Notes"}</p>
          <Textarea
            value={(editMode ? editForm.notes : product.notes) || ""}
            onChange={e => {
              if (editMode) setEditForm(ef => ({ ...ef, notes: e.target.value }));
              else updateMutation.mutate({ notes: e.target.value });
            }}
            onBlur={e => { if (!editMode) updateMutation.mutate({ notes: e.target.value }); }}
            className="rounded-none font-body min-h-[60px] text-sm"
            placeholder={isAr ? "ملاحظاتك.." : "Your notes.."}
          />
        </div>

        {/* Purchase Logs */}
        <div className="bg-card border border-border rounded-none p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-heading font-semibold text-sm">{isAr ? "سجل المشتريات" : "Purchase Log"}</h3>
              <p className="text-[10px] text-muted-foreground font-body">{isAr ? "إجمالي المدفوع:" : "Total spent:"} <span className="font-bold text-primary">{formatPrice(product.cost || 0)}</span></p>
            </div>
            <button onClick={() => setAddPurchase(!addPurchase)}
              className="px-3 h-7 rounded-none bg-white border-0 text-primary hover:bg-secondary flex items-center justify-center transition-colors text-[11px] font-body font-semibold">
              {addPurchase ? (isAr ? "إلغاء" : "Cancel") : (isAr ? "إضافة" : "Add")}
            </button>
          </div>

          {addPurchase && (
            <div className="space-y-3 pt-2 border-t border-border/40">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">{isAr ? "التكلفة" : "Cost"}</p>
                  <Input value={purchaseForm.cost} onChange={e => setPurchaseForm(p => ({ ...p, cost: e.target.value }))} type="number" placeholder="0.00" className="h-9 rounded-none font-body text-sm" />
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">{isAr ? "التاريخ" : "Date"}</p>
                  <Input value={purchaseForm.purchase_date} onChange={e => setPurchaseForm(p => ({ ...p, purchase_date: e.target.value }))} type="date" className="h-9 rounded-none font-body text-sm" />
                </div>
              </div>
              <Button className="w-full h-10 rounded-none font-body text-sm" onClick={handleAddPurchase}>
                {isAr ? "تأكيد الشراء" : "Confirm Purchase"}
              </Button>
            </div>
          )}

          {purchaseLogs.length > 0 && (
            <div className="space-y-2 pt-1">
              {purchaseLogs.map(log => (
                <PurchaseLogRow
                  key={log.id}
                  log={{ ...log, cost: log.amount, purchase_date: log.date }}
                  onDelete={handleDeletePurchaseLog}
                  onUpdate={handleUpdatePurchaseLog}
                  isAr={isAr}
                  formatPrice={formatPrice}
                />
              ))}
            </div>
          )}
        </div>

        {/* Status */}
        {editMode && (
          <div className="bg-card border border-border rounded-none p-4">
            <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider mb-2">{isAr ? "الحالة" : "Status"}</p>
            <div className="flex flex-wrap gap-2">
              {[
                { value: "active", en: "Active", ar: "نشط" },
                { value: "expired", en: "Expired", ar: "منتهي" },
                { value: "discontinued", en: "Discontinued", ar: "متوقف" },
                { value: "returned", en: "Returned", ar: "مُرتجع" },
              ].map(s => (
                <button key={s.value} onClick={() => setEditForm(ef => ({ ...ef, status: s.value }))}
                  className={` rounded-none text-xs font-body transition-all ${editForm.status === s.value ? " text-primary-foreground " : " "}`}>
                  {isAr ? s.ar : s.en}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}