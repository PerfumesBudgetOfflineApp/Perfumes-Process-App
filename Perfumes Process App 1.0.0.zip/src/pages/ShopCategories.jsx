import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import ShopCategoryManager from "@/components/shopping/ShopCategoryManager";

// صفحة مستقلّة لإدارة أقسام التسوّق (نُقلت من تبويب داخل /shopping بطلب A).
export default function ShopCategories() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  return (
    <div className="px-5 page-top pb-10 space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-bold">{isAr ? "الأقسام" : "Categories"}</h1>
        <button
          type="button"
          onClick={() => { if (typeof window !== "undefined" && window.history.length > 1) navigate(-1); else navigate("/shopping"); }}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity"
          aria-label={isAr ? "رجوع" : "Back"}
        >
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} style={{ color: "var(--brand)" }} />
        </button>
      </div>
      <ShopCategoryManager isAr={isAr} />
    </div>
  );
}
