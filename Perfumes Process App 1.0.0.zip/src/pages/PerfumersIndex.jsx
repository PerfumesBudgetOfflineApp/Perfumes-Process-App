import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Search } from "lucide-react";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";

/**
 * PerfumersIndex — alphabetic index of perfumers, rebuilt to mirror the
 * Brand / Perfume indexes: a single "All" toggle that expands A–Z + #;
 * picking a letter filters and collapses the bar to that letter alone;
 * pressing the active (collapsed) letter re-opens the bar. No gender/year
 * filters — just names, colored by gender (blue male, pink female, gray
 * otherwise). "#" buckets every non-Latin first character (Arabic, digits,
 * symbols, other scripts).
 */
const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").concat("#");

export default function PerfumersIndex() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [query, setQuery] = useState("");
  const [letter, setLetter] = useState("all");
  const [lettersOpen, setLettersOpen] = useState(false);

  const { data: perfumers = [], isLoading } = useQuery({
    queryKey: ["perfumers"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
  });

  const bucketOf = (p) => {
    const c = (p.name || p.name_ar || "").trim().charAt(0).toUpperCase();
    return /[A-Z]/.test(c) ? c : "#";
  };
  const genderColor = (g) => (g === "Male" ? "#185FA5" : g === "Female" ? "#993556" : "#6b7280");

  const filtered = useMemo(() => {
    let list = perfumers.filter((p) => !p.hidden);
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter(
        (p) =>
          (p.name || "").toLowerCase().includes(q) ||
          (p.name_ar || "").includes(query) ||
          (p.nationality || "").toLowerCase().includes(q)
      );
    } else if (letter !== "all") {
      list = list.filter((p) => bucketOf(p) === letter);
    }
    return list;
  }, [perfumers, query, letter]);

  const onPickLetter = (l) => {
    setQuery("");
    if (l === "all") { setLetter("all"); setLettersOpen(true); return; }
    if (!lettersOpen && l === letter) { setLettersOpen(true); return; }
    setLetter(l);
    setLettersOpen(false);
  };

  return (
    <div className="px-5 page-top pb-16">
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => navigate("/perfumers")} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors -ml-1">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="font-heading text-2xl font-bold text-[var(--brand)]">{isAr ? "فهرس العطّارين" : "Perfumers Index"}</h1>
      </div>

      {/* Search */}
      <div className="relative mb-3">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input name="PerfumersIndex-1"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={isAr ? "بحث عن عطّار" : "Search perfumer"}
          className="w-full pl-10 pr-9 h-11 rounded-none font-body bg-secondary/50 border-0 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand)]/40"
        />
        
      </div>

      {/* All + A–Z + # : collapsed by default, opens on All; picking a letter keeps it alone */}
      <div className="flex flex-wrap gap-1 mb-5" dir="ltr">
        <button
          onClick={() => onPickLetter("all")}
          className={`px-2 h-7 rounded-none text-xs font-body font-bold transition-colors ${
            !query.trim() && letter === "all" ? "bg-[var(--brand)] text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/70"
          }`}
        >
          {isAr ? "الكل" : "All"}
        </button>
        {lettersOpen ? (
          LETTERS.map((l) => {
            const active = !query.trim() && l === letter;
            return (
              <button
                key={l}
                onClick={() => onPickLetter(l)}
                className={`w-7 h-7 rounded-none text-xs font-body font-bold transition-colors ${
                  active ? "bg-[var(--brand)] text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/70"
                }`}
              >
                {l}
              </button>
            );
          })
        ) : (
          !query.trim() && letter !== "all" && (
            <button
              key={letter}
              onClick={() => onPickLetter(letter)}
              className="w-7 h-7 rounded-none text-xs font-body font-bold transition-colors bg-[var(--brand)] text-white shadow"
            >
              {letter}
            </button>
          )
        )}
      </div>

      {/* Results: flat name chips, colored by gender */}
      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-[var(--brand)]/30 border-t-[var(--brand)] rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-center text-sm text-muted-foreground font-body py-16">{isAr ? "لا نتائج" : "No results"}</p>
      ) : (
        // No pagination: the full list renders as one continuous flow, but each
        // ~80-name chunk uses CSS content-visibility so the browser skips
        // layout/paint for off-screen chunks (virtualization without JS/paging).
        <div className="space-y-2">
          {(() => {
            const CHUNK = 80, groups = [];
            for (let i = 0; i < filtered.length; i += CHUNK) groups.push(filtered.slice(i, i + CHUNK));
            return groups.map((group, gi) => (
              <div
                key={gi}
                className="flex flex-wrap gap-x-4 gap-y-2"
                style={{ contentVisibility: "auto", containIntrinsicSize: `${Math.ceil(group.length / 3) * 32}px` }}
              >
                {group.map((p) => (
                  <Link
                    key={p.id}
                    to={`/perfumer?id=${p.id}`}
                    className="text-sm font-body font-medium hover:opacity-70 transition-opacity"
                    style={{ color: genderColor(p.gender) }}
                  >
                    {isAr ? (p.name_ar || p.name) : (p.name || p.name_ar)}
                  </Link>
                ))}
              </div>
            ));
          })()}
        </div>
      )}

      <p className="text-center text-[10px] text-muted-foreground font-body pt-8">{filtered.length} {isAr ? "عطّار" : "perfumers"}</p>
    </div>
  );
}
