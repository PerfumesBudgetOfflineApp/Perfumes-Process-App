import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Trash2, Eye, EyeOff, Check, X, ArrowUp } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { ENC, dispName, ensureDefaultLanguages } from "@/lib/encyclopedia";

// إعداد الموسوعة — صفحة منفردة fit-to-screen (لا منبثقة).
// تدير: اللغات، الأقسام الرئيسية، التصنيفات الفرعية، و الخطوط الزمنية.
export default function EncyclopediaSetup() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [sectionId, setSectionId] = useState(null);

  const inval = (keys) => keys.forEach((k) => qc.invalidateQueries({ queryKey: k }));
  // ترتيب: ارفع العنصر للأعلى بتبديل order مع سابقه
  const moveUp = async (list, idx, entityFn, invalKeys) => {
    if (idx <= 0 || idx >= list.length) return;
    const cur = list[idx], prev = list[idx - 1];
    const co = (cur.order != null ? cur.order : idx);
    const po = (prev.order != null ? prev.order : idx - 1);
    await entityFn().update(cur.id, { order: po });
    await entityFn().update(prev.id, { order: co });
    inval(invalKeys);
  };

  const { data: langs = [] } = useQuery({ queryKey: ["enc-langs"], queryFn: () => ENC.Language().list("order", 50), staleTime: 1000 * 30 });
  const { data: sections = [] } = useQuery({ queryKey: ["enc-sections"], queryFn: () => ENC.Section().list("order", 200), staleTime: 1000 * 30 });
  const { data: subs = [] } = useQuery({ queryKey: ["enc-subs", sectionId], queryFn: () => ENC.Subclass().filter({ section_id: sectionId }, "order", 200), enabled: !!sectionId, staleTime: 1000 * 30 });
  const { data: lines = [] } = useQuery({ queryKey: ["enc-lines", sectionId], queryFn: () => ENC.Timeline().filter({ section_id: sectionId }, "order", 200), enabled: !!sectionId, staleTime: 1000 * 30 });

  // بذر اللغتين الافتراضيتين ثم إبطال فهرس اللغات كي تظهرا فوراً (لا تنتظر إضافة لغة)
  useEffect(() => {
    let alive = true;
    (async () => { await ensureDefaultLanguages(); if (alive) qc.invalidateQueries({ queryKey: ["enc-langs"] }); })();
    return () => { alive = false; };
  }, [qc]);

  // إظهار التصنيفات الفرعية و الخطوط تلقائياً: اختر القسم الجديد عند إضافته، أو الأول إن لا اختيار
  // عند أول تحميل: اختر أول قسم تلقائياً كي تظهر خياراته. القسم الجديد يُختار صراحةً عند إضافته.
  useEffect(() => {
    if (!sectionId && sections.length) setSectionId(sections[0].id);
  }, [sections, sectionId]);

  return (
    <div className="px-5 page-top pb-24 space-y-7">
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-bold" style={{ color: "var(--brand)" }}>
          {isAr ? "إعداد الموسوعة" : "Encyclopedia Setup"}
        </h1>
        <button type="button" onClick={() => navigate("/encyclopedia")}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity" aria-label={isAr ? "رجوع" : "Back"}>
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} style={{ color: "var(--brand)" }} />
        </button>
      </div>

      {/* اللغات */}
      <Block title={isAr ? "اللغات" : "Languages"} hint={isAr ? "اسم اللغة و اتجاه النص" : "Name and text direction"}>
        {langs.map((l) => (
          <Row key={l.id} onDelete={async () => { await ENC.Language().delete(l.id); inval([["enc-langs"]]); }}>
            <span className="font-body text-sm">{l.name}</span>
            <span className="text-[11px] text-muted-foreground font-body">{l.dir === "rtl" ? (isAr ? "يمين↔يسار" : "RTL") : (isAr ? "يسار↔يمين" : "LTR")}</span>
          </Row>
        ))}
        <AddLanguage isAr={isAr} onAdd={async (name, dir) => { await ENC.Language().create({ name, dir, order: langs.length, created_date: new Date().toISOString() }); inval([["enc-langs"]]); }} />
      </Block>

      {/* الأقسام الرئيسية */}
      <Block title={isAr ? "الأقسام الرئيسية" : "Main Sections"} hint={isAr ? "تظهر أزراراً أعلى الموسوعة" : "Shown as top buttons"}>
        {sections.map((s, i) => (
          <EditableRow key={s.id} isAr={isAr}
            en={s.name_en} ar={s.name_ar}
            label={dispName(s, isAr)}
            selected={sectionId === s.id}
            onMoveUp={i > 0 ? () => moveUp(sections, i, ENC.Section, [["enc-sections"]]) : undefined}
            onSelect={() => setSectionId(sectionId === s.id ? null : s.id)}
            onSave={async (en, ar) => { await ENC.Section().update(s.id, { name_en: en, name_ar: ar }); inval([["enc-sections"]]); }}
            onDelete={async () => { await ENC.Section().delete(s.id); if (sectionId === s.id) setSectionId(null); inval([["enc-sections"]]); }} />
        ))}
        <AddNamePair isAr={isAr} onAdd={async (en, ar) => { const created = await ENC.Section().create({ name_en: en, name_ar: ar, order: sections.length, created_date: new Date().toISOString() }); inval([["enc-sections"]]); if (created?.id) setSectionId(created.id); }} />
      </Block>

      {/* التصنيفات الفرعية + الخطوط — للقسم المختار */}
      {sectionId ? (
        <>
          <SectionDesc isAr={isAr} section={sections.find((x) => String(x.id) === String(sectionId))}
            onSave={async (dAr, dEn) => { await ENC.Section().update(sectionId, { desc_ar: dAr, desc_en: dEn }); inval([["enc-sections"]]); }} />
          <Block title={isAr ? "تصنيفات فرعية" : "Sub-classifications"} hint={isAr ? "محوران لكل قسم — كل محور تصنيفاته" : "Two axes per section"}>
            {(() => {
              const AXIS_LABEL = { kind: isAr ? "النوع" : "Kind", category: isAr ? "الفئة" : "Category", field: isAr ? "الحقل" : "Field", region: isAr ? "المنطقة" : "Region", other: isAr ? "تصنيف" : "Class" };
              const byAxis = {}; subs.forEach((c) => { const a = c.axis || "kind"; (byAxis[a] = byAxis[a] || []).push(c); });
              const present = ["kind", "category", "field", "region", "other"].filter((a) => byAxis[a] && byAxis[a].length);
              const slot1 = present[0] || "kind";
              const slot2 = present[1] || (slot1 === "kind" ? "region" : "category");
              const renderAxis = (ax) => (
                <div key={ax} className="space-y-1 mb-2">
                  <p className="text-[10px] font-body" style={{ color: "var(--brand)", opacity: 0.7 }}>{AXIS_LABEL[ax] || ax}</p>
                  {(byAxis[ax] || []).map((c, i) => (
                    <EditableRow key={c.id} isAr={isAr} en={c.name_en} ar={c.name_ar} label={dispName(c, isAr)}
                      onMoveUp={i > 0 ? () => moveUp(byAxis[ax], i, ENC.Subclass, [["enc-subs", sectionId]]) : undefined}
                      onSave={async (en, ar) => { await ENC.Subclass().update(c.id, { name_en: en, name_ar: ar }); inval([["enc-subs", sectionId]]); }}
                      onDelete={async () => { await ENC.Subclass().delete(c.id); inval([["enc-subs", sectionId]]); }} />
                  ))}
                  <AddNamePair isAr={isAr} onAdd={async (en, ar) => { await ENC.Subclass().create({ section_id: sectionId, axis: ax, name_en: en, name_ar: ar, order: subs.length, created_date: new Date().toISOString() }); inval([["enc-subs", sectionId]]); }} />
                </div>
              );
              return <>{renderAxis(slot1)}{slot2 !== slot1 && renderAxis(slot2)}</>;
            })()}
          </Block>

          <Block title={isAr ? "خطوط زمنية" : "Timelines"} hint={isAr ? "عنوان باللغتين — يُربط بالمدخلات صراحةً" : "Title per language — linked explicitly"}>
            {lines.map((t, i) => (
              <EditableRow key={t.id} isAr={isAr} en={t.title_en} ar={t.title_ar} label={dispName(t, isAr)} dimmed={t.hidden}
                onMoveUp={i > 0 ? () => moveUp(lines, i, ENC.Timeline, [["enc-lines", sectionId]]) : undefined}
                extra={
                  <button type="button" title={t.hidden ? (isAr ? "إظهار" : "Show") : (isAr ? "إخفاء" : "Hide")}
                    onClick={async () => { await ENC.Timeline().update(t.id, { hidden: !t.hidden }); inval([["enc-lines", sectionId]]); }}
                    className="hover:opacity-70 transition-opacity">
                    {t.hidden ? <EyeOff className="w-4 h-4 text-muted-foreground" /> : <Eye className="w-4 h-4" style={{ color: "var(--brand)" }} />}
                  </button>
                }
                onSave={async (en, ar) => { await ENC.Timeline().update(t.id, { title_en: en, title_ar: ar }); inval([["enc-lines", sectionId]]); }}
                onDelete={async () => { await ENC.Timeline().delete(t.id); inval([["enc-lines", sectionId]]); }} />
            ))}
            <AddNamePair isAr={isAr} onAdd={async (en, ar) => { await ENC.Timeline().create({ section_id: sectionId, title_en: en, title_ar: ar, hidden: false, order: lines.length, created_date: new Date().toISOString() }); inval([["enc-lines", sectionId]]); }} />
          </Block>
        </>
      ) : (
        <p className="text-xs text-muted-foreground font-body">{isAr ? "ضع قسماً رئيسياً لإدارة تصنيفاته الفرعية و خطوطه الزمنية" : "Select a main section to manage its sub-classifications and timelines"}</p>
      )}
    </div>
  );
}

function SectionDesc({ isAr, section, onSave }) {
  const [ar, setAr] = useState(section?.desc_ar || "");
  const [en, setEn] = useState(section?.desc_en || "");
  useEffect(() => { setAr(section?.desc_ar || ""); setEn(section?.desc_en || ""); }, [section?.id]);
  if (!section) return null;
  return (
    <Block title={isAr ? "شرح القسم" : "Section description"} hint={isAr ? "يظهر صغيراً تحت القسم في التصفّح" : "Shown small under the section"}>
      <textarea value={ar} onChange={(e) => setAr(e.target.value)} dir="rtl" rows={2} placeholder={isAr ? "شرح عربي" : "Arabic description"} className="w-full bg-white outline-none border-b border-border text-sm font-body px-1 py-1" />
      <textarea value={en} onChange={(e) => setEn(e.target.value)} dir="ltr" rows={2} placeholder={isAr ? "شرح إنجليزي" : "English description"} className="w-full bg-white outline-none border-b border-border text-sm font-body px-1 py-1 mt-2" />
      <button type="button" onClick={() => onSave(ar.trim(), en.trim())} className="font-body text-sm font-semibold hover:opacity-70 mt-2" style={{ color: "var(--brand)" }}>{isAr ? "حفظ الشرح" : "Save description"}</button>
    </Block>
  );
}

function Block({ title, hint, children }) {
  return (
    <section className="space-y-2">
      <div className="pb-1">
        <h2 className="font-heading text-base font-semibold" style={{ color: "var(--brand)" }}>{title}</h2>
        {hint ? <p className="text-[11px] text-muted-foreground font-body">{hint}</p> : null}
      </div>
      <div className="space-y-1">{children}</div>
    </section>
  );
}

function Row({ children, onDelete, extra }) {
  return (
    <div className="flex items-center gap-3 py-1.5">
      <div className="flex-1 min-w-0 flex items-center gap-2">{children}</div>
      {extra}
      {onDelete && (
        <button type="button" onClick={onDelete} className="hover:opacity-70 transition-opacity" aria-label="delete">
          <Trash2 className="w-4 h-4 text-red-500" />
        </button>
      )}
    </div>
  );
}

function EditableRow({ isAr, en, ar, label, onSave, onDelete, onSelect, onMoveUp, selected, dimmed, extra }) {
  const [editing, setEditing] = useState(false);
  const [e, setE] = useState(en || "");
  const [a, setA] = useState(ar || "");
  if (editing) {
    return (
      <div className="flex items-center gap-2 py-1.5">
        <input value={e} onChange={(ev) => setE(ev.target.value)} dir="ltr" placeholder="English"
          className="flex-1 min-w-0 bg-white outline-none border-b border-border text-sm font-body px-1 py-1" />
        <input value={a} onChange={(ev) => setA(ev.target.value)} dir="rtl" placeholder="العربية"
          className="flex-1 min-w-0 bg-white outline-none border-b border-border text-sm font-body px-1 py-1" />
        <button type="button" onClick={() => { onSave(e.trim(), a.trim()); setEditing(false); }} aria-label="save" className="hover:opacity-70"><Check className="w-4 h-4" style={{ color: "var(--brand)" }} /></button>
        <button type="button" onClick={() => { setE(en || ""); setA(ar || ""); setEditing(false); }} aria-label="cancel" className="hover:opacity-70"><X className="w-4 h-4 text-muted-foreground" /></button>
      </div>
    );
  }
  return (
    <div className={`flex items-center gap-3 py-1.5 ${dimmed ? "opacity-50" : ""}`}>
      <button type="button" onClick={onSelect || (() => setEditing(true))}
        className="flex-1 min-w-0 text-start font-body text-sm hover:opacity-70 transition-opacity"
        style={{ color: "var(--brand)", fontWeight: selected ? 700 : 400 }}>
        {label || (isAr ? "بلا اسم" : "Unnamed")}
      </button>
      {extra}
      {onMoveUp && <button type="button" onClick={onMoveUp} aria-label={isAr ? "تحريك للأعلى" : "Move up"} title={isAr ? "للأعلى" : "Up"} className="hover:opacity-70"><ArrowUp className="w-4 h-4" style={{ color: "var(--brand)" }} /></button>}
      <button type="button" onClick={() => setEditing(true)} className="text-[11px] font-body hover:opacity-70" style={{ color: "var(--brand)" }}>{isAr ? "تسمية" : "Rename"}</button>
      {onDelete && <button type="button" onClick={onDelete} aria-label="delete" className="hover:opacity-70"><Trash2 className="w-4 h-4 text-red-500" /></button>}
    </div>
  );
}

function AddNamePair({ isAr, onAdd }) {
  const [e, setE] = useState("");
  const [a, setA] = useState("");
  return (
    <div className="flex items-center gap-2 pt-1">
      <input value={e} onChange={(ev) => setE(ev.target.value)} dir="ltr" placeholder="English"
        className="flex-1 min-w-0 bg-white outline-none border-b border-border text-sm font-body px-1 py-1" />
      <input value={a} onChange={(ev) => setA(ev.target.value)} dir="rtl" placeholder="العربية"
        className="flex-1 min-w-0 bg-white outline-none border-b border-border text-sm font-body px-1 py-1" />
      <button type="button" disabled={!e.trim() && !a.trim()}
        onClick={() => { onAdd(e.trim(), a.trim()); setE(""); setA(""); }}
        className="inline-flex items-center gap-1 font-body text-xs font-semibold disabled:opacity-40 hover:opacity-70" style={{ color: "var(--brand)" }}>
{isAr ? "إضافة" : "Add"}
      </button>
    </div>
  );
}

function AddLanguage({ isAr, onAdd }) {
  const [name, setName] = useState("");
  const [dir, setDir] = useState("ltr");
  return (
    <div className="flex items-center gap-2 pt-1 flex-wrap">
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder={isAr ? "اسم اللغة" : "Language name"}
        className="flex-1 min-w-[120px] bg-white outline-none border-b border-border text-sm font-body px-1 py-1" />
      <div className="flex items-center gap-1">
        <button type="button" onClick={() => setDir("ltr")} className="font-body text-xs px-2 py-1" style={dir === "ltr" ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>LTR</button>
        <button type="button" onClick={() => setDir("rtl")} className="font-body text-xs px-2 py-1" style={dir === "rtl" ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>RTL</button>
      </div>
      <button type="button" disabled={!name.trim()} onClick={() => { onAdd(name.trim(), dir); setName(""); setDir("ltr"); }}
        className="inline-flex items-center gap-1 font-body text-xs font-semibold disabled:opacity-40 hover:opacity-70" style={{ color: "var(--brand)" }}>
{isAr ? "إضافة" : "Add"}
      </button>
    </div>
  );
}
