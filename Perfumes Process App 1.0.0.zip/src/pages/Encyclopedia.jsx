import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Heart, Search, Pin } from "lucide-react";
import { usePersonNames } from "@/lib/usePersonNames";
import { usePins } from "@/lib/usePins";
import { useLang } from "@/lib/LanguageContext";
import { ENC, ensureDefaultLanguages, seedEncyclopedia, dispName, dispNameOrdered, langField } from "@/lib/encyclopedia";
import EncOptionsBar from "@/components/encyclopedia/EncOptionsBar";
const PerfumeTimeline = lazy(() => import("@/components/explore/PerfumeTimeline"));
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";

// صفحة تصفّح الموسوعة — مستقلّة تماماً عن المعجم القائم. تبدأ فارغة.
// الأقسام الرئيسية أزرار أعلى الصفحة؛ التصنيفات الفرعية أسفلها؛ المدخلات أسفلهما.
export default function Encyclopedia() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [sectionId, setSectionId] = useState(null);
  const [tlId, setTlId] = useState(() => { try { return new URLSearchParams(window.location.search).get("tl"); } catch { return null; } });
  const [subId, setSubId] = useState(() => { try { return new URLSearchParams(window.location.search).get("sub"); } catch { return null; } });
  const [search, setSearch] = useState("");
  const [sortMode, setSortModeRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_sort")) || "newest");
  const setSortMode = (m) => { setSortModeRaw(m); try { localStorage.setItem("enc_sort", m); } catch { /* تجاهل */ } };
  const [titleOrder, setTitleOrderRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_title_order")) || "ar_en");
  const setTitleOrder = (o) => { setTitleOrderRaw(o); try { localStorage.setItem("enc_title_order", o); } catch { /* تجاهل */ } };
  const [subTitleOrder, setSubTitleOrderRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_sub_title_order")) || "lang");
  const setSubTitleOrder = (o) => { setSubTitleOrderRaw(o); try { localStorage.setItem("enc_sub_title_order", o); } catch { /* تجاهل */ } };
  const [encAccent, setEncAccent] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_accent_color")) || "");
  const [encFs, setEncFs] = useState(() => parseInt((typeof localStorage !== "undefined" && localStorage.getItem("enc_font_scale")) || "0", 10) || 0);
  useEffect(() => {
    const ha = () => setEncAccent(localStorage.getItem("enc_accent_color") || "");
    const hf = () => setEncFs(parseInt(localStorage.getItem("enc_font_scale") || "0", 10) || 0);
    window.addEventListener("enc-accent-change", ha);
    window.addEventListener("enc-fs-change", hf);
    return () => { window.removeEventListener("enc-accent-change", ha); window.removeEventListener("enc-fs-change", hf); };
  }, []);
  const ENC_FS = [11, 12, 13, 14.5, 16];
  const encFsPx = (ENC_FS[encFs] || 11) + "px";

  const qcc = useQueryClient();
  useEffect(() => {
    let alive = true;
    (async () => {
      await ensureDefaultLanguages();
      await seedEncyclopedia();
      if (alive) ["enc-langs", "enc-sections", "enc-subs", "enc-entries", "enc-fav-entries"].forEach((k) => qcc.invalidateQueries({ queryKey: [k] }));
    })();
    return () => { alive = false; };
  }, [qcc]);

  const { data: sections = [] } = useQuery({
    queryKey: ["enc-sections"],
    queryFn: () => ENC.Section().list("order", 200),
    staleTime: 1000 * 30,
  });

  const { data: langs = [] } = useQuery({
    queryKey: ["enc-langs"],
    queryFn: () => ENC.Language().list("order", 50),
    staleTime: 1000 * 30,
  });

  const { data: timelines = [] } = useQuery({
    queryKey: ["enc-timelines"],
    queryFn: () => ENC.Timeline().list("order", 500),
    staleTime: 1000 * 30,
  });

  const { data: subs = [] } = useQuery({
    queryKey: ["enc-subs"],
    queryFn: () => ENC.Subclass().list("order", 1000),
    staleTime: 1000 * 30,
  });

  const code = isAr ? "ar" : "en";

  // أوّل قسم يُختار تلقائياً — أو القسم المُمرَّر من المصنّفات (?sec=)
  useEffect(() => {
    if (sectionId || !sections.length) return;
    let pick = null;
    try { pick = new URLSearchParams(window.location.search).get("sec"); } catch { pick = null; }
    const found = pick && sections.find((s) => String(s.id) === String(pick) || s.key === pick);
    setSectionId(found ? found.id : sections[0].id);
  }, [sections, sectionId]);

  const { profiles } = usePersonNames();
  const activePerson = (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1";
  const { data: allEntries = [] } = useQuery({ queryKey: ["enc-fav-entries"], queryFn: () => ENC.Entry().list("-updated_date", 20000), staleTime: 1000 * 10 });

  // المدخلات المثبّتة (encentry) — تُعرض أعلى الرئيسية بترتيب التثبيت
  const { pinnedIds } = usePins("encentry");
  const pinnedEntries = useMemo(() => {
    if (!pinnedIds.length) return [];
    const byId = new Map(allEntries.map((e) => [String(e.id), e]));
    return pinnedIds.map((id) => byId.get(String(id))).filter(Boolean);
  }, [pinnedIds, allEntries]);
  const favColor = profiles[activePerson]?.color || "var(--brand)";
  const hasFav = allEntries.some((e) => {
    const r = (e.reactions || (e.reaction ? { person1: e.reaction } : {}))[activePerson] || "none";
    const d = (e.reads || (e.read_status ? { person1: e.read_status } : {}))[activePerson] || "none";
    return r !== "none" || d !== "none";
  });

  // الفرز مطبّق على الموسوعة: الأحدث (افتراضي) أو أبجدي بالعنوان.
  const titleOf = (e) => (langField(e.titles, code, langs) || "").trim();
  const byNewest = (a, b) => new Date(b.created_date || 0) - new Date(a.created_date || 0);
  const byOldest = (a, b) => new Date(a.created_date || 0) - new Date(b.created_date || 0);
  const byAlphaAsc = (a, b) => titleOf(a).localeCompare(titleOf(b), isAr ? "ar" : "en");
  const sorter = sortMode === "alpha_asc" ? byAlphaAsc
    : sortMode === "alpha_desc" ? ((a, b) => -byAlphaAsc(a, b))
    : sortMode === "oldest" ? byOldest : byNewest;
  // عنوان المدخل حسب تخصيص لغة القراءة (عربي/إنجليزي/ثنائي)
  const browseLang = (typeof localStorage !== "undefined" && localStorage.getItem("enc_read_lang")) || "both";
  const PER_PAGE = 25;
  const [page, setPage] = useState(0);
  useEffect(() => { setPage(0); }, [search, sortMode, tlId, subId]);
  // حفظ آخر صفحة لكل قسم و استعادتها عند الرجوع من المدخل (صفحات التنقل ترجع لآخر صفحة)
  useEffect(() => { if (!sectionId || tlId || subId) return; try { const sv = sessionStorage.getItem(`enc_page_${sectionId}`); setPage(sv ? Number(sv) : 0); } catch { setPage(0); } }, [sectionId, tlId, subId]);
  useEffect(() => { if (sectionId) { try { sessionStorage.setItem(`enc_page_${sectionId}`, String(page)); } catch { /* تجاهل */ } } }, [page, sectionId]);
  const activeSection = sections.find((x) => String(x.id) === String(sectionId));
  const q = search.trim().toLowerCase();
  const matchTitle = (e) => (((langField(e.titles, "ar", langs) || "") + " " + (langField(e.titles, "en", langs) || "")).toLowerCase()).includes(q);
  const yearNum = (e) => { const n = parseInt(e.year, 10); return Number.isFinite(n) ? n : 999999; };
  // وضع الفلترة: خط زمنيّ (?tl) مرتّب بالسنة · فرعيّة (?sub) · أو القسم.
  const filterTimeline = tlId ? timelines.find((t) => String(t.id) === String(tlId)) : null;
  const filterSub = subId ? subs.find((c) => String(c.id) === String(subId)) : null;
  const entries = useMemo(() => (tlId
    ? allEntries.filter((e) => String(e.timeline_id) === String(tlId)).sort((a, b) => yearNum(a) - yearNum(b))
    : subId
    ? allEntries.filter((e) => String(e.subclass_id) === String(subId) || String(e.subclass2_id) === String(subId))
    : sectionId ? allEntries.filter((e) => String(e.section_id) === String(sectionId)) : []),
    [allEntries, tlId, subId, sectionId]);
  // الخط الزمنيّ: تقطيع بالأجيال (٣٣ سنة) أو ٣٣ مدخلاً، و كشف تدريجيّ بزرّ التالي (بلا تحميل الخط كاملاً)
  const GEN = 33;
  const tlChunks = useMemo(() => {
    if (!tlId) return [];
    const out = [];
    for (let i = 0; i < entries.length; i += GEN) out.push(entries.slice(i, i + GEN));
    return out;
  }, [entries, tlId]);
  const [tlReveal, setTlReveal] = useState(1);
  useEffect(() => { setTlReveal(1); }, [tlId]);
  const tlShown = useMemo(() => tlChunks.slice(0, tlReveal).flat(), [tlChunks, tlReveal]);
  const fmtYr = (y) => { const n = parseInt(y, 10); if (!Number.isFinite(n)) return ""; return n < 0 ? `${-n}${isAr ? " ق.م" : " BC"}` : String(n); };
  const shown = q
    ? allEntries.filter(matchTitle).slice().sort(sorter)
    : (tlId ? entries.slice() : entries.slice().sort(sorter));
  // «أطوار العطور» مستثناة من قاعدة الـ25/صفحة (تُعرض كاملة)
  const isPhases = !tlId && !subId && !!activeSection && (activeSection.name_ar === "اطوار العطور" || activeSection.name_en === "Perfume Era" || activeSection.name_en === "Perfume Phases");
  const pageCount = isPhases ? 1 : Math.max(1, Math.ceil(shown.length / PER_PAGE));
  const pageItems = isPhases ? shown : shown.slice(page * PER_PAGE, page * PER_PAGE + PER_PAGE);

  return (
    <div className="px-5 page-top pb-24 space-y-4 overflow-x-hidden" style={{ ...(encAccent ? { "--brand": encAccent } : {}), "--enc-fs": encFsPx }}>
      {/* الترويسة */}
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-bold" style={{ color: "var(--brand)" }}>
          {isAr ? "موسوعة" : "Encyclopedia"}
        </h1>
        <SettingsSheet><UserAvatarButton size={28} /></SettingsSheet>
      </div>

      {/* المثبّتة — أعلى الرئيسية (تظهر إلا عند تصفّح خطّ زمني محدّد) */}
      {!tlId && pinnedEntries.length > 0 && (
        <div className="space-y-1">
          {pinnedEntries.map((e) => {
            const ar = langField(e.titles, "ar", langs) || "";
            const en = langField(e.titles, "en", langs) || "";
            const label = isAr ? (ar || en) : (en || ar);
            return (
              <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
                className="w-full block py-1 text-start hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
                <span className="font-body flex items-center gap-1.5 min-w-0 max-w-full" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>
                  <Pin className="w-3 h-3 flex-shrink-0" fill="var(--brand)" /><span className="truncate min-w-0">{label || (isAr ? "بلا عنوان" : "Untitled")}</span>
                </span>
              </button>
            );
          })}
        </div>
      )}

      {sections.length === 0 ? (
        <div className="py-16 text-center space-y-3">
          <p className="text-sm text-muted-foreground font-body">
            {isAr ? "الموسوعة فارغة، ابدأ بإضافة قسم رئيسي — قصة، مصطلح، رمزية" : "Empty. Start by adding a main section: Story, Term, Symbolism"}
          </p>
          <button type="button" onClick={() => navigate("/encyclopedia/setup")}
            className="font-body text-sm font-semibold hover:opacity-70 transition-opacity" style={{ color: "var(--brand)" }}>
            {isAr ? "ابدأ تنصيب الموسوعة" : "Start Encyclopedia Setup"}
          </button>
        </div>
      ) : (
        <>
          {/* بحث + فرز — بعد الهيدر مباشرة، كالمعجم. الحقل بلا إطار، أيقونة فقط، بلا نص */}
          <div className="flex items-center gap-3 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
            <div className="relative flex-1 min-w-[130px] flex items-center gap-2">
              <Search className="w-4 h-4 flex-shrink-0" style={{ color: "var(--brand)" }} />
              <input value={search} onChange={(e) => setSearch(e.target.value)} aria-label={isAr ? "بحث" : "Search"}
                className="w-full bg-transparent outline-none border-0 text-sm font-body py-1.5" style={{ color: "var(--brand)" }} />
            </div>
          </div>

          {/* المفضلة + الأقسام الرئيسية — أو ترويسة الوضع المفلتر (خط/فرعيّة) */}
          <div>
            {(filterTimeline || filterSub) ? (
              <>
              <div className="flex items-center gap-3 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
                <button type="button" onClick={() => { setTlId(null); setSubId(null); }}
                  className="font-body text-xs hover:opacity-70 transition-opacity" style={{ color: "var(--brand)", opacity: 0.7 }}>
                  {isAr ? "الأقسام" : "Sections"}
                </button>
                <span className="font-body text-sm font-semibold" style={{ color: "var(--brand)" }}>
                  {dispNameOrdered(filterTimeline || filterSub, titleOrder, isAr)}
                </span>
              </div>
              {/* خط بلون المستخدم لكل خط زمنيّ في صفحته */}
              {filterTimeline && <div className="mt-2" style={{ height: 2, background: favColor, opacity: 0.55, borderRadius: 1 }} />}
              </>
            ) : (
            <div className="flex flex-wrap items-center gap-2" dir={isAr ? "rtl" : "ltr"}>
              <button type="button" onClick={() => navigate("/encyclopedia/favorites")}
                className="flex items-center justify-center w-8 h-8 hover:opacity-70 transition-opacity"
                aria-label={isAr ? "المفضلة" : "Favorites"} title={isAr ? "المفضلة" : "Favorites"}>
                <Heart className="w-5 h-5" style={{ color: "var(--brand)" }} />
              </button>
              {sections.map((s) => (
                <button key={s.id} type="button" onClick={() => { setSectionId(s.id); setSubId(null); setTlId(null); }}
                  className="font-body text-[11px] px-1 pb-1.5 transition-opacity hover:opacity-70"
                  style={{ color: "var(--brand)", fontWeight: sectionId === s.id ? 700 : 400, borderBottom: sectionId === s.id ? "2px solid var(--brand)" : "2px solid transparent" }}>
                  {dispName(s, isAr)}
                </button>
              ))}
            </div>
            )}
            {!filterTimeline && !filterSub && activeSection && (isAr ? activeSection.desc_ar : activeSection.desc_en) && (
              <div className="mt-1.5">
                <p className="text-[10px] text-muted-foreground font-body leading-relaxed" dir={isAr ? "rtl" : "ltr"}>
                  {isAr ? activeSection.desc_ar : activeSection.desc_en}
                </p>
              </div>
            )}
          </div>

          {/* قسم «أطوار العطور / Perfume Era» — يُسحب من قاعدة العطور (Perfume Timeline) */}
          {isPhases ? (
            <Suspense fallback={<p className="text-sm text-muted-foreground font-body py-8 text-center">{isAr ? "جارٍ التحميل…" : "Loading…"}</p>}>
              <PerfumeTimeline embedded={true} />
            </Suspense>
          ) : (
          <>
          {filterTimeline ? (
            /* الخط الزمنيّ المرسوم — كأطوار العطور، كشف تدريجيّ بالأجيال */
            shown.length === 0 ? (
              <p className="text-sm text-muted-foreground font-body py-8 text-center">{isAr ? "لا مدخلات في هذا الخط بعد" : "No entries in this timeline yet"}</p>
            ) : (
            <div className="relative pt-1" dir="ltr">
              <div className="absolute top-0 bottom-0 w-0.5 z-0" style={{ left: 54, background: "linear-gradient(to bottom, color-mix(in srgb, var(--brand) 18%, transparent), var(--brand), color-mix(in srgb, var(--brand) 18%, transparent))" }} />
              <div className="relative z-10">
                {tlShown.map((e) => {
                  const ar = langField(e.titles, "ar", langs) || "";
                  const en = langField(e.titles, "en", langs) || "";
                  const showBothT = browseLang === "both" && ar && en && titleOrder !== "lang";
                  const prim = titleOrder === "lang" ? (isAr ? (ar || en) : (en || ar))
                    : browseLang === "ar" ? (ar || en) : browseLang === "en" ? (en || ar)
                    : titleOrder === "en_ar" ? (en || ar) : (ar || en);
                  const sec = titleOrder === "en_ar" ? ar : en;
                  const yr = fmtYr(e.year);
                  return (
                    <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
                      className="w-full flex items-start pb-2.5 relative hover:opacity-70 transition-opacity" dir="ltr">
                      <span className="shrink-0 font-body" style={{ width: 46, textAlign: "right", color: "var(--brand)", opacity: 0.6, fontSize: "8.5px", lineHeight: 1.5, paddingTop: 2 }}>{yr}</span>
                      <span className="absolute w-2 h-2 rotate-45 z-10" style={{ left: 50, top: 6, background: "var(--brand)" }} />
                      <span className="min-w-0 flex-1" style={{ paddingLeft: 22 }}>
                        <span className="block font-body" dir="auto" style={{ textAlign: "left", color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{prim || (isAr ? "بلا عنوان" : "Untitled")}</span>
                        {showBothT && sec && (
                          <span className="block font-body truncate" dir="auto" style={{ textAlign: "left", color: "var(--brand)", fontSize: "var(--enc-fs, 11px)", opacity: 0.85 }}>{sec}</span>
                        )}
                      </span>
                    </button>
                  );
                })}
                {tlReveal < tlChunks.length && (
                  <button type="button" onClick={() => setTlReveal((r) => r + 1)}
                    className="w-full flex items-start pb-2 relative hover:opacity-70 transition-opacity" dir="ltr">
                    <span className="shrink-0" style={{ width: 46 }} />
                    <span className="absolute w-2 h-2 rotate-45 z-10" style={{ left: 50, top: 6, background: "var(--brand)", opacity: 0.55 }} />
                    <span className="flex-1 block font-body font-semibold" style={{ paddingLeft: 22, color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{isAr ? "التالي" : "Next"}</span>
                  </button>
                )}
              </div>
            </div>
            )
          ) : (
          <>
          {/* المدخلات — عنوان فقط بلا صورة، حسب لغة العرض، خطّ أصغر بلون التطبيق */}
          <div className="space-y-1">
            {shown.length === 0 ? (
              <p className="text-sm text-muted-foreground font-body py-8 text-center">
                {q ? (isAr ? "لا نتائج" : "No results") : (isAr ? "لا مدخلات في هذا القسم بعد" : "No entries in this section yet")}
              </p>
            ) : pageItems.map((e) => {
              const ar = langField(e.titles, "ar", langs) || "";
              const en = langField(e.titles, "en", langs) || "";
              const showBothT = browseLang === "both" && ar && en;
              const single = browseLang === "ar" ? (ar || en) : browseLang === "en" ? (en || ar) : (ar || en);
              return (
                <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
                  className="w-full block py-1.5 text-start hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
                  {titleOrder === "lang" ? (
                    <span className="block font-body truncate" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{(isAr ? (ar || en) : (en || ar)) || (isAr ? "بلا عنوان" : "Untitled")}</span>
                  ) : showBothT ? (
                    titleOrder === "en_ar" ? (
                      <>
                        <span className="block font-body truncate" dir="ltr" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{en}</span>
                        <span className="block font-body truncate" dir="rtl" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)", opacity: 0.85 }}>{ar}</span>
                      </>
                    ) : (
                      <>
                        <span className="block font-body truncate" dir="rtl" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{ar}</span>
                        <span className="block font-body truncate" dir="ltr" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)", opacity: 0.85 }}>{en}</span>
                      </>
                    )
                  ) : (
                    <span className="block font-body truncate" style={{ color: "var(--brand)", fontSize: "var(--enc-fs, 11px)" }}>{single || (isAr ? "بلا عنوان" : "Untitled")}</span>
                  )}
                </button>
              );
            })}
          </div>

          {/* شريط الصفحات — صفحة X / Y فقط، بلا مجموع الموسوعة، أرقام بلا فواصل */}
          {pageCount > 1 && (
            <div className="flex items-center justify-center gap-5 pt-2" dir="ltr">
              <button type="button" disabled={page === 0} onClick={() => setPage((p) => Math.max(0, p - 1))}
                className="font-body text-xs hover:opacity-70 disabled:opacity-30" style={{ color: "var(--brand)" }}>{isAr ? "السابق" : "Prev"}</button>
              <span className="font-body text-xs" style={{ color: "var(--brand)" }}>{isAr ? `صفحة ${page + 1} / ${pageCount}` : `Page ${page + 1} / ${pageCount}`}</span>
              <button type="button" disabled={page >= pageCount - 1} onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
                className="font-body text-xs hover:opacity-70 disabled:opacity-30" style={{ color: "var(--brand)" }}>{isAr ? "التالي" : "Next"}</button>
            </div>
          )}
          </>
          )}
          </>
          )}

          {/* روابط الإدارة أسفل الموسوعة — نصوص ملوّنة بلا رموز/أسهم/شرح */}
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-3 font-body text-xs font-semibold">
            <button type="button" onClick={() => navigate(`/encyclopedia/entry?section=${sectionId}`)}
              style={{ color: "var(--brand)" }} className="hover:opacity-70 transition-opacity">{isAr ? "اضافة مدخل" : "Add Entry"}</button>
            <button type="button" onClick={() => navigate("/encyclopedia/timelines")}
              style={{ color: "#2E7D6B" }} className="hover:opacity-70 transition-opacity">{isAr ? "خطوط و مصنّفات" : "Timelines & Classifications"}</button>
            <button type="button" onClick={() => navigate("/reading-guide")}
              style={{ color: "#7C6FB0" }} className="hover:opacity-70 transition-opacity">{isAr ? "موجِّهة القراءة" : "Reading Guide"}</button>
            <button type="button" onClick={() => navigate("/encyclopedia/setup")}
              style={{ color: "#B76E79" }} className="hover:opacity-70 transition-opacity">{isAr ? "إدارة موسوعة" : "Manage Encyclopedia"}</button>
          </div>

          {/* خيارات الموسوعة — بعد الروابط أسفل الصفحة */}
          <EncOptionsBar isAr={isAr} titleOrder={titleOrder} setTitleOrder={setTitleOrder} subTitleOrder={subTitleOrder} setSubTitleOrder={setSubTitleOrder} sortMode={sortMode} setSortMode={setSortMode} showSubTitle={true} />
        </>
      )}
    </div>
  );
}
