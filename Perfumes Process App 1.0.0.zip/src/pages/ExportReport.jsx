import { useState, useMemo, useRef, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import html2canvas from "html2canvas";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { downloadBlob, saveCanvasAsImage } from "@/lib/exportHelper";
import { DEFAULT_USER_MARK } from "@/lib/exportSettings";
import {
  REPORT_FONTS, REPORT_FONT_KEYS, pickLang as pick,
  buildBudgetModel, buildShoppingModel, buildGoalsModel, buildProgressModel,
  buildPerfumersModel, buildNotesModel, buildSamplesModel,
  genIntro, genOutro, toTXT, toCSV, reportDateLine, periodRange, periodLabel,
} from "@/lib/exportReport";
import { RISK_GROUPS } from "@/lib/headacheRisk";

const GOLD = "var(--brand)", INK = "#2E7D32", N = "#d9cfb0";
const OPT_KEY = "exportReportOptions";
const TITLES = {
  budget: { ar: "الميزانية", en: "Budget" },
  shopping: { ar: "المتاجر", en: "Shopping" },
  progress: { ar: "التقدّم", en: "Progress" },
  goals: { ar: "الأهداف", en: "Goals" },
  perfumers: { ar: "العطّارون", en: "Perfumers" },
  notes: { ar: "النوتات", en: "Notes" },
  samples: { ar: "العيّنات", en: "Samples" },
};

export default function ExportReport() {
  const [sp] = useSearchParams();
  const navigate = useNavigate();
  const { isAr } = useLang();
  const type0 = (sp.get("type") || "budget").toLowerCase();
  const [type, setType] = useState(type0);

  const [opts, setOpts] = useState(() => {
    const base = { font: "amiri", fontSize: 14, lang: "both", dir: "auto", period: "all", from: "", to: "", showIntro: true, showOutro: true, showDate: true, showMark: true, format: "txt", filename: "", userStart: "", userEnd: "", gender: "male", ageSort: "oldest", topN: 0, noteClass: "main", noteSort: "alphaAsc" };
    try { return { ...base, ...JSON.parse(localStorage.getItem(OPT_KEY) || "{}") }; }
    catch { return base; }
  });
  useEffect(() => { try { localStorage.setItem(OPT_KEY, JSON.stringify(opts)); } catch { /* ignore */ } }, [opts]);
  const set = (patch) => setOpts((o) => ({ ...o, ...patch }));

  // العيّنات: المارك فقط افتراضياً، بلا تاريخ/مقدمة/خاتمة، وصيغة PDF (جداول) — مرّة واحدة عند الدخول
  useEffect(() => {
    if (type0 === "samples") {
      setOpts((o) => ({ ...o, showIntro: false, showOutro: false, showDate: false, showMark: true, format: "pdf" }));
    }
  }, []);

  // ===== بيانات حسب القسم =====
  const { data: budgetData } = useQuery({ enabled: type === "budget", queryKey: ["er-budget"], queryFn: async () => ({
    income: await apphost.entities.BudgetIncome.list().catch(() => []), expenses: await apphost.entities.BudgetExpense.list().catch(() => []),
    obligations: await apphost.entities.BudgetObligation.list().catch(() => []), savings: await apphost.entities.SavingsGoal.list().catch(() => []),
  }) });
  const { data: shopData } = useQuery({ enabled: type === "shopping", queryKey: ["er-shop"], queryFn: async () => ({ products: await apphost.entities.ShopProduct.list().catch(() => []), brands: await apphost.entities.ShopBrand.list().catch(() => []), purchases: await apphost.entities.PurchaseRecord.list().catch(() => []) }) });
  const { data: goalsData } = useQuery({ enabled: type === "goals", queryKey: ["er-goals"], queryFn: async () => ({ goals: await apphost.entities.Goal.list().catch(() => []) }) });
  const { data: samplesData } = useQuery({ enabled: type === "samples", queryKey: ["er-samples"], queryFn: async () => ({ purchases: (await apphost.entities.PurchaseRecord.list().catch(() => [])).filter((p) => p.type === "sample" || p.type === "bottle") }) });
  const { data: me } = useQuery({ queryKey: ["er-me"], queryFn: () => apphost.auth.me().catch(() => null) });
  const userMark = String(me?.mark || DEFAULT_USER_MARK || "").slice(0, 32);
  const { data: progData } = useQuery({ enabled: type === "progress", queryKey: ["er-prog"], queryFn: async () => {
    const ups = await apphost.entities.UserPerfume.list().catch(() => []);
    const wears = await apphost.entities.WearLog.list().catch(() => []);
    const fav = ups.filter((u) => u.list === "favorite").length;
    return { stats: [
      { label: { ar: "عدد العطور", en: "Perfumes" }, value: ups.length },
      { label: { ar: "المفضّلة", en: "Favorites" }, value: fav },
      { label: { ar: "مرّات الارتداء", en: "Wears" }, value: wears.length },
    ] };
  } });

  const { data: perfumersData = [] } = useQuery({ enabled: type === "perfumers", queryKey: ["er-perfumers"], queryFn: () => apphost.entities.Perfumer.list("name").catch(() => []) });
  const { data: notesData = [] } = useQuery({ enabled: type === "notes", queryKey: ["er-notes"], queryFn: () => apphost.entities.PerfumeNote.list("name").catch(() => []) });

  // ===== العطّارون: فلترة بالجنس + ترتيب بالعمر =====
  const perfumerRows = useMemo(() => {
    if (type !== "perfumers") return [];
    const bucket = (g) => { const v = String(g || "").toLowerCase(); return v === "male" ? "male" : v === "female" ? "female" : "other"; };
    const filtered = perfumersData.filter((p) => bucket(p.gender) === opts.gender);
    const yr = (p) => (Number(p.birth_year) || (opts.ageSort === "oldest" ? 999999 : -999999));
    filtered.sort((a, b) => opts.ageSort === "oldest" ? yr(a) - yr(b) : yr(b) - yr(a));
    const cap = Number(opts.topN) || 0;
    const sliced = cap > 0 ? filtered.slice(0, cap) : filtered;
    return sliced.map((p) => ({
      name: `${p.name || ""}${p.name_ar ? `  ${p.name_ar}` : ""}`.trim(),
      nationality: p.nationality || "",
      years: p.birth_year ? `${p.birth_year}${p.death_year ? ` - ${p.death_year}` : ""}` : "",
    }));
  }, [type, perfumersData, opts.gender, opts.ageSort, opts.topN]);

  // ===== النوتات: تصنيف خماسي + ترتيب (أبجدي صعود/هبوط أو بالاستلام) =====
  const noteRows = useMemo(() => {
    if (type !== "notes") return [];
    const c = opts.noteClass;
    let list;
    if (c === "main") list = notesData.filter((n) => n.note_category === "main_note");
    else if (c === "sub") list = notesData.filter((n) => !n.note_category || n.note_category === "sub_notes");
    else if (c === "low") list = notesData.filter((n) => n.note_category === "low_notes");
    else if (c === "restricted") list = notesData.filter((n) => n.is_allowed === false);
    else { // health — مطابقة مفاتيح مجموعات المخاطر
      const keys = RISK_GROUPS.flatMap((g) => g.keys.map((k) => String(k).toLowerCase()));
      list = notesData.filter((n) => { const t = `${n.name || ""} ${n.name_en || ""} ${n.name_ar || ""}`.toLowerCase(); return keys.some((k) => t.includes(k)); });
    }
    list = [...list];
    const nm = (n) => String(n.name_en || n.name || "").toLowerCase();
    if (opts.noteSort === "received") list.sort((a, b) => new Date(a.created_date || 0) - new Date(b.created_date || 0));
    else list.sort((a, b) => opts.noteSort === "alphaDesc" ? nm(b).localeCompare(nm(a)) : nm(a).localeCompare(nm(b)));
    return list.map((n) => ({
      name: `${n.name_en || n.name || ""}${(n.name_ar) ? `  ${n.name_ar}` : ""}`.trim(),
      family: n.odor_family_en || n.odor_family || "",
      restriction: n.restriction_en || n.restriction_ar || (n.is_allowed === false ? "Restricted" : ""),
    }));
  }, [type, notesData, opts.noteClass, opts.noteSort]);

  const range = useMemo(() => periodRange(opts.period, opts.from, opts.to), [opts.period, opts.from, opts.to]);
  const model = useMemo(() => {
    const m = type === "budget" ? buildBudgetModel(budgetData || {}, "", range)
      : type === "shopping" ? buildShoppingModel(shopData || {}, "", range)
      : type === "goals" ? buildGoalsModel(goalsData || {})
      : type === "progress" ? buildProgressModel(progData || {})
      : type === "perfumers" ? buildPerfumersModel(perfumerRows, { gender: opts.gender })
      : type === "notes" ? buildNotesModel(noteRows, { classification: opts.noteClass })
      : type === "samples" ? buildSamplesModel(samplesData || {}, "", range)
      : buildBudgetModel({}, "", range);
    if (opts.period !== "all" && (type === "budget" || type === "shopping" || type === "samples")) m.subtitle = periodLabel(opts.period, opts.from, opts.to);
    return m;
  }, [type, budgetData, shopData, goalsData, progData, perfumerRows, noteRows, samplesData, range, opts.period, opts.from, opts.to, opts.gender, opts.noteClass]);

  const lang = opts.lang;
  const fam = REPORT_FONTS[opts.font] || REPORT_FONTS.amiri;
  const exportAr = lang !== "en";
  const previewDir = opts.dir === "rtl" ? "rtl" : opts.dir === "ltr" ? "ltr" : (exportAr ? "rtl" : "ltr");
  const alignStart = previewDir === "rtl" ? "right" : "left";
  const previewFam = lang === "en" ? fam.en : fam.ar; // Amiri يعرض العربي واللاتيني معاً
  const previewRef = useRef(null);

  const [busy, setBusy] = useState(false);
  const exportNow = async () => {
    if (busy) return;
    const safe = (opts.filename || "").trim().replace(/[^\w\u0600-\u06FF -]/g, "").replace(/\s+/g, "-").slice(0, 60);
    const base = safe || `${type}-report-${Date.now().toString(36)}`;
    const o = { lang, showIntro: opts.showIntro, showOutro: opts.showOutro, showDate: opts.showDate, userStart: opts.userStart, userEnd: opts.userEnd, mark: opts.showMark ? userMark : "" };
    setBusy(true);
    try {
      if (opts.format === "txt") return await downloadBlob(new Blob([toTXT(model, o)], { type: "text/plain;charset=utf-8" }), `${base}.txt`);
      if (opts.format === "csv") return await downloadBlob(new Blob(["\uFEFF" + toCSV(model, o)], { type: "text/csv;charset=utf-8" }), `${base}.csv`);
      if (opts.format === "pdf") {
        // نصّ عربي حقيقي قابل للنسخ — خط أميري مدمج + تشكيل + ترتيب اتجاهي (chunk مستقلّ يُحمَّل عند الطلب)
        const { exportReportPdfBlob } = await import("@/lib/pdfReport");
        const blob = await exportReportPdfBlob(model, { ...o, dir: opts.dir, fontSize: opts.fontSize });
        return await downloadBlob(blob, `${base}.pdf`, { toDownload: true });
      }
      if (opts.format === "png") {
        if (!previewRef.current) return;
        const canvas = await html2canvas(previewRef.current, { backgroundColor: "#ffffff", scale: 3, useCORS: true });
        return await saveCanvasAsImage(canvas, `${base}.png`, "image/png", 0.95, { toDownload: true });
      }
    } catch (err) {
      console.error("export failed:", err);
      try { window.alert(isAr ? "تعذّر التصدير، حاول مجدداً" : "Export failed, please try again"); } catch { /* تجاهل */ }
    } finally { setBusy(false); }
  };

  const seg = (val, key, choices, onSel) => (
    <div style={{ display: "inline-flex", flexWrap: "wrap", border: `1px solid ${N}` }}>
      {choices.map(([v, l], i) => (
        <button key={v} onClick={() => (onSel ? onSel(v) : set({ [key]: v }))} style={{ border: "none", borderInlineStart: i ? `1px solid ${N}` : "none", background: val === v ? GOLD : "#fff", color: val === v ? "#fff" : INK, padding: "6px 14px", fontSize: 12, cursor: "pointer", fontFamily: "Cairo, sans-serif" }}>{l}</button>
      ))}
    </div>
  );
  const lbl = (t) => <div style={{ fontSize: 11, color: "#9a8f7c", margin: "10px 0 5px", fontFamily: "Cairo, sans-serif" }}>{t}</div>;

  // ===== المعاينة المذهّبة (بلا إطارات) =====
  const Cell = ({ children, head, align }) => (
    <td style={{ padding: "5px 9px", textAlign: align || alignStart, color: head ? GOLD : "#3a352b", fontWeight: head ? 700 : 400, borderBottom: `1px solid ${GOLD}22`, fontSize: opts.fontSize, fontFamily: previewFam }}>{children}</td>
  );

  return (
    <div className="min-h-screen bg-[var(--page-bg,#fff)] page-top px-4 pb-28">
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        <button onClick={() => { const h = window.history.state; if (h && typeof h.idx === "number" && h.idx > 0) navigate(-1); else navigate("/"); }} aria-label={isAr ? "رجوع" : "Back"} style={{ display: "flex", alignItems: "center", border: `1px solid ${N}`, background: "#fff", color: INK, padding: "5px 9px", cursor: "pointer" }}><ArrowLeft size={14} /></button>
        <span style={{ fontFamily: "Cairo, sans-serif", color: INK, fontWeight: 700 }}>{isAr ? `تصدير ${TITLES[type]?.ar || ""}` : `Export ${TITLES[type]?.en || ""}`}</span>
      </div>

      {/* الخيارات */}
      <div style={{ background: "#F3EEE2", border: `1px solid ${N}`, padding: 12 }}>
        {lbl(isAr ? "النوع" : "Type")}
        {seg(type, null, [["budget", isAr ? "ميزانية" : "Budget"], ["shopping", isAr ? "تسوق" : "Shopping"], ["progress", isAr ? "تقدم" : "Progress"], ["goals", isAr ? "أهداف" : "Goals"], ["perfumers", isAr ? "عطّارون" : "Perfumers"], ["notes", isAr ? "نوتات" : "Notes"], ["samples", isAr ? "عيّنات" : "Samples"]], setType)}

        {type === "perfumers" && (<>
          {lbl(isAr ? "الجنس" : "Gender")}
          {seg(opts.gender, "gender", [["male", isAr ? "ذكر" : "Male"], ["female", isAr ? "أنثى" : "Female"], ["other", isAr ? "غير محدد" : "Unspecified"]])}
          {lbl(isAr ? "الترتيب" : "Order")}
          {seg(opts.ageSort, "ageSort", [["oldest", isAr ? "الأكبر" : "Oldest"], ["youngest", isAr ? "الأصغر" : "Youngest"]])}
          {lbl(isAr ? "العدد" : "Count")}
          {seg(opts.topN, "topN", [[0, isAr ? "الكل" : "All"], [50, "50"], [100, "100"], [200, "200"]])}
        </>)}

        {type === "notes" && (<>
          {lbl(isAr ? "التصنيف" : "Classification")}
          {seg(opts.noteClass, "noteClass", [["main", isAr ? "رئيسية" : "Main"], ["sub", isAr ? "فرعية" : "Sub"], ["low", isAr ? "منخفضة" : "Low"], ["restricted", isAr ? "مقيّدة" : "Restricted"], ["health", isAr ? "صحّية" : "Health"]])}
          {lbl(isAr ? "الترتيب" : "Sort")}
          {seg(opts.noteSort, "noteSort", [["alphaAsc", "A↓"], ["alphaDesc", "A↑"], ["received", isAr ? "بالاستلام" : "Received"]])}
        </>)}

        {lbl(isAr ? "الصيغة" : "Format")}
        {seg(opts.format, "format", [["txt", "TXT"], ["csv", "CSV"], ["png", "PNG"], ["pdf", "PDF"]])}
        {lbl(isAr ? "اللغة" : "Language")}
        {seg(opts.lang, "lang", [["ar", "ع"], ["en", "EN"], ["both", "ع/EN"]])}
        {(type === "budget" || type === "shopping" || type === "samples") && (<>
        {lbl(isAr ? "فترة التصدير" : "Export period")}
        {seg(opts.period, "period", [["all", isAr ? "كل الوقت" : "All"], ["day", isAr ? "اليوم" : "Day"], ["week", isAr ? "أسبوع" : "Week"], ["month", isAr ? "شهر" : "Month"], ["year", isAr ? "سنة" : "Year"], ["custom", isAr ? "محدد" : "Custom"]])}
        {opts.period === "custom" && (
          <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
            <input name="ExportReport-1" type="date" value={opts.from} onChange={(e) => set({ from: e.target.value })} style={{ flex: 1, border: `1px solid ${N}`, padding: 6, fontSize: 12, background: "#fff" }} />
            <input name="ExportReport-2" type="date" value={opts.to} onChange={(e) => set({ to: e.target.value })} style={{ flex: 1, border: `1px solid ${N}`, padding: 6, fontSize: 12, background: "#fff" }} />
          </div>
        )}
        </>)}
        {lbl(isAr ? "اتجاه النص" : "Text direction")}
        {seg(opts.dir, "dir", [["auto", isAr ? "تلقائي" : "Auto"], ["rtl", "RTL"], ["ltr", "LTR"]])}
        {lbl(isAr ? "الخط" : "Font")}
        <div style={{ display: "inline-flex", gap: 8, flexWrap: "wrap" }}>
          {REPORT_FONT_KEYS.map((k) => (
            <button key={k} onClick={() => set({ font: k })} title="" style={{ width: 54, height: 38, border: `1px solid ${opts.font === k ? GOLD : N}`, background: opts.font === k ? "#fff7e3" : "#fff", color: INK, cursor: "pointer", fontFamily: REPORT_FONTS[k].ar, fontSize: 18 }}>أ Aa</button>
          ))}
        </div>
        {lbl(isAr ? "حجم الخط" : "Font size")}
        <div style={{ display: "inline-flex", border: `1px solid ${N}` }}>
          {[10, 12, 14, 17, 20].map((sz, i) => (
            <button key={sz} onClick={() => set({ fontSize: sz })} title={String(sz)}
              style={{ border: "none", borderInlineStart: i ? `1px solid ${N}` : "none", background: opts.fontSize === sz ? GOLD : "#fff", color: opts.fontSize === sz ? "#fff" : INK, width: 44, height: 40, cursor: "pointer", fontFamily: "Amiri, serif", fontSize: 11 + i * 3, lineHeight: 1, display: "inline-flex", alignItems: "center", justifyContent: "center" }}>A</button>
          ))}
        </div>
        {lbl(isAr ? "التقرير المولّد" : "Generated report")}
        <div style={{ display: "flex", gap: 16, fontSize: 12, color: INK, fontFamily: "Cairo, sans-serif" }}>
          <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}><input type="checkbox" checked={opts.showIntro} onChange={(e) => set({ showIntro: e.target.checked })} /> {isAr ? "افتتاحي" : "Intro"}</label>
          <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}><input type="checkbox" checked={opts.showOutro} onChange={(e) => set({ showOutro: e.target.checked })} /> {isAr ? "ختامي" : "Outro"}</label>
          <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}><input type="checkbox" checked={opts.showDate} onChange={(e) => set({ showDate: e.target.checked })} /> {isAr ? "التاريخ" : "Date"}</label>
          <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}><input type="checkbox" checked={opts.showMark} onChange={(e) => set({ showMark: e.target.checked })} /> {isAr ? "المارك" : "Mark"}</label>
        </div>
        {lbl(isAr ? "اسم الملف" : "File name")}
        <input name="ExportReport-3" value={opts.filename} onChange={(e) => set({ filename: e.target.value })} placeholder={isAr ? "اختياري — يُولّد تلقائياً" : "Optional — auto-generated"} style={{ width: "100%", border: `1px solid ${N}`, padding: 7, fontSize: 12, fontFamily: fam.ar, background: "#fff", boxSizing: "border-box" }} />
        {lbl(isAr ? "رسالتك (بداية / ختام)" : "Your message (start / end)")}
        <div style={{ display: "flex", gap: 8 }}>
          <textarea name="ExportReport-tex1" value={opts.userStart} onChange={(e) => set({ userStart: e.target.value })} placeholder={isAr ? "رسالة البداية" : "Opening message"} rows={2} style={{ flex: 1, border: `1px solid ${N}`, padding: 7, fontSize: 12, fontFamily: fam.ar, resize: "vertical", background: "#fff" }} />
          <textarea name="ExportReport-tex2" value={opts.userEnd} onChange={(e) => set({ userEnd: e.target.value })} placeholder={isAr ? "رسالة الختام" : "Closing message"} rows={2} style={{ flex: 1, border: `1px solid ${N}`, padding: 7, fontSize: 12, fontFamily: fam.ar, resize: "vertical", background: "#fff" }} />
        </div>
      </div>

      {/* المعاينة المذهّبة بلا إطارات */}
      <div style={{ marginTop: 14, background: "#fff", padding: 18 }} ref={previewRef} dir={previewDir}>
        <div style={{ textAlign: "center", color: GOLD, fontWeight: 700, fontSize: opts.fontSize + 6, fontFamily: previewFam, letterSpacing: ".02em" }}>{pick(model.title, lang)}</div>
        {model.subtitle && <div style={{ textAlign: "center", color: INK, fontSize: opts.fontSize - 1, marginTop: 2, fontFamily: previewFam }}>{pick(model.subtitle, lang)}</div>}
        {opts.showIntro && (() => { const g = genIntro(model, lang); return <div style={{ textAlign: "center", color: "#8a8276", fontSize: opts.fontSize - 2, marginTop: 4, fontFamily: previewFam }}>{pick(g, lang)}{opts.showDate && g.line ? <div>{g.line}</div> : null}</div>; })()}
        {!opts.showIntro && opts.showDate && <div style={{ textAlign: "center", color: "#8a8276", fontSize: opts.fontSize - 3, marginTop: 4, fontFamily: previewFam }}>{reportDateLine(lang)}</div>}
        {opts.userStart && <div style={{ textAlign: "center", color: "#3a352b", fontSize: opts.fontSize, margin: "8px 0", fontFamily: fam.ar }}>{opts.userStart}</div>}
        {model.sections.map((sec, si) => (
          <div key={si} style={{ marginTop: 16 }}>
            <div style={{ color: GOLD, fontWeight: 700, fontSize: opts.fontSize + 1, fontFamily: previewFam, borderBottom: `1.5px solid ${GOLD}`, paddingBottom: 3, marginBottom: 4 }}>{pick(sec.heading, lang)}</div>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead><tr>{sec.columns.map((c) => <Cell key={c.key} head align={c.align}>{pick(c, lang)}</Cell>)}</tr></thead>
              <tbody>{sec.rows.map((r, ri) => <tr key={ri}>{sec.columns.map((c) => <Cell key={c.key} align={c.align}>{r[c.key]}</Cell>)}</tr>)}</tbody>
            </table>
          </div>
        ))}
        {model.totals?.length > 0 && (
          <div style={{ marginTop: 14, borderTop: `1.5px solid ${GOLD}`, paddingTop: 8, display: "flex", flexWrap: "wrap", gap: "4px 22px", justifyContent: "center" }}>
            {model.totals.map((t, i) => <span key={i} style={{ fontSize: opts.fontSize, color: "#3a352b", fontFamily: previewFam }}><b style={{ color: GOLD }}>{pick(t.label, lang)}:</b> {t.value}</span>)}
          </div>
        )}
        {opts.userEnd && <div style={{ textAlign: "center", color: "#3a352b", fontSize: opts.fontSize, margin: "10px 0 0", fontFamily: fam.ar }}>{opts.userEnd}</div>}
        {opts.showOutro && <div style={{ textAlign: "center", color: "#8a8276", fontSize: opts.fontSize - 2, marginTop: 8, fontFamily: previewFam }}>{pick(genOutro(model, lang), lang)}</div>}
        {opts.showMark && userMark && <div style={{ textAlign: "center", color: GOLD, fontWeight: 700, fontSize: opts.fontSize, marginTop: 6, fontFamily: "Amiri, serif" }}>{userMark}</div>}
      </div>

      {/* حفظ */}
      <div style={{ display: "flex", justifyContent: "center", padding: "16px 0 26px" }}>
        <button onClick={exportNow} disabled={busy} style={{ border: `1px solid ${GOLD}`, background: busy ? "#d9c684" : GOLD, color: "#fff", padding: "10px 30px", fontSize: 14, fontWeight: 700, cursor: busy ? "wait" : "pointer", fontFamily: "Cairo, sans-serif" }}>{busy ? (isAr ? "يجري التصدير" : "Exporting") : (isAr ? "حفظ التصدير" : "Save export")}</button>
      </div>
    </div>
  );
}
