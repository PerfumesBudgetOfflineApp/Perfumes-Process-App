import { useState, useRef, useEffect, useMemo } from "react";
import { useSearchParams, useNavigate, useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { ArrowLeft, Image as ImageIcon, FileText, Type } from "lucide-react";
import { captureElement } from "@/lib/captureCanvas";
import { apphost } from "@/api/apphostClient";
import { saveCanvasAsImage, downloadBlob, downscaleCanvas } from "@/lib/exportHelper";
import { usePersonNames } from "@/lib/usePersonNames";
import { useContentEncryption } from "@/lib/useContentEncryption";
import { useLang } from "@/lib/LanguageContext";
import { splitMedia } from "@/components/blog/MediaSection";

const GOLD = "var(--brand)", INK = "#2E7D32", N = "#d9cfb0";
const OPT_KEY = "exportBlogOptions";
const ENTRY_TYPE_LABEL = { memo: "📝 Memo", not_set: "Not Set", perfume: "🌹 Perfume", music: "🎵 Music", tv: "📺 TV", films: "🎬 Films", idea: "💡 Idea", poetry: "✍️ Poetry", thought: "💭 Thought", knowledge: "🧠 Knowledge", concept: "🔮 Concept" };

export default function ExportBlog() {
  const [sp] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { decryptFields, userId } = useContentEncryption();
  const postId = sp.get("id");
  const statePost = location.state?.post || null;

  // التدوينة: من حالة التنقّل (مفكوكة مسبقاً) أو جلب+فكّ احتياطي عند الرابط المباشر
  const { data: fetched } = useQuery({
    enabled: !statePost && !!postId && !!userId,
    queryKey: ["export-blog-post", postId, userId],
    queryFn: async () => {
      const rows = postId ? await apphost.entities.BlogPost.filter({ id: postId }) : [];
      if (rows?.[0]) { try { return await decryptFields(rows[0], ["title", "body", "personal_notes"]); } catch { return rows[0]; } }
      return null;
    },
  });
  const post = statePost || fetched || null;
  const { data: me } = useQuery({ queryKey: ["eb-me"], queryFn: () => apphost.auth.me().catch(() => null) });

  const [opts, setOpts] = useState(() => {
    const base = { format: "img", includeBody: true, includeMedia: true, includeLinks: true, includeTags: true, includeMark: true, addGoldenFrame: true, includeDate: false, includeType: true, includeUser: true, alignment: "center", fontSize: 16, bgColor: "#ffffff", textColor: "#1a1a1a" };
    try { return { ...base, ...JSON.parse(localStorage.getItem(OPT_KEY) || "{}") }; } catch { return base; }
  });
  useEffect(() => { try { localStorage.setItem(OPT_KEY, JSON.stringify(opts)); } catch { /* تجاهل */ } }, [opts]);
  const set = (patch) => setOpts((o) => ({ ...o, ...patch }));

  const [busy, setBusy] = useState(false);
  const previewRef = useRef(null);

  const personName = post ? (post.person === "person2" ? names.person2 : names.person1) : "";
  const userMark = String(me?.mark || "").slice(0, 32);
  const tags = useMemo(() => (post?.tags ? post.tags.split(",").map((t) => t.trim()).filter(Boolean) : []), [post]);
  const mediaUrls = useMemo(() => splitMedia(post?.media_urls), [post]);
  const hasLinks = post && (post.linked_perfume_name || post.linked_brand_name || post.linked_perfumer_name || post.linked_notes);

  // التقاط المعاينة لصورة (يرفع القيود مؤقتاً ثم يعيدها)
  const captureCanvas = async (scale = 2) => {
    const el = previewRef.current;
    if (!el) return null;
    const original = el.style.cssText;
    const parent = el.parentElement;
    const originalParent = parent ? parent.style.cssText : "";
    el.style.cssText = "";
    el.style.position = "fixed"; el.style.left = "0"; el.style.top = "0"; el.style.zIndex = "-1";
    el.style.opacity = "1"; el.style.pointerEvents = "none"; el.style.width = "794px";
    if (parent) { parent.style.overflow = "visible"; parent.style.maxHeight = "none"; }
    await new Promise((r) => setTimeout(r, 120));
    const canvas = await captureElement(el, { scale, useCORS: true, backgroundColor: opts.addGoldenFrame ? "#4CAF50" : opts.bgColor, logging: false, allowTaint: true, height: el.scrollHeight, width: el.scrollWidth });
    el.style.cssText = original;
    if (parent) parent.style.cssText = originalParent;
    return canvas;
  };

  const buildTxt = () => {
    const L = [];
    const meta = [];
    if (opts.includeType) meta.push(ENTRY_TYPE_LABEL[post.entry_type] || "Thought");
    if (opts.includeUser && personName) meta.push(personName);
    if (opts.includeDate && post.created_date) meta.push(format(new Date(post.created_date), "dd MMM yyyy"));
    if (meta.length) L.push(meta.join("  "));
    L.push(post.title || "");
    if (opts.includeBody && post.body) L.push("", post.body);
    if (opts.includeTags && tags.length) L.push("", tags.join("  "));
    if (opts.includeLinks && hasLinks) {
      L.push("", isAr ? "ارتباط Related" : "Related ارتباط");
      if (post.linked_brand_name) L.push(`${isAr ? "علامة Brand" : "Brand علامة"}: ${post.linked_brand_name}`);
      if (post.linked_perfume_name) L.push(`${isAr ? "عطر Perfume" : "Perfume عطر"}: ${post.linked_perfume_name}`);
      if (post.linked_perfumer_name) L.push(`${isAr ? "عطار Perfumer" : "Perfumer عطار"}: ${post.linked_perfumer_name}`);
      if (post.linked_notes) L.push(`${isAr ? "نوتة Note" : "Note نوتة"}: ${post.linked_notes}`);
    }
    if (opts.includeMark && userMark) L.push("", userMark);
    return L.join("\n");
  };

  const fileBase = () => (post?.title || "blog").replace(/\s+/g, "_").replace(/[^\w\u0600-\u06FF-]/g, "") || "blog";

  const saveNow = async () => {
    if (busy || !post) return;
    setBusy(true);
    try {
      const base = fileBase();
      if (opts.format === "text") {
        return await downloadBlob(new Blob(["\uFEFF" + buildTxt()], { type: "text/plain;charset=utf-8" }), `${base}.txt`, { toDownload: true });
      }
      // تمرير إطار كي تُرسم حالة الحفظ قبل العمل الثقيل
      await new Promise((r) => setTimeout(r, 0));
      if (opts.format === "img") {
        let canvas = await captureCanvas(2);
        if (!canvas) return;
        canvas = downscaleCanvas(canvas, 1080);
        return await saveCanvasAsImage(canvas, `${base}.png`, "image/png", 0.95, { toDownload: true });
      }
      if (opts.format === "pdf") {
        const canvas = await captureCanvas(2);
        if (!canvas) return;
        const imgData = canvas.toDataURL("image/png");
        const pageW = 210, pageH = 297;
        const imgH = pageW * (canvas.height / canvas.width);
        const { jsPDF } = await import("jspdf");
        const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: [pageW, Math.max(imgH, pageH)], compress: true });
        pdf.addImage(imgData, "PNG", 0, 0, pageW, imgH);
        return await downloadBlob(pdf.output("blob"), `${base}.pdf`, { toDownload: true });
      }
    } catch (err) {
      console.error("blog export failed:", err);
      try { window.alert(isAr ? "تعذّر التصدير، حاول مجدداً" : "Export failed, please try again"); } catch { /* تجاهل */ }
    } finally { setBusy(false); }
  };

  const seg = (val, key, choices) => (
    <div style={{ display: "inline-flex", flexWrap: "wrap", border: `1px solid ${N}` }}>
      {choices.map(([v, l, Icon], i) => (
        <button key={v} onClick={() => set({ [key]: v })} style={{ border: "none", borderInlineStart: i ? `1px solid ${N}` : "none", background: val === v ? GOLD : "#fff", color: val === v ? "#fff" : INK, padding: "7px 16px", fontSize: 12, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 5, fontFamily: "Cairo, sans-serif" }}>{Icon ? <Icon size={14} /> : null}{l}</button>
      ))}
    </div>
  );
  const lbl = (t) => <div style={{ fontSize: 11, color: "#9a8f7c", margin: "10px 0 5px", fontFamily: "Cairo, sans-serif" }}>{t}</div>;
  const chk = (key, label) => (
    <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer", fontSize: 12, color: INK, fontFamily: "Cairo, sans-serif" }}>
      <input type="checkbox" checked={opts[key]} onChange={(e) => set({ [key]: e.target.checked })} /> {label}
    </label>
  );

  if (!post) {
    return (
      <div className="min-h-screen bg-[var(--page-bg,#fff)] page-top px-4 text-center text-sm font-body text-muted-foreground">
        {isAr ? "جارٍ التحميل" : "Loading"}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[var(--page-bg,#fff)] page-top px-4 pb-28">
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
        <button onClick={() => { const h = window.history.state; if (h && typeof h.idx === "number" && h.idx > 0) navigate(-1); else navigate("/blog"); }} aria-label={isAr ? "رجوع" : "Back"} style={{ display: "flex", alignItems: "center", border: `1px solid ${N}`, background: "#fff", color: INK, padding: "5px 9px", cursor: "pointer" }}><ArrowLeft size={14} /></button>
        <span style={{ fontFamily: "Cairo, sans-serif", color: INK, fontWeight: 700 }}>{isAr ? "تصدير التدوينة" : "Export Post"}</span>
      </div>

      {/* الخيارات */}
      <div style={{ background: "#F3EEE2", border: `1px solid ${N}`, padding: 12 }}>
        {lbl(isAr ? "الصيغة" : "Format")}
        {seg(opts.format, "format", [["img", "IMG", ImageIcon], ["text", "Text", Type], ["pdf", "PDF", FileText]])}
        {lbl(isAr ? "المحتوى" : "Content")}
        <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
          {chk("includeBody", isAr ? "النص" : "Body")}
          {chk("includeTags", isAr ? "الوسوم" : "Tags")}
          {chk("includeLinks", isAr ? "الروابط" : "Links")}
          {chk("includeMedia", isAr ? "الوسائط" : "Media")}
        </div>
        {lbl(isAr ? "الترويسة" : "Header")}
        <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
          {chk("includeType", isAr ? "النوع" : "Type")}
          {chk("includeUser", isAr ? "الكاتب" : "Author")}
          {chk("includeDate", isAr ? "التاريخ" : "Date")}
          {chk("includeMark", isAr ? "المارك" : "Mark")}
          {chk("addGoldenFrame", isAr ? "إطار ذهبي" : "Gold frame")}
        </div>
        {lbl(isAr ? "المحاذاة" : "Alignment")}
        {seg(opts.alignment, "alignment", [["right", isAr ? "يمين" : "Right"], ["center", isAr ? "وسط" : "Center"], ["left", isAr ? "يسار" : "Left"]])}
        {lbl(isAr ? "حجم الخط" : "Font size")}
        <div style={{ display: "inline-flex", border: `1px solid ${N}` }}>
          {[14, 16, 18, 20].map((sz, i) => (
            <button key={sz} onClick={() => set({ fontSize: sz })} style={{ border: "none", borderInlineStart: i ? `1px solid ${N}` : "none", background: opts.fontSize === sz ? GOLD : "#fff", color: opts.fontSize === sz ? "#fff" : INK, width: 44, height: 38, cursor: "pointer", fontFamily: "Amiri, serif", fontSize: 11 + i * 3 }}>A</button>
          ))}
        </div>
      </div>

      {/* المعاينة (تصميم بسيط أنيق كالحالي) */}
      <div style={{ marginTop: 14, border: `1px solid ${N}`, overflow: "hidden" }}>
        <div style={{ fontSize: 10, color: "#9a8f7c", padding: "6px 10px", background: "#faf6ec", fontFamily: "Cairo, sans-serif" }}>{isAr ? "معاينة" : "Preview"}</div>
        <div ref={previewRef} style={{ background: opts.addGoldenFrame ? "#4CAF50" : opts.bgColor, padding: opts.addGoldenFrame ? "12px" : "0" }}>
          <div style={{ padding: "36px 30px", background: opts.bgColor, color: opts.textColor, fontFamily: "'Amiri', 'Segoe UI', serif", direction: "auto", boxShadow: opts.addGoldenFrame ? "inset 0 0 30px rgba(212,175,55,0.25)" : "none", textAlign: opts.alignment }}>
            <div style={{ fontSize: 13, color: opts.textColor, marginBottom: 8, opacity: 0.7 }}>
              {opts.includeType && <span>{ENTRY_TYPE_LABEL[post.entry_type] || "Thought"}</span>}
              {opts.includeType && opts.includeUser && <span> </span>}
              {opts.includeUser && <span>{personName}</span>}
              {opts.includeDate && post.created_date && <span> {format(new Date(post.created_date), "dd MMM yyyy")}</span>}
            </div>
            <h1 style={{ fontSize: 28, fontWeight: 700, marginBottom: 16, lineHeight: 1.2, direction: "auto", wordBreak: "break-word" }}>{post.title}</h1>
            {opts.includeBody && post.body && <p style={{ fontSize: opts.fontSize, lineHeight: 1.9, whiteSpace: "pre-wrap", marginBottom: 16, direction: "auto", wordBreak: "break-word" }}>{post.body}</p>}
            {opts.includeTags && tags.length > 0 && (
              <div style={{ marginBottom: 12, direction: "auto" }}>
                {tags.map((t) => <span key={t} style={{ display: "inline-block", color: opts.textColor, opacity: 0.75, fontSize: 12, margin: "0 6px" }}>{t}</span>)}
              </div>
            )}
            {opts.includeMedia && mediaUrls.length > 0 && (
              <div style={{ marginBottom: 16 }}>{mediaUrls.map((url, i) => <img key={i} src={url} alt="" style={{ maxWidth: "100%", marginBottom: 8 }} crossOrigin="anonymous" />)}</div>
            )}
            {opts.includeLinks && hasLinks && (
              <div style={{ fontSize: 13, color: opts.textColor, borderTop: `1px solid ${opts.textColor}22`, paddingTop: 12, marginTop: 12, direction: "auto" }}>
                <div style={{ marginBottom: 10, fontWeight: 700 }}>Related ارتباط</div>
                {post.linked_brand_name && <div style={{ marginBottom: 6 }}><b style={{ opacity: 0.7 }}>Brand علامة:</b> {post.linked_brand_name}</div>}
                {post.linked_perfume_name && <div style={{ marginBottom: 6 }}><b style={{ opacity: 0.7 }}>Perfume عطر:</b> {post.linked_perfume_name}</div>}
                {post.linked_perfumer_name && <div style={{ marginBottom: 6 }}><b style={{ opacity: 0.7 }}>Perfumer عطار:</b> {post.linked_perfumer_name}</div>}
                {post.linked_notes && <div><b style={{ opacity: 0.7 }}>Note نوتة:</b> {post.linked_notes}</div>}
              </div>
            )}
            {opts.includeMark && userMark && <div style={{ fontSize: 22, fontWeight: 700, textAlign: "center", marginTop: 20, paddingTop: 18, borderTop: `1px solid ${opts.textColor}22` }}>{userMark}</div>}
          </div>
        </div>
      </div>

      {/* حفظ بعد المعاينة (بدل الطباعة) */}
      <div style={{ display: "flex", justifyContent: "center", padding: "16px 0 26px" }}>
        <button onClick={saveNow} disabled={busy} style={{ border: `1px solid ${GOLD}`, background: busy ? "#d9c684" : GOLD, color: "#fff", padding: "10px 34px", fontSize: 14, fontWeight: 700, cursor: busy ? "wait" : "pointer", fontFamily: "Cairo, sans-serif" }}>{busy ? (isAr ? "يجري الحفظ" : "Saving") : (isAr ? "حفظ" : "Save")}</button>
      </div>
    </div>
  );
}
