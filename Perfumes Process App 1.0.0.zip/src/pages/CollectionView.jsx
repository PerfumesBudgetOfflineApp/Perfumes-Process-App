import { captureElement } from "@/lib/captureCanvas";
import { useState, useEffect, useRef, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Heart, Package, ShoppingBag, HeartOff, Download, FileImage, FileText, Printer, CalendarCheck } from "lucide-react";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import WearListView from "@/components/wearlog/WearListView";
import { usePersonNames } from "@/lib/usePersonNames";
import { ENC, langField } from "@/lib/encyclopedia";
import { useLang } from "@/lib/LanguageContext";
import { cn } from "@/lib/utils";
import { openHtmlReport, saveCanvasAsImage, downloadBlob } from "@/lib/exportHelper";

const TABS = [
  { key: "favorites", label: "Favorites & Sets", label_ar: "مفضلة و قوائم", icon: Heart, listValue: "favorite" },
  { key: "collections", label: "Collections", label_ar: "مجموعات", icon: Package, listValue: "own" },
  { key: "wear", label: "Wear", label_ar: "ارتداء", icon: CalendarCheck, listValue: null },
  { key: "wishes", label: "I Want To Buy", label_ar: "أرغب شرائه", icon: ShoppingBag, listValue: "wishlist" },
];

export default function CollectionView() {
  const urlParams = new URLSearchParams(window.location.search);
  const rawTab = urlParams.get("tab") || "favorites";
  const defaultTab = (rawTab === "wearlog" || rawTab === "future") ? "wear" : rawTab;
  const [activeTab, setActiveTab] = useState(defaultTab);
  const [showExport, setShowExport] = useState(false);
  const [exporting, setExporting] = useState(false);
  const exportRef = useRef(null);
  const navigate = useNavigate();
  const { names, profiles } = usePersonNames();

  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: encEntries = [] } = useQuery({ queryKey: ["enc-fav-entries"], queryFn: () => ENC.Entry().list("-updated_date", 5000), staleTime: 1000 * 10 });
  const { data: encLangs = [] } = useQuery({ queryKey: ["enc-langs"], queryFn: () => ENC.Language().list("order", 50), staleTime: 1000 * 30 });

  const { data: perfumers = [] } = useQuery({
    queryKey: ["perfumers-all"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
  });

  const { data: wishlists = [] } = useQuery({
    queryKey: ["wishlists"],
    queryFn: () => apphost.entities.Wishlist.list("-created_date"),
  });

  // عطور المجموعة فقط: نجمع المعرّفات من UserPerfume + الأمنيات ونجلبها بالمعرّف
  // (بدل تحميل 130 ألف). يبقى الاسم perfumes فلا يتغيّر باقي الكود.
  const collectionIds = useMemo(() => {
    const set = new Set();
    userPerfumes.forEach((u) => { if (u.perfume_id) set.add(String(u.perfume_id)); });
    wishlists.forEach((w) => { if (w.perfume_id) set.add(String(w.perfume_id)); });
    return [...set];
  }, [userPerfumes, wishlists]);

  const { data: perfumes = [] } = useQuery({
    queryKey: ["collection-perfumes", collectionIds.join(",")],
    queryFn: () => apphost.entities.Perfume.getMany(collectionIds),
    enabled: collectionIds.length > 0,
    staleTime: 1000 * 60 * 5,
  });

  const [userData, setUserData] = useState(null);
  useEffect(() => {
    apphost.auth.me().then(setUserData).catch(() => {});
  }, []);

  const { isAr } = useLang();

  const currentTab = TABS.find((t) => t.key === activeTab) || TABS[0];

  const getPersonPerfumes = (person) => {
    if (activeTab === "wishes") {
      return wishlists.filter((w) => w.person === person).map((w) => {
        const perfume = perfumes.find((p) => String(p.id) === String(w.perfume_id));
        return perfume ? { ...perfume, wishData: w } : null;
      }).filter(Boolean);
    }
    
    const ids = userPerfumes
      .filter((u) => {
        if (activeTab === "favorites" && (currentTab.listValue === "favorite")) {
          return u.person === person && (u.list === "favorite" || u.list === "own");
        }
        return u.person === person && u.list === currentTab.listValue;
      })
      .map((u) => u.perfume_id);
    return perfumes.filter((p) => ids.includes(p.id));
  };

  const p1Perfumes = getPersonPerfumes("person1");
  const p2Perfumes = getPersonPerfumes("person2");

  const getList = (key) =>
    userData?.[key]?.split(",").map(s => s.trim()).filter(Boolean) || [];

  const getFavBrands = (person) => brands.filter(b => getList(person === "person1" ? "fav_brands_p1" : "fav_brands_p2").includes(b.id));
  const getDislikeBrands = (person) => brands.filter(b => getList(person === "person1" ? "dislike_brands_p1" : "dislike_brands_p2").includes(b.id));
  const getFavPerfumers = (person) => perfumers.filter(p => getList(person === "person1" ? "fav_perfumers_p1" : "fav_perfumers_p2").includes(p.id));
  const getDislikePerfumers = (person) => perfumers.filter(p => getList(person === "person1" ? "dislike_perfumers_p1" : "dislike_perfumers_p2").includes(p.id));

  const handlePrint = async () => {
    const content = exportRef.current?.innerHTML;
    if (!content) return;
    await openHtmlReport(`<html><head><title>{isAr ? "المفضّلة" : "Favorites"}</title>
      <style>body{font-family:sans-serif;padding:24px;background:#fff;color:#111}
      h1{font-size:22px;margin-bottom:16px}.section{margin-bottom:20px}
      .label{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:#888;margin-bottom:6px}
      .chips{display:flex;flex-wrap:wrap;gap:6px}.chip{padding:4px 12px;border-radius:999px;font-size:12px;font-weight:600}
      .fav{background:#fef3c7;color:#92400e}.dislike{background:#fee2e2;color:#991b1b}
      .violet{background:#ede9fe;color:#5b21b6}.violet-dislike{background:#fee2e2;color:#991b1b}
      hr{border:none;border-top:1px solid #eee;margin:16px 0}
      </style></head><body>${content}</body></html>`);
    // User triggers print via the overlay — no auto-print.
  };

  const handleExportImage = async () => {
    setExporting(true);
    const canvas = await captureElement(exportRef.current, { scale: 2, backgroundColor: "#ffffff" });
    await saveCanvasAsImage(canvas, "favorites.png");
    setExporting(false);
  };

  const handleExportPDF = async () => {
    setExporting(true);
    const { jsPDF } = await import("jspdf");
    const canvas = await captureElement(exportRef.current, { scale: 2, backgroundColor: "#ffffff" });
    const imgData = canvas.toDataURL("image/png");
    const pdf = new jsPDF({ orientation: "portrait", unit: "px", format: [canvas.width / 2, canvas.height / 2] });
    pdf.addImage(imgData, "PNG", 0, 0, canvas.width / 2, canvas.height / 2);
    const pdfBlob = pdf.output('blob');
    await downloadBlob(pdfBlob, "favorites.pdf");
    setExporting(false);
  };

  const personData = [
    { person: "person1", name: names.person1, color: profiles.person1?.color || "#10b981", photo: profiles.person1?.photo, perfumes: p1Perfumes },
    { person: "person2", name: names.person2, color: profiles.person2?.color || "#8b5cf6", photo: profiles.person2?.photo, perfumes: p2Perfumes },
  ];

  // مفضلة الموسوعة لكل مستخدم — عرض إضافي أسفل تبويب المفضلة، خارج التصدير
  const encReactionOf = (e, person) => (e.reactions || (e.reaction ? { person1: e.reaction } : {}))[person] || "none";
  const encCode = isAr ? "ar" : "en";
  const encTitle = (e) => langField(e.titles, encCode, encLangs) || (isAr ? "بلا عنوان" : "Untitled");
  const encFavByPerson = personData.map(({ person, name, color }) => ({
    person, name, color,
    items: encEntries.filter((e) => encReactionOf(e, person) === "favorite"),
  }));
  const hasEncFav = encFavByPerson.some((g) => g.items.length > 0);

  return (
    <div className="pb-4">
      {/* Header */}
      <div className="px-4 page-top pb-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate(-1)} className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity">
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="font-heading text-xl font-bold">{isAr ? currentTab.label_ar : currentTab.label}</h1>
            <p className="text-xs text-muted-foreground font-body">{isAr ? "كلا الملفّين" : "Both profiles"}</p>
          </div>
        </div>
        <button onClick={() => setShowExport(!showExport)}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity"
          title={isAr ? "تصدير" : "Export"}>
          <Download className="w-4 h-4" />
        </button>
      </div>

      {/* Export options — available on every tab */}
      {showExport && (
         <div className="px-4 mb-4">
           <div className="space-y-3">
             <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wide">
               {isAr ? "تصدير" : "Export"} {isAr ? currentTab.label_ar : currentTab.label}
             </p>
            <div className="flex flex-wrap gap-x-5 gap-y-2">
              <button onClick={handlePrint}
                className="text-xs font-body font-medium text-primary hover:opacity-70 transition-opacity flex items-center gap-1.5">
                <Printer className="w-3.5 h-3.5" /> {isAr ? "طباعة" : "Print"}
              </button>
              <button onClick={handleExportImage} disabled={exporting}
                className="text-xs font-body font-medium text-emerald-600 hover:opacity-70 transition-opacity disabled:opacity-50 flex items-center gap-1.5">
                <FileImage className="w-3.5 h-3.5" /> {exporting ? ".." : (isAr ? "صورة" : "Image")}
              </button>
              <button onClick={handleExportPDF} disabled={exporting}
                className="text-xs font-body font-medium text-rose-600 hover:opacity-70 transition-opacity disabled:opacity-50 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" /> {exporting ? ".." : "PDF"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tabs — نصوص ملوّنة بلا أيقونات وبلا إطارات وبلا خلفيّة */}
      <div className="px-4 flex flex-wrap gap-x-5 gap-y-1 mb-5">
        {TABS.map((tab, i) => {
          const active = activeTab === tab.key;
          // لون مميّز لكل تبويب بصرياً
          const colors = ["text-rose-600", "text-emerald-600", "text-sky-600", "text-violet-600", "text-amber-600"];
          const color = colors[i % colors.length];
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={cn(
                "text-xs font-body py-1 hover:opacity-70 transition-opacity",
                color,
                active ? "font-bold" : "opacity-60"
              )}>
              {isAr ? tab.label_ar : tab.label}
            </button>
          );
        })}
        <button onClick={() => navigate("/lists")} className="text-xs font-body py-1 hover:opacity-70 transition-opacity text-teal-600 opacity-90">{isAr ? "القوائم" : "Lists"}</button>
        <button onClick={() => navigate("/samples")} className="text-xs font-body py-1 hover:opacity-70 transition-opacity text-fuchsia-600 opacity-90">{isAr ? "العيّنات" : "Samples"}</button>
      </div>

      {/* Exportable content */}
      <div ref={exportRef} className="px-4 space-y-6 bg-background">
        {(activeTab === "favorites" || activeTab === "wishes") && (
            <div className="hidden-for-screen py-2">
              <h1 style={{ fontFamily: "serif", fontSize: 20, fontWeight: "bold", marginBottom: 4 }}>
                {activeTab === "wishes" ? "I Want To Buy" : "Favorites"}
              </h1>
            </div>
          )}

        {/* تبويب الارتداء الموحّد: الجدولة (القادم) فوق، ثمّ سجل الارتداء أسفله */}
        {activeTab === "wear" && (
          <div className="space-y-6">
            <div className="space-y-2">
              <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-widest" style={{ color: "var(--brand)" }}>
                {isAr ? "الارتداء القادم" : "Upcoming"}
              </p>
              <WearListView mode="future" names={names} profiles={profiles} />
            </div>
            <div className="space-y-2">
              <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-widest" style={{ color: "var(--brand)" }}>
                {isAr ? "سجل الارتداء" : "Wear Log"}
              </p>
              <WearListView mode="log" names={names} profiles={profiles} />
            </div>
          </div>
        )}

        {/* بقية التبويبات */}
        {activeTab !== "wear" && personData.map(({ person, name, color, photo, perfumes: pf }, idx) => (
          <div key={person}>
            {idx > 0 && <div className="border-t border-border/50 mb-6" />}
            <PersonBlock
              name={name} color={color} photo={photo} perfumes={pf}
              emptyMsg={`${name} has no ${currentTab.label.toLowerCase()} yet`}
              favBrands={activeTab === "favorites" ? getFavBrands(person) : []}
              dislikeBrands={activeTab === "favorites" ? getDislikeBrands(person) : []}
              favPerfumers={activeTab === "favorites" ? getFavPerfumers(person) : []}
              dislikePerfumers={activeTab === "favorites" ? getDislikePerfumers(person) : []}
              isWishlist={activeTab === "wishes"}
            />
          </div>
        ))}
      </div>

      {/* مفضلة الموسوعة — عرض إضافي أسفل المفضلة، خارج exportRef فلا يدخل التصدير */}
      {activeTab === "favorites" && hasEncFav && (
        <div className="px-4 pt-2 space-y-4">
          <h2 className="font-heading text-sm font-semibold" style={{ color: "var(--brand)" }}>{isAr ? "مفضلة الموسوعة" : "Encyclopedia favorites"}</h2>
          {encFavByPerson.map(({ person, name, color, items }) => items.length > 0 && (
            <div key={person} className="space-y-1">
              <p className="font-heading text-xs font-semibold" style={{ color }}>{name}</p>
              {items.map((e) => (
                <button key={e.id} type="button" onClick={() => navigate(`/encyclopedia/view/${e.id}`)}
                  className="w-full flex items-center gap-2 py-1.5 text-start hover:opacity-70 transition-opacity" dir={isAr ? "rtl" : "ltr"}>
                  <Heart className="w-3.5 h-3.5 flex-shrink-0 fill-current" style={{ color }} />
                  <span className="flex-1 min-w-0 font-body text-sm truncate">{encTitle(e)}</span>
                </button>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PersonBlock({ name, color, photo, perfumes, emptyMsg, favBrands = [], dislikeBrands = [], favPerfumers = [], dislikePerfumers = [], isWishlist = false }) {
  const { isAr } = useLang();
  return (
    <div className="space-y-3">
      {/* Person header */}
      <div className="flex items-center justify-between gap-2.5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-none overflow-hidden flex items-center justify-center flex-shrink-0"
            style={{ background: color + "22" }}>
            {photo ? (
              <img src={photo} alt={name} className="w-full h-full object-cover" />
            ) : (
              <span className="text-xs font-bold" style={{ color }}>{name?.[0]?.toUpperCase()}</span>
            )}
          </div>
          <div>
            <p className="font-heading font-semibold text-sm" style={{ color }}>{name}</p>
            <p className="text-[11px] text-muted-foreground font-body">{perfumes.length} perfume{perfumes.length !== 1 ? "s" : ""}</p>
          </div>
        </div>
      </div>

      {perfumes.length === 0 ? (
        <p className="text-sm text-muted-foreground font-body pl-10">{emptyMsg}</p>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {perfumes.map((p) => (
            <div key={p.id} className="relative">
              <PerfumeCard perfume={p} />
              {/* Price and wishlist badge */}
              <div className="absolute top-2 right-2 flex flex-col items-end gap-1">
                {isWishlist && p.wishData?.priority && (
                  <div className="text-xs font-bold rounded-none ">
                    {p.wishData.priority === "high" ? "🔴" : p.wishData.priority === "medium" ? "🟡" : "🔵"}
                  </div>
                )}
                {isWishlist && p.wishData?.estimated_price && (
                  <div className="text-xs font-bold rounded-none text-amber-700 dark:text-amber-300 ">
                    {p.wishData.estimated_price}
                  </div>
                )}
                {!isWishlist && p.price && (
                  <div className="text-xs font-bold rounded-none text-green-700 dark:text-green-300 ">
                    {p.price}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Favorite Brands */}
      {favBrands.length > 0 && (
        <div className="space-y-2 pt-1">
          <p className="text-[11px] text-muted-foreground font-body font-semibold uppercase tracking-wide">{isAr ? "البراندات المفضّلة" : "Favorite Brands"}</p>
          <div className="flex flex-wrap gap-2">
            {favBrands.map((b) => (
              <Link key={b.id} to={`/brand?id=${b.id}`}
                className="text-xs rounded-none font-body font-medium text-amber-700 dark:text-amber-400 transition-colors flex items-center gap-1">
                <Heart className="w-3 h-3 fill-current" /> {b.name}
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Dislike Brands */}
      {dislikeBrands.length > 0 && (
        <div className="space-y-2 pt-1">
          <p className="text-[11px] text-muted-foreground font-body font-semibold uppercase tracking-wide">{isAr ? "براندات غير مفضّلة" : "Not Favorite Brands"}</p>
          <div className="flex flex-wrap gap-2">
            {dislikeBrands.map((b) => (
              <Link key={b.id} to={`/brand?id=${b.id}`}
                className="text-xs rounded-none font-body font-medium text-red-600 dark:text-red-400 transition-colors flex items-center gap-1">
                <HeartOff className="w-3 h-3" /> {b.name}
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Favorite Perfumers */}
      {favPerfumers.length > 0 && (
        <div className="space-y-2 pt-1">
          <p className="text-[11px] text-muted-foreground font-body font-semibold uppercase tracking-wide">{isAr ? "المعطّرون المفضّلون" : "Favorite Perfumers"}</p>
          <div className="flex flex-wrap gap-2">
            {favPerfumers.map((pf) => (
              <Link key={pf.id} to={`/perfumer?id=${pf.id}`}
                className="text-xs rounded-none font-body font-medium text-violet-700 dark:text-violet-400 transition-colors flex items-center gap-1">
                <Heart className="w-3 h-3 fill-current" /> {pf.name}
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Dislike Perfumers */}
      {dislikePerfumers.length > 0 && (
        <div className="space-y-2 pt-1">
          <p className="text-[11px] text-muted-foreground font-body font-semibold uppercase tracking-wide">{isAr ? "معطّرون غير مفضّلين" : "Not Favorite Perfumers"}</p>
          <div className="flex flex-wrap gap-2">
            {dislikePerfumers.map((pf) => (
              <Link key={pf.id} to={`/perfumer?id=${pf.id}`}
                className="text-xs rounded-none font-body font-medium text-red-600 dark:text-red-400 transition-colors flex items-center gap-1">
                <HeartOff className="w-3 h-3" /> {pf.name}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}