import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, X, Image as ImageIcon } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import ImageUploadButton from "@/components/ui/ImageUploadButton";
import ImagesField from "@/components/shared/ImagesField";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";

/**
 * GlossaryTermEdit — صفحة تعديل مستقلة للمصطلح/القصة بدل النافذة المنبثقة
 * (المنبثقة كانت مشكلة على الجوال). نفس حقول النموذج القديم + حقل
 * «ترجمة عربية إضافية» (meaning_extraar) للقصص — الحقل مزروع على كل
 * السجلات وقت التنصيب والتحديث فيُعدَّل كأي حقل أصيل.
 *
 * المسار: /glossary-term-edit?id=X — الحفظ/الإلغاء يعيدان لصفحة المدخل.
 */
export default function GlossaryTermEdit() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { isAr } = useLang();
  const params = new URLSearchParams(window.location.search);
  const termId = params.get("id");
  const isNew = !termId;
  const newType = params.get("type") === "story" ? "story" : "term";

  const { data: terms = [] } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
  });
  const term = terms.find((t) => String(t.id) === String(termId));

  const [form, setForm] = useState(null);
  useEffect(() => {
    if (isNew && !form) {
      setForm({ term_en: "", term_ar: "", meaning: "", meaning_ar: "", meaning_extraar: "", tags: "", image_url: "", images: [], entry_type: newType });
      return;
    }
    if (term && !form) {
      setForm({
        term_en: term.term_en || "",
        term_ar: term.term_ar || "",
        meaning: term.meaning || "",
        meaning_ar: term.meaning_ar || "",
        meaning_extraar: term.meaning_extraar || "",
        tags: term.tags || "",
        image_url: term.image_url || "",
        images: Array.isArray(term.images) ? term.images : [],
        entry_type: term.entry_type || "term",
      });
    }
  }, [term, form]);

  const saveMutation = useMutation({
    mutationFn: async (fields) => {
      const clean = {};
      ["term_en", "term_ar", "meaning", "meaning_ar", "meaning_extraar", "tags", "image_url", "entry_type", "images"].forEach((k) => {
        if (fields[k] !== undefined) clean[k] = fields[k];
      });
      if (isNew) return apphost.entities.GlossaryTerm.create({ ...clean, is_user: true });
      return apphost.entities.GlossaryTerm.update(term.id, clean);
    },
    onSuccess: (created) => {
      qc.invalidateQueries({ queryKey: ["glossary-terms"] });
      toast.success(isAr ? "تم الحفظ" : "Saved");
      if (isNew) navigate(created?.id ? `/glossary-term?id=${created.id}` : "/encyclopedia", { replace: true });
      else navigate(`/glossary-term?id=${termId}`);
    },
  });

  const isStory = (form?.entry_type || term?.entry_type) === "story";
  const goBack = () => (isNew ? navigate(-1) : navigate(`/glossary-term?id=${termId}`));

  const Field = ({ label, children }) => (
    <div className="space-y-1">
      <p className="text-[11px] font-body font-medium text-[#2E7D32]">{label}</p>
      {children}
    </div>
  );

  return (
    <div className="page-top pb-20 px-5 max-w-2xl mx-auto space-y-5">
      {/* Back */}
      <button
        onClick={goBack}
        className="flex items-center gap-1.5 text-sm font-body text-muted-foreground hover:text-foreground transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        {isStory ? (isAr ? "القصة" : "Story") : (isAr ? "المصطلح" : "Term")}
      </button>

      {/* رأس الصفحة — بأسلوب صفحة القصة: إنجليزي ذهبي وعربي وردي */}
      <div className="bg-white dark:bg-transparent px-5 py-4" style={{ borderRadius: 0, border: "1px solid var(--brand)" }}>
        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.1rem", fontWeight: 700, color: "#2E7D32", lineHeight: 1.2 }}>
          {isStory ? "Edit Story" : "Edit Entry"}
        </div>
        <div dir="rtl" style={{ fontFamily: "'Amiri', serif", fontSize: "1.05rem", fontWeight: 700, color: "#9D174D", lineHeight: 1.4, marginTop: 2 }}>
          {isStory ? "تعديل القصة" : "تعديل المدخل"}
        </div>
      </div>

      {!term && (
        <p className="text-center text-sm font-body text-muted-foreground pt-8">
          {isAr ? "المدخل غير موجود" : "Entry not found"}
        </p>
      )}

      {(isNew || term) && form && (
        <div className="bg-white dark:bg-transparent px-5 py-5 space-y-4" style={{ borderRadius: 0, border: "1px solid var(--brand)" }}>
          {isNew && (
            <div className="flex gap-2">
              {[["term", isAr ? "مصطلح" : "Term"], ["story", isAr ? "قصة" : "Story"]].map(([v, label]) => (
                <button key={v} type="button" onClick={() => setForm((f) => ({ ...f, entry_type: v }))}
                  className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${form.entry_type === v ? "bg-[var(--brand)] text-white" : "bg-secondary text-muted-foreground"}`}>
                  {label}
                </button>
              ))}
            </div>
          )}
          <Field label={isAr ? "العنوان (إنجليزي)" : "Title (EN)"}>
            <Input
              value={form.term_en}
              onChange={(e) => setForm((f) => ({ ...f, term_en: e.target.value }))}
              className="rounded-none font-body text-sm"
              dir="auto"
            />
          </Field>
          <Field label={isAr ? "العنوان (عربي)" : "Title (AR)"}>
            <Input
              value={form.term_ar}
              onChange={(e) => setForm((f) => ({ ...f, term_ar: e.target.value }))}
              className="rounded-none font-body text-sm"
              dir="auto"
            />
          </Field>
          <Field label={isStory ? (isAr ? "القصة (إنجليزي)" : "Story (English)") : (isAr ? "المعنى (إنجليزي)" : "Meaning (English)")}>
            <Textarea
              value={form.meaning}
              onChange={(e) => setForm((f) => ({ ...f, meaning: e.target.value }))}
              className="rounded-none font-body text-sm min-h-[180px]"
              dir="ltr"
            />
          </Field>
          <Field label={isStory ? (isAr ? "القصة (عربي)" : "Story (Arabic)") : (isAr ? "المعنى (عربي)" : "Meaning (Arabic)")}>
            <Textarea
              value={form.meaning_ar}
              onChange={(e) => setForm((f) => ({ ...f, meaning_ar: e.target.value }))}
              className="rounded-none font-body text-sm min-h-[180px] text-right"
              dir="rtl"
            />
          </Field>
          {isStory && (
            <Field label={isAr ? "ترجمة عربية إضافية" : "Extra Arabic Translation"}>
              <Textarea
                value={form.meaning_extraar}
                onChange={(e) => setForm((f) => ({ ...f, meaning_extraar: e.target.value }))}
                className="rounded-none font-body text-sm min-h-[180px] text-right"
                dir="rtl"
              />
            </Field>
          )}
          <Field label={isAr ? "وسوم (مفصولة بفاصلة)" : "Tags (comma-separated)"}>
            <Input
              value={form.tags}
              onChange={(e) => setForm((f) => ({ ...f, tags: e.target.value }))}
              className="rounded-none font-body text-sm"
              dir="auto"
            />
          </Field>
          <Field label={isAr ? "صورة" : "Image"}>
            <div className="flex items-center gap-2 flex-wrap">
              {form.image_url ? (
                <div className="relative">
                  <img
                    src={form.image_url}
                    alt=""
                    className="w-16 h-16 object-cover rounded-none border border-border"
                  />
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, image_url: "" }))}
                    className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-rose-500 text-white rounded-none flex items-center justify-center"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <span className="text-muted-foreground text-[11px] font-body flex items-center gap-1">
                  <ImageIcon className="w-3.5 h-3.5" />
                  {isAr ? "لا توجد صورة" : "No image"}
                </span>
              )}
              <ImageUploadButton onUploaded={(url) => setForm((f) => ({ ...f, image_url: url }))} />
            </div>
          </Field>

          <ImagesField value={form.images || []} onChange={(arr) => setForm((f) => ({ ...f, images: arr }))} />

          <div className="flex gap-2 pt-2">
            <Button
              className="flex-1 h-10 rounded-none"
              onClick={() => saveMutation.mutate(form)}
              disabled={saveMutation.isPending}
            >
              {saveMutation.isPending ? (isAr ? "جارٍ.." : "Saving..") : isAr ? "حفظ" : "Save"}
            </Button>
            <Button variant="outline" className="h-10 rounded-none" onClick={goBack}>
              {isAr ? "إلغاء" : "Cancel"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
