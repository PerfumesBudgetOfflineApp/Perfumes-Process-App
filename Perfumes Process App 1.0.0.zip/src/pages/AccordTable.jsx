import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

/**
 * AccordTable — «جدول الأكورد / The Accord Table».
 * صفحة معرفية تفاعلية لكلّ الأكوردات (اسم عربي/إنجليزي + معنى مطوّل + تكرار/ثقافي).
 * تقرأ public/seed/accord_table.json أوفلاين. بخطوط التطبيق Amiri + Cinzel وثيمة وردية.
 */
const ROSE = "#B76E79";
const ROSE_DEEP = "#a85d68";
const LINE = "#ead8d3";
const INK = "#15110c";
const MUTED = "#9a8d80";

export default function AccordTable() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [data, setData] = useState([]);
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(null);

  useEffect(() => {
    let alive = true;
    fetch(`${import.meta.env.BASE_URL || "/"}seed/accord_table.json`)
      .then((r) => r.json())
      .then((d) => { if (alive) setData(Array.isArray(d) ? d : []); })
      .catch(() => { if (alive) setData([]); });
    return () => { alive = false; };
  }, []);

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return data;
    return data.filter(
      (r) => (r.en || "").toLowerCase().includes(t) || (r.ar || "").includes(q.trim())
    );
  }, [q, data]);

  return (
    <div dir="rtl" className="px-4 page-top pb-16" style={{ color: INK }}>
      {/* الترويسة */}
      <div className="flex items-center gap-3 mb-5">
        <button
          onClick={() => navigate(-1)}
          className="w-8 h-8 flex items-center justify-center hover:bg-muted/40 shrink-0"
          dir="ltr"
          aria-label="back"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div className="flex-1 text-center">
          <h1 style={{ fontFamily: "'Amiri', serif", fontWeight: 700, fontSize: 34, lineHeight: 1.05, color: ROSE }}>
            جدول الأكورد
          </h1>
          <div style={{ fontFamily: "'Cinzel', serif", fontStyle: "italic", fontSize: 15, color: ROSE_DEEP, marginTop: 4 }}>
            The Accord Table
          </div>
        </div>
        <div className="w-8 shrink-0" />
      </div>

      {/* البحث */}
      <input name="AccordTable-1"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={isAr ? "ابحث عن أكورد" : "Search an accord"}
        style={{
          fontFamily: "'Amiri', serif", fontSize: 15, padding: "12px 18px", width: "100%",
          border: `1px solid ${LINE}`, background: "#fff", color: INK, textAlign: "center",
          outline: "none", borderRadius: 0, marginBottom: 18,
        }}
      />

      {/* القائمة */}
      <div className="flex flex-col">
        {filtered.map((r, i) => {
          const isOpen = open === i;
          const cnt =
            r.freq === null || r.freq === undefined
              ? isAr ? "أكورد ثقافي" : "Cultural accord"
              : `${r.freq} ${isAr ? "عطر" : "perfumes"}`;
          return (
            <div
              key={`${r.en}-${i}`}
              style={{ background: "#fff", borderBottom: `1px solid ${ROSE}`, borderRadius: 0, overflow: "hidden" }}
            >
              <div
                onClick={() => setOpen(isOpen ? null : i)}
                className="flex items-center gap-3 cursor-pointer"
                style={{ padding: "14px 16px" }}
              >
                <span style={{ width: 12, height: 12, flex: "none", background: r.bar || ROSE, border: `1px solid ${LINE}` }} />
                <span className="flex items-baseline gap-2 flex-wrap flex-1 min-w-0">
                  <span style={{ fontFamily: "'Amiri', serif", fontWeight: 700, fontSize: 21, color: ROSE }}>{r.ar || ""}</span>
                  <span style={{ fontFamily: "'Cinzel', serif", fontStyle: "italic", fontSize: 15, color: ROSE_DEEP, textTransform: "capitalize" }}>{r.en}</span>
                </span>
              </div>
              {isOpen && (
                <div style={{ padding: "4px 18px 18px", borderTop: `1px solid ${LINE}` }}>
                  {r.meaning_ar && (
                    <div dir="rtl" style={{ fontFamily: "'Amiri', serif", fontSize: 15.5, color: "#3c3022", lineHeight: 1.95, marginTop: 12 }}>
                      {r.meaning_ar}
                    </div>
                  )}
                  {r.meaning_en && (
                    <div style={{ fontFamily: "'Cinzel', serif", fontSize: 14.5, color: "#564730", lineHeight: 1.7, direction: "ltr", textAlign: "left", marginTop: 10 }}>
                      {r.meaning_en}
                    </div>
                  )}
                  <span style={{ display: "block", marginTop: 12, fontFamily: "'Cinzel', serif", fontSize: 13, color: r.cultural ? ROSE_DEEP : MUTED, fontStyle: r.cultural ? "italic" : "normal" }}>
                    {cnt}
                  </span>
                </div>
              )}
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="text-center text-sm font-body py-8" style={{ color: MUTED }}>
            {isAr ? "لا نتائج" : "No results"}
          </div>
        )}
      </div>
    </div>
  );
}
