import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { exportSingleTerm, exportSingleTermImage } from "@/lib/glossaryExport";
import { toast } from "sonner";
import UserContentControls from "@/components/shared/UserContentControls";
import InteractionBar from "@/components/shared/InteractionBar";
import ZoomableImage from "@/components/shared/ZoomableImage";
import StoryFooter from "@/components/shared/StoryFooter";
import ExportOptionsDialog from "@/components/export/ExportOptionsDialog";
import { useReadingPrefs } from "@/lib/useReadingPrefs";
import GlosseryExplain from "@/components/shared/GlosseryExplain";
import { compareGlossary } from "@/lib/sortName";

/**
 * GlossaryTermDetail
 *
 * Renders two styles:
 *  - term: compact dictionary entry
 *  - story: literary bedtime-reading layout (large serif, indents, sections by ---)
 *
 * User interactions (UserGlossaryTerm):
 *   - reaction: like / dislike / wtf / favorite / none
 *   - thought: optional free-text the user writes about the term/story
 */
export default function GlossaryTermDetail() {
  const navigate = useNavigate();
  const location = useLocation();
  const cameFromActivities = location.state?.from === "activities";
  const cameFromTimelines = location.state?.from === "timelines";
  const backTo = location.state?.backTo || null;
  const qc = useQueryClient();
  const { isAr } = useLang();
  const [thoughtOpen, setThoughtOpen] = useState(false);
  const [thoughtDraft, setThoughtDraft] = useState("");
  const { lang: readingLangRaw, fontScale } = useReadingPrefs(); // 'ar' | 'en' | 'both' | 'extra'
  // المصطلحات لا ترجمة إضافية لها — نمط «عربي إضافي» يعامَل كالعربية خارج القصص
  const readingLang = readingLangRaw;
  const params = new URLSearchParams(window.location.search);
  const termId = params.get("id");

  const { data: terms = [] } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
  });

  const { data: userReactions = [] } = useQuery({
    queryKey: ["user-glossary-terms"],
    queryFn: () => apphost.entities.UserGlossaryTerm.list("-created_date"),
  });

  const term = terms.find((t) => String(t.id) === String(termId));
  const myReaction = userReactions.find((r) => r.term_id === termId);

  const reactMutation = useMutation({
    mutationFn: async ({ reaction }) => {
      if (myReaction) {
        if (myReaction.reaction === reaction) {
          return apphost.entities.UserGlossaryTerm.update(myReaction.id, { reaction: "none" });
        }
        return apphost.entities.UserGlossaryTerm.update(myReaction.id, { reaction });
      }
      return apphost.entities.UserGlossaryTerm.create({
        term_id: termId,
        term_en: term?.term_en || "",
        term_ar: term?.term_ar || "",
        reaction,
      });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-glossary-terms"] }),
  });

  const readStatusMutation = useMutation({
    mutationFn: async ({ status }) => {
      if (myReaction) {
        if (myReaction.read_status === status) {
          return apphost.entities.UserGlossaryTerm.update(myReaction.id, { read_status: "none" });
        }
        return apphost.entities.UserGlossaryTerm.update(myReaction.id, { read_status: status });
      }
      return apphost.entities.UserGlossaryTerm.create({
        term_id: termId,
        term_en: term?.term_en || "",
        term_ar: term?.term_ar || "",
        read_status: status,
      });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-glossary-terms"] }),
  });

  const thoughtMutation = useMutation({
    mutationFn: async ({ newThought }) => {
      if (myReaction) {
        return apphost.entities.UserGlossaryTerm.update(myReaction.id, { thought: newThought });
      }
      return apphost.entities.UserGlossaryTerm.create({
        term_id: termId,
        term_en: term?.term_en || "",
        term_ar: term?.term_ar || "",
        thought: newThought,
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["user-glossary-terms"] });
      setThoughtOpen(false);
      toast.success(isAr ? "تم حفظ الخاطرة" : "Thought saved");
    },
  });

  const openThoughtEditor = () => {
    setThoughtDraft(myReaction?.thought || "");
    setThoughtOpen(true);
  };

  // ── Edit / delete / hide the glossary entry itself ──
  const editMutation = useMutation({
    mutationFn: async (fields) => {
      const clean = {};
      ["term_en", "term_ar", "meaning", "meaning_ar", "meaning_extraar", "tags", "image_url", "entry_type"].forEach((k) => {
        if (fields[k] !== undefined) clean[k] = fields[k];
      });
      return apphost.entities.GlossaryTerm.update(term.id, clean);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["glossary-terms"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      // User-created entries are deleted outright; built-in entries are
      // flagged hidden so a re-seed can restore them and nothing breaks.
      if (term.is_user) {
        return apphost.entities.GlossaryTerm.delete(term.id);
      }
      return apphost.entities.GlossaryTerm.update(term.id, { hidden: true });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["glossary-terms"] });
      navigate("/encyclopedia");
    },
  });

  if (!termId) {
    navigate("/encyclopedia");
    return null;
  }

  if (terms.length > 0 && !term) {
    return (
      <div className="px-4 page-top pb-20 text-center">
        <p className="text-muted-foreground font-body">
          {isAr ? "غير موجود." : "Term not found."}
        </p>
        <button
          onClick={() => navigate("/encyclopedia")}
          className="text-primary text-sm mt-2 font-body underline"
        >
          {isAr ? "العودة" : "Back"}
        </button>
      </div>
    );
  }

  const entryType = term?.entry_type || "term";
  const isStory = entryType === "story";
  const currentReaction = myReaction?.reaction || "none";

  // All stories, sorted the same way the Stories tab shows them (English
  // alphabetical for both languages) so the footer's Previous / Next walks them
  // in the listed order.
  const sortedStories = terms
    .filter((t) => t.entry_type === "story")
    .sort((a, b) => compareGlossary(a, b, 1));

  const sortedTerms = terms
    .filter((t) => (t.entry_type || "term") === "term")
    .sort((a, b) => compareGlossary(a, b, 1));

  // For stories: render the meaning as book-like text with section breaks
  const renderStoryBody = (text) => {
    if (!text) return null;
    // Split by --- (used as section dividers) or by blank lines
    const sections = text.split(/\n\s*---+\s*\n/);
    // Strip the section header markers — we enter each language directly
    // without "English Version 🇬🇧" / "النسخة العربية 🇸🇦" labels.
    const SECTION_MARKERS = [
      /^\s*English Version[\s🇬🇧]*\s*$/im,
      /^\s*النسخة العربية[\s🇸🇦]*\s*$/im,
    ];
    return sections.map((section, sIdx) => {
      // Drop the first paragraph of each section if it is just a language marker.
      let body = section;
      for (const marker of SECTION_MARKERS) {
        body = body.replace(marker, "");
      }
      const paragraphs = body
        .split(/\n\s*\n/)
        .map((p) => p.trim())
        .filter(Boolean);
      if (paragraphs.length === 0) return null;
      return (
        <div key={sIdx}>
          {paragraphs.map((para, pIdx) => {
            const sp = para.indexOf(" ");
            const firstWord = sp > 0 ? para.slice(0, sp) : para;
            const rest = sp > 0 ? para.slice(sp) : "";
            return (
              <p
                key={pIdx}
                className="font-body leading-loose mb-5"
                style={{
                  fontFamily: "'Cormorant Garamond', 'Amiri', Georgia, serif",
                  fontSize: `${(16 * fontScale).toFixed(1)}px`,
                  color: "#1c1917",
                  textAlign: "justify",
                  wordSpacing: "0.05em",
                }}
                dir="auto"
              >
                <span style={{ color: "#9D174D", fontWeight: 700 }}>{firstWord}</span>{rest}
              </p>
            );
          })}
        </div>
      );
    });
  };

  return (
    <div
      className={`page-top pb-20 space-y-6 ${
        isStory ? "px-6 max-w-2xl mx-auto" : "px-4 max-w-lg mx-auto"
      }`}
    >
      {/* Back */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => {
            // يحترم آخر صفحة زرتها: إن جئت من خطّ في /timelines يرجعك لذات
            // الخطّ بحالته (backTo)؛ وإلا navigate(-1)؛ وإلا تبويب المعجم المناسب.
            if (backTo) navigate(backTo);
            else if (typeof window !== "undefined" && window.history.length > 1) navigate(-1);
            else if (cameFromActivities) navigate("/");
            else navigate("/encyclopedia");
          }}
          className="flex items-center gap-1.5 text-sm font-body text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          {cameFromTimelines ? (isAr ? "الخطّ الزمنيّ" : "Timeline") : cameFromActivities ? (isAr ? "النشاطات" : "Activities") : (isStory ? (isAr ? "القصص" : "Stories") : (isAr ? "المعجم" : "Glossary"))}
        </button>
      </div>

      {term && (
        <>
          {/* ═══ STORY MODE ═══ */}
          {isStory ? (
            <div className="space-y-6">
              {/* رأس القصة: مبدّل اللغة أعلى الصفحة قبل العنوان، ثمّ عنوان ثنائي مصغّر بلا مائل */}
              {(() => {
                const hasArField = !!(term.meaning_ar && term.meaning_ar.trim());
                const hasEnField = !!(term.meaning && term.meaning.trim());
                const bothLangs = hasEnField && hasArField;
                return (
                  <div className="space-y-2">
                    {/* جدول العنوان — صندوق ذهبي بخلفية بيضاء، اللغتان أعلى اليسار */}
                    <div className="bg-white dark:bg-transparent px-5 py-4" dir="ltr" style={{ borderRadius: 0, border: "none", textAlign: "left" }}>
                      {term.term_en && (
                        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.3rem", fontWeight: 700, color: "#2E7D32", lineHeight: 1.2 }}>
                          {term.term_en}
                        </div>
                      )}
                      {term.term_ar && (
                        <div style={{ fontFamily: "'Amiri', serif", fontSize: "1.25rem", fontWeight: 700, color: "#9D174D", lineHeight: 1.4, marginTop: 2 }}>
                          {term.term_ar}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* Story body — الأنماط: عربي / English / AR EN / عربي إضافي / AR AR / AR AR EN (افتراضي) */}
              {(() => {
                const hasArField = !!(term.meaning_ar && term.meaning_ar.trim());
                const hasEnField = !!(term.meaning && term.meaning.trim());
                // العنصر النائب «لا يوجد نص no text» (سجلات قديمة زرعت قبل التطبيع) = لا ترجمة — يخفى القسم شرطيا
                const extraRaw = String(term.meaning_extraar || "").trim();
                const extraArText = extraRaw === "لا يوجد نص no text" ? "" : extraRaw;
                const legacyCombined =
                  term.meaning && !hasArField && /[\u0600-\u06FF]/.test(term.meaning);
                if (legacyCombined) {
                  return <article className="space-y-2">{renderStoryBody(term.meaning)}</article>;
                }
                const lang = readingLang;
                // نمط «عربي إضافي»: الترجمة الإضافية وحدها — وإن لم تُجهَّز بعد يُعرض الأساسي كي لا تفرغ الصفحة.
                if (lang === "extra") {
                  return (
                    <article className="space-y-2" dir="rtl">
                      {renderStoryBody(extraArText || term.meaning_ar || term.meaning)}
                      {(term.image_url_ar || term.image_url) && (
                        <ZoomableImage src={term.image_url_ar || term.image_url} alt={term.term_ar} caption={term.image_caption || ""} />
                      )}
                    </article>
                  );
                }
                const showMainAr = (lang === "ar" || lang === "both" || lang === "ar-extra" || lang === "ar-extra-en") && hasArField;
                const showExtra = (lang === "ar-extra" || lang === "ar-extra-en") && !!extraArText;
                const showEn = (lang === "en" || lang === "both" || lang === "ar-extra-en") && hasEnField;
                // إن لم تتوفّر العربية الأساسية لكن المطلوب عربي، اعرض ما هو متاح
                if (!showMainAr && !showEn && !showExtra) {
                  return <article className="space-y-2" dir={hasArField ? "rtl" : undefined}>{hasArField ? renderStoryBody(term.meaning_ar) : renderStoryBody(term.meaning)}</article>;
                }
                return (
                  <>
                    {showMainAr && (
                      <article className="space-y-2" dir="rtl">
                        {renderStoryBody(term.meaning_ar)}
                        {(term.image_url_ar || (lang === "ar" && term.image_url)) && (
                          <ZoomableImage src={term.image_url_ar || term.image_url} alt={term.term_ar} caption={term.image_caption || ""} />
                        )}
                      </article>
                    )}
                    {showExtra && (
                      <article className="space-y-2" dir="rtl">
                        <div className="pt-2" style={{ borderTop: "1px solid rgba(200,160,46,0.35)" }}>
                          <span style={{ fontFamily: "'Amiri', serif", fontSize: "0.8rem", fontWeight: 700, color: "#9D174D" }}>ترجمة إضافية</span>
                        </div>
                        {renderStoryBody(extraArText)}
                      </article>
                    )}
                    {showEn && <div className="my-8" />}
                    {showEn && (
                      <article className="space-y-2">
                        {renderStoryBody(term.meaning)}
                        {(term.image_url_en || (lang === "en" && term.image_url)) && (
                          <ZoomableImage src={term.image_url_en || term.image_url} alt={term.term_en} caption={term.image_caption || ""} />
                        )}
                      </article>
                    )}
                  </>
                );
              })()}

              {/* شرح و إشارات — بعد متن القصة مباشرة (مواصفة A) */}
              <GlosseryExplain entry={term} showAr={readingLang !== "en"} showEn={readingLang === "en" || readingLang === "both" || readingLang === "ar-extra-en"} />

              {/* Image — تظهر فقط إذا لم تُعرض صور خاصة باللغة أعلاه */}
              {term.image_url && !term.image_url_en && !term.image_url_ar && (
                <ZoomableImage
                  src={term.image_url}
                  alt={term.term_en}
                  caption={term.image_caption || ""}
                />
              )}

              {/* Tags moved below — they now sit above the prev/next navigation */}

              {/* End spacing — clean, no decorative dingbat */}
              <div className="pt-4" />
            </div>
          ) : (
            /* ═══ TERM MODE (original layout) ═══ */
            <>
              <div
                className="bg-white dark:bg-transparent px-5 py-5 space-y-3"
                style={{ borderRadius: 0, border: "none" }}
              >
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  {term.term_en && (
                    <span style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.05rem", fontWeight: 700, color: "#2E7D32", letterSpacing: "0.02em" }}>
                      {term.term_en}
                    </span>
                  )}
                  {term.term_ar && (
                    <span className="text-base" dir="rtl" style={{ fontFamily: "'Amiri', serif", fontWeight: 700, color: "#9D174D" }}>
                      {term.term_ar}
                    </span>
                  )}
                </div>
                <div style={{ height: 1, background: "linear-gradient(90deg, transparent, var(--brand), transparent)" }} />

              {(() => {
                const hasArField = !!(term.meaning_ar && term.meaning_ar.trim());
                const hasEnField = !!(term.meaning && term.meaning.trim());
                const bothLangs = hasEnField && hasArField;
                const lang = readingLang === "extra" || readingLang === "ar-extra" ? "ar"
                           : readingLang === "ar-extra-en" ? "both"
                           : readingLang;
                const para = (text, dir) => (
                  <p className="font-body text-foreground/80 leading-relaxed pt-1" dir={dir} style={{ fontSize: `${(13 * fontScale).toFixed(1)}px`, ...(dir === "rtl" ? { textAlign: "right" } : {}) }}>
                    {text}
                  </p>
                );
                if (!bothLangs) {
                  const m = hasArField ? term.meaning_ar : term.meaning;
                  return m ? para(m, hasArField ? "rtl" : "ltr") : null;
                }
                return (
                  <>
                    {(lang === "ar" || lang === "both") && para(term.meaning_ar, "rtl")}
                    {lang === "both" && <div className="my-4" />}
                    {(lang === "en" || lang === "both") && para(term.meaning, "ltr")}
                  </>
                );
              })()}

              {/* شرح و إشارات — بعد متن المفردة مباشرة (مواصفة A) */}
              <GlosseryExplain entry={term} showAr={readingLang !== "en"} showEn={readingLang === "en" || readingLang === "both" || readingLang === "ar-extra-en"} />

              {term.image_url && (
                <ZoomableImage
                  src={term.image_url}
                  alt={term.term_en}
                  caption={term.image_caption || ""}
                />
              )}

              {Array.isArray(term.images) && term.images.length > 0 && (
                <div className="flex flex-wrap gap-2 pt-2">
                  {term.images.map((url, i) => (
                    <img key={i} src={url} alt="" className="h-20 w-20 object-cover rounded-lg" />
                  ))}
                </div>
              )}

              {/* Tags moved below — they now sit above the prev/next navigation */}
              </div>
            </>
          )}

          {/* Unified interaction bar: reactions + notebook (single row, no WTF) */}
          <InteractionBar
            reaction={currentReaction}
            hasThought={!!myReaction?.thought}
            showWtf={true}
            center={true}
            showReadStatus={true}
            readStatus={myReaction?.read_status || "none"}
            onReadStatus={(status) => readStatusMutation.mutate({ status })}
            onReact={(kind) => reactMutation.mutate({ reaction: kind })}
            onThought={openThoughtEditor}
            bookmark={{
              item_type: isStory ? "story" : "glossary",
              item_id: termId,
              title_en: term.term_en || "",
              title_ar: term.term_ar || "",
              subtitle: isStory ? (isAr ? "قصة" : "Story") : (isAr ? "مصطلح" : "Term"),
              path: `/glossary-term?id=${termId}`,
            }}
          />

          {/* قائمة واحدة مطويّة: التصدير والإعداد — لغة + خطّ + خيارات + لون + أزرار التصدير + التعديل */}
          <div className="flex justify-center pt-1">
            <ExportOptionsDialog userMarkAvailable={true} showReading accent={isStory ? "amber" : "emerald"}>
              <div className="space-y-4 pt-2 border-t border-border/30">
                <StoryFooter
                  term={term}
                  showNav={false}
                  topBorder={false}
                  accentColor={isStory ? "amber" : "emerald"}
                  onExportPdf={(lang) => exportSingleTerm(term, myReaction, { lang: lang || "both" })}
                  onExportImg={(lang) => exportSingleTermImage(term, { lang: lang || "both" })}
                />
                <UserContentControls
                  kind="glossary"
                  entry={term}
                  isUser={!!term.is_user}
                  onSave={(fields) => editMutation.mutateAsync(fields)}
                  onDelete={() => deleteMutation.mutateAsync()}
                />
              </div>
            </ExportOptionsDialog>
          </div>

          {/* Existing thought display */}
          {myReaction?.thought && (
            <div className="p-3 mt-1 space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                {isAr ? "فكرتي" : "My thought"}
              </p>
              <p className="text-sm font-body" dir="auto">
                {myReaction.thought}
              </p>
              <button
                onClick={openThoughtEditor}
                className="text-[10px] text-muted-foreground hover:underline font-body"
              >
                {isAr ? "تعديل" : "Edit"}
              </button>
            </div>
          )}

          {/* Navigation — moved to the very bottom of the page. Hashtags sit above prev/next, using the page color. */}
          <StoryFooter
            term={term}
            stories={isStory ? sortedStories : sortedTerms}
            showActions={false}
            tags={term.tags || ""}
            accentColor={isStory ? "amber" : "emerald"}
          />
        </>
      )}

      {!term && (
        <div className="flex items-center justify-center py-20">
          <div className="w-6 h-6 border-2 border-emerald-300 border-t-emerald-600 rounded-full animate-spin" />
        </div>
      )}

      {/* Thought editor — works for both terms and stories */}
      <Dialog open={thoughtOpen} onOpenChange={setThoughtOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {isAr ? "أضف فكرتك" : "Add your thought"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Textarea
              value={thoughtDraft}
              onChange={(e) => setThoughtDraft(e.target.value)}
              placeholder={isAr ? "ماذا تفكر بهذا؟" : "What do you think about this?"}
              className="rounded-none font-body text-xs min-h-[110px] resize-none"
              dir="auto"
            />
            <div className="flex gap-2">
              <Button
                className="flex-1 h-10 rounded-none"
                onClick={() => thoughtMutation.mutate({ newThought: thoughtDraft.trim() })}
                disabled={thoughtMutation.isPending}
              >
                {thoughtMutation.isPending
                  ? isAr ? "جارٍ.." : "Saving.."
                  : isAr ? "حفظ" : "Save"}
              </Button>
              {myReaction?.thought && (
                <Button
                  variant="outline"
                  className="h-10 rounded-none"
                  onClick={() => thoughtMutation.mutate({ newThought: "" })}
                >
                  {isAr ? "حذف" : "Delete"}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
