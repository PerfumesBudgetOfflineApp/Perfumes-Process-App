import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link, useSearchParams } from "react-router-dom";
import { Search, ChevronRight, ChevronLeft } from "lucide-react";
import BackButton from "@/components/shared/BackButton";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { Input } from "@/components/ui/input";
import { useLang } from "@/lib/LanguageContext";
import { LINES, LINE_AR, LINE_EN, lineOf, extractYear, WORLD_LINE, isWorldTime } from "@/lib/storyLines";
import WORLD_CHRONO_STATIC from "@/data/builtin_database/world_time_chronology.json";
import WESTEROS from "@/data/builtin_database/westeros_plot_timeline.json";
import NATURE from "@/data/builtin_database/nature_scientists_timeline.json";
import SCIENCE from "@/data/builtin_database/category_timelines/science_timeline.json";
import MYTHOLOGY from "@/data/builtin_database/mythology_timeline.json";
import US_TIMELINE from "@/data/builtin_database/us_timeline.json";
import LEADERS from "@/data/builtin_database/leaders_timeline.json";
import ARABIA from "@/data/builtin_database/arabia_timeline.json";
import CAT_WARS from "@/data/builtin_database/category_timelines/wars_timeline.json";
import CAT_CIVIL from "@/data/builtin_database/category_timelines/civilizations_timeline.json";
import CAT_TV from "@/data/builtin_database/category_timelines/television_timeline.json";
import CAT_POETS from "@/data/builtin_database/category_timelines/poets_timeline.json";
import CAT_SPORTS from "@/data/builtin_database/category_timelines/sports_timeline.json";
import CAT_CINEMA from "@/data/builtin_database/category_timelines/cinema_timeline.json";
import CAT_WOMEN from "@/data/builtin_database/category_timelines/women_timeline.json";
import CAT_MONEY from "@/data/builtin_database/category_timelines/money_timeline.json";
import CAT_ARCH from "@/data/builtin_database/category_timelines/architecture_timeline.json";
import CAT_PHILPSY from "@/data/builtin_database/category_timelines/philosophy_psychology_timeline.json";
import CAT_ARTMUSIC from "@/data/builtin_database/category_timelines/art_music_timeline.json";

const NATURE_LINE = "__nature__";
const MYTH_LINE = "__mythology__";
const US_LINE = "__united_states__";
const LEADERS_LINE = "__leaders__";
const ARABIA_LINE = "__arabia__";

// خطوط التصنيفات المؤرّخة — كل خط قد يجمع أكثر من ملف (datas) مدموجةً بلا تكرار
// و مرتّبةً بالسنة. الدمج بطلب A: الحروب+الحضارات؛ شعر+تلفاز+سينما+فن+موسيقى؛
// المال+العمارة. الرياضة و النساء و فلسفة-علم نفس تبقى كلٌّ خطّا واحدا.
const CATEGORY_LINES = [
  { key: "__cat_wars_civ__", datas: [CAT_WARS, CAT_CIVIL], ar: "الحروب و الحضارات", en: "Wars & Civilizations" },
  { key: "__cat_arts__", datas: [CAT_POETS, CAT_TV, CAT_CINEMA, CAT_ARTMUSIC], ar: "شعر.. تلفاز.. سينما.. فن.. موسيقى", en: "Poetry.. Television.. Cinema.. Art.. Music" },
  { key: "__cat_sports__", datas: [CAT_SPORTS], ar: "الرياضة", en: "Sport" },
  { key: "__cat_women__", datas: [CAT_WOMEN], ar: "النساء", en: "Women" },
  { key: "__cat_money_arch__", datas: [CAT_MONEY, CAT_ARCH], ar: "مال.. أعمال.. فن معماري", en: "Money.. Business.. Architecture" },
  { key: "__cat_philpsy__", datas: [CAT_PHILPSY], ar: "فلسفة و علم نفس", en: "Philosophy & Psychology" },
];

// يستخرج المصفوفة من ملف خط زمني سواء كان مصفوفة مباشرة أو غلافا {entries:[]}
const asEntries = (x) => (Array.isArray(x) ? x : (x && Array.isArray(x.entries) ? x.entries : []));

// دمج عدّة ملفات في مصفوفة واحدة بلا تكرار (بالعنوان الإنجليزي) مرتّبة بالسنة.
function mergeByTitle(datas) {
  const seen = new Set();
  const out = [];
  for (const d of datas) {
    for (const e of asEntries(d)) {
      const k = String(e.title_en || "").trim();
      if (k && seen.has(k)) continue;
      if (k) seen.add(k);
      out.push(e);
    }
  }
  return out.sort((a, b) => (a.year ?? 0) - (b.year ?? 0));
}

// تنسيق السنة (قاعدة A): أقدم من ٦٠٠٠ ق.م ← «التاريخ البعيد» / «The Distant Past».
function fmtYear(y, isAr) {
  if (y == null || y === "") return "";
  const n = typeof y === "number" ? y : parseInt(y, 10);
  if (!Number.isFinite(n)) return "";
  if (n < -6000) return isAr ? "التاريخ البعيد" : "The Distant Past";
  if (n < 0) return `${-n}${isAr ? " ق.م" : " BC"}`;
  if (n >= 2040) return isAr ? `${n} افتراضي` : `${n} notional`;
  return String(n);
}

// يبني خريطة (العنوان الإنجليزي → السنة) من مصفوفة الخطوط الزمنية.
function buildCuratedYear(arr) {
  const m = {};
  (arr || []).forEach((e) => {
    const k = String(e.title_en || "").trim();
    const y = parseInt(e.year, 10);
    if (k && Number.isFinite(y)) m[k] = y;
  });
  return m;
}
import { compareGlossary } from "@/lib/sortName";

const GOLD = "var(--brand)";

/**
 * مصنفات / Classification (/timelines)
 *
 * — تصانيف بعد خانة البحث؛ كلّ تصنيف يفتح خطّه الزمنيّ الخاصّ (لا «الكل»).
 * — الترتيب (طلب A): زمن المعمورة، الولايات المتحدة، الميثولوجيا (و فيها عالم
 *   ويستروس أولا ثم الإغريق ثم الروم)، ثم مجالات المعجم، ثم خطوط التصنيفات
 *   المدموجة، ثم قادة العالم (قبل الأخير) ثم طبيعة و علماء (الأخير).
 * — الأسهم أُزيلت من قائمة التصانيف؛ تبقى العناوين فقط.
 * — الرجوع من قصّة يعيدك لذات صفحة الخطّ (state.backTo) لا لصفحة المعجم.
 */
export default function GlossaryTimelines() {
  const { isAr } = useLang();
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") === "term" ? "term" : "story";
  const line = params.get("line") || "";
  const query = params.get("q") || "";

  // رابط الرجوع: ذات صفحة الخطّ بحالتها (tab/line/q) — يُمرَّر لصفحة القصّة.
  const backTo = useMemo(() => {
    const qs = params.toString();
    return "/timelines" + (qs ? `?${qs}` : "");
  }, [params]);

  const { data: all = [], isLoading } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
    staleTime: Infinity,
    gcTime: Infinity,
  });

  // الخطوط الزمنية (السنوات المنسّقة) من كيان WorldTime القابل للتعديل في المايسترو،
  // مع الرجوع للملف الثابت إن كان المخزن فارغاً (قبل اكتمال الزرع).
  const { data: worldTimeDb = [] } = useQuery({
    queryKey: ["world-time"],
    queryFn: () => apphost.entities.WorldTime.list("-created_date"),
    staleTime: Infinity,
    gcTime: Infinity,
  });
  const curatedYear = useMemo(
    () => buildCuratedYear(worldTimeDb && worldTimeDb.length ? worldTimeDb : WORLD_CHRONO_STATIC),
    [worldTimeDb]
  );

  // تصنيف خفيف لكلّ سجلّ (مجال + هل هو قصّة) — بلا استخراج سنة هنا (مؤجّل).
  const classified = useMemo(
    () => all.map((r) => ({ rec: r, isStory: r.entry_type === "story", lineKey: lineOf(r), isWorld: isWorldTime(r) })),
    [all]
  );

  const pool = useMemo(
    () => classified.filter((c) => (tab === "story" ? c.isStory : !c.isStory)),
    [classified, tab]
  );

  // خريطة العنوان الإنجليزي → سجلّ القصّة (لربط مدخلات الخطوط المنسّقة).
  const recByTitleEn = useMemo(() => {
    const m = {};
    (all || []).forEach((r) => {
      if (r.entry_type !== "story") return;
      const k = String(r.term_en || "").trim();
      if (k && !(k in m)) m[k] = r;
    });
    return m;
  }, [all]);

  const attach = (arr) => arr.map((e) => ({ entry: e, rec: recByTitleEn[String(e.title_en || "").trim()] || null }));

  // عالم ويستروس مرتّبا بترتيب الحبكة (يُعرض داخل الميثولوجيا أولا).
  const westerosItems = useMemo(
    () => attach(asEntries(WESTEROS).slice().sort((a, b) => (a.order ?? 0) - (b.order ?? 0))),
    [recByTitleEn]
  );

  // «طبيعة وعلماء» = طبيعة + علم مدموجين بلا تكرار، مرتّبين تصاعديا بالسنة.
  const natureItems = useMemo(
    () => attach(mergeByTitle([NATURE, SCIENCE])),
    [recByTitleEn]
  );
  const hasNature = useMemo(() => natureItems.some((w) => w.rec), [natureItems]);

  // الميثولوجيا بترتيب الأجيال (order).
  const mythItems = useMemo(
    () => attach(asEntries(MYTHOLOGY).slice().sort((a, b) => (a.order ?? 0) - (b.order ?? 0))),
    [recByTitleEn]
  );
  // الميثولوجيا حاضرة إن كان فيها قصة أو في عالم ويستروس المدموج فيها.
  const hasMyth = useMemo(
    () => mythItems.some((w) => w.rec) || westerosItems.some((w) => w.rec),
    [mythItems, westerosItems]
  );

  // خط أمريكا مرتّبا بالترتيب.
  const usItems = useMemo(
    () => attach(asEntries(US_TIMELINE).slice().sort((a, b) => (a.order ?? 0) - (b.order ?? 0))),
    [recByTitleEn]
  );
  const hasUs = useMemo(() => usItems.some((w) => w.rec), [usItems]);

  // قادة العالم — خط زمنيّ موحّد (بلا تفريق مناطق)، مرتّب بالسنة.
  const leaderItems = useMemo(
    () => attach(asEntries(LEADERS).slice().sort((a, b) => (a.year ?? 0) - (b.year ?? 0))),
    [recByTitleEn]
  );
  const hasLeaders = useMemo(() => leaderItems.some((w) => w.rec), [leaderItems]);

  // الجزيرة العربية — خط زمنيّ مؤرّخ (نمط قادة العالم)، مرتّب بالسنة، بعد زمن المعمورة.
  const arabiaItems = useMemo(
    () => attach(asEntries(ARABIA).slice().sort((a, b) => (a.year ?? 0) - (b.year ?? 0))),
    [recByTitleEn]
  );
  const hasArabia = useMemo(() => arabiaItems.some((w) => w.rec), [arabiaItems]);

  // خطوط التصنيفات: لكل مفتاح عناصره المدموجة المرتّبة بالسنة + هل فيه قصة مطابقة
  const categoryData = useMemo(() => {
    const map = {};
    for (const c of CATEGORY_LINES) {
      const arr = attach(mergeByTitle(c.datas));
      map[c.key] = { items: arr, has: arr.some((w) => w.rec), ar: c.ar, en: c.en };
    }
    return map;
  }, [recByTitleEn]);

  // التصانيف الحاضرة في التبويب الحاليّ بترتيب A.
  const presentLines = useMemo(() => {
    const present = new Set(pool.map((c) => c.lineKey));
    const ordered = [];
    if (tab === "story") {
      // المسارات الأساسية في الأعلى
      if (pool.some((c) => c.isWorld)) ordered.push(WORLD_LINE);
      if (hasArabia) ordered.push(ARABIA_LINE);
      if (hasUs) ordered.push(US_LINE);
      if (hasMyth) ordered.push(MYTH_LINE);
    }
    // مجالات المعجم (بترتيب LINES) ثم «أخرى»
    for (const [k] of LINES) if (present.has(k)) ordered.push(k);
    if (present.has("other")) ordered.push("other");
    if (tab === "story") {
      // خطوط التصنيفات المدموجة في الذيل
      for (const c of CATEGORY_LINES) if (categoryData[c.key]?.has) ordered.push(c.key);
      // قادة العالم قبل الأخير، ثم طبيعة و علماء الأخير
      if (hasLeaders) ordered.push(LEADERS_LINE);
      if (hasNature) ordered.push(NATURE_LINE);
    }
    return ordered;
  }, [pool, tab, hasMyth, hasUs, hasArabia, hasLeaders, hasNature, categoryData]);

  const lineName = (k) => {
    if (k === NATURE_LINE) return isAr ? "طبيعة وعلماء" : "Nature and Scientists";
    if (k === MYTH_LINE) return isAr ? "الميثولوجيا" : "Mythology";
    if (k === US_LINE) return isAr ? "الولايات المتحدة" : "The United States";
    if (k === LEADERS_LINE) return isAr ? "قادة العالم" : "World Leaders";
    if (k === ARABIA_LINE) return isAr ? "الجزيرة العربية" : "The Arabian Peninsula";
    const cat = categoryData[k];
    if (cat) return isAr ? cat.ar : cat.en;
    return isAr ? (LINE_AR[k] || k) : (LINE_EN[k] || k);
  };

  const setUrl = (next, opts) => {
    const merged = { tab, line, q: query, ...next };
    const sp = {};
    if (merged.tab && merged.tab !== "story") sp.tab = merged.tab;
    if (merged.line) sp.line = merged.line;
    if (merged.q) sp.q = merged.q;
    setParams(sp, opts);
  };

  // عناصر التصنيف المفتوح + استخراج السنة (هنا فقط — كسول).
  const lineItems = useMemo(() => {
    if (!line) return [];
    const q = query.trim().toLowerCase();
    let arr = line === WORLD_LINE ? pool.filter((c) => c.isWorld) : pool.filter((c) => c.lineKey === line);
    if (q) arr = arr.filter((c) =>
      ((c.rec.term_ar || "") + " " + (c.rec.term_en || "")).toLowerCase().includes(q));
    return arr.map((c) => ({ ...c, year: tab === "story" ? (curatedYear[String(c.rec.term_en || "").trim()] ?? extractYear(c.rec.meaning || c.rec.meaning_ar || "")) : null }));
  }, [pool, line, query, tab]);

  // بحث على مستوى التصانيف: أيّ تصنيف فيه نتيجة مطابقة.
  const matchedLines = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return presentLines;
    const has = (rows) => rows.some((w) => ((w.entry.title_ar || "") + " " + (w.entry.title_en || "")).toLowerCase().includes(q));
    const matchedPool = pool.filter((c) => ((c.rec.term_ar || "") + " " + (c.rec.term_en || "")).toLowerCase().includes(q));
    const present = new Set(matchedPool.map((c) => c.lineKey));
    if (matchedPool.some((c) => c.isWorld)) present.add(WORLD_LINE);
    if (hasUs && has(usItems)) present.add(US_LINE);
    if (hasMyth && (has(mythItems) || has(westerosItems))) present.add(MYTH_LINE);
    if (hasLeaders && has(leaderItems)) present.add(LEADERS_LINE);
    if (hasArabia && has(arabiaItems)) present.add(ARABIA_LINE);
    if (hasNature && has(natureItems)) present.add(NATURE_LINE);
    for (const c of CATEGORY_LINES) {
      const cd = categoryData[c.key];
      if (cd?.has && has(cd.items)) present.add(c.key);
    }
    return presentLines.filter((k) => present.has(k));
  }, [pool, presentLines, query, hasUs, usItems, hasMyth, mythItems, westerosItems, hasArabia, arabiaItems, hasLeaders, leaderItems, hasNature, natureItems, categoryData]);

  // رابط قصّة يحمل حالة الرجوع لذات صفحة الخطّ.
  const storyLinkProps = (id) => ({ to: `/glossary-term?id=${id}`, state: { from: "timelines", backTo } });

  const TitleLink = ({ c }) => (
    <Link {...storyLinkProps(c.rec.id)} className="block hover:opacity-70 transition-opacity">
      <span className="font-body text-[15px] leading-snug text-foreground">
        {isAr ? (c.rec.term_ar || c.rec.term_en) : (c.rec.term_en || c.rec.term_ar)}
      </span>
      <span className="font-body text-[11px] text-muted-foreground ms-2">
        {isAr ? (c.rec.term_en || "") : (c.rec.term_ar || "")}
      </span>
    </Link>
  );

  // صفّ خطّ زمنيّ موحّد (سنة + عنوان) — يُعاد استعماله لكلّ المسارات و التصنيفات.
  const Row = ({ w, ri, label }) => (
    <div key={w.entry.idx ?? ri} className="relative py-1.5">
      <span className="absolute top-2 w-2 h-2 rotate-45" style={{ insetInlineStart: "-1.3rem", background: GOLD }} />
      {label != null && label !== "" && (
        <span className="font-body text-xs tabular-nums text-muted-foreground" dir="ltr">{label}</span>
      )}
      <div className="mt-0.5">
        {w.rec ? (
          <Link {...storyLinkProps(w.rec.id)} className="block hover:opacity-70 transition-opacity">
            <span className="font-body text-[15px] leading-snug text-foreground">{isAr ? (w.entry.title_ar || w.entry.title_en) : (w.entry.title_en || w.entry.title_ar)}</span>
          </Link>
        ) : (
          <span className="font-body text-[15px] leading-snug text-muted-foreground">{isAr ? (w.entry.title_ar || w.entry.title_en) : (w.entry.title_en || w.entry.title_ar)}</span>
        )}
      </div>
    </div>
  );

  const Lane = ({ rows, yearOf }) => (
    <div className="relative border-s ps-4 ms-1" style={{ borderColor: "rgba(200,160,46,0.45)" }}>
      {rows.map((w, ri) => <Row key={w.entry.idx ?? ri} w={w} ri={ri} label={yearOf(w)} />)}
    </div>
  );

  // خطّ زمنيّ للقصص داخل مجالات المعجم.
  const Timeline = ({ items }) => {
    const dated = items.filter((c) => c.year != null).sort((a, b) => a.year - b.year);
    const undated = items.filter((c) => c.year == null);
    return (
      <div>
        {dated.length > 0 && (
          <div className="relative border-s ps-4 ms-1" style={{ borderColor: "rgba(200,160,46,0.45)" }}>
            {dated.map((c) => (
              <div key={c.rec.id} className="relative py-1.5">
                <span className="absolute top-2 w-2 h-2 rotate-45"
                  style={{ insetInlineStart: "-1.3rem", background: GOLD }} />
                <span className="font-body text-xs tabular-nums text-muted-foreground" dir="ltr">{fmtYear(c.year, isAr)}</span>
                <div className="mt-0.5"><TitleLink c={c} /></div>
              </div>
            ))}
          </div>
        )}
        {undated.length > 0 && (
          <div className="mt-5">
            <p className="font-body text-[11px] text-muted-foreground mb-2">{isAr ? "بلا تاريخ محدّد" : "Undated"}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5">
              {undated.map((c) => <TitleLink key={c.rec.id} c={c} />)}
            </div>
          </div>
        )}
      </div>
    );
  };

  // قائمة المصطلحات داخل التصنيف — مرتّبة أبجدياً بالإنجليزية (بلا رؤوس أحرف).
  const AlphaList = ({ items }) => {
    const sorted = [...items].sort((a, b) => compareGlossary(a.rec, b.rec, 1));
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 ps-1">
        {sorted.map((c) => <TitleLink key={c.rec.id} c={c} />)}
      </div>
    );
  };

  // الميثولوجيا — عالم ويستروس أولا، ثم آلهة الإغريق، ثم آلهة الروم.
  const MythologyView = () => {
    const q = query.trim().toLowerCase();
    const m = (w) => !q || ((w.entry.title_ar || "") + " " + (w.entry.title_en || "")).toLowerCase().includes(q);
    const west = westerosItems.filter(m);
    const myth = mythItems.filter(m);
    const sections = [
      { ar: "عالم ويستروس", en: "World of Westeros", rows: west },
      { ar: "آلهة الإغريق", en: "Greek Gods", rows: myth.filter((w) => String(w.entry.branch_en || "").trim() === "Greek Gods") },
      { ar: "آلهة الروم", en: "Roman Gods", rows: myth.filter((w) => String(w.entry.branch_en || "").trim() === "Roman Gods") },
    ];
    return (
      <div className="space-y-5">
        {sections.map((s) => s.rows.length === 0 ? null : (
          <div key={s.en} className="space-y-1">
            <h3 className="font-body text-sm font-semibold" style={{ color: GOLD }} dir={isAr ? "rtl" : "ltr"}>{isAr ? s.ar : s.en}</h3>
            <Lane rows={s.rows} yearOf={(w) => (isAr ? (w.entry.era_ar || "") : (w.entry.era_en || ""))} />
          </div>
        ))}
      </div>
    );
  };

  const NatureView = () => {
    const q = query.trim().toLowerCase();
    const items = q ? natureItems.filter((w) => ((w.entry.title_ar || "") + " " + (w.entry.title_en || "")).toLowerCase().includes(q)) : natureItems;
    return <Lane rows={items} yearOf={(w) => fmtYear(w.entry.year, isAr)} />;
  };

  const USView = () => {
    const q = query.trim().toLowerCase();
    const items = q ? usItems.filter((w) => ((w.entry.title_ar || "") + " " + (w.entry.title_en || "")).toLowerCase().includes(q)) : usItems;
    return <Lane rows={items} yearOf={(w) => fmtYear(w.entry.year, isAr)} />;
  };

  // قادة العالم — خط زمنيّ موحّد بلا تفريق مناطق.
  const LeadersView = () => {
    const q = query.trim().toLowerCase();
    const items = q ? leaderItems.filter((w) => ((w.entry.title_ar || "") + " " + (w.entry.title_en || "")).toLowerCase().includes(q)) : leaderItems;
    return <Lane rows={items} yearOf={(w) => fmtYear(w.entry.year, isAr)} />;
  };

  // الجزيرة العربية — خط مؤرّخ بعد زمن المعمورة.
  const ArabiaView = () => {
    const q = query.trim().toLowerCase();
    const items = q ? arabiaItems.filter((w) => ((w.entry.title_ar || "") + " " + (w.entry.title_en || "")).toLowerCase().includes(q)) : arabiaItems;
    return <Lane rows={items} yearOf={(w) => fmtYear(w.entry.year, isAr)} />;
  };

  const CategoryView = ({ lineKey }) => {
    const cd = categoryData[lineKey];
    if (!cd) return null;
    const q = query.trim().toLowerCase();
    const items = q ? cd.items.filter((w) => ((w.entry.title_ar || "") + " " + (w.entry.title_en || "")).toLowerCase().includes(q)) : cd.items;
    return <Lane rows={items} yearOf={(w) => fmtYear(w.entry.year, isAr)} />;
  };

  const Chevron = isAr ? ChevronLeft : ChevronRight;

  return (
    <div className="px-5 page-top pb-24 space-y-4">
      {/* الترويسة */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/encyclopedia" />
        <h1 className="font-heading text-lg font-semibold" style={{ color: GOLD }}>
          {isAr ? "مصنفات" : "Classification"}
        </h1>
        <SettingsSheet>
          <UserAvatarButton size={28} />
        </SettingsSheet>
      </div>

      {/* تبويبان: قصص / مصطلحات */}
      <div className={`flex gap-4 ${isAr ? "flex-row-reverse" : ""}`}>
        {[["story", isAr ? "القصص" : "Stories"], ["term", isAr ? "المصطلحات" : "Terms"]].map(([m, label]) => (
          <button key={m}
            onClick={() => setUrl({ tab: m, line: "" }, { replace: true })}
            className="font-body text-sm py-1 hover:opacity-70 transition-opacity"
            style={{ color: GOLD, fontWeight: tab === m ? 700 : 500, opacity: tab === m ? 1 : 0.55 }}>
            {label}
          </button>
        ))}
      </div>

      {/* بحث — إطار شفّاف */}
      <div className="relative">
        <Search className={`absolute ${isAr ? "right-3" : "left-3"} top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none`} />
        <Input
          placeholder={isAr ? "ابحث" : "Search"}
          value={query}
          onChange={(e) => setUrl({ q: e.target.value }, { replace: true })}
          dir={isAr ? "rtl" : "ltr"}
          className="pl-10 pr-10 h-11 font-body bg-white border border-transparent rounded-none focus-visible:ring-0 focus-visible:ring-offset-0"
        />
      </div>

      {/* المحتوى */}
      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground font-body text-sm">{isAr ? "جارٍ التحميل…" : "Loading…"}</div>
      ) : line ? (
        <div className="space-y-3 pt-1">
          <button
            onClick={() => setUrl({ line: "" })}
            className="inline-flex items-center gap-1 font-body text-xs hover:opacity-70 transition-opacity"
            style={{ color: GOLD, fontWeight: 600 }}
          >
            <Chevron className="w-3.5 h-3.5 rotate-180" />
            {isAr ? "التصانيف" : "Categories"}
          </button>
          <h2 className="font-body text-base font-semibold" style={{ color: GOLD }}>{lineName(line)}</h2>
          {lineItems.length === 0 && line !== NATURE_LINE && line !== MYTH_LINE && line !== US_LINE && line !== LEADERS_LINE && line !== ARABIA_LINE && !categoryData[line] ? (
            <div className="text-center py-10 text-muted-foreground font-body text-sm">{isAr ? "لا مدخلات" : "No entries"}</div>
          ) : line === NATURE_LINE ? (
            <NatureView />
          ) : line === MYTH_LINE ? (
            <MythologyView />
          ) : line === US_LINE ? (
            <USView />
          ) : line === LEADERS_LINE ? (
            <LeadersView />
          ) : line === ARABIA_LINE ? (
            <ArabiaView />
          ) : categoryData[line] ? (
            <CategoryView lineKey={line} />
          ) : tab === "story" ? (
            <Timeline items={lineItems} />
          ) : (
            <AlphaList items={lineItems} />
          )}
        </div>
      ) : (
        /* قائمة التصانيف — عناوين فقط، بلا أسهم */
        <div className="flex flex-col pt-1">
          {matchedLines.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground font-body text-sm">{isAr ? "لا تصانيف" : "No categories"}</div>
          ) : (
            matchedLines.map((k) => (
              <button key={k}
                onClick={() => setUrl({ line: k })}
                className="flex items-center py-2 text-start hover:opacity-70 transition-opacity"
                style={{ color: GOLD }}
              >
                <span className="text-sm font-body font-semibold inline-flex items-center gap-2">
                  {(k === WORLD_LINE || k === NATURE_LINE || k === MYTH_LINE || k === US_LINE || k === LEADERS_LINE || k === ARABIA_LINE || categoryData[k]) && <span className="w-2 h-2 rotate-45 inline-block shrink-0" style={{ background: GOLD }} />}
                  {lineName(k)}
                </span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
