import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { CARE_REFERENCE, CARE_REFERENCE_META } from "@/lib/careReference";

// دليل صحة منتجات العناية و معطّرات الجو — مرجع كامل قائم بذاته.
// يقرأ القاعدة المرجعية فقط (لا بيانات منتجات) — يعمل بصفر منتجات.
// العرض ثنائي اللغة: العربية وحدها ثم الإنجليزية وحدها (قاعدة A).
export default function CareGuide() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [q, setQ] = useState("");

  const sections = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return CARE_REFERENCE;
    return CARE_REFERENCE
      .map((sec) => {
        const rows = (sec.rows || []).filter((r) =>
          `${r.ar || ""} ${r.en || ""} ${r.inci || ""}`.toLowerCase().includes(needle)
        );
        const titleHit = `${sec.titleAr} ${sec.titleEn}`.toLowerCase().includes(needle);
        if (titleHit) return sec;
        if (rows.length) return { ...sec, rows };
        return null;
      })
      .filter(Boolean);
  }, [q]);

  const STATUS = {
    banned: { ar: "غير مسموح", en: "Not Allowed", color: "#dc2626" },
    restricted: { ar: "مقيّد", en: "Restricted", color: "#d97706" },
    allowed: { ar: "مسموح", en: "Allowed", color: "#059669" },
    flag: { ar: "علم تحسّس", en: "Allergen flag", color: "#7C6FB0" },
  };

  return (
    <div className="px-5 page-top pb-24 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-secondary transition-colors">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </button>
        <div>
          <h1 className="font-heading text-xl font-bold text-[var(--brand)]">دليل العناية الشخصية <span className="text-muted-foreground font-normal">Personal Care Guide</span></h1>
          <p className="text-xs text-muted-foreground font-body">سلامة تركيب منتجات العناية و معطّرات الجو — مرجع مستقلّ</p>
        </div>
      </div>

      {/* مبدأ — عربي ثم إنجليزي */}
      <div className="space-y-2 text-sm font-body leading-relaxed">
        <p className="text-foreground">كل مكوّن يُصنّف <b style={{ color: STATUS.allowed.color }}>مسموح</b> أو <b style={{ color: STATUS.restricted.color }}>مقيّد بنسبة</b> أو <b style={{ color: STATUS.banned.color }}>غير مسموح</b>، مقارنةً بالأنظمة الأوروبية و معايير IFRA. «مسموح» تعني «لا مادة غير مسموحة و لا تجاوز حدّ» لا «بلا مخاطر مطلقا».</p>
        <p className="text-muted-foreground text-xs italic" dir="ltr">Each ingredient is classed as allowed, restricted with a limit, or not allowed, against EU regulation and IFRA. "Allowed" means "nothing disallowed and no limit exceeded", not "risk-free".</p>
      </div>

      {/* بحث */}
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={isAr ? "ابحث بالاسم أو الوظيفة أو الحالة Search" : "Search by name, function, status"}
        className="w-full text-sm font-body bg-white rounded-none border-b border-[var(--brand)] p-2"
        dir={isAr ? "rtl" : "ltr"}
      />

      {/* الأقسام */}
      {sections.map((sec) => (
        <section key={sec.id} className="space-y-3">
          <div>
            <h2 className="font-heading font-semibold text-base text-[var(--brand)]">{sec.titleAr} <span className="text-muted-foreground font-normal">{sec.titleEn}</span></h2>
            {sec.noteAr && <p className="text-xs text-muted-foreground font-body mt-0.5">{sec.noteAr}</p>}
            {sec.noteEn && <p className="text-[11px] text-muted-foreground/80 font-body italic mt-0.5" dir="ltr">{sec.noteEn}</p>}
          </div>
          <div className="space-y-2">
            {(sec.rows || []).map((r, i) => (
              <div key={i} className="bg-white rounded-none border-b border-[var(--brand)] p-3">
                <div className="flex items-start justify-between gap-2">
                  <span className="font-body font-semibold text-sm">
                    <span style={r.status === "banned" ? { textDecoration: "underline", textDecorationColor: "#C0392B", textDecorationThickness: "2px", textUnderlineOffset: "3px" } : r.status === "restricted" ? { textDecoration: "underline", textDecorationColor: "#8B5E3C", textDecorationThickness: "2px", textUnderlineOffset: "3px" } : undefined}>{r.ar}</span>{r.inci ? <span className="text-muted-foreground font-normal text-xs" dir="ltr"> {r.inci}</span> : null}
                  </span>
                </div>
                {r.detailAr && <p className="text-xs text-muted-foreground font-body mt-1">{r.detailAr}</p>}
                {r.en && <p className="text-[11px] text-muted-foreground/80 font-body italic mt-1" dir="ltr">{r.en}</p>}
                {r.ref && <p className="text-[10px] text-muted-foreground/60 font-body mt-1" dir="ltr">{r.ref}</p>}
              </div>
            ))}
          </div>
        </section>
      ))}

      {/* ترويسة المرجع */}
      <div className="pt-2 text-[11px] text-muted-foreground/70 font-body" dir="ltr">
        {CARE_REFERENCE_META.reference_version} · reviewed {CARE_REFERENCE_META.reviewed_on}
        <br />Sources: {CARE_REFERENCE_META.sources}
      </div>
    </div>
  );
}
