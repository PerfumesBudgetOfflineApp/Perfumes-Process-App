import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { ArrowLeft, GitCompare, Search, Star, Droplets, X, Sparkles, Layers } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { usePersonNames } from "@/lib/usePersonNames";
import { toast } from "sonner";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import PerfumePicker from "@/components/wearlog/PerfumePicker";
import { searchPerfumeIds } from "@/lib/searchIndex";
import LayerCard from "@/components/layering/LayerCard";
import { format } from "date-fns";

const TABS = [
  { key: "compare", label: "Compare", icon: GitCompare },
  { key: "mix", label: "Mix", icon: Layers },
  { key: "suggest", label: "Suggestions", icon: Sparkles },
];

function PerfumePickerModal({ selected, onSelect, onClose }) {
  const [q, setQ] = useState("");
  const query = q.trim();
  // بحثٌ عبر الفهرس (searchPerfumeIds + getMany) — لا تحميل ~130 ألف عطر.
  const { data: filtered = [] } = useQuery({
    queryKey: ["perfume-picker-modal", query.toLowerCase()],
    enabled: query.length >= 2,
    staleTime: 1000 * 60,
    queryFn: async () => {
      const { ids } = await searchPerfumeIds(query);
      if (!ids.length) return [];
      return await apphost.entities.Perfume.getMany(ids.slice(0, 60));
    },
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-end justify-center" onClick={onClose}>
      <div className="bg-background rounded-none w-full max-w-md p-5 pb-10 space-y-4 max-h-[80vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <h3 className="font-heading font-semibold text-base">اختر عطراً Choose Perfume</h3>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث... / Search.." className="pl-9 rounded-none h-10 font-body text-sm" autoFocus />
        </div>
        <div className="overflow-y-auto flex-1 space-y-1">
          {filtered.map((p) => (
            <button key={p.id} onClick={() => { onSelect(p); onClose(); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-none text-left transition-colors ${
                selected?.id === p.id ? "bg-primary/10 border border-primary/30" : "hover:bg-secondary"
              }`}>
              {p.image_url ? (
                <img src={p.image_url} alt={p.name} className="w-9 h-9 rounded-none object-cover flex-shrink-0" />
              ) : (
                <div className="w-9 h-9 rounded-none bg-secondary flex items-center justify-center flex-shrink-0">
                  <Droplets className="w-4 h-4 text-primary/40" />
                </div>
              )}
              <div className="min-w-0">
                <p className="text-sm font-body font-medium truncate">{p.name}</p>
                <p className="text-[11px] text-muted-foreground font-body truncate">{p.brand_name}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function PerfumeSlot({ perfume, side, onChoose }) {
  const color = side === "left" ? "text-primary border-primary/30 bg-primary/5" : "text-violet-500 border-violet-300 bg-violet-50";
  const emptyColor = side === "left" ? "border-primary/30 text-primary" : "border-violet-300 text-violet-500";

  if (!perfume) {
    return (
      <button onClick={onChoose} className={`flex-1 flex flex-col items-center justify-center gap-2 h-28 rounded-none border-2 border-dashed transition-colors hover:bg-secondary/50 ${emptyColor}`}>
        <Droplets className="w-6 h-6 opacity-50" />
        <span className="text-xs font-body font-medium">اختر عطراً Choose Perfume</span>
      </button>
    );
  }

  return (
    <button onClick={onChoose} className={`flex-1 flex flex-col items-center gap-2 p-3 rounded-none border transition-colors ${color}`}>
      {perfume.image_url ? (
        <img src={perfume.image_url} alt={perfume.name} className="w-14 h-14 rounded-none object-cover" />
      ) : (
        <div className="w-14 h-14 rounded-none bg-secondary/60 flex items-center justify-center">
          <Droplets className="w-7 h-7 text-primary/30" />
        </div>
      )}
      <div className="text-center">
        <p className="text-xs font-body font-semibold leading-tight line-clamp-2">{perfume.name}</p>
        <p className="text-[10px] text-muted-foreground font-body">{perfume.brand_name}</p>
      </div>
    </button>
  );
}

function CompareRow({ label, leftVal, rightVal }) {
  const leftEmpty = !leftVal || leftVal === "—";
  const rightEmpty = !rightVal || rightVal === "—";

  return (
    <div className="grid grid-cols-[1fr_auto_1fr] gap-2 items-center py-2.5">
      <div className={`text-right text-xs font-body pr-1 ${leftEmpty ? "text-muted-foreground/40 italic" : "text-foreground"}`}>
        {leftVal || "—"}
      </div>
      <div className="text-[10px] font-body text-muted-foreground text-center w-20 flex-shrink-0 font-semibold uppercase tracking-wide">
        {label}
      </div>
      <div className={`text-left text-xs font-body pl-1 ${rightEmpty ? "text-muted-foreground/40 italic" : "text-foreground"}`}>
        {rightVal || "—"}
      </div>
    </div>
  );
}

function Stars({ rating }) {
  if (!rating) return <span className="text-xs text-muted-foreground/50 font-body">لا تقييم No rating</span>;
  return (
    <span className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star key={s} className={`w-3 h-3 ${s <= rating ? "fill-primary text-primary" : "text-border"}`} />
      ))}
    </span>
  );
}

export default function Compare() {
  const navigate = useNavigate();
  const { names } = usePersonNames();
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState("compare");

  // Compare state
  const [leftPerfume, setLeftPerfume] = useState(null);
  const [rightPerfume, setRightPerfume] = useState(null);
  const [picker, setPicker] = useState(null);

  // Layering state
  const [dialogOpen, setDialogOpen] = useState(false);
  const [logDialogOpen, setLogDialogOpen] = useState(false);
  const [logTarget, setLogTarget] = useState(null);
  const [logDate, setLogDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [logPerson, setLogPerson] = useState("person1");
  const [logNote, setLogNote] = useState("");
  const [selectedPerfumes, setSelectedPerfumes] = useState([null, null]);
  const [comboName, setComboName] = useState("");
  const [comboNotes, setComboNotes] = useState("");
  const [comboRating, setComboRating] = useState(0);
  const [comboPerson, setComboPerson] = useState("person1");

  // Suggestions state
  const [recPerson, setRecPerson] = useState("person1");
  const [recs, setRecs] = useState([]);
  const [recsLoading, setRecsLoading] = useState(false);

  // المنتقيات تبحث عبر الفهرس داخلياً (searchPerfumeIds) — لا تحميل ~130 ألف عطر.

  const { data: wearLogs = [] } = useQuery({
    queryKey: ["wear-logs"],
    queryFn: () => apphost.entities.WearLog.list("-date"),
  });

  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const { data: layers = [], isLoading } = useQuery({
    queryKey: ["layers"],
    queryFn: () => apphost.entities.PerfumeLayer.list("-created_date"),
  });

  const createLayer = useMutation({
    mutationFn: (data) => apphost.entities.PerfumeLayer.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["layers"] });
      toast.success("حُفظ المزج");
      setDialogOpen(false);
      resetForm();
    },
  });

  const deleteLayer = useMutation({
    mutationFn: (id) => apphost.entities.PerfumeLayer.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["layers"] }); toast.success("أُزيل"); },
  });

  const updateLayer = useMutation({
    mutationFn: ({ id, data }) => apphost.entities.PerfumeLayer.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["layers"] }),
  });

  const createWearLog = useMutation({
    mutationFn: (data) => apphost.entities.WearLog.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wear-logs"] });
      toast.success("سُجّل");
      setLogDialogOpen(false);
      setLogNote("");
    },
  });

  const resetForm = () => {
    setSelectedPerfumes([null, null]);
    setComboName(""); setComboNotes("");
    setComboRating(0); setComboPerson("person1");
  };

  const getStats = (perfume) => {
    if (!perfume) return null;
    const id = perfume.id;
    const p1Wears = wearLogs.filter((l) => String(l.perfume_id) === String(id) && (l.person === "person1" || !l.person)).length;
    const p2Wears = wearLogs.filter((l) => String(l.perfume_id) === String(id) && l.person === "person2").length;
    const logsForThis = wearLogs.filter((l) => String(l.perfume_id) === String(id)).sort((a, b) => b.date?.localeCompare(a.date));
    const lastWorn = logsForThis[0]?.date || null;
    const up1 = userPerfumes.find((u) => String(u.perfume_id) === String(id) && u.person === "person1");
    const up2 = userPerfumes.find((u) => String(u.perfume_id) === String(id) && u.person === "person2");
    return { p1Wears, p2Wears, lastWorn, up1, up2 };
  };

  const leftStats = useMemo(() => getStats(leftPerfume), [leftPerfume, wearLogs, userPerfumes]);
  const rightStats = useMemo(() => getStats(rightPerfume), [rightPerfume, wearLogs, userPerfumes]);


  const validPerfumes = selectedPerfumes.filter(Boolean);
  const selectedIds = selectedPerfumes.filter(Boolean).map((p) => p.id);

  const handleCreate = () => {
    if (validPerfumes.length < 2) { toast.error("اختر عطرين على الأقل"); return; }
    const uniqueIds = new Set(validPerfumes.map((p) => p.id));
    if (uniqueIds.size !== validPerfumes.length) { toast.error("اختر عطوراً مختلفة"); return; }

    const ids = validPerfumes.map((p) => p.id).join(",");
    const names_ = validPerfumes.map((p) => p.name).join(",");
    const brands = validPerfumes.map((p) => p.brand_name || "").join(",");

    createLayer.mutate({
      perfume_ids: ids,
      perfume_names: names_,
      perfume_brands: brands,
      perfume1_id: validPerfumes[0].id,
      perfume1_name: validPerfumes[0].name,
      perfume1_brand: validPerfumes[0].brand_name,
      perfume2_id: validPerfumes[1]?.id || "",
      perfume2_name: validPerfumes[1]?.name || "",
      perfume2_brand: validPerfumes[1]?.brand_name || "",
      name: comboName, notes: comboNotes, rating: comboRating, person: comboPerson, wear_count: 0,
    });
  };

  const handleLogWear = (layer) => {
    setLogTarget(layer);
    setLogPerson("person1");
    setLogDate(format(new Date(), "yyyy-MM-dd"));
    setLogNote("");
    setLogDialogOpen(true);
  };

  const handleConfirmLog = () => {
    const allNames = logTarget.perfume_names
      ? logTarget.perfume_names.split(",").join(" + ")
      : `${logTarget.perfume1_name} + ${logTarget.perfume2_name}`;
    const comboLabel = logTarget.name || allNames;
    createWearLog.mutate({
      date: logDate,
      perfume_id: logTarget.perfume1_id,
      perfume_name: `[Layer] ${comboLabel}`,
      brand_name: logTarget.perfume1_brand,
      person: logPerson,
      note: logNote || `Layered: ${allNames}`,
    });
    updateLayer.mutate({
      id: logTarget.id,
      data: { wear_count: (logTarget.wear_count || 0) + 1, last_worn: logDate },
    });
  };

  const getLayerLabel = (layer) => {
    if (layer.name) return layer.name;
    if (layer.perfume_names) return layer.perfume_names.split(",").join(" + ");
    return `${layer.perfume1_name} + ${layer.perfume2_name}`;
  };

  const loadRecommendations = async () => {
    setRecsLoading(true);
    try {
      const result = await apphost.functions.invoke('recommendPerfumes', { person: recPerson, limit: 6 });
      setRecs(result.data.recommendations || []);
      toast.success(`Found ${result.data.recommendations?.length || 0} recommendations`);
    } catch {
      toast.error('Failed to load recommendations');
    }
    setRecsLoading(false);
  };

  const addSlot = () => {
    if (selectedPerfumes.length < 5) setSelectedPerfumes((prev) => [...prev, null]);
  };

  const removeSlot = (i) => {
    setSelectedPerfumes((prev) => prev.filter((_, idx) => idx !== i));
  };

  const setSlot = (i, perfume) => {
    setSelectedPerfumes((prev) => prev.map((p, idx) => (idx === i ? perfume : p)));
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden" style={{ backgroundColor: "#1a5d3f" }}>
      <div className="px-4 page-top pb-4 space-y-4 max-w-2xl mx-auto flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="rounded-none text-white hover:bg-white/10" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-heading text-2xl font-bold text-white">Compare · Mix · Suggestions</h1>
            <p className="text-xs text-white/70 font-body">مساحة عطورك المتكاملة All-in-one fragrance workspace</p>
          </div>
        </div>

        {/* Tabs - Gold frame */}
        <div className="bg-amber-500/20 border-2 border-amber-500/60 rounded-none p-3 space-y-3 flex-1 flex flex-col overflow-hidden">
          <div className="grid grid-cols-3 gap-2">
            {TABS.map((tab) => {
              const Icon = tab.icon;
              const active = activeTab === tab.key;
              return (
                <button key={tab.key} onClick={() => setActiveTab(tab.key)}
                  className={`flex items-center justify-center gap-1.5 py-2.5 rounded-none text-sm font-body font-medium transition-all ${
                    active
                      ? "bg-amber-500/80 text-white shadow-lg"
                      : "bg-white/10 text-white/70 hover:bg-white/20"
                  }`}>
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>

          {/* Tab Content */}
          <div className="space-y-4 flex-1 overflow-y-auto">
            {/* COMPARE TAB */}
            {activeTab === "compare" && (
              <div className="space-y-4">
                <div className="flex gap-3">
                  <PerfumeSlot perfume={leftPerfume} side="left" onChoose={() => setPicker("left")} />
                  <div className="flex items-center justify-center">
                    <div className="w-8 h-8 rounded-none bg-white/20 flex items-center justify-center">
                      <GitCompare className="w-4 h-4 text-white" />
                    </div>
                  </div>
                  <PerfumeSlot perfume={rightPerfume} side="right" onChoose={() => setPicker("right")} />
                </div>

                {leftPerfume && rightPerfume && (
                  <div className="bg-black/30 rounded-none border border-amber-500/40 divide-y divide-amber-500/30 overflow-hidden">
                    <div className="grid grid-cols-[1fr_auto_1fr] gap-2 px-4 py-3 bg-black/40">
                      <p className="text-[11px] font-body font-bold text-amber-300 text-right truncate pr-1">{leftPerfume.name}</p>
                      <div className="w-20" />
                      <p className="text-[11px] font-body font-bold text-amber-300 text-left truncate pl-1">{rightPerfume.name}</p>
                    </div>

                    <div className="px-4 py-1">
                      <p className="text-[10px] font-body font-bold uppercase tracking-widest text-amber-300/70 pt-3 pb-1">الأساسيات Basics</p>
                      <CompareRow label="Brand" leftVal={leftPerfume.brand_name} rightVal={rightPerfume.brand_name} />
                      <CompareRow label="Type" leftVal={leftPerfume.type} rightVal={rightPerfume.type} />
                      <CompareRow label="Gender" leftVal={leftPerfume.gender} rightVal={rightPerfume.gender} />
                      <CompareRow label="Season" leftVal={leftPerfume.season} rightVal={rightPerfume.season} />
                    </div>

                    <div className="px-4 py-1">
                      <p className="text-[10px] font-body font-bold uppercase tracking-widest text-amber-300/70 pt-3 pb-1">النوتات Notes</p>
                      <CompareRow label="Top" leftVal={leftPerfume.top_notes} rightVal={rightPerfume.top_notes} />
                      <CompareRow label="Heart" leftVal={leftPerfume.heart_notes} rightVal={rightPerfume.heart_notes} />
                      <CompareRow label="Base" leftVal={leftPerfume.base_notes} rightVal={rightPerfume.base_notes} />
                    </div>
                  </div>
                )}
                {!leftPerfume || !rightPerfume && (
                  <div className="text-center py-8">
                    <p className="text-sm font-body text-white/70">اختر عطرين للمقارنة Select two perfumes to compare</p>
                  </div>
                )}
              </div>
            )}

            {/* MIX TAB */}
            {activeTab === "mix" && (
              <div className="space-y-3">
                <Button onClick={() => { resetForm(); setDialogOpen(true); }} className="w-full rounded-none font-body h-10 bg-amber-500/80 hover:bg-amber-500 text-white">
                  New Mix
                </Button>

                {isLoading && (
                  <div className="flex items-center justify-center py-8">
                    <div className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  </div>
                )}

                {!isLoading && layers.length === 0 && (
                  <p className="text-center py-6 text-sm text-white/70 font-body">لا مزجات بعد أنشئ أول مزج No mixes yet. Create your first combo!</p>
                )}

                {layers.length > 0 && (
                  <div className="space-y-3">
                    {layers.map((layer) => (
                      <LayerCard key={layer.id} layer={layer} names={names}
                        onDelete={() => deleteLayer.mutate(layer.id)}
                        onLogWear={() => handleLogWear(layer)}
                        onRateUpdate={(rating) => updateLayer.mutate({ id: layer.id, data: { rating } })}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* SUGGESTIONS TAB */}
            {activeTab === "suggest" && (
              <div className="space-y-3">
                <select name="Compare-sel1" value={recPerson} onChange={(e) => setRecPerson(e.target.value)} className="w-full px-3 py-2 rounded-none border border-amber-500/40 bg-black/30 text-white text-sm font-body">
                  <option value="person1" style={{ color: "black" }}>{names.person1}'s Recommendations</option>
                  <option value="person2" style={{ color: "black" }}>{names.person2}'s Recommendations</option>
                </select>

                <Button onClick={loadRecommendations} disabled={recsLoading} className="w-full rounded-none font-body h-10 bg-amber-500/80 hover:bg-amber-500 text-white">
                  {recsLoading ? "Loading.." : "Generate"}
                </Button>

                {recs.length > 0 && (
                  <div className="grid grid-cols-2 gap-3">
                    {recs.map((p) => <PerfumeCard key={p.id} perfume={p} />)}
                  </div>
                )}

                {!recsLoading && recs.length === 0 && (
                  <p className="text-center py-6 text-sm text-white/70 font-body">No suggestions yet. Click Generate to find recommendations based on your favorites.</p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Dialogs */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-sm rounded-none max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading text-base flex items-center gap-2">
              <Layers className="w-4 h-4 text-primary" /> New Mix
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedPerfumes.map((slot, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                    Perfume {i + 1} {i < 2 ? "(required)" : "(optional)"}
                  </p>
                  {i >= 2 && (
                    <button onClick={() => removeSlot(i)} className="text-muted-foreground hover:text-destructive">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <PerfumePicker excludeIds={selectedIds.filter((sid) => sid !== slot?.id)} selected={slot} onSelect={(p) => setSlot(i, p)} />
              </div>
            ))}

            {selectedPerfumes.length < 5 && (
              <button onClick={addSlot} className="w-full flex items-center justify-center gap-2 py-2.5 rounded-none border border-dashed border-border text-xs font-body text-muted-foreground hover:border-primary hover:text-primary transition-colors">
                Add another
              </button>
            )}

            <Input value={comboName} onChange={(e) => setComboName(e.target.value)} placeholder='e.g. "Evening Mystery"' className="rounded-none h-9 font-body text-sm" />
            <Textarea value={comboNotes} onChange={(e) => setComboNotes(e.target.value)} placeholder="كيف رائحتهما معاً؟ How do they smell together?" className="rounded-none font-body text-xs min-h-[48px] resize-none" />

            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-2">التقييم Rating</p>
              <div className="flex gap-1.5">
                {[1, 2, 3, 4, 5].map((s) => (
                  <button key={s} onClick={() => setComboRating(comboRating === s ? 0 : s)}
                    className={`text-xl transition-all ${s <= comboRating ? "text-primary" : "text-border hover:text-primary/40"}`}>{s <= comboRating ? "■" : "□"}</button>
                ))}
              </div>
            </div>

            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-2">من جرّبه Who tried it?</p>
              <div className="flex gap-2">
                {[
                  { val: "person1", label: names.person1 },
                  { val: "person2", label: names.person2 },
                  { val: "both", label: "Both" },
                ].map(({ val, label }) => (
                  <button key={val} onClick={() => setComboPerson(val)}
                    className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${comboPerson === val ? val === "person2" ? "bg-violet-500 text-white shadow" : "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <Button className="w-full h-10 rounded-none font-body" onClick={handleCreate} disabled={validPerfumes.length < 2 || createLayer.isPending}>
              {createLayer.isPending ? "Saving.." : `Save Mix (${validPerfumes.length})`}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={logDialogOpen} onOpenChange={setLogDialogOpen}>
        <DialogContent className="max-w-xs rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">سجّل هذا المزيج Log This Mix</DialogTitle>
          </DialogHeader>
          {logTarget && (
            <div className="space-y-4">
              <div className="bg-secondary/50 rounded-none p-3 text-center">
                <p className="text-xs font-body font-semibold">{getLayerLabel(logTarget)}</p>
              </div>
              <Input type="date" value={logDate} onChange={(e) => setLogDate(e.target.value)} className="rounded-none h-9 font-body text-sm" />
              <div className="flex gap-2">
                <button onClick={() => setLogPerson("person1")} className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${logPerson === "person1" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>
                  {names.person1}
                </button>
                <button onClick={() => setLogPerson("person2")} className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${logPerson === "person2" ? "bg-violet-500 text-white shadow" : "bg-secondary text-muted-foreground"}`}>
                  {names.person2}
                </button>
              </div>
              <Textarea value={logNote} onChange={(e) => setLogNote(e.target.value)} placeholder="ملاحظة اختيارية... / Optional note.." className="rounded-none font-body text-xs min-h-[48px] resize-none" />
              <Button className="w-full h-10 rounded-none font-body" onClick={handleConfirmLog} disabled={createWearLog.isPending}>
                {createWearLog.isPending ? "Logging.." : "Log"}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {picker && (
        <PerfumePickerModal selected={picker === "left" ? leftPerfume : rightPerfume}
          onSelect={(p) => picker === "left" ? setLeftPerfume(p) : setRightPerfume(p)}
          onClose={() => setPicker(null)}
        />
      )}
    </div>
  );
}