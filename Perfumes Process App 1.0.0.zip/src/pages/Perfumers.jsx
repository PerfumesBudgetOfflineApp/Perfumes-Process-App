import { hilalBorder } from "@/lib/hilalArt";
import { compareEnglish } from "@/lib/sortName";
import React, { useState, useMemo } from 'react';
import { apphost } from '@/api/apphostClient';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, User, AArrowUp, AArrowDown, Pin } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useLang } from '@/lib/LanguageContext';
import Pagination from "@/components/Pagination";
import { getAppName } from "@/lib/useAppName";
import { openHtmlReport } from "@/lib/exportHelper";
import { usePins } from "@/lib/usePins";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";

export default function Perfumers() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [view, setView] = useState("manage");
  const [search, setSearch] = useState("");
  const [genderFilter, setGenderFilter] = useState("all");
  const [yearSort, setYearSort] = useState("none");
  const currentYear = new Date().getFullYear();

  const { data: perfumers = [], isLoading } = useQuery({
    queryKey: ["perfumers"],
    queryFn: async () => {
      try {
        return await apphost.entities.Perfumer.list("name");
      } catch (error) {
        console.error("Error fetching perfumers:", error);
        return [];
      }
    },
  });

  const handleExportPerfumers = async (format) => {
    const sortedPerfumers = [...perfumers].sort((a, b) => {
      const yearA = a.birth_year || 9999;
      const yearB = b.birth_year || 9999;
      return yearA - yearB;
    });
    
    if (format === "pdf") {
            const perfumerRows = sortedPerfumers.map((p) => `
        <div class="perfumer-card">
          <div class="perfumer-header">
            <div class="perfumer-name">${p.name || ''}</div>
            <div class="perfumer-name-ar">${p.name_ar || ''}</div>
          </div>
          <div class="perfumer-info">
            <div class="info-row">
              <span class="label">الجنسية Nationality:</span>
              <span class="value">${p.nationality || '—'}</span>
            </div>
            <div class="info-row">
              <span class="label">الميلاد Birth Year:</span>
              <span class="value">${p.birth_year ? `${p.birth_year}${p.death_year ? ` – ${p.death_year}` : ''}` : '—'}</span>
            </div>
            <div class="info-row">
              <span class="label">الجنس Gender:</span>
              <span class="value">${p.gender || '—'}</span>
            </div>
            ${p.famous_works ? `<div class="info-row">
              <span class="label">الأعمال الشهيرة Famous Works:</span>
              <span class="value">${p.famous_works}</span>
            </div>` : ''}
            ${p.brand_names ? `<div class="info-row">
              <span class="label">العلامات التجارية Brands:</span>
              <span class="value">${p.brand_names}</span>
            </div>` : ''}
            ${p.bio ? `<div class="info-row bio">
              <span class="label">النبذة Bio:</span>
              <span class="value">${p.bio}</span>
            </div>` : ''}
          </div>
        </div>
      `).join('');
      
      await openHtmlReport(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="utf-8"/>
  <style>
      /* خطوط محلية — لا اتصال خارجيا (كان Google Fonts) */
      @font-face { font-family: 'Cairo'; src: url('/fonts/Cairo.woff') format('woff'); font-weight: 400 800; font-display: swap; }
      @font-face { font-family: 'Amiri'; src: url('/fonts/Amiri.woff') format('woff'); font-weight: 400 700; font-display: swap; }
      @font-face { font-family: 'Playfair Display'; src: url('/fonts/PlayfairDisplay.woff') format('woff'); font-weight: 400 800; font-style: normal; font-display: swap; }
      @font-face { font-family: 'Playfair Display'; src: url('/fonts/PlayfairDisplay.woff') format('woff'); font-weight: 400 800; font-style: italic; font-display: swap; }
      @font-face { font-family: 'Cormorant Garamond'; src: url('/fonts/Cormorant.woff2') format('woff2'); font-weight: 400 600; font-style: normal; font-display: swap; }
      @font-face { font-family: 'Cormorant Garamond'; src: url('/fonts/Cormorant.woff2') format('woff2'); font-weight: 400 600; font-style: italic; font-display: swap; }
    </style>
  <title>الأنف العطرية Perfumers</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { 
      font-family: 'Cairo', 'Segoe UI', Arial, sans-serif; 
      direction: rtl; 
      unicode-bidi: embed;
      padding: 32px; 
      color: #1a1a1a; 
      background: #fff; 
      font-size: 13px; 
      line-height: 1.8;
    }
    h1 { 
      font-size: 18px; 
      font-weight: 700; 
      text-align: center; 
      margin-bottom: 6px; 
      letter-spacing: -0.3px;
      color: #0f5f3f;
    }
    .subtitle { 
      text-align: center; 
      color: #666; 
      margin-bottom: 24px; 
      font-size: 10px;
    }
    .perfumer-card {
      background: transparent;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 12px;
      page-break-inside: avoid;
    }
    .perfumer-header {
      margin-bottom: 10px;
    }
    .perfumer-name {
      font-size: 13px;
      font-weight: 600;
      color: #0f5f3f;
      margin-bottom: 2px;
      letter-spacing: -0.2px;
    }
    .perfumer-name-ar {
      font-size: 11px;
      color: #555;
      font-weight: 500;
    }
    .perfumer-info {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .info-row {
      display: grid;
      grid-template-columns: 140px 1fr;
      gap: 10px;
      align-items: start;
      font-size: 10px;
    }
    .info-row.bio {
      grid-template-columns: 1fr;
      gap: 4px;
    }
    .info-row.bio .label {
      display: block;
      margin-bottom: 2px;
    }
    .label {
      font-weight: 600;
      color: #333;
      white-space: nowrap;
    }
    .value {
      color: #555;
      line-height: 1.5;
    }
    @media print {
      body { padding: 20px; }
      @page { 
        margin: 1.2cm;
        size: A4;
      }
      .perfumer-card {
        page-break-inside: avoid;
        margin-bottom: 16px;
      }
    }
  </style>
</head>
<body>
<h1>الأنف العطرية Perfumers</h1>
<div class="subtitle">${getAppName().name_en} > الأنف العطرية Perfumers</div>
${perfumerRows}
<script>
  /* auto-print disabled — user prints via overlay Print button */
<\/script>
</body></html>`, 'process-app_export');
    }
  };

  const filtered = perfumers
    .filter((p) => {
      if (p.hidden) return false;
      // لا فلترة حية (قاعدة A): الأيقونة/Enter تفتح صفحة النتائج
      const matchGender = genderFilter === "all" || p.gender === genderFilter;
      return matchGender;
    })
    .sort((a, b) => {
      if (yearSort === "asc") return (a.birth_year || 9999) - (b.birth_year || 9999);
      if (yearSort === "desc") return (b.birth_year || 0) - (a.birth_year || 0);
      // افتراضي: A → Z
      return compareEnglish(a, b, 1);
    });

  // أعداد الربط (مرحلة 3): عطّار «مرتبط» = له معرّفات عطور مخزّنة (perfume_ids) أو
  // أسماء عطور قديمة (perfume_names). تُحسب من العطّارين غير المخفيين.
  const visiblePerfumers = perfumers.filter((p) => !p.hidden);
  const { pinnedIds: pinnedPerfumerIds } = usePins("perfumer");
  const pinnedPerfumers = useMemo(() => {
    const byId = Object.fromEntries((perfumers || []).map((p) => [String(p.id), p]));
    return pinnedPerfumerIds.map((pid) => byId[String(pid)]).filter((p) => p && !p.hidden);
  }, [perfumers, pinnedPerfumerIds]);
  const linkedCount = visiblePerfumers.filter(
    (p) => (p.perfume_ids && String(p.perfume_ids).trim()) || (p.perfume_names && String(p.perfume_names).trim())
  ).length;
  const unlinkedCount = visiblePerfumers.length - linkedCount;

  return (
    <div className="space-y-5">
      {/* Header — بنسق الهيدر الرئيسي (قاعدة A 1.795): ثابت غير لاصق و لا متحرك،
          نفس تنسيق هيدر /home مع مربع المستخدم، و الفاصل الذهبي تحته،
          و أزرار الإجراءات بإطاراتها الذهبية في صف يليه */}
      <div className="px-4 pt-2 pb-2 flex items-center justify-between min-h-[44px]">
        <h1 className="font-heading text-xl font-bold leading-none" style={{ color: "var(--brand)" }}>{isAr ? "مصممي عطور" : "Perfumers"}</h1>
        <div className="flex items-center gap-2">
          <SettingsSheet>
            <UserAvatarButton size={28} />
          </SettingsSheet>
        </div>
      </div>

      <div className="px-5 pb-4 space-y-5">
      {/* Manage content shown directly (tabs removed; index is a standalone page) */}
      <div className="space-y-5 mt-2">

      <div className="space-y-2">
        <div className="flex gap-2">
          {["all", "Male", "Female"].map((g) => (
            <button key={g} onClick={() => setGenderFilter(g)}
              className="flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-opacity hover:opacity-70"
              style={{ color: genderFilter === g ? "var(--brand)" : "#2E7D32" }}>
              {g === "all" ? "All" : g === "Male" ? "Male" : "Female"}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          {[
            { value: "none", label: "Year" },
            { value: "asc", label: "↑ Oldest" },
            { value: "desc", label: "↓ Youngest" },
          ].map(({ value, label }) => (
            <button key={value} onClick={() => setYearSort(value)}
              className="flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-opacity hover:opacity-70"
              style={{ color: yearSort === value ? "var(--brand)" : "#2E7D32" }}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {pinnedPerfumers.length > 0 && (
        <div className="space-y-2 mb-3">
          {pinnedPerfumers.map((perfumer) => (
            <Link key={`pin-${perfumer.id}`} to={`/perfumer?id=${perfumer.id}`}>
              <div className="bg-[var(--page-bg,#fff)] p-4 flex items-center gap-3">
                <div className="w-11 h-11 flex items-center justify-center flex-shrink-0 overflow-hidden bg-[var(--page-bg,#fff)] dark:bg-white/95" style={{ border: hilalBorder(perfumer.name, perfumer.name_ar, "1.5px solid #4CAF50") }}>
                  {perfumer.photo_url ? (
                    <img src={perfumer.photo_url} alt={perfumer.name} className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} />
                  ) : (
                    <div className="w-full h-full bg-[var(--page-bg,#fff)]" />
                  )}
                </div>
                <p className="font-body font-semibold text-sm flex-1 min-w-0">{perfumer.name}</p>
                <Pin className="w-3.5 h-3.5 flex-shrink-0" style={{ color: "var(--brand)" }} fill="var(--brand)" />
              </div>
            </Link>
          ))}
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 rounded-full animate-spin" style={{ borderColor: "color-mix(in srgb, var(--brand) 30%, transparent)", borderTopColor: "var(--brand)" }} />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 space-y-3">
          <div className="w-16 h-16 bg-green-50 dark:bg-green-900/20 rounded-none flex items-center justify-center mx-auto">
            <User className="w-8 h-8 text-green-700" />
          </div>
          <p className="text-muted-foreground font-body text-sm">لا معطّرين No perfumers found</p>
        </div>
      ) : (
        <Pagination
           items={filtered}
           itemsPerPage={25}
           renderItem={(items) => (
            <div className="space-y-2">
              {items.map((perfumer) => {
                const brandList = perfumer.brand_names ? perfumer.brand_names.split(",").map(b => b.trim()).filter(Boolean) : [];
                return (
                  <Link key={perfumer.id} to={`/perfumer?id=${perfumer.id}`}>
                    <div className="bg-[var(--page-bg,#fff)] p-4 flex items-start gap-3 relative">
                      {perfumer.gender && (
                        <span className={`absolute top-3 right-3 text-[9px] rounded-none font-body font-bold ${perfumer.gender === "Female" ? " text-pink-600" : " text-blue-900"}`}>
                          {perfumer.gender === "Female" ? "♀" : "♂"}
                        </span>
                      )}
                      <div className="w-11 h-11 rounded-none flex items-center justify-center flex-shrink-0 overflow-hidden bg-[var(--page-bg,#fff)] dark:bg-white/95" style={{ border: hilalBorder(perfumer.name, perfumer.name_ar, "1.5px solid #4CAF50") }}>
                        {perfumer.photo_url ? (
                          <img src={perfumer.photo_url} alt={perfumer.name} className="w-full h-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} />
                        ) : (
                          <div className="w-full h-full bg-[var(--page-bg,#fff)]" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-body font-semibold text-sm">{perfumer.name}</p>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
          emptyMessage="No perfumers found"
        />
      )}

        {/* حقل البحث — أسفل جدول العطّارين */}
        <div className="relative flex items-center h-11 bg-[var(--page-bg,#fff)] border-t border-border/50" dir="ltr">
          <div aria-hidden="true" className="w-px h-5 mx-3 flex-shrink-0" style={{ background: "var(--brand)" }} />
          <input value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && search.trim()) navigate(`/search-results?type=perfumers&q=${encodeURIComponent(search.trim())}`); }} placeholder="" dir={isAr ? "rtl" : "ltr"} className="flex-1 h-11 bg-transparent outline-none text-sm font-body px-1" />
          <button type="button" aria-label="search" onClick={() => { if (search.trim()) navigate(`/search-results?type=perfumers&q=${encodeURIComponent(search.trim())}`); }} className="px-3 flex-shrink-0 hover:opacity-70 transition-opacity">
            <Search className="w-4 h-4" style={{ color: "var(--brand)" }} />
          </button>
        </div>

        {/* Action Buttons */}
         {view === "manage" && (
           <div className="flex gap-2 pt-4 pb-4 border-t border-border/50">
             <Button className="flex-1 rounded-none font-body bg-green-700 hover:bg-green-800" onClick={() => navigate("/add-perfumer")}>
               إضافة Add
             </Button>
           </div>
         )}
        </div>

      {/* Create / Index / Export — منقولة لأسفل الصفحة */}
      <div className="pt-4 flex gap-4 items-center flex-wrap justify-center" dir={isAr ? "rtl" : "ltr"}>
        <button type="button" onClick={() => navigate("/create-sample")}
          className="rounded-none font-body text-[11px] px-1 py-1 transition-opacity whitespace-nowrap hover:opacity-70" style={{ color: "var(--brand)" }}>
          Create Perfume
        </button>
        <button type="button" onClick={() => navigate("/perfumers-index")}
          className="rounded-none font-body text-[11px] px-1 py-1 transition-opacity whitespace-nowrap hover:opacity-70" style={{ color: "var(--brand)" }}>
          index
        </button>
        <button type="button" onClick={() => navigate("/export?type=perfumers")}
          className="rounded-none font-body text-[11px] px-1 py-1 transition-opacity whitespace-nowrap hover:opacity-70" style={{ color: "var(--brand)" }}>
          Export
        </button>
      </div>

      {/* Count Footer — آخر شيء بعد الروابط: على سطر واحد، خط صغير، بلا نقاط */}
      <div className="text-center text-[10px] text-muted-foreground font-body pt-6 space-x-3">
        <span>{perfumers.length} noses</span>
        <span className="text-emerald-700">{linkedCount} linked</span>
        <span>{unlinkedCount} unlinked</span>
      </div>


      {/* Add Perfumer moved to a standalone page (/add-perfumer) — modal removed */}
      </div>
    </div>
  );
}

export function PerfumersIndexContent({ perfumers, isLoading, search, setSearch, genderFilter, setGenderFilter, yearSort, setYearSort }) {
  const navigate = useNavigate();
  const currentYear = new Date().getFullYear();
  const [alphaDir, setAlphaDir] = useState("asc");           // 'asc' | 'desc'
  const [scriptBucket, setScriptBucket] = useState("all");   // 'all' | 'latin' | 'numbers' | 'other' | 'symbols'

  // Classify a name's first character into a script bucket. Used both for
  // filtering (when user picks a single bucket) and for the section header
  // shown above each block of names.
  const bucketOf = (name) => {
    const c = String(name || "")[0] || "";
    if (!c) return "symbols";
    if (/[A-Za-z]/.test(c)) return "latin";
    if (/[0-9]/.test(c)) return "numbers";
    if (/\p{L}/u.test(c)) return "other";            // any letter outside ASCII (Arabic, CJK, Cyrillic…)
    return "symbols";                                // /, :, #, …
  };

  const filtered = perfumers
    .filter((p) => {
      if (p.hidden) return false;
      // لا فلترة حية (قاعدة A): الأيقونة/Enter تفتح صفحة النتائج
      const matchGender = genderFilter === "all" || p.gender === genderFilter;
      const matchBucket = scriptBucket === "all" || bucketOf(p.name) === scriptBucket;
      return matchGender && matchBucket;
    })
    .sort((a, b) => {
      if (yearSort === "asc") return (a.birth_year || 9999) - (b.birth_year || 9999);
      if (yearSort === "desc") return (b.birth_year || 0) - (a.birth_year || 0);
      // Alphabetical — direction controlled by alphaDir
      const cmp = compareEnglish(a, b, 1);
      return alphaDir === "desc" ? -cmp : cmp;
    });

  return (
    <div className="space-y-3">
      {/* Filters */}
      <div className="space-y-3">
        <div className="relative">
          <button type="button" aria-label="search"
            onClick={() => { const q = search.trim(); if (q) navigate(`/search-results?type=perfumers&q=${encodeURIComponent(q)}`); }}
            className="absolute left-3 top-1/2 -translate-y-1/2 hover:opacity-70 transition-opacity">
            <Search className="w-4 h-4" style={{ color: "var(--brand)" }} />
          </button>
          <Input value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && search.trim()) navigate(`/search-results?type=perfumers&q=${encodeURIComponent(search.trim())}`); }} placeholder="بحث" className="pl-9 h-11 rounded-none font-body bg-secondary/50 border-0" />
        </div>
        <div className="flex gap-2">
          {["all", "Male", "Female"].map((g) => (
            <button key={g} onClick={() => setGenderFilter(g)}
              className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${genderFilter === g ? "bg-green-800 text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
              {g === "all" ? "All" : g === "Male" ? "Male" : "Female"}
            </button>
          ))}
        </div>
        {/* Alpha direction + Year (matches sort-icon convention from /glossary) */}
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => { setAlphaDir("asc"); setYearSort("none"); }}
            className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all inline-flex items-center justify-center gap-1 ${alphaDir === "asc" && yearSort === "none" ? "bg-green-300 text-green-900 shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            aria-label="Sort A-Z"
          >
            A <AArrowUp className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => { setAlphaDir("desc"); setYearSort("none"); }}
            className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all inline-flex items-center justify-center gap-1 ${alphaDir === "desc" && yearSort === "none" ? "bg-green-300 text-green-900 shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            aria-label="Sort Z-A"
          >
            A <AArrowDown className="w-3.5 h-3.5" />
          </button>
          {[
            { value: "asc", label: "↑ Oldest" },
            { value: "desc", label: "↓ Youngest" },
          ].map(({ value, label }) => (
            <button key={value} onClick={() => setYearSort(value)}
              className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${yearSort === value ? "bg-green-300 text-green-900 shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
              {label}
            </button>
          ))}
        </div>
        {/* Script bucket filter — A-Z / Numbers / Other / Symbols / All */}
        <div className="flex gap-2 flex-wrap">
          {[
            { value: "all",     label: "All" },
            { value: "latin",   label: "A–Z" },
            { value: "numbers", label: "0–9" },
            { value: "other",   label: "أبجد" },
            { value: "symbols", label: ": / #" },
          ].map(({ value, label }) => (
            <button
              key={value}
              type="button"
              onClick={() => setScriptBucket(value)}
              className={`flex-1 min-w-[3rem] py-1.5 rounded-none text-[11px] font-body font-medium transition-all ${scriptBucket === value ? "bg-amber-600 text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 rounded-full animate-spin" style={{ borderColor: "color-mix(in srgb, var(--brand) 30%, transparent)", borderTopColor: "var(--brand)" }} />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 space-y-3">
          <p className="text-muted-foreground font-body text-sm">لا نتائج No results</p>
        </div>
      ) : (
        <PerfumerChipsList items={filtered} />
      )}
     </div>
   );
}

/**
 * Compact chip list mirroring the Brands index layout. Each perfumer is a
 * small pill — no image, no gender icon — and the *name itself* is tinted to
 * indicate gender:
 *   - Male   → blue   #1d4ed8
 *   - Female → pink   #db2777
 *   - Other  → black  (foreground)
 * No pagination: the whole list renders continuously, virtualized via CSS
 * content-visibility (off-screen ~80-chip chunks skip layout/paint).
 */
function PerfumerChipsList({ items }) {
  const colorFor = (g) => g === "Male" ? "#1d4ed8" : g === "Female" ? "#db2777" : undefined;
  const CHUNK = 80, groups = [];
  for (let i = 0; i < items.length; i += CHUNK) groups.push(items.slice(i, i + CHUNK));
  return (
    <div className="page-top space-y-1.5">
      {groups.map((group, gi) => (
        <div
          key={gi}
          className="flex flex-wrap gap-1.5"
          style={{ contentVisibility: "auto", containIntrinsicSize: `${Math.ceil(group.length / 3) * 30}px` }}
        >
          {group.map((p) => (
            <Link
              key={p.id}
              to={`/perfumer?id=${p.id}`}
              className="text-xs rounded-none font-body transition-colors"
              style={{ color: colorFor(p.gender) }}
            >
              {p.name}
            </Link>
          ))}
        </div>
      ))}
    </div>
  );
 }