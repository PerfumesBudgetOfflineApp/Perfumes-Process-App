import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Download } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import UserContentControls from "@/components/shared/UserContentControls";
import InteractionBar from "@/components/shared/InteractionBar";
import { exportSingleQuoteImage } from "@/lib/quoteExport";

// نفس منطق صفحة الاقتباسات لاستخراج النصّين والمؤلّف (مكرّر مؤقتاً — يُستخرج لمكتبة لاحقاً).
function resolveQuoteTexts(q) {
  if (!q) return { en: "", ar: "" };
  if (q.text_en || q.text_ar) {
    return { en: String(q.text_en || "").trim(), ar: String(q.text_ar || "").trim() };
  }
  const raw = String(q.text_enar || "").trim();
  if (!raw) return { en: "", ar: "" };
  const parts = raw.split(/\s+\.\.\s+/);
  if (parts.length >= 2) {
    let en = parts[0].trim().replace(/\.$/, "").trim();
    let ar = parts.slice(1).join(" .. ").trim().replace(/\.$/, "").trim();
    const enHasAr = /[\u0600-\u06FF]/.test(en);
    const arHasAr = /[\u0600-\u06FF]/.test(ar);
    if (enHasAr && !arHasAr) [en, ar] = [ar, en];
    return { en, ar };
  }
  if (/[\u0600-\u06FF]/.test(raw)) return { en: "", ar: raw };
  return { en: raw, ar: "" };
}

function resolveQuoteAuthor(q) {
  if (!q) return "";
  return (q.quoteauthor || q.author || "").trim();
}

export default function QuoteDetail() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { isAr } = useLang();
  const [thoughtOpen, setThoughtOpen] = useState(false);
  const [thoughtDraft, setThoughtDraft] = useState("");
  const [exportLang, setExportLang] = useState("both"); // both | en | ar
  const [exporting, setExporting] = useState(false);

  const params = new URLSearchParams(window.location.search);
  const quoteId = params.get("id");

  // جلب الاقتباس وحده بمعرّفه — لا تحميل للجدول كله
  const { data: quote = null, isFetched: quoteFetched } = useQuery({
    queryKey: ["quote", String(quoteId)],
    queryFn: async () => {
      try { return await apphost.entities.Quote.get(quoteId); }
      catch { return null; }
    },
    enabled: !!quoteId,
  });
  const { data: userQuotes = [] } = useQuery({
    queryKey: ["user-quotes"],
    queryFn: () => apphost.entities.UserQuote.list("-updated_date"),
  });

  const uq = userQuotes.find((u) => String(u.quote_id) === String(quoteId));

  const snapshotOf = (q) => ({ text_en: q?.text_en, text_ar: q?.text_ar, category: q?.category });

  const reactionMutation = useMutation({
    mutationFn: async ({ reaction }) => {
      const snapshot = snapshotOf(quote);
      if (uq) return apphost.entities.UserQuote.update(uq.id, { reaction, ...snapshot });
      return apphost.entities.UserQuote.create({ quote_id: quoteId, reaction, ...snapshot });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-quotes"] }),
  });

  const favoriteMutation = useMutation({
    mutationFn: async ({ favorite }) => {
      const snapshot = snapshotOf(quote);
      if (uq) return apphost.entities.UserQuote.update(uq.id, { favorite, ...snapshot });
      return apphost.entities.UserQuote.create({ quote_id: quoteId, favorite, ...snapshot });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-quotes"] }),
  });

  const thoughtMutation = useMutation({
    mutationFn: async ({ newThought }) => {
      const snapshot = snapshotOf(quote);
      if (uq) return apphost.entities.UserQuote.update(uq.id, { thought: newThought });
      return apphost.entities.UserQuote.create({ quote_id: quoteId, thought: newThought, ...snapshot });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["user-quotes"] });
      setThoughtOpen(false);
      toast.success(isAr ? "تم حفظ الخاطرة" : "Thought saved");
    },
  });

  const deleteThoughtMutation = useMutation({
    mutationFn: async () => {
      if (uq) return apphost.entities.UserQuote.update(uq.id, { thought: "" });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-quotes"] }),
  });

  const editMutation = useMutation({
    mutationFn: async (fields) => {
      const clean = {};
      ["text_en", "text_ar", "quoteauthor", "category"].forEach((k) => {
        if (fields[k] !== undefined) clean[k] = fields[k];
      });
      return apphost.entities.Quote.update(quote.id, clean);
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["quotes"] }); qc.invalidateQueries({ queryKey: ["quote", String(quoteId)] }); qc.invalidateQueries({ queryKey: ["quotes-cat"] }); },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      if (quote.is_user) return apphost.entities.Quote.delete(quote.id);
      return apphost.entities.Quote.update(quote.id, { hidden: true });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["quotes"] });
      qc.invalidateQueries({ queryKey: ["quotes-cat"] });
      qc.invalidateQueries({ queryKey: ["quote-categories"] });
      navigate("/quotes");
    },
  });

  if (!quoteId) {
    navigate("/quotes");
    return null;
  }

  if (quoteFetched && !quote) {
    return (
      <div className="px-4 page-top pb-20 text-center">
        <p className="text-muted-foreground font-body">{isAr ? "الاقتباس غير موجود." : "Quote not found."}</p>
        <button onClick={() => navigate("/quotes")} className="text-primary text-sm mt-2 font-body underline">
          {isAr ? "العودة" : "Back"}
        </button>
      </div>
    );
  }

  const { en, ar } = resolveQuoteTexts(quote);
  const author = resolveQuoteAuthor(quote);
  const reaction = uq?.reaction || "none";
  const favorite = !!uq?.favorite;
  const hasThought = !!uq?.thought;

  const openThoughtEditor = () => {
    setThoughtDraft(uq?.thought || "");
    setThoughtOpen(true);
  };

  const handleExport = async () => {
    setExporting(true);
    try {
      await exportSingleQuoteImage(quote, { lang: exportLang, en, ar, author });
      toast.success(isAr ? "تم تصدير الصورة" : "Image exported");
    } catch {
      toast.error(isAr ? "تعذّر التصدير" : "Export failed");
    } finally {
      setExporting(false);
    }
  };

  const LANGS = [
    { v: "both", label: isAr ? "الكل" : "Both" },
    { v: "en", label: "EN" },
    { v: "ar", label: "ع" },
  ];

  return (
    <div className="px-4 page-top pb-24 space-y-5 max-w-xl mx-auto">
      {/* Header */}
      <div className={`flex items-center gap-3 ${isAr ? "flex-row-reverse" : ""}`}>
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-secondary transition-colors"
          title={isAr ? "رجوع" : "Back"}
        >
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </button>
        <h1 className="font-heading text-lg font-semibold">{isAr ? "اقتباس" : "Quote"}</h1>
      </div>

      {/* Quote card */}
      <div className="bg-card rounded-none border border-border/50 p-5 space-y-3">
        {en && (
          <p className="text-base font-body leading-relaxed text-foreground/90" dir="ltr" style={{ unicodeBidi: "isolate" }}>
            {en}
          </p>
        )}
        {ar && (
          <p className="text-base font-body leading-relaxed text-foreground/90" dir="rtl" style={{ unicodeBidi: "isolate" }}>
            {ar}
          </p>
        )}
        <div className="flex items-center justify-between gap-2 text-[11px] text-muted-foreground font-body pt-1">
          <span>{author && <span>— {author}</span>}</span>
          {quote?.category && (
            <Link
              to={`/at?name=${encodeURIComponent(quote.category)}`}
              className="px-1.5 py-0.5 rounded bg-secondary/60 hover:bg-secondary transition-colors"
              title={`@${quote.category}`}
            >
              {quote.category}
            </Link>
          )}
        </div>
        {Array.isArray(quote?.images) && quote.images.length > 0 && (
          <div className="flex flex-wrap gap-2 pt-2">
            {quote.images.map((url, i) => (
              <img key={i} src={url} alt="" className="h-20 w-20 object-cover rounded-lg" />
            ))}
          </div>
        )}
      </div>

      {/* Interactions (incl. WTF) */}
      <InteractionBar
        reaction={favorite ? "favorite" : reaction}
        hasThought={hasThought}
        showWtf={true}
        onReact={(kind) => {
          if (kind === "favorite") favoriteMutation.mutate({ favorite: !favorite });
          else reactionMutation.mutate({ reaction: reaction === kind ? "none" : kind });
        }}
        onThought={openThoughtEditor}
        bookmark={{
          item_type: "quote",
          item_id: quote?.id,
          title_en: en || "",
          title_ar: ar || "",
          subtitle: author || "",
          path: `/quote?id=${quote?.id}`,
        }}
      />

      {/* Existing thought */}
      {hasThought && (
        <div className="bg-secondary/40 rounded-none p-3 space-y-1.5">
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "فكرتي" : "My thought"}</p>
          <p className="text-[13px] font-body" dir="auto">{uq.thought}</p>
          <button
            onClick={() => deleteThoughtMutation.mutate()}
            className="text-[11px] text-destructive hover:text-destructive/70 font-body"
          >
            {isAr ? "حذف" : "Delete"}
          </button>
        </div>
      )}

      {/* Export as image — language + button */}
      <div className="bg-card rounded-none border border-border/50 p-4 space-y-3">
        <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-body">
          {isAr ? "تصدير كصورة" : "Export as image"}
        </p>
        <div className="flex items-center gap-2">
          {LANGS.map((o) => (
            <button
              key={o.v}
              onClick={() => setExportLang(o.v)}
              className={` rounded-none text-xs font-body font-medium transition-colors ${
 exportLang === o.v ? " text-primary-foreground" : " text-muted-foreground hover:text-foreground"
 }`}
            >
              {o.label}
            </button>
          ))}
          <Button onClick={handleExport} disabled={exporting} size="sm" className="ms-auto rounded-none gap-1.5">
            <Download className="w-4 h-4" />
            {exporting ? (isAr ? "جارٍ…" : "…") : "Export IMG"}
          </Button>
        </div>
      </div>

      {/* Edit / delete the quote itself */}
      <UserContentControls
        kind="quote"
        entry={quote}
        isUser={!!quote?.is_user}
        compact
        onSave={(fields) => editMutation.mutateAsync(fields)}
        onDelete={() => deleteMutation.mutateAsync()}
      />

      {/* Thought editor */}
      <Dialog open={thoughtOpen} onOpenChange={setThoughtOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-heading">{isAr ? "خاطرتي عن الاقتباس" : "My thought on this quote"}</DialogTitle>
          </DialogHeader>
          <Textarea
            value={thoughtDraft}
            onChange={(e) => setThoughtDraft(e.target.value)}
            placeholder={isAr ? "اكتب فكرتك…" : "Write your thought…"}
            className="min-h-[120px] font-body"
            dir="auto"
          />
          <div className="flex justify-end gap-2">
            <Button variant="ghost" size="sm" onClick={() => setThoughtOpen(false)}>{isAr ? "إلغاء" : "Cancel"}</Button>
            <Button size="sm" onClick={() => thoughtMutation.mutate({ newThought: thoughtDraft })}>{isAr ? "حفظ" : "Save"}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
