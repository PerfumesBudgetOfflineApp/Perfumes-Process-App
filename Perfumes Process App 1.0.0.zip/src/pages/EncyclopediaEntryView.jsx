import { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, Play, Pause, Square, FileCog, Download, Copy, Pencil, ChevronLeft, ChevronRight } from "lucide-react";
import { exportEntryImage, exportEntryPdf, previewEntryImage, ENC_FONT_THEMES } from "@/lib/encyclopediaExport";
import { ENC_ACCENTS, ENC_ACCENTS_SOLID } from "@/lib/encAccents";
import AccentHearts from "@/components/encyclopedia/AccentHearts";
import { getExportSettings, setExportSettings } from "@/lib/exportSettings";
import { useLang } from "@/lib/LanguageContext";
import { ENC, langField } from "@/lib/encyclopedia";
import { isNativeTTS, nativeSpeak, nativeStop, ttsSupported, nativeOpenInstall, nativeLangSupported } from "@/lib/tts";
import InteractionBar from "@/components/shared/InteractionBar";
import { usePersonNames } from "@/lib/usePersonNames";

// قارئ مدخل الموسوعة — عرض للقراءة + نطق صوتيّ أوفلاين عبر محرّك الجهاز.
// اختيار اللغة أزرار (لا قوائم): عربية · English · ثنائي (افتراضي). التاريخ لا يظهر هنا.
function buildChunks(text) {
  const segs = [];
  String(text || "").split(/\n+/).forEach((para, pi) => {
    const p = para.trim();
    if (!p) return;
    if (p.length <= 200) { segs.push({ text: p, para: pi }); return; }
    let buf = "";
    p.split(/\s+/).forEach((w) => {
      if ((buf + " " + w).length > 200) { segs.push({ text: buf.trim(), para: pi }); buf = w; }
      else buf += " " + w;
    });
    if (buf.trim()) segs.push({ text: buf.trim(), para: pi });
  });
  return segs;
}

function fmtYr(y, isAr) {
  if (y == null || y === "") return "";
  const n = parseInt(y, 10);
  if (!Number.isFinite(n)) return String(y);
  if (n < 0) return `${-n}${isAr ? " ق.م" : " BC"}`;
  if (n >= 2040) return isAr ? `${n} افتراضي` : `${n} notional`;
  return String(n);
}

export default function EncyclopediaEntryView() {
  const { isAr } = useLang();
  const { names, profiles } = usePersonNames();
  const [activePerson, setActivePerson] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_active_person")) || "person1");
  useEffect(() => { try { localStorage.setItem("enc_active_person", activePerson); } catch { /* تجاهل */ } }, [activePerson]);
  const [thoughtOpen, setThoughtOpen] = useState(false);
  const [thoughtDraft, setThoughtDraft] = useState("");
  const navigate = useNavigate();
  const { id } = useParams();

  const { data: langs = [] } = useQuery({ queryKey: ["enc-langs"], queryFn: () => ENC.Language().list("order", 50), staleTime: 1000 * 30 });
  const { data: entry } = useQuery({ queryKey: ["enc-entry", id], queryFn: () => ENC.Entry().get(Number(id)), staleTime: 1000 * 30 });
  // تالي/سابق ضمن القسم الرئيسي — يعيد استخدام قائمة المداخل المخبّأة (نفس ترتيب «الأحدث»).
  const { data: encAll = [] } = useQuery({ queryKey: ["enc-fav-entries"], queryFn: () => ENC.Entry().list("-updated_date", 20000), staleTime: 1000 * 10, enabled: !!entry });
  const sectionSibs = useMemo(() => (entry ? encAll.filter((e) => String(e.section_id) === String(entry.section_id)) : []), [encAll, entry]);
  const sibIdx = useMemo(() => sectionSibs.findIndex((e) => String(e.id) === String(entry?.id)), [sectionSibs, entry]);
  const prevEntryId = sibIdx > 0 ? sectionSibs[sibIdx - 1].id : null;
  const nextEntryId = (sibIdx >= 0 && sibIdx < sectionSibs.length - 1) ? sectionSibs[sibIdx + 1].id : null;
  const qc = useQueryClient();
  const patchEntry = async (patch) => {
    try { await ENC.Entry().update(Number(id), patch); qc.invalidateQueries({ queryKey: ["enc-entry", id] }); qc.invalidateQueries({ queryKey: ["enc-entries"] }); } catch { /* تجاهل */ }
  };

  // وضع العرض: ثنائي (افتراضي) · عربية · إنجليزية — حسب تفضيل المستخدم لاحقاً
  const defaultMode = (typeof localStorage !== "undefined" && localStorage.getItem("enc_read_lang")) || "both";
  const [mode, setMode] = useState(defaultMode);

  // اللغات التي للمدخل فيها محتوى
  const contentLangs = useMemo(() => langs.filter((l) => entry && langField(entry.texts, l.code, [])), [langs, entry]);
  const hasAr = contentLangs.some((l) => l.code === "ar");
  const hasEn = contentLangs.some((l) => l.code === "en");

  // اللغة المقروءة صوتياً: في الثنائي = لغة الواجهة، وإلا الوضع نفسه
  const [ttsLang, setTtsLang] = useState(() => { try { return localStorage.getItem("enc_tts_lang") || ""; } catch { return ""; } });
  const readCode = ttsLang || (mode === "both" ? (isAr ? "ar" : "en") : mode);
  const readLang = useMemo(() => langs.find((l) => l.code === readCode) || langs[0], [langs, readCode]);
  const bodyText = entry ? langField(entry.texts, readCode, langs) : "";
  const segs = useMemo(() => buildChunks(bodyText), [bodyText]);
  const paras = useMemo(() => {
    const map = [];
    segs.forEach((s, i) => {
      const last = map[map.length - 1];
      if (last && last.para === s.para) last.items.push({ ...s, i });
      else map.push({ para: s.para, items: [{ ...s, i }] });
    });
    return map;
  }, [segs]);

  // قراءة ثنائية مدمجة AR EN AR EN — تبادل مقاطع العربي و الإنجليزي
  const arText = entry ? langField(entry.texts, "ar", langs) : "";
  const enText = entry ? langField(entry.texts, "en", langs) : "";
  const [bilingual, setBilingual] = useState(() => { try { return localStorage.getItem("enc_tts_bi") === "1"; } catch { return false; } });
  useEffect(() => { try { localStorage.setItem("enc_tts_bi", bilingual ? "1" : "0"); } catch { /* تجاهل */ } }, [bilingual]);
  const readSegs = useMemo(() => {
    if (bilingual && hasAr && hasEn) {
      const a = buildChunks(arText).map((s) => ({ ...s, lang: "ar" }));
      const e = buildChunks(enText).map((s) => ({ ...s, lang: "en" }));
      const out = []; const n = Math.max(a.length, e.length);
      for (let i = 0; i < n; i++) { if (a[i]) out.push(a[i]); if (e[i]) out.push(e[i]); }
      return out;
    }
    return segs.map((s) => ({ ...s, lang: readCode }));
  }, [bilingual, hasAr, hasEn, arText, enText, segs, readCode]);

  const native = isNativeTTS();
  const supported = ttsSupported();
  const [voices, setVoices] = useState([]);
  const [nativeSupported, setNativeSupported] = useState(null); // null=غير معروف، false=لا صوت للغة على الجهاز
  const [voiceURI, setVoiceURI] = useState("");
  const [rate, setRate] = useState(() => { try { const n = Number(localStorage.getItem("enc_tts_rate")); return n >= 0.6 && n <= 1.4 ? n : 1; } catch { return 1; } });
  const [font, setFont] = useState(() => { const n = Number(typeof localStorage !== "undefined" && localStorage.getItem("enc_font_scale")); return n >= 13 && n <= 26 ? n : 13; });
  const [encAccent, setEncAccentRaw] = useState(() => (typeof localStorage !== "undefined" && localStorage.getItem("enc_accent_color")) || "");
  const setEncAccent = (c) => {
    setEncAccentRaw(c);
    try { localStorage.setItem("enc_accent_color", c); } catch { /* تجاهل */ }
    try { window.dispatchEvent(new Event("enc-accent-change")); } catch { /* تجاهل */ }
  };
  const [showSet, setShowSet] = useState(false);
  const [showExp, setShowExp] = useState(false);
  const [expLang, setExpLang] = useState(defaultMode);
  const [expFontPx, setExpFontPx] = useState(19);
  const [expTheme, setExpTheme] = useState(ENC_FONT_THEMES[0]);
  const [expSettings, setExpSettings] = useState(() => getExportSettings());
  const updExpColor = (k, v) => { setExpSettings((p) => ({ ...p, [k]: v })); setExportSettings({ [k]: v }); };
  const [expInc, setExpInc] = useState({ entries: true, mark: true, year: false, pronunciation: false, explain: false, source: false, refs: false, tags: false });
  const [expPreview, setExpPreview] = useState(null);
  const [expShape, setExpShape] = useState("portrait"); // طوليّ/عرضيّ/مربّع — اتجاه و سقف الإخراج
  const toggleInc = (k) => setExpInc((pr) => ({ ...pr, [k]: !pr[k] }));
  const [showInfo, setShowInfo] = useState(false);
  useEffect(() => { try { localStorage.setItem("enc_font_scale", String(font)); } catch { /* تجاهل */ } }, [font]);
  useEffect(() => { try { localStorage.setItem("enc_tts_rate", String(rate)); } catch { /* تجاهل */ } }, [rate]);
  useEffect(() => { try { localStorage.setItem("enc_tts_lang", ttsLang); } catch { /* تجاهل */ } }, [ttsLang]);
  const [state, setState] = useState("idle");
  const [current, setCurrent] = useState(-1);
  const idxRef = useRef(0);
  const genRef = useRef(0); // رمز جيل: يزداد عند كل إيقاف فتُبطَل المؤقّتات/الوعود المعلّقة
  const activeRef = useRef(null);

  useEffect(() => {
    if (!supported || native) return;
    const load = () => setVoices(window.speechSynthesis.getVoices() || []);
    load();
    window.speechSynthesis.onvoiceschanged = load;
    return () => { try { window.speechSynthesis.onvoiceschanged = null; } catch { /* تجاهل */ } };
  }, [supported]);

  const langVoices = useMemo(() => {
    const code = (readLang?.code || "en").toLowerCase();
    return voices.filter((v) => String(v.lang || "").toLowerCase().startsWith(code));
  }, [voices, readLang]);
  // فحص دعم الصوت أصلياً (أندرويد): يحدّد إن كانت لغة القراءة منزّلة على الجهاز.
  useEffect(() => {
    if (!native) { setNativeSupported(null); return; }
    let alive = true;
    setNativeSupported(null);
    nativeLangSupported(readCode).then((ok) => { if (alive) setNativeSupported(ok); }).catch(() => {});
    return () => { alive = false; };
  }, [native, readCode]);
  // ينقص الصوت؟ أصلياً: لغة غير مدعومة؛ ويب: لا أصوات للغة. عند الشكّ لا ننذر.
  const voicesMissing = native ? (nativeSupported === false) : (supported && langVoices.length === 0);
  // اختيار الصوت: يحفظ اختيار المستخدم لكل لغة و لا يُعاد ضبطه عند إعادة الرسم.
  const voiceForLang = useCallback((code) => {
    const c = (code || "en").toLowerCase();
    const list = voices.filter((v) => String(v.lang || "").toLowerCase().startsWith(c));
    if (!list.length) return null;
    let saved = null; try { saved = localStorage.getItem(`enc_tts_voice_${c}`); } catch { /* تجاهل */ }
    return (saved && list.find((v) => v.voiceURI === saved)) || list[0];
  }, [voices]);
  useEffect(() => {
    if (!langVoices.length) { setVoiceURI(""); return; }
    setVoiceURI((cur) => {
      if (cur && langVoices.some((v) => v.voiceURI === cur)) return cur; // احفظ اختيار المستخدم
      const v = voiceForLang(readCode);
      return v ? v.voiceURI : langVoices[0].voiceURI;
    });
  }, [langVoices, readCode, voiceForLang]);

  const stop = useCallback(() => {
    if (native) { try { nativeStop(); } catch { /* تجاهل */ } }
    else if (supported) { try { window.speechSynthesis.cancel(); } catch { /* تجاهل */ } }
    idxRef.current = 0; genRef.current++; setState("idle"); setCurrent(-1);
  }, [native, supported]);
  useEffect(() => () => stop(), [stop]);
  useEffect(() => { stop(); }, [readCode, id, stop]);
  useEffect(() => {
    if (current >= 0 && activeRef.current) {
      try { activeRef.current.scrollIntoView({ block: "center", behavior: "smooth" }); } catch { /* تجاهل */ }
    }
  }, [current]);

  const speakFrom = useCallback((i) => {
    if (!supported) return;
    if (i >= readSegs.length) { setState("idle"); setCurrent(-1); idxRef.current = 0; return; }
    idxRef.current = i; setCurrent(bilingual ? -1 : i);
    const seg = readSegs[i];
    const segLang = seg.lang || readCode || "en";
    if (native) {
      // المنصّة الأصليّة: ننطق المقطع عبر الملحق، وعند انتهائه ننتقل للتالي.
      // شبكة أمان: بعض محرّكات أندرويد لا تُطلق onDone فلا يُحَلّ الوعد و يتوقّف
      // النطق بعد المقطع الأوّل. نضع مؤقّتاً تقديرياً (حدّاً أعلى) ينقل للتالي إن
      // لم يصل الوعد. الحارس يُلغى متى وصل الوعد أوّلاً، فلا قطع للنطق السليم.
      // رمز الجيل يمنع أي تقدّم بعد إيقاف المستخدم (حتى أثناء المقطع الأوّل).
      const gen = genRef.current;
      let advanced = false;
      const advance = () => { if (!advanced && genRef.current === gen && idxRef.current === i) { advanced = true; speakFrom(i + 1); } };
      const est = Math.min(30000, 1500 + (seg.text.length / Math.max(0.5, rate)) * 110);
      const wd = setTimeout(advance, est);
      nativeSpeak({ text: seg.text, langCode: segLang, rate })
        .then(() => { clearTimeout(wd); advance(); })
        .catch(() => { clearTimeout(wd); if (genRef.current === gen && idxRef.current === i) { setState("idle"); setCurrent(-1); } });
      return;
    }
    const u = new SpeechSynthesisUtterance(seg.text);
    const v = bilingual ? voiceForLang(segLang) : (voices.find((vv) => vv.voiceURI === voiceURI) || voiceForLang(segLang));
    if (v) u.voice = v;
    u.lang = (v && v.lang) || (segLang === "ar" ? "ar-SA" : (segLang || "en"));
    u.rate = rate;
    u.onend = () => { if (idxRef.current === i) speakFrom(i + 1); };
    u.onerror = () => { setState("idle"); setCurrent(-1); };
    window.speechSynthesis.speak(u);
  }, [supported, native, readSegs, bilingual, voices, voiceURI, rate, readCode, voiceForLang]);

  const play = () => {
    if (!supported || !readSegs.length) return;
    if (!native && state === "paused") { window.speechSynthesis.resume(); setState("playing"); return; }
    stop(); setState("playing"); setTimeout(() => speakFrom(0), 0);
  };
  const pause = () => {
    if (!supported || state !== "playing") return;
    if (native) { stop(); return; }   // أندرويد لا يدعم الإيقاف المؤقّت — نوقف تماماً
    window.speechSynthesis.pause(); setState("paused");
  };
  const playFrom = (i) => { if (!supported) return; stop(); setState("playing"); setTimeout(() => speakFrom(i), 0); };
  const setModePersist = (m) => { setMode(m); try { localStorage.setItem("enc_read_lang", m); } catch { /* تجاهل */ } };

  if (!entry) return <div className="px-5 page-top"><p className="text-sm text-muted-foreground font-body py-10">{isAr ? "تحميل" : "Loading"}</p></div>;

  const arTitle = langField(entry.titles, "ar", langs);
  const enTitle = langField(entry.titles, "en", langs);
  const arBody = langField(entry.texts, "ar", langs);
  const enBody = langField(entry.texts, "en", langs);
  const imgs = Array.isArray(entry.images) ? entry.images : (entry.images && typeof entry.images === "object" ? Object.values(entry.images).filter(Boolean) : []);
  const hl = "color-mix(in srgb, var(--brand) 20%, transparent)";
  const reactionsMap = entry.reactions || (entry.reaction ? { person1: entry.reaction } : {});
  const readsMap = entry.reads || (entry.read_status ? { person1: entry.read_status } : {});
  const myReaction = reactionsMap[activePerson] || "none";
  const myRead = readsMap[activePerson] || "none";
  const thoughtsMap = entry.thoughts || {};
  const myThought = thoughtsMap[activePerson] || "";
  const showAr = mode !== "en" && hasAr;
  const showEn = mode !== "ar" && hasEn;
  const copyContent = () => {
    const parts = [];
    if (showAr) parts.push([arTitle, arBody].filter(Boolean).join("\n"));
    if (showEn) parts.push([enTitle, enBody].filter(Boolean).join("\n"));
    const txt = parts.filter(Boolean).join("\n\n");
    try { navigator.clipboard?.writeText(txt); } catch { /* تجاهل */ }
  };

  const renderRead = () => (
    <article dir={readLang?.dir || (isAr ? "rtl" : "ltr")} style={{ fontFamily: "'Cormorant Garamond', 'Amiri', Georgia, serif", fontSize: `${font}px`, color: encAccent || undefined }} className="leading-loose">
      {paras.map((p, pi) => (
        <p key={pi} className="mb-4">
          {p.items.map((seg) => (
            <span key={seg.i} ref={current === seg.i ? activeRef : null} onClick={() => playFrom(seg.i)}
              className="cursor-pointer transition-colors" style={current === seg.i ? { background: hl, borderRadius: 0 } : undefined}>
              {seg.text}{" "}
            </span>
          ))}
        </p>
      ))}
    </article>
  );
  const renderPlain = (text, dir) => (
    <article dir={dir} style={{ fontFamily: "'Cormorant Garamond', 'Amiri', Georgia, serif", fontSize: `${font}px`, color: encAccent || undefined }} className="leading-loose">
      {String(text || "").split(/\n+/).filter((p) => p.trim()).map((p, i) => <p key={i} className="mb-4">{p}</p>)}
    </article>
  );

  return (
    <div className="px-5 page-top pb-28 space-y-4" style={encAccent ? { "--brand": encAccent } : undefined}>
      <div className="flex items-center justify-end">
        <button type="button" onClick={() => { if (window.history.length > 1) navigate(-1); else navigate("/encyclopedia"); }}
          className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity" aria-label={isAr ? "رجوع" : "Back"}>
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} style={{ color: "var(--brand)" }} />
        </button>
      </div>

      {/* العنوان — سطر للعربي و سطر للإنجليزي، كلٌّ واضح على سطره */}
      <header className="space-y-0.5" dir={isAr ? "rtl" : "ltr"}>
        {showAr && arTitle ? <h1 className="font-heading text-2xl font-bold leading-snug break-words" dir="rtl" style={{ color: encAccent || undefined }}>{arTitle}</h1> : null}
        {showEn && enTitle ? <h1 className={`font-heading leading-snug break-words ${showAr && arTitle ? "text-base font-semibold opacity-90" : "text-2xl font-bold"}`} dir="ltr" style={{ color: encAccent || undefined }}>{enTitle}</h1> : null}
      </header>
      {imgs.length > 0 && (
        <div className="space-y-2">
          {imgs.map((src, i) => <img key={i} src={src} alt="" className="w-full max-h-72 object-contain bg-white" />)}
        </div>
      )}

      {/* المحتوى */}
      <div className="space-y-5">
        {showAr && arBody ? (readCode === "ar" ? renderRead() : renderPlain(arBody, "rtl")) : null}
        {showEn && enBody ? (readCode === "en" ? renderRead() : renderPlain(enBody, "ltr")) : null}
        {!arBody && !enBody && <p className="text-sm text-muted-foreground font-body">{isAr ? "لا نصّ لهذه اللغة" : "No text for this language"}</p>}
      </div>

      {/* قراءة النص بصوت — بعد المحتوى، بلا إطارات */}
      <div className="flex items-center gap-3 flex-wrap py-1" dir={isAr ? "rtl" : "ltr"}>
        {state === "playing"
          ? <button type="button" onClick={pause} className="inline-flex items-center gap-1.5 font-body text-sm font-semibold hover:opacity-70" style={{ color: "var(--brand)" }}><Pause className="w-5 h-5" />{isAr ? "إيقاف مؤقّت" : "Pause"}</button>
          : <button type="button" onClick={play} disabled={!supported || !readSegs.length} className="inline-flex items-center gap-1.5 font-body text-sm font-semibold disabled:opacity-40 hover:opacity-70" style={{ color: "var(--brand)" }}><Play className="w-5 h-5" /></button>}
        {state !== "idle" && <button type="button" onClick={stop} className="inline-flex items-center gap-1.5 font-body text-sm hover:opacity-70" style={{ color: "var(--brand)" }}><Square className="w-4 h-4" />{isAr ? "إيقاف" : "Stop"}</button>}
        <input type="range" min="0.6" max="1.4" step="0.1" value={rate} onChange={(e) => setRate(Number(e.target.value))} className="w-24 sharp-range" aria-label={isAr ? "سرعة" : "Speed"} />
        {/* لغة القراءة — يختارها المستخدم بغضّ النظر عن لغة العرض */}
        {hasAr && hasEn && (
          <div className="inline-flex items-center gap-2" dir="ltr">
            <button type="button" onClick={() => { setBilingual(false); setTtsLang(ttsLang === "ar" ? "" : "ar"); }} className="font-body text-xs" style={(!bilingual && readCode === "ar") ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>AR</button>
            <button type="button" onClick={() => { setBilingual(false); setTtsLang(ttsLang === "en" ? "" : "en"); }} className="font-body text-xs" style={(!bilingual && readCode === "en") ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>EN</button>
            <button type="button" onClick={() => setBilingual((b) => !b)} title={isAr ? "قراءة ثنائية مدمجة" : "Bilingual reading"} className="font-body text-xs" style={bilingual ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>AR EN</button>
          </div>
        )}
        {/* اختيار الصوت — يتغيّر مع تغيير اللغة */}
        {langVoices.length > 0 && (
          <select value={voiceURI} onChange={(e) => { setVoiceURI(e.target.value); try { localStorage.setItem(`enc_tts_voice_${readCode}`, e.target.value); } catch { /* تجاهل */ } }} dir="ltr"
            className="bg-transparent outline-none border-0 text-xs font-body max-w-[140px] truncate" style={{ color: "var(--brand)" }}>
            {langVoices.map((v) => <option key={v.voiceURI} value={v.voiceURI}>{v.name}</option>)}
          </select>
        )}
      </div>
      {voicesMissing && (
        <div className="flex items-center gap-2 flex-wrap pt-0.5" dir={isAr ? "rtl" : "ltr"}>
          <span className="text-[11px] text-amber-700 font-body">
            {isAr ? "لا يوجد صوت لهذه اللغة على الجهاز" : "No on-device voice for this language"}
          </span>
          {native ? (
            <button type="button" onClick={() => { nativeOpenInstall(); }} className="text-[11px] font-body font-semibold underline hover:opacity-70" style={{ color: "var(--brand)" }}>
              {isAr ? "تفعيل الصوت" : "Enable voice"}
            </button>
          ) : (
            <span className="text-[11px] text-amber-700 font-body">
              {isAr ? "نزّله من إعدادات الجهاز، إمكانية الوصول، تحويل النص إلى كلام" : "Install it in Settings, Accessibility, Text-to-speech"}
            </span>
          )}
        </div>
      )}

      {/* إشارات و معلومات — قائمة مدمجة مطوية، ثنائية اللغة دائماً، بلا أيقونة و لا أسهم */}
      {(entry.explain || entry.pronunciation || entry.source || entry.refs || entry.tags || entry.year) && (
        <div className="pt-1" dir={isAr ? "rtl" : "ltr"}>
          <button type="button" onClick={() => setShowInfo((v) => !v)} className="font-body text-xs font-semibold hover:opacity-70" style={{ color: "var(--brand)" }}>{isAr ? "إشارات و معلومات" : "Reference and Info"}</button>
          {showInfo && (
            <div className="space-y-1 pt-2 text-sm font-body">
              {entry.year ? <p dir="ltr"><span className="text-muted-foreground">السنة / Year: </span>{fmtYr(entry.year, isAr)}</p> : null}
              {entry.pronunciation ? <p><span className="text-muted-foreground">النطق / Pronunciation: </span>{entry.pronunciation}</p> : null}
              {entry.explain ? <p><span className="text-muted-foreground">إشارات و مراجع / References: </span>{entry.explain}</p> : null}
              {entry.source ? <p><span className="text-muted-foreground">المصدر / Source: </span>{entry.source}</p> : null}
              {entry.refs ? <p><span className="text-muted-foreground">ملاحظات / Notes: </span>{entry.refs}</p> : null}
              {entry.tags ? <p className="text-xs text-muted-foreground">{entry.tags}</p> : null}
            </div>
          )}
        </div>
      )}

      {/* مبدّل الملفّ — أسماء بلون المستخدم بلا إطارات */}
      <div className="flex items-center gap-5 pt-1" dir={isAr ? "rtl" : "ltr"}>
        {["person1", "person2"].map((pk) => (
          <button key={pk} type="button" onClick={() => setActivePerson(pk)} className="font-body text-sm transition-opacity hover:opacity-70"
            style={{ color: profiles[pk].color, fontWeight: activePerson === pk ? 700 : 400, opacity: activePerson === pk ? 1 : 0.55 }}>
            {names[pk]}
          </button>
        ))}
      </div>

      {/* خيارات الإعجاب و القراءة + المفضلة/المفكرة + تعديل — لكل مستخدم */}
      <InteractionBar
        reaction={myReaction}
        showWtf={true}
        showReadStatus={true}
        readStatusAsText={true}
        showCastaway={true}
        readStatus={myRead}
        hasThought={!!myThought}
        accentColor={profiles[activePerson]?.color}
        onReact={(kind) => patchEntry({ reactions: { ...reactionsMap, [activePerson]: (myReaction === kind ? "none" : kind) } })}
        onReadStatus={(status) => patchEntry({ reads: { ...readsMap, [activePerson]: (myRead === status ? "none" : status) } })}
        onThought={() => { setThoughtDraft(myThought); setThoughtOpen(true); }}
        bookmark={{ item_type: "encyclopedia", item_id: entry.id, title_en: enTitle || "", title_ar: arTitle || "", subtitle: isAr ? "موسوعة" : "Encyclopedia", path: `/encyclopedia/view/${entry.id}` }}
        pin={{ kind: "encentry", id: entry.id }}
      />

      {/* تعليق المستخدم على المدخل — لكل ملفّ على حدة */}
      {thoughtOpen ? (
        <div className="space-y-2" dir={isAr ? "rtl" : "ltr"}>
          <textarea value={thoughtDraft} onChange={(e) => setThoughtDraft(e.target.value)} rows={3}
            placeholder={isAr ? "تعليقك على هذا المدخل" : "Your comment on this entry"}
            className="w-full bg-white outline-none border border-border text-sm font-body p-2 resize-y" />
          <div className="flex items-center gap-3">
            <button type="button" onClick={() => { patchEntry({ thoughts: { ...thoughtsMap, [activePerson]: thoughtDraft.trim() } }); setThoughtOpen(false); }}
              className="font-body text-sm font-semibold hover:opacity-70" style={{ color: "var(--brand)" }}>{isAr ? "حفظ التعليق" : "Save comment"}</button>
            <button type="button" onClick={() => setThoughtOpen(false)}
              className="font-body text-sm text-muted-foreground hover:opacity-70">{isAr ? "إلغاء" : "Cancel"}</button>
          </div>
        </div>
      ) : myThought ? (
        <p className="font-body text-sm text-muted-foreground border-s-2 ps-3" style={{ borderColor: profiles[activePerson]?.color }} dir={isAr ? "rtl" : "ltr"}>{myThought}</p>
      ) : null}

      {/* صندوق الإعدادات + صندوق التصدير و النسخ — أيقونات بمربّع لون المستخدم */}
      <div className="flex items-center gap-2 pt-1" dir={isAr ? "rtl" : "ltr"}>
        <button type="button" onClick={() => { setShowSet((v) => !v); setShowExp(false); }}
          className="w-8 h-8 flex items-center justify-center hover:opacity-70" style={{ color: "var(--brand)" }}
          aria-label={isAr ? "إعدادات" : "Settings"} title={isAr ? "إعدادات" : "Settings"}><FileCog className="w-4 h-4" /></button>
        <button type="button" onClick={() => { setShowExp((v) => !v); setShowSet(false); }}
          className="w-8 h-8 flex items-center justify-center hover:opacity-70" style={{ color: "var(--brand)" }}
          aria-label={isAr ? "تصدير و نسخ" : "Export & copy"} title={isAr ? "تصدير و نسخ" : "Export & copy"}><Download className="w-4 h-4" /></button>
        {/* تالي / سابق — بعد الإعدادات و التصدير، بلا عناوين، ضمن القسم الرئيسي */}
        <button type="button" disabled={!prevEntryId} onClick={() => prevEntryId && navigate(`/encyclopedia/view/${prevEntryId}`)}
          className="w-8 h-8 flex items-center justify-center hover:opacity-70 disabled:opacity-25" style={{ color: "var(--brand)" }}
          aria-label={isAr ? "السابق" : "Previous"}>{isAr ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}</button>
        <button type="button" disabled={!nextEntryId} onClick={() => nextEntryId && navigate(`/encyclopedia/view/${nextEntryId}`)}
          className="w-8 h-8 flex items-center justify-center hover:opacity-70 disabled:opacity-25" style={{ color: "var(--brand)" }}
          aria-label={isAr ? "التالي" : "Next"}>{isAr ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}</button>
      </div>
      {showSet && (
        <div className="space-y-3 text-sm font-body pt-1" dir={isAr ? "rtl" : "ltr"}>
          {/* اختيار اللغة — بلا إطارات */}
          <div className="flex items-center gap-4 flex-wrap">
            {hasAr && <button type="button" onClick={() => setModePersist("ar")} className="font-body text-xs" style={mode === "ar" ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>عربية</button>}
            {hasEn && <button type="button" onClick={() => setModePersist("en")} className="font-body text-xs" style={mode === "en" ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>English</button>}
            {hasAr && hasEn && <button type="button" onClick={() => setModePersist("both")} className="font-body text-xs" style={mode === "both" ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 }}>AR EN</button>}
          </div>
          {/* حجم الخط — A A A A A بأحجام مختلفة، بلا إطارات */}
          <div className="flex items-center gap-3">
            <span className="text-muted-foreground text-xs">{isAr ? "حجم الخط" : "Font size"}</span>
            {[13, 16, 19, 22, 26].map((sz, i) => (
              <button key={sz} type="button" onClick={() => setFont(sz)} className="font-body leading-none hover:opacity-70"
                style={{ fontSize: 12 + i * 3, color: "var(--brand)", fontWeight: font === sz ? 700 : 400, opacity: font === sz ? 1 : 0.5 }}>A</button>
            ))}
          </div>
          {/* لون المدخل — قلوب، الأول الحاليّ افتراضيّ (كرئيسية الموسوعة) */}
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-muted-foreground text-xs">{isAr ? "لون المدخل" : "Entry Color"}</span>
            <AccentHearts value={encAccent} onPick={setEncAccent} colors={ENC_ACCENTS} size={18} />
          </div>
          {/* تعديل المدخل — منقول من الأعلى */}
          <button type="button" onClick={() => navigate(`/encyclopedia/entry/${entry.id}`)} aria-label={isAr ? "تعديل المدخل" : "Edit entry"} title={isAr ? "تعديل المدخل" : "Edit entry"} className="inline-flex items-center hover:opacity-70" style={{ color: "var(--brand)" }}><Pencil className="w-4 h-4" /></button>
        </div>
      )}
      {showExp && (() => {
        const reactLabels = { favorite: isAr ? "مفضّل" : "Favourite", like: isAr ? "إعجاب" : "Like", dislike: isAr ? "عدم إعجاب" : "Dislike", wtf: "WTF", castaway: isAr ? "إبعاد" : "Cast away" };
        const exportOpts = () => {
          const mergeTitle = expSettings.titleMerge !== false; // افتراضي: دمج
          const dupAr = mergeTitle && arTitle && arBody && arBody.trim().startsWith(arTitle.trim());
          const dupEn = mergeTitle && enTitle && enBody && enBody.trim().startsWith(enTitle.trim());
          return ({
          lang: expLang, isAr,
          titleAr: dupAr ? "" : (arTitle || ""), titleEn: dupEn ? "" : (enTitle || ""), bodyAr: arBody || "", bodyEn: enBody || "",
          reactionLabel: (myReaction && myReaction !== "none") ? (reactLabels[myReaction] || "") : "",
          comment: myThought || "",
          personName: names[activePerson], personColor: profiles[activePerson]?.color,
          fontPx: expFontPx, theme: expTheme, images: Array.isArray(entry.images) ? entry.images : [],
          bg: expSettings.exportBg, fontColor: expSettings.exportFontColor, accent: expSettings.exportAccent, bold: !!expSettings.exportBold,
          include: expInc,
          orientation: expShape,
          fields: { year: entry.year, pronunciation: entry.pronunciation, explain: entry.explain, source: entry.source, refs: entry.refs, tags: entry.tags },
        }); };
        const doExportImage = async () => { try { await exportEntryImage(exportOpts()); } catch { /* غير حرِج */ } };
        const doExportPdf = async () => { try { await exportEntryPdf(exportOpts()); } catch { /* غير حرِج */ } };
        const doPreview = async () => { try { setExpPreview(await previewEntryImage(exportOpts())); } catch { /* غير حرِج */ } };
        const onCss = (a) => a ? { color: "var(--brand)", fontWeight: 700 } : { color: "var(--brand)", opacity: 0.5 };
        const Chk = ({ k, ar, en }) => (
          <button type="button" onClick={() => toggleInc(k)} className="font-body text-xs hover:opacity-70" style={{ color: "var(--brand)", fontWeight: expInc[k] ? 700 : 400, opacity: expInc[k] ? 1 : 0.45 }}>{isAr ? ar : en}</button>
        );
        const hasFields = entry.year || entry.pronunciation || entry.explain || entry.source || entry.refs || entry.tags;
        return (
        <div className="space-y-3 text-sm font-body pt-1" dir={isAr ? "rtl" : "ltr"}>
          <button type="button" onClick={copyContent} className="inline-flex items-center gap-1.5 hover:opacity-70" style={{ color: "var(--brand)" }}><Copy className="w-4 h-4" />{isAr ? "نسخ القصة" : "Copy story"}</button>
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-muted-foreground text-xs">{isAr ? "اللغة" : "Language"}</span>
            {hasAr && <button type="button" onClick={() => setExpLang("ar")} className="font-body text-xs" style={onCss(expLang === "ar")}>عربية</button>}
            {hasEn && <button type="button" onClick={() => setExpLang("en")} className="font-body text-xs" style={onCss(expLang === "en")}>English</button>}
            {hasAr && hasEn && <button type="button" onClick={() => setExpLang("both")} className="font-body text-xs" style={onCss(expLang === "both")}>{isAr ? "مدمج" : "Merged"}</button>}
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-muted-foreground text-xs">{isAr ? "العنوان" : "Title"}</span>
            <button type="button" onClick={() => updExpColor("titleMerge", true)} className="font-body text-xs" style={onCss(expSettings.titleMerge !== false)}>{isAr ? "دمج" : "Merge"}</button>
            <button type="button" onClick={() => updExpColor("titleMerge", false)} className="font-body text-xs" style={onCss(expSettings.titleMerge === false)}>{isAr ? "لا دمج" : "Separate"}</button>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-muted-foreground text-xs">{isAr ? "حجم الخط" : "Font size"}</span>
            {[15, 17, 19, 22, 25].map((sz, i) => (
              <button key={sz} type="button" onClick={() => setExpFontPx(sz)} className="font-body leading-none hover:opacity-70" style={{ fontSize: 12 + i * 3, color: "var(--brand)", fontWeight: expFontPx === sz ? 700 : 400, opacity: expFontPx === sz ? 1 : 0.5 }}>A</button>
            ))}
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-muted-foreground text-xs">{isAr ? "نوع الخط" : "Font"}</span>
            {ENC_FONT_THEMES.map((t) => (
              <button key={t.id} type="button" onClick={() => setExpTheme(t)} className="font-body text-xs" style={onCss(expTheme.id === t.id)}>{isAr ? t.ar : t.en}</button>
            ))}
          </div>
          <div className="flex items-center gap-5 flex-wrap">
            <label className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">{isAr ? "الخلفية" : "Background"}<input type="color" value={expSettings.exportBg || "#ffffff"} onChange={(e) => updExpColor("exportBg", e.target.value)} className="w-7 h-7 p-0 bg-transparent border-0 cursor-pointer" /></label>
            <label className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">{isAr ? "لون الخط" : "Font Color"}<input type="color" value={expSettings.exportFontColor || "#1c1917"} onChange={(e) => updExpColor("exportFontColor", e.target.value)} className="w-7 h-7 p-0 bg-transparent border-0 cursor-pointer" /></label>
            <label className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">{isAr ? "لون العنوان" : "Title Color"}<input type="color" value={expSettings.exportAccent || "#a16207"} onChange={(e) => updExpColor("exportAccent", e.target.value)} className="w-7 h-7 p-0 bg-transparent border-0 cursor-pointer" /></label>
          </div>
          {/* ألوان سريعة موحّدة — قلوب، للعنوان و للخط (نفس لوحة الموسوعة) */}
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-muted-foreground text-xs">{isAr ? "لون العنوان" : "Title"}</span>
            <AccentHearts value={expSettings.exportAccent} onPick={(c) => updExpColor("exportAccent", c)} colors={ENC_ACCENTS_SOLID} size={17} />
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <span className="text-muted-foreground text-xs">{isAr ? "لون الخط" : "Font"}</span>
            <AccentHearts value={expSettings.exportFontColor} onPick={(c) => updExpColor("exportFontColor", c)} colors={ENC_ACCENTS_SOLID} size={17} />
            <button type="button" onClick={() => updExpColor("exportFontColor", "#1c1917")} className="font-body text-xs hover:opacity-70" style={{ color: "#1c1917", fontWeight: 400 }}>{isAr ? "داكن" : "Dark"}</button>
            <button type="button" onClick={() => updExpColor("exportBold", !expSettings.exportBold)} className="font-body text-xs hover:opacity-70" style={{ color: "var(--brand)", fontWeight: expSettings.exportBold ? 700 : 400, opacity: expSettings.exportBold ? 1 : 0.5 }}>{isAr ? "عريض" : "Bold"}</button>
          </div>
          {/* خيارات اختيارية: مدخلات المستخدم + علامته */}
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-muted-foreground text-xs">{isAr ? "يتضمّن" : "Include"}</span>
            <Chk k="entries" ar="مدخلات المستخدم" en="User entries" />
            <Chk k="mark" ar="علامة المستخدم" en="User mark" />
          </div>
          {/* خيار لكل حقل إضافي */}
          {hasFields && (
            <div className="flex items-center gap-4 flex-wrap">
              <span className="text-muted-foreground text-xs">{isAr ? "حقول إضافية" : "Extra fields"}</span>
              {entry.year ? <Chk k="year" ar="السنة" en="Year" /> : null}
              {entry.pronunciation ? <Chk k="pronunciation" ar="النطق" en="Pronunciation" /> : null}
              {entry.explain ? <Chk k="explain" ar="إشارات" en="References" /> : null}
              {entry.source ? <Chk k="source" ar="المصدر" en="Source" /> : null}
              {entry.refs ? <Chk k="refs" ar="ملاحظات" en="Notes" /> : null}
              {entry.tags ? <Chk k="tags" ar="وسوم" en="Tags" /> : null}
            </div>
          )}
          {/* شكل البطاقة و سقف الحجم: طوليّ/عرضيّ ≤2048 · مربّع 1024 (PDF يخرج A4) */}
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-muted-foreground text-xs">{isAr ? "شكل البطاقة" : "Card shape"}</span>
            <button type="button" onClick={() => setExpShape("portrait")} className="font-body text-xs hover:opacity-70" style={onCss(expShape === "portrait")}>{isAr ? "طوليّ" : "Portrait"}</button>
            <button type="button" onClick={() => setExpShape("landscape")} className="font-body text-xs hover:opacity-70" style={onCss(expShape === "landscape")}>{isAr ? "عرضيّ" : "Landscape"}</button>
            <button type="button" onClick={() => setExpShape("square")} className="font-body text-xs hover:opacity-70" style={onCss(expShape === "square")}>{isAr ? "مربّع ١٠٢٤" : "Square 1024"}</button>
          </div>
          {/* معاينة مصغّرة قبل التصدير */}
          {expPreview && <img src={expPreview} alt="" className="w-full max-w-[230px] h-auto" style={{ background: expSettings.exportBg || "#fff" }} />}
          <div className="flex items-center gap-5 pt-1">
            <button type="button" onClick={doPreview} className="font-body text-xs hover:opacity-70" style={{ color: "var(--brand)" }}>{isAr ? "معاينة" : "Preview"}</button>
            <button type="button" onClick={doExportImage} className="inline-flex items-center gap-1.5 font-semibold hover:opacity-70" style={{ color: "var(--brand)" }}><Download className="w-4 h-4" />تصدير Export</button>
            <button type="button" onClick={doExportPdf} className="font-body text-xs hover:opacity-70" style={{ color: "var(--brand)" }}>PDF A4</button>
          </div>
        </div>
        );
      })()}

    </div>
  );
}
