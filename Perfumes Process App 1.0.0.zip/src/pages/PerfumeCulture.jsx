import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Copy, Check, Edit2, Save, X, RotateCcw } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";

/**
 * Culture, Rules & Courtesy
 *
 * Bilingual page — both English and Arabic shown together in every section,
 * regardless of the app's UI language. Title and headings appear in both.
 *
 * Sections (in order):
 *   1. Comments (تعليقات)
 *      - User-editable; persisted to localStorage
 *      - Bilingual; bullets use a small square mark
 *   2. Perfume Culture (ثقافة العطور)
 *   3. How to Wear Perfume (كيفية ارتداء العطر)
 *   4. When to Wear Different Fragrances (متى ترتدي عطوراً مختلفة)
 *   5. Where NOT to Wear Strong Perfume (حيث لا تضع عطراً قوياً)
 *
 * Comments are authored by the user locally; the page ships with no preset content.
 */

// ── Square bullet ───────────────────────────────────────────────────────
function Square({ color = "#10b981", solid = true }) {
  return (
    <span
      aria-hidden
      style={{
        display: "inline-block",
        width: 8,
        height: 8,
        background: solid ? color : "transparent",
        border: `1.5px solid ${color}`,
        flexShrink: 0,
        marginTop: 8,
        marginInlineEnd: 10,
        verticalAlign: "top",
      }}
    />
  );
}



const STORAGE_KEY = "processapp.perfumeCulture.userComments";

function loadUserComments() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function saveUserComments(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // ignore quota errors
  }
}

// ── Page ──────────────────────────────────────────────────────────────────
export default function PerfumeCulture() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  // ── Comments (editable) ──
  const [editing, setEditing] = useState(false);
  const [copied, setCopied] = useState(false);
  const initial = useMemo(() => loadUserComments(), []);
  const [commentsAr, setCommentsAr] = useState(initial?.ar?.join("\n\n") || "");
  const [commentsEn, setCommentsEn] = useState(initial?.en?.join("\n\n") || "");

  // Convert text-block to array (split by blank lines)
  const arItems = useMemo(() => commentsAr.split(/\n\s*\n/).map((s) => s.trim()).filter(Boolean), [commentsAr]);
  const enItems = useMemo(() => commentsEn.split(/\n\s*\n/).map((s) => s.trim()).filter(Boolean), [commentsEn]);

  const handleSave = () => {
    saveUserComments({ ar: arItems, en: enItems });
    setEditing(false);
    toast.success(isAr ? "تم الحفظ" : "Saved");
  };

  const handleReset = () => {
    if (!confirm(isAr ? "مسح ملاحظاتك؟" : "Clear your notes?")) return;
    setCommentsAr("");
    setCommentsEn("");
    localStorage.removeItem(STORAGE_KEY);
    toast.success(isAr ? "تم المسح" : "Cleared");
  };

  const handleCopy = async () => {
    // Plain-text bilingual export — paste-friendly in any app.
    const lines = [];
    lines.push("Your Notes and Ideas — ملاحظاتك و أفكارك");
    lines.push("");
    const max = Math.max(arItems.length, enItems.length);
    for (let i = 0; i < max; i++) {
      if (enItems[i]) lines.push("■ " + enItems[i]);
      if (arItems[i]) lines.push("■ " + arItems[i]);
      lines.push("");
    }
    try {
      await navigator.clipboard.writeText(lines.join("\n"));
      setCopied(true);
      toast.success(isAr ? "تم النسخ" : "Copied");
      setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error(isAr ? "فشل النسخ" : "Copy failed");
    }
  };

  // ── Bilingual section helper ──
  // Renders a card with English heading + Arabic heading on top, then EN paragraph + AR paragraph
  const Section = ({ headingEn, headingAr, paraEn, paraAr }) => {
    const toParas = (p) => (Array.isArray(p) ? p : [p]);
    return (
      <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
        <div className="space-y-1">
          <h2 className="font-heading font-semibold text-lg" dir="ltr">{headingEn}</h2>
          <h2 className="font-heading font-semibold text-lg text-foreground/90" dir="rtl">{headingAr}</h2>
        </div>
        <div className="space-y-3">
          {toParas(paraEn).map((p, i) => (
            <p key={`en${i}`} className="text-sm font-body text-foreground/80 leading-relaxed" dir="ltr">{p}</p>
          ))}
          {toParas(paraAr).map((p, i) => (
            <p key={`ar${i}`} className="text-sm font-body text-foreground/80 leading-relaxed" dir="rtl">{p}</p>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="relative bg-gradient-to-br from-blue-50 dark:from-blue-950/20 to-blue-100 dark:to-blue-900/20 px-5 page-top pb-8">
        <Button variant="secondary" size="icon" className="rounded-none shadow-md mb-4" onClick={() => navigate("/perfumes")}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex items-start gap-4">
          {/* Perfume-bottle icon — kept as-is */}
          <div className="w-20 h-20 rounded-none bg-card shadow-lg flex items-center justify-center flex-shrink-0">
            <span style={{ fontSize: 38, lineHeight: 1 }}>🧴</span>
          </div>
          <div className="flex-1 min-w-0">
            {/* Bilingual title — both languages always shown */}
            <h1 className="font-heading text-2xl font-bold leading-tight" dir="ltr">
              Culture, Rules &amp; Courtesy
            </h1>
            <h1 className="font-heading text-xl font-bold leading-tight text-foreground/80 mt-0.5" dir="rtl">
              الثقافة، القواعد و اللباقة
            </h1>
            <p className="text-xs text-muted-foreground font-body mt-2" dir="ltr">
              Understanding perfume etiquette and cultural significance &nbsp;&nbsp; فهم آداب العطور و دلالاتها الثقافية
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 space-y-5 mt-5">
        {/* ─── 1. Comments تعليقات ─── */}
        <div className="bg-card rounded-none p-5 shadow-sm space-y-4">
          {/* Heading row + actions */}
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div className="space-y-0.5">
              <h2 className="font-heading font-semibold text-lg" dir="ltr">{isAr ? "نوتاتك و أفكارك" : "Your Notes and Ideas"}</h2>
              <h2 className="font-heading font-semibold text-lg text-foreground/90" dir="rtl">ملاحظاتك و أفكارك</h2>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={handleCopy}
                className="flex items-center gap-1.5 rounded-none text-foreground/80 text-xs font-body transition-colors"
                title={isAr ? "نسخ" : "Copy"}
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{isAr ? "نسخ" : "Copy"}</span>
              </button>
              {!editing && (
                <button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="flex items-center gap-1.5 rounded-none text-foreground/80 text-xs font-body transition-colors"
                  title={isAr ? "تعديل" : "Edit"}
                >
                  <Edit2 className="w-3.5 h-3.5" />
                  <span>{isAr ? "تعديل" : "Edit"}</span>
                </button>
              )}
              {editing && (
                <>
                  <button
                    type="button"
                    onClick={handleSave}
                    className="flex items-center gap-1.5 rounded-none text-primary-foreground text-xs font-body transition-colors"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isAr ? "حفظ" : "Save"}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditing(false)}
                    className="flex items-center gap-1.5 rounded-none text-foreground/80 text-xs font-body transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                    <span>{isAr ? "إلغاء" : "Cancel"}</span>
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={handleReset}
                className="flex items-center gap-1.5 rounded-none text-muted-foreground text-xs font-body transition-colors"
                title={isAr ? "استعادة" : "Reset"}
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {editing ? (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">English (separate items with a blank line)</label>
                <textarea name="PerfumeCulture-tex1"
                  value={commentsEn}
                  onChange={(e) => setCommentsEn(e.target.value)}
                  placeholder={isAr ? "أضف نوتاتك" : "Add Your Notes"}
                  className="w-full rounded-none border border-border bg-background p-3 font-body text-xs leading-relaxed resize-y min-h-[200px]"
                  dir="ltr"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">العربية (افصل بين البنود بسطر فارغ)</label>
                <textarea name="PerfumeCulture-tex2"
                  value={commentsAr}
                  onChange={(e) => setCommentsAr(e.target.value)}
                  placeholder="اضف ملاحظاتك"
                  className="w-full rounded-none border border-border bg-background p-3 font-body text-sm leading-relaxed resize-y min-h-[200px]"
                  dir="rtl"
                />
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              {(enItems.length === 0 && arItems.length === 0) ? (
                <button
                  type="button"
                  onClick={() => setEditing(true)}
                  className="w-full text-center py-8 text-sm font-body text-muted-foreground hover:text-foreground transition-colors"
                >
                  {isAr ? 'اضف ملاحظاتك' : 'Add Your Notes'}
                </button>
              ) : (
              /* Render up to max(en, ar) length, pairing each item EN/AR with a diamond bullet */
              <ul className="space-y-4 list-none p-0 m-0">
                {Array.from({ length: Math.max(enItems.length, arItems.length) }).map((_, i) => (
                  <li key={i} className="space-y-1.5">
                    {enItems[i] && (
                      <div className="flex items-start" dir="ltr">
                        <Square color="#10b981" solid />
                        <p className="text-sm font-body text-foreground/85 leading-relaxed flex-1">
                          {enItems[i]}
                        </p>
                      </div>
                    )}
                    {arItems[i] && (
                      <div className="flex items-start" dir="rtl">
                        <Square color="#10b981" solid={false} />
                        <p className="text-sm font-body text-foreground/85 leading-relaxed flex-1">
                          {arItems[i]}
                        </p>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
              )}
            </div>
          )}
        </div>

        {/* ─── 2. Courtesy ─── */}
        <Section
          headingEn="Courtesy"
          headingAr="اللباقة"
          paraEn={["A perfume is worn on the body, but it lives in the air around you — and that air belongs to everyone in the room. The first elegance of fragrance is not the scent itself but the consideration with which you wear it. To perfume yourself elegantly is also to perfume yourself kindly: close enough to be discovered, never so much as to be imposed.", "And there are places where it is gentler to arrive almost unscented — where the air is shared closely, where some cannot simply step away, and where a strong perfume may bring others discomfort rather than delight. Among them: hospitals and clinics, where many are unwell and sensitive; gyms and sports clubs, where breath runs deep and fast; offices and shared workplaces, where people sit together for hours; and mosques, churches, and places of worship, where stillness and closeness are part of the grace. In such spaces, the kindest perfume is a quiet one — or none at all."]}
          paraAr={["العطر يُلبَس على الجسد، لكنه يعيش في الهواء من حولك — و هذا الهواء ملك لكل من في المكان. أول أناقة في العطر ليست الرائحة نفسها بل اللطف الذي ترتديها به. أن تتعطر بأناقة هو أيضا أن تتعطر برفق: قريبا بما يكفي ليُكتشَف، لا كثيرا حتى يُفرَض.", "و ثمة أماكن يكون الأرفق أن تصل إليها بلا عطر يُذكَر — حيث الهواء مشترك عن قرب، و حيث لا يستطيع بعضهم أن ينصرف ببساطة، حيث قد يجلب العطر القوي للآخرين ضيقا لا متعة. منها: المستشفيات و العيادات، يكون كثيرون مرضى و لديهم حساسية الجيوب الأنفية؛ النوادي الرياضية، حيث النفَس عميق و سريع؛ المكاتب و أماكن العمل المشتركة، حيث يجلس الناس معا ساعات؛ المساجد و الكنائس و دور العبادة، حيث السكون و القرب جزء من الجلال. في مثل هذه الأماكن، أرحم العطر أهدؤه — أو لا عطر أفضل بكثير."]}
        />

        {/* ─── 3. Etiquette ─── */}
        <Section
          headingEn="Etiquette"
          headingAr="الإتيكيت"
          paraEn={["How. Apply to the warm pulse points — wrists, the base of the neck, behind the ears — and let the body's heat lift the scent gently; never rub the wrists together, for it bruises the delicate top notes. One or two sprays, not five: you should be the last to stop noticing your own perfume, not the first.", "When. Perfume yourself a little before you leave, so the sharpest opening has settled by the time you meet others, and the fragrance greets them softened and warm.", "What is preferred. Lighter, fresher scents by day and in the heat; richer, deeper ones by evening and in the cool. And always the quiet rule: an arm's length is the right reach of a perfume — felt by those you welcome close, unnoticed by those who merely pass."]}
          paraAr={["كيف. ضع العطر على مواضع النبض الدافئة — الرسغين، أسفل العنق، خلف الأذنين — و دع حرارة الجسد ترفع الرائحة برفق؛ و لا تفرك الرسغين معا فذلك يهشّم النوتات العليا الرقيقة. رشّة أو رشّتان لا خمس: ينبغي أن تكون آخر من يكفّ عن الإحساس بعطره لا أولهم.", "متى. تعطّر قبيل خروجك بقليل، كي تكون أحدّ بداية للعطر قد هدأت حين تلتقي الناس، فيستقبلهم العطر لينا دافئا.", "ما يُفضَّل. العطور الأخف و الأنعش نهارا و في الحر؛ و الأغنى و الأعمق مساء و بالبرد. و دائما تلك القاعدة الهادئة: مدى الذراع هو المدى الصحيح للعطر — يحسّه من تقرّبهم إليك، و لا ينتبه له العابرون."]}
        />

        {/* ─── 4. What troubles others ─── */}
        <Section
          headingEn="What troubles others"
          headingAr="ما يزعج الآخرين"
          paraEn="It helps to understand why a strong scent troubles some people, for the discomfort is real and not mere fussiness. A heavy fragrance can bring on headaches, a tightness in the chest, or a wave of nausea in those who are sensitive — and, importantly, the reaction is not always immediate. Some materials, especially the dense oily attars and concentrated oud oils, can sit lightly at first and then, an hour or more later, settle into a dull headache or a faint, draining unease, as the heaviest molecules linger and the nervous system tires of them. Because the effect can arrive so late, the wearer rarely connects it to their perfume at all. So the gentlest measure is simply restraint: a smaller dose, a lighter concentration, and the awareness that what feels lovely to you at the first spray may quietly weigh on someone beside you an hour from now."
          paraAr="يعين أن تفهم لماذا يزعج العطر القوي بعض الناس، فالضيق حقيقي لا تدلّلا. قد تجلب الرائحة الثقيلة صداعا، أو ضيقا في الصدر، أو موجة غثيان لدى الحساسين — و الأهم أن ردّ الفعل ليس دائما فوريا. بعض المواد، خاصة الأدهان الزيتية الكثيفة و زيوت العود المركّزة، قد تبدو خفيفة أول الأمر، ثم بعد ساعة أو أكثر تستقر صداعا خفيفا أو تعبا غامضا يسحب الطاقة، إذ تتباطأ أثقل الجزيئات و يملّ منها الجهاز العصبي. و لأن الأثر قد يأتي متأخرا، نادرا ما يربطه صاحب العطر بعطره أصلا. فأرفق التدابير هو ببساطة الاعتدال: جرعة أقل، و تركيز أخف، و وعي بأن ما يبدو لك جميلا عند أول رشّة قد يثقل بهدوء على من بجانبك بعد ساعة."
        />

        {/* ─── 5. Perfume Culture ─── */}
        <Section
          headingEn="Perfume Culture"
          headingAr="ثقافة العطور"
          paraEn="Perfume is one of the oldest of human arts, and one of the very few you wear. Long before it was a luxury, it was a language — of welcome and of mourning, of devotion and of desire. Cultures have prayed in smoke, anointed their dead in resin, and signed their letters in scent. To learn perfume is to learn a quiet history of how people have wished to be remembered: not by how they looked, but by the trace they left in the air when they walked out of a room."
          paraAr="العطر من أقدم فنون الإنسان، و من القليل النادر الذي يُلبَس. قبل أن يكون ترفا بزمن طويل، كان لغة — للترحيب و للحزن، و للتعبّد و للرغبة. صلّت الحضارات في الدخان، و حنّطت موتاها بالراتنج، و وقّعت رسائلها برائحة. أن تتعلّم العطر هو أن تتعلّم تاريخا هادئا لكيف أراد الناس أن يُذكَروا: لا بما بدوا عليه، بل بالأثر الذي تركوه في الهواء حين غادروا الغرفة."
        />

        {/* ─── 6. How to Wear Perfume ─── */}
        <Section
          headingEn="How to Wear Perfume"
          headingAr="كيفية ارتداء العطر"
          paraEn="Wear perfume the way you would keep a secret: close to the skin, and meant first for you. Place it on the warm points where the blood runs near the surface — the wrists, the neck, behind the ears — and let your own heat carry it outward. Do not drown it; a fragrance is meant to be discovered, not announced. And let it become part of you: the finest way to wear a scent is to wear it until you barely notice it yourself, so that only those who come near are quietly reminded that you are there."
          paraAr="ارتدِ العطر كما تحفظ سرا: قريبا من البشرة، و مقصودا لك أولا. ضعه على المواضع الدافئة حيث يجري الدم قرب السطح — الرسغان، العنق، خلف الأذنين — ودع حرارتك تحمله إلى الخارج. لا تُغرِقه؛ فالعطر يُكتشَف و لا يُعلَن. و دعه يصير جزءا منك: أجمل طريقة لارتداء رائحة أن تلبسها حتى تكاد لا تحسّها أنت، فلا يتذكّر وجودك بهدوء إلا من يقترب منك."
        />

        {/* ─── 7. When to Wear Different Fragrances ─── */}
        <Section
          headingEn="When to Wear Different Fragrances"
          headingAr="متى ترتدي عطورا مختلفة"
          paraEn="A fragrance keeps time with the day and the season. Morning and heat ask for lightness: citrus, green, cool water — everything that lifts. Evening and cold welcome weight: amber, wood, spice — everything that glows. Wear something bright and clean to work, something quieter to grief, something warm and close for those you love. A perfume wardrobe is not vanity; it is the simple wisdom that you are not the same person at dawn that you are at midnight — and your scent can keep you honest company through both."
          paraAr="العطر يضبط إيقاعه مع النهار و الفصل. الصباح و الحر يطلبان الخفّة: الحمضيات، و الأخضر، و الماء البارد — كل ما يرفع. المساء و البرد يرحّبان بالثقل: العنبر، الخشب، التوابل — كل ما يتوهّج. البَس شيئا مشرقا نقيا للعمل، و أهدأ للحزن، و أدفأ و أقرب لمن تحب. خزانة العطور ليست غرورا؛ بل حكمة بسيطة أنك لست في الفجر الشخص نفسه الذي أنت عليه في منتصف الليل — و لعطرك أن يرافقك بصدق في كليهما."
        />

        {/* ─── 8. Where NOT to Wear Strong Perfume ─── */}
        <Section
          headingEn="Where NOT to Wear Strong Perfume"
          headingAr="حيث لا تضع عطرا قويا"
          paraEn="There are rooms that ask for silence, and the same is true of scent. Reach for little or none where the air is shared and inescapable — a hospital bed, a crowded lift, an exam hall, a long flight, a small office, the closeness of worship. Reach for less where breath runs hard, as in a gym, and where food is the guest of honor, as at a fine table, for a heavy perfume can dull a meal as surely as it can crowd a prayer. Beneath all of these lies a single rule, and it is one of empathy: before the last spray, ask not whether you like it — but whether the person who cannot move away from you will."
          paraAr="ثمة غرف تطلب الصمت، و كذلك العطر. خفّف أو دع حيث الهواء مشترك و لا فكاك منه — سرير مستشفى، مصعد مكتظ، قاعة امتحان، رحلة طويلة، مكتب صغير، و قرب العبادة. و أقلِل حيث يشتدّ النفَس كالنادي الرياضي، و حيث يكون الطعام ضيف الشرف كمائدة فاخرة، فالعطر الثقيل يُفسد وجبة كما يزاحم صلاة. تحت هذا كله قاعدة منفردة، و هي رحمة: قبل الرشّة الأخيرة، لا تسأل هل يعجبك — بل هل سيعجب من لا يستطيع أن يبتعد عنك."
        />
      </div>
    </div>
  );
}
