import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ChevronDown } from "lucide-react";
import { toast } from "sonner";
import BackButton from "@/components/shared/BackButton";
import SearchableEntityPicker from "@/components/blog/SearchableEntityPicker";
import MediaSection from "@/components/blog/MediaSection";
import { usePersonNames } from "@/lib/usePersonNames";
import { useLang } from "@/lib/LanguageContext";

// صفحة منفردة لإضافة/تعديل التدوينة بدل المنبثقة (تحرير الجوال أدقّ).
// نفس نموذج المنبثقة السابق حرفياً + سقف خمس صور في الوسائط.
const ENTRY_TYPES = [
  { val: "not_set", label: "Not Set", color: "bg-gray-500" },
  { val: "perfume", label: "🌹 Perfume", color: "bg-rose-500" },
  { val: "music", label: "🎵 Music", color: "bg-indigo-500" },
  { val: "tv", label: "📺 TV", color: "bg-cyan-500" },
  { val: "films", label: "🎬 Films", color: "bg-red-500" },
  { val: "idea", label: "💡 Idea", color: "bg-yellow-500" },
  { val: "poetry", label: "✍️ Poetry", color: "bg-rose-500" },
  { val: "thought", label: "💭 Thought", color: "bg-blue-500" },
  { val: "knowledge", label: "🧠 Knowledge", color: "bg-amber-500" },
  { val: "concept", label: "🔮 Concept", color: "bg-purple-500" },
];

const EMPTY_FORM = {
  title: "", body: "", person: "person1", entry_type: "", tags: "",
  media_urls: "", media_links: "",
  linked_perfume_id: "", linked_perfume_name: "",
  linked_brand_id: "", linked_brand_name: "",
  linked_perfumer_id: "", linked_perfumer_name: "",
  linked_notes: "",
};

const MAX_IMAGES = 5;
const countMedia = (s) => String(s || "").split(",").map((x) => x.trim()).filter(Boolean).filter((x) => !/^data:[^,]*;base64$/i.test(x)).length;

export default function BlogEdit() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { names } = usePersonNames();
  const [params] = useSearchParams();
  const id = params.get("id") || "";
  const isEdit = !!id;
  const [showLinks, setShowLinks] = useState(false);

  const { data: post, isLoading } = useQuery({
    queryKey: ["blog-edit", id],
    queryFn: () => apphost.entities.BlogPost.get(Number(id)),
    enabled: isEdit,
  });
  const { data: perfumers = [] } = useQuery({ queryKey: ["perfumers-all"], queryFn: () => apphost.entities.Perfumer.list("-created_date") });
  const { data: notes = [] } = useQuery({ queryKey: ["notes-all"], queryFn: () => apphost.entities.PerfumeNote.list("name") });

  const [form, setForm] = useState(isEdit ? null : EMPTY_FORM);
  useEffect(() => {
    if (isEdit && post && !form) {
      const next = { ...EMPTY_FORM };
      Object.keys(EMPTY_FORM).forEach((k) => { next[k] = post[k] ?? EMPTY_FORM[k]; });
      setForm(next);
    }
  }, [post, isEdit]);  

  const f = (k, v) => {
    if (k === "media_urls" && countMedia(v) > MAX_IMAGES) {
      toast.error(isAr ? `الحدّ الأقصى ${MAX_IMAGES} وسائط` : `Maximum ${MAX_IMAGES} media items`);
      return;
    }
    setForm((prev) => ({ ...prev, [k]: v }));
  };

  const save = useMutation({
    mutationFn: () => {
      if (isEdit) return apphost.entities.BlogPost.update(post.id, { ...form });
      return apphost.entities.BlogPost.create({ ...form, is_user: true });
    },
    onSuccess: (rec) => {
      qc.invalidateQueries({ queryKey: ["blog-posts"] });
      toast.success(isEdit ? (isAr ? "تم الحفظ" : "Saved") : (isAr ? "نُشر المدخل" : "Published"));
      if (isEdit) navigate(`/blog-detail?id=${post.id}`, { replace: true });
      else navigate(rec?.id ? `/blog-detail?id=${rec.id}` : "/blog", { replace: true });
    },
    onError: () => toast.error(isAr ? "تعذّر الحفظ" : "Save failed"),
  });

  if (isEdit && (isLoading || !form)) {
    return <div className="px-5 page-top text-center text-sm font-body text-muted-foreground">{isAr ? "جارٍ التحميل…" : "Loading…"}</div>;
  }
  if (!form) return null;

  return (
    <div className="px-5 page-top pb-24 max-w-md mx-auto space-y-4" dir={isAr ? "rtl" : "ltr"}>
      <div className="flex items-center justify-between">
        <BackButton />
        <h1 className="font-heading text-lg font-semibold" style={{ color: "#b8960c" }}>
          {isEdit ? (isAr ? "تعديل التدوينة" : "Edit Entry") : (isAr ? "إضافة تدوينة" : "Add Entry")}
        </h1>
        <span className="w-8" />
      </div>

      <div className="space-y-3">
            {/* Type — multi-select */}
            <div className="grid grid-cols-3 gap-2">
              {ENTRY_TYPES.map(({ val, label, color }) => {
                const selected = (form.entry_type || "").split(",").map(t => t.trim()).includes(val);
                return (
                  <button key={val} onClick={() => {
                    const types = (form.entry_type || "").split(",").map(t => t.trim()).filter(Boolean);
                    if (types.includes(val)) {
                      f("entry_type", types.filter(t => t !== val).join(","));
                    } else {
                      f("entry_type", [...types, val].join(","));
                    }
                  }}
                    className={`py-2 rounded-none text-xs font-body font-medium transition-all ${selected ? `${color} text-white shadow` : "bg-secondary text-muted-foreground"}`}>
                    {label}
                  </button>
                );
              })}
            </div>

            <Input value={form.title} onChange={(e) => f("title", e.target.value)} placeholder={isAr ? "العنوان" : "Title"} className="rounded-none h-10 font-body text-sm" />
            <Textarea value={form.body} onChange={(e) => f("body", e.target.value)} placeholder={isAr ? "اكتب خواطرك" : "Write your thoughts"} className="rounded-none font-body text-sm min-h-[120px] resize-none" />
            <Input value={form.tags} onChange={(e) => f("tags", e.target.value)} placeholder={isAr ? "وسوم مفصولة بفاصلة" : "Tags (comma separated)"} className="rounded-none h-9 font-body text-xs" />

            {/* Author */}
            <div className="flex gap-2">
              <button onClick={() => f("person", "person1")}
                className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${form.person === "person1" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>
                {names.person1}
              </button>
              <button onClick={() => f("person", "person2")}
                className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${form.person === "person2" ? "bg-violet-500 text-white shadow" : "bg-secondary text-muted-foreground"}`}>
                {names.person2}
              </button>
            </div>

            {/* Media */}
             <MediaSection
               mediaUrls={form.media_urls}
               mediaLinks={form.media_links}
               onMediaUrlsChange={(v) => f("media_urls", v)}
               onMediaLinksChange={(v) => f("media_links", v)}
             />

             {/* Link Items */}
             <button
               type="button"
               onClick={() => setShowLinks(!showLinks)}
               className="w-full flex items-center justify-between px-1 py-2 hover:bg-secondary/30 transition-colors text-xs font-body font-medium"
             >
               <span>🔗 {isAr ? "ربط عناصر (براند، عطر، عطّار، نوتات)" : "Link Items (Brand, Perfume, Perfumer, Notes)"}</span>
               <ChevronDown className={`w-4 h-4 transition-transform ${showLinks ? "rotate-180" : ""}`} />
             </button>

             {showLinks && (
               <div className="space-y-2 p-1">
                 {/* Brand */}
                 <SearchableEntityPicker
                   label="Brand"
                   placeholder={isAr ? "ابحث عن براندات" : "Search brands"}
                   getLabel={(item) => item.name}
                   getValue={(item) => item.id}
                   searchFn={async (q) => {
                     const results = await apphost.entities.PerfumeBrand.filter({
                       $or: [
                         { name: { $regex: q, $options: "i" } },
                         { name_ar: { $regex: q, $options: "i" } },
                       ]
                     }, "name", 15);
                     return results.filter(b => b.name);
                   }}
                   selectedId={form.linked_brand_id}
                   selectedLabel={form.linked_brand_name}
                   onSelect={(id, name) => { f("linked_brand_id", id); f("linked_brand_name", name); }}
                   onClear={() => { f("linked_brand_id", ""); f("linked_brand_name", ""); }}
                 />

                 {/* Perfume */}
                 <SearchableEntityPicker
                   label="Perfume"
                   placeholder={isAr ? "ابحث عن عطر" : "Search perfumes"}
                   getLabel={(item) => `${item.name_en || item.name_ar || "??"} · ${item.brand_name || "??"}`}
                   getValue={(item) => item.id}
                   searchFn={async (q) => {
                     const results = await apphost.entities.Perfume.filter({ 
                       $or: [
                         { name_en: { $regex: q, $options: "i" } },
                         { name_ar: { $regex: q, $options: "i" } },
                         { brand_name: { $regex: q, $options: "i" } }
                       ]
                     }, "name_en", 15);
                     return results.filter(p => p.name_en || p.name_ar || p.brand_name);
                   }}
                   selectedId={form.linked_perfume_id}
                   selectedLabel={form.linked_perfume_name}
                   onSelect={(id, name) => { 
                     f("linked_perfume_id", id);
                     f("linked_perfume_name", name);
                   }}
                   onClear={() => { f("linked_perfume_id", ""); f("linked_perfume_name", ""); }}
                 />

                 {/* Perfumer */}
                 <SearchableEntityPicker
                   label="Perfumer"
                   placeholder={isAr ? "ابحث عن معطّرين" : "Search perfumers"}
                   getLabel={(item) => item.name}
                   getValue={(item) => item.id}
                   searchFn={async (q) => {
                     const ql = q.toLowerCase();
                     const filtered = perfumers.filter(p =>
                       p.name?.toLowerCase().includes(ql) ||
                       p.name_ar?.includes(q)
                     );
                     return filtered.slice(0, 15);
                   }}
                   selectedId={form.linked_perfumer_id}
                   selectedLabel={form.linked_perfumer_name}
                   onSelect={(id, name) => { f("linked_perfumer_id", id); f("linked_perfumer_name", name); }}
                   onClear={() => { f("linked_perfumer_id", ""); f("linked_perfumer_name", ""); }}
                 />

                 {/* Notes */}
                 <SearchableEntityPicker
                   label="Notes"
                   placeholder={isAr ? "ابحث عن نوتات" : "Search notes"}
                   getLabel={(item) => item.name}
                   getValue={(item) => item.name}
                   searchFn={async (q) => {
                     const ql = q.toLowerCase();
                     const filtered = notes.filter(n =>
                       n.name?.toLowerCase().includes(ql) ||
                       n.name_ar?.includes(q)
                     );
                     return filtered.slice(0, 15);
                   }}
                   isMulti={true}
                   currentValue={form.linked_notes}
                   onSelect={(value) => {
                     const current = form.linked_notes ? form.linked_notes.split(",").map(n => n.trim()).filter(Boolean) : [];
                     if (!current.includes(value)) {
                       f("linked_notes", [...current, value].join(", "));
                     }
                   }}
                   onRemove={(value) => {
                     const current = form.linked_notes ? form.linked_notes.split(",").map(n => n.trim()).filter(Boolean) : [];
                     f("linked_notes", current.filter(n => n !== value).join(", "));
                   }}
                 />
               </div>
             )}

             <Button
              className="w-full h-10 rounded-none font-body"
              onClick={() => save.mutate()}
              disabled={!form.title || !form.body || save.isPending}
            >
              {save.isPending ? (isAr ? "جارٍ الحفظ.." : "Saving..") : isEdit ? (isAr ? "حفظ التعديلات" : "Save changes") : (isAr ? "نشر التدوينة" : "Publish Entry")}
            </Button>
          </div>
    </div>
  );
}
