import { compareEnglish } from "@/lib/sortName";
import { useState, useMemo } from "react";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { useNavigate, useSearchParams } from "react-router-dom";
import { ArrowLeft, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { useLang } from "@/lib/LanguageContext";

const GOLD = "var(--brand)";
const NO_SEARCH_CAP = 200;

/**
 * NotesAccord — صفحة النوتات: بلا إطارات، بلا خلفيات، خلفية بيضاء.
 * فرز رباعي (الأكثر/الأقل/الأحدث/الأقدم)، تحليل تلقائي، ولون موحّد للصفحة (ذهبي).
 */
export default function NotesAccord() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [searchParams, setSearchParams] = useSearchParams();
  const urlNote = searchParams.get("noteSearch") || "";
  const [noteSearch, setNoteSearch] = useState(urlNote);
  const [activeNote, setActiveNote] = useState(urlNote || null);
  const [sortBy, setSortBy] = useState("most"); // "most" | "least" | "newest" | "oldest"
  const [loaded, setLoaded] = useState(!!urlNote); // تحميل كسول؛ يبدأ تلقائياً عند فتح برابط نوتة

  const { data: perfumes = [], isLoading } = useAllPerfumes("-created_date", { enabled: loaded });

  // أسماء النوتات + عدد العطور لكل نوتة + آخر تاريخ ظهور (لمعيار الأحدث/الأقدم).
  const { allNotes, noteCount, noteLastSeen } = useMemo(() => {
    const count = new Map();
    const lastSeen = new Map();
    for (const p of perfumes) {
      const set = new Set();
      for (const field of [p.top_notes, p.heart_notes, p.base_notes]) {
        if (!field) continue;
        for (const raw of String(field).split(",")) {
          const n = raw.trim();
          if (n) set.add(n);
        }
      }
      const ts = p.created_date ? new Date(p.created_date).getTime() : 0;
      for (const n of set) {
        count.set(n, (count.get(n) || 0) + 1);
        const prev = lastSeen.get(n) || 0;
        if (ts > prev) lastSeen.set(n, ts);
      }
    }
    const names = [...count.keys()].sort((a, b) => compareEnglish(a, b, 1));
    return { allNotes: names, noteCount: count, noteLastSeen: lastSeen };
  }, [perfumes]);

  // التحليل التلقائي — يُحتسب من كل النوتات (مرّة واحدة).
  const analysis = useMemo(() => {
    if (!allNotes.length) return null;
    const sortedByCount = [...allNotes].sort((a, b) => (noteCount.get(b) || 0) - (noteCount.get(a) || 0));
    const top3 = sortedByCount.slice(0, 3);
    const totalUsages = [...noteCount.values()].reduce((s, v) => s + v, 0);
    return {
      totalNotes: allNotes.length,
      totalUsages,
      avgPerPerfume: perfumes.length ? Math.round(totalUsages / perfumes.length) : 0,
      top3,
    };
  }, [allNotes, noteCount, perfumes.length]);

  const q = noteSearch.trim().toLowerCase();
  const matched = q ? allNotes.filter((n) => n.toLowerCase().includes(q)) : allNotes;

  const sorted = useMemo(() => {
    const arr = [...matched];
    if (sortBy === "most") arr.sort((a, b) => (noteCount.get(b) || 0) - (noteCount.get(a) || 0));
    else if (sortBy === "least") arr.sort((a, b) => (noteCount.get(a) || 0) - (noteCount.get(b) || 0));
    else if (sortBy === "newest") arr.sort((a, b) => (noteLastSeen.get(b) || 0) - (noteLastSeen.get(a) || 0));
    else if (sortBy === "oldest") arr.sort((a, b) => (noteLastSeen.get(a) || 0) - (noteLastSeen.get(b) || 0));
    return arr;
  }, [matched, sortBy, noteCount, noteLastSeen]);

  const filteredNotes = q ? sorted : sorted.slice(0, NO_SEARCH_CAP);
  const capped = !q && sorted.length > NO_SEARCH_CAP;

  const perfumesWithNote = useMemo(() => {
    if (!activeNote) return [];
    const target = activeNote.toLowerCase().trim();
    return perfumes.filter((p) =>
      [p.top_notes, p.heart_notes, p.base_notes, p.innovation_notes]
        .filter(Boolean)
        .some((field) =>
          String(field)
            .split(",")
            .map((n) => n.trim().toLowerCase())
            .some((n) => n === target || n.includes(target) || target.includes(n))
        )
    );
  }, [activeNote, perfumes]);

  const clearActive = () => {
    setActiveNote(null);
    if (searchParams.get("noteSearch")) {
      const next = new URLSearchParams(searchParams);
      next.delete("noteSearch");
      setSearchParams(next, { replace: true });
    }
  };

  const SORT_OPTIONS = [
    { id: "most",   en: "Most",   ar: "الأكثر" },
    { id: "least",  en: "Least",  ar: "الأقل" },
    { id: "newest", en: "Newest", ar: "الأحدث" },
    { id: "oldest", en: "Oldest", ar: "الأقدم" },
  ];

  return (
    <div className="px-5 page-top pb-24 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className={`flex items-center gap-2.5 ${isAr ? "flex-row-reverse" : ""}`}>
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity"
            title={isAr ? "رجوع" : "Back"}
          >
            <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} style={{ color: GOLD }} />
          </button>
          <h1 className="font-heading text-lg font-semibold" style={{ color: GOLD }}>
            {isAr ? "ممتزج" : "Blended"}
          </h1>
        </div>
        <SettingsSheet>
          <UserAvatarButton size={28} />
        </SettingsSheet>
      </div>

      {/* Search — نص واحد لكل لغة بلا أمثلة بين قوسين */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder={isAr ? "ابحث عن نوتة" : "Search notes"}
          value={noteSearch}
          onChange={(e) => { setLoaded(true); setNoteSearch(e.target.value); setActiveNote(null); }}
          className="pl-10 h-11 rounded-none font-body bg-transparent border-0 focus-visible:ring-1"
          style={{ boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.06)" }}
        />
      </div>

      {/* Sort buttons — أزرار نص فقط، بلا خلفية ولا إطار */}
      <div className="flex flex-wrap gap-x-5 gap-y-1">
        {SORT_OPTIONS.map((opt) => {
          const active = sortBy === opt.id;
          return (
            <button
              key={opt.id}
              onClick={() => { setLoaded(true); setSortBy(opt.id); }}
              className="text-xs font-body py-1 transition-opacity hover:opacity-70"
              style={{ color: GOLD, fontWeight: active ? 700 : 400, opacity: active ? 1 : 0.6 }}
            >
              {isAr ? opt.ar : opt.en}
            </button>
          );
        })}
      </div>

      {!loaded ? (
        <div className="text-center py-12 space-y-2">
          <p className="text-3xl">🌿</p>
          <p className="text-sm font-body text-muted-foreground">
            {isAr ? "اضغط فرزاً أو ابحث لعرض النوتات" : "Pick a sort or search to load notes"}
          </p>
        </div>
      ) : isLoading ? (
        <div className="text-center py-12 text-muted-foreground font-body text-sm">{isAr ? "جارٍ التحميل…" : "Loading…"}</div>
      ) : activeNote ? (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-sm font-body font-semibold" style={{ color: GOLD }}>{activeNote}</span>
              <span className="text-xs text-muted-foreground font-body">{perfumesWithNote.length} {isAr ? "عطر" : "perfumes"}</span>
            </div>
            <button onClick={clearActive} className="text-xs text-muted-foreground font-body hover:text-foreground">
              ✕ {isAr ? "مسح" : "Clear"}
            </button>
          </div>
          {perfumesWithNote.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground font-body py-8">{isAr ? "لا عطور" : "No perfumes found"}</p>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {perfumesWithNote.map((p) => <PerfumeCard key={p.id} perfume={p} />)}
            </div>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground font-body">
            {q
              ? `${matched.length} ${isAr ? "نوتة — اضغط للتصفح" : "notes found — tap to browse"}`
              : (isAr ? `${allNotes.length} نوتة — اكتب للبحث، أو اضغط أي نوتة` : `${allNotes.length} notes — search, or tap any note`)}
          </p>
          {/* قائمة النوتات — نصّ بلا خلفية بلا إطار، بلون الصفحة */}
          <div className="flex flex-wrap gap-x-4 gap-y-1">
            {filteredNotes.map((note) => (
              <button
                key={note}
                onClick={() => setActiveNote(note)}
                className="text-xs font-body py-1 hover:opacity-70 transition-opacity"
                style={{ color: GOLD }}
              >
                {note}
                <span className="text-[10px] text-muted-foreground ms-1">{noteCount.get(note) || 0}</span>
              </button>
            ))}
          </div>
          {capped && (
            <p className="text-center text-[11px] text-muted-foreground font-body py-2">
              {isAr ? "… والمزيد — ابحث لإيجاد نوتة محدّدة" : "… and more — search to find a specific note"}
            </p>
          )}
          {filteredNotes.length === 0 && (
            <p className="text-center text-sm text-muted-foreground font-body py-8">{isAr ? "لا نوتات" : "No notes found"}</p>
          )}
        </div>
      )}

      {/* Auto-analysis — سطر تحليل تلقائي مختصر، أسفل الصفحة */}
      {analysis && loaded && !isLoading && (
        <p className="text-[11px] font-body pt-2" style={{ color: GOLD }}>
          {isAr
            ? `${analysis.totalNotes} نوتة ${analysis.totalUsages} استخدام ${analysis.avgPerPerfume} نوتة/عطر الأكثر: ${analysis.top3.join("، ")}`
            : `${analysis.totalNotes} notes ${analysis.totalUsages} usages ${analysis.avgPerPerfume} per perfume top: ${analysis.top3.join(", ")}`}
        </p>
      )}
    </div>
  );
}
