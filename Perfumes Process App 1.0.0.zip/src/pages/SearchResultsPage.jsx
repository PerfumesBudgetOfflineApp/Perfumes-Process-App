import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Search } from "lucide-react";
import { apphost } from "@/api/apphostClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import ActivityTimeline from "@/components/home/ActivityTimeline";
import { useLang } from "@/lib/LanguageContext";
import { rankName } from "@/lib/sortName";
import { searchIndexReady, searchPerfumeIds } from "@/lib/searchIndex";

// resolver مصغّر لنص الاقتباس (جديد أو legacy text_enar)
function quoteTexts(x) {
  if (x?.text_en || x?.text_ar) return { en: x.text_en || "", ar: x.text_ar || "" };
  const raw = x?.text_enar || x?.text || ""; if (!raw) return { en: "", ar: "" };
  const m = raw.match(/^([^\u0600-\u06FF]*)([\u0600-\u06FF][\s\S]*)$/);
  if (m && m[1].trim()) return { en: m[1].trim(), ar: m[2].trim() };
  if (/[\u0600-\u06FF]/.test(raw)) return { en: "", ar: raw };
  return { en: raw, ar: "" };
}

/**
 * SearchResultsPage — صفحة نتائج بحث منفصلة، تُفتح عند ضغط «بحث» في الأقسام.
 * كلّ قسم بنمط صفحته: عطور (PerfumeCard) / براندات (صفوف) / نشاطات (ActivityTimeline).
 * العطور تُحلّ عبر فهرس البحث (searchPerfumeIds) ثمّ getMany — بلا تحميل الـ130 ألف.
 */
export default function SearchResultsPage() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const type = params.get("type") || "perfumes";
  const q = (params.get("q") || "").trim();
  const [box, setBox] = useState(q);

  const submit = () => {
    const s = box.trim();
    if (s) navigate(`/search-results?type=${type}&q=${encodeURIComponent(s)}`);
  };

  // ── عطور: عبر الفهرس (آمن) ثمّ احتياط بادئة الاسم ──
  const { data: perfumes = [], isLoading: pLoading } = useQuery({
    queryKey: ["search-perfumes", q],
    enabled: type === "perfumes" && !!q,
    queryFn: async () => {
      const t = q.toLowerCase();
      if (searchIndexReady()) {
        const { ids } = await searchPerfumeIds(t);
        if (ids && ids.length) return apphost.entities.Perfume.getMany(ids);
      }
      const prefix = String(rankName(t)) + t;
      const { items } = await apphost.entities.Perfume.pageByIndexRange(
        "sort_key", { lower: prefix, upper: prefix + "\uffff" }, 0, 100, "next", false
      );
      return items || [];
    },
    staleTime: 5 * 60 * 1000,
  });

  // ── براندات: قائمة صغيرة تُرشَّح بالذاكرة ──
  const { data: allBrands = [] } = useQuery({
    queryKey: ["search-brands"],
    enabled: type === "brands",
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
    staleTime: 5 * 60 * 1000,
  });
  const brands = useMemo(() => {
    const s = q.toLowerCase();
    if (!s) return [];
    return allBrands.filter((b) =>
      b && !b.hidden && (
        String(b.name || "").toLowerCase().includes(s) ||
        String(b.name_en || "").toLowerCase().includes(s) ||
        String(b.name_ar || "").includes(q) ||
        String(b.country || "").toLowerCase().includes(s) ||
        String(b.country_ar || "").includes(q)
      )
    );
  }, [allBrands, q]);

  // ── عطّارون / نوتات / اقتباسات: قوائم تُرشّح بالذاكرة ──
  const { data: allPerfumers = [] } = useQuery({
    queryKey: ["search-perfumers"], enabled: type === "perfumers",
    queryFn: () => apphost.entities.Perfumer.list("name"), staleTime: 5 * 60 * 1000,
  });
  const perfumers = useMemo(() => {
    const s = q.toLowerCase(); if (!s) return [];
    return allPerfumers.filter((x) => x && (String(x.name || "").toLowerCase().includes(s) || String(x.name_ar || "").includes(q) || String(x.nationality || "").toLowerCase().includes(s)));
  }, [allPerfumers, q]);

  const { data: allNotes = [] } = useQuery({
    queryKey: ["search-notes"], enabled: type === "notes",
    queryFn: () => apphost.entities.PerfumeNote.list("name"), staleTime: 5 * 60 * 1000,
  });
  const notes = useMemo(() => {
    const s = q.toLowerCase(); if (!s) return [];
    return allNotes.filter((n) => n && (String(n.name || "").toLowerCase().includes(s) || String(n.name_en || "").toLowerCase().includes(s) || String(n.name_ar || "").includes(q) || String(n.odor_family || "").toLowerCase().includes(s)));
  }, [allNotes, q]);

  const { data: allQuotes = [] } = useQuery({
    queryKey: ["search-quotes"], enabled: type === "quotes",
    queryFn: () => apphost.entities.Quote.list("-created_date"), staleTime: 5 * 60 * 1000,
  });
  const quotes = useMemo(() => {
    const s = q.toLowerCase(); if (!s) return [];
    return allQuotes.filter((x) => { const t = quoteTexts(x); return String(t.en).toLowerCase().includes(s) || String(t.ar).includes(q) || String(x.quoteauthor || x.author || "").toLowerCase().includes(s); });
  }, [allQuotes, q]);

  const titleMap = {
    brands: isAr ? "نتائج البراندات" : "Brand results",
    activities: isAr ? "نتائج النشاطات" : "Activity results",
    perfumers: isAr ? "نتائج العطّارين" : "Perfumer results",
    notes: isAr ? "نتائج النوتات" : "Note results",
    quotes: isAr ? "نتائج الاقتباسات" : "Quote results",
    perfumes: isAr ? "نتائج العطور" : "Perfume results",
  };
  const title = titleMap[type] || titleMap.perfumes;

  return (
    <div className="page-top pb-24">
      {/* رأس: رجوع + صندوق بحث */}
      <div className="px-5 pt-2 pb-3 space-y-3">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="rounded-none hover:bg-secondary/20" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="font-heading text-lg font-bold text-[var(--brand)]">{title}</h1>
        </div>
        <div className="relative">
          <Search className={`absolute ${isAr ? "right-3" : "left-3"} top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none`} />
          <Input
            value={box}
            onChange={(e) => setBox(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") submit(); }}
            placeholder=""
            dir={isAr ? "rtl" : "ltr"}
            className={`${isAr ? "pr-10" : "pl-10"} h-11 rounded-none font-body bg-[var(--page-bg,#fff)] border border-transparent`}
          />
        </div>
        {q && (
          <p className="text-xs text-muted-foreground font-body">
            {isAr ? "نتائج" : "Results for"} «{q}»
          </p>
        )}
      </div>

      {/* النتائج بنمط القسم */}
      {type === "perfumes" && (
        <div className="px-4 space-y-2">
          {pLoading ? (
            <div className="flex justify-center py-16">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : perfumes.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground font-body py-16">
              {isAr ? "لا عطور مطابِقة" : "No matching perfumes"}
            </p>
          ) : (
            perfumes.map((p) => <PerfumeCard key={p.id} perfume={p} />)
          )}
        </div>
      )}

      {type === "brands" && (
        <div className="px-4">
          {brands.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground font-body py-16">
              {isAr ? "لا براندات مطابِقة" : "No matching brands"}
            </p>
          ) : (
            brands.map((b) => (
              <Link key={b.id} to={`/brand?id=${b.id}`} className="block bg-card p-4 border-t border-b border-border">
                {b.name_ar && <p className="text-xs font-body text-[#9D174D]" dir="rtl">{b.name_ar}</p>}
                <p className="font-body font-semibold text-sm">{b.name_en || b.name}</p>
                {(b.country || b.country_ar) && (
                  <p className="text-xs text-muted-foreground font-body">{isAr ? (b.country_ar || b.country) : (b.country || b.country_ar)}</p>
                )}
              </Link>
            ))
          )}
        </div>
      )}

      {type === "activities" && (
        <div className="px-2">
          {q
            ? <ActivityTimeline searchQuery={q} />
            : <p className="text-center text-sm text-muted-foreground font-body py-16">{isAr ? "اكتب كلمة البحث" : "Type a search term"}</p>}
        </div>
      )}

      {type === "perfumers" && (
        <div className="px-4">
          {perfumers.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground font-body py-16">{isAr ? "لا عطّارين مطابِقين" : "No matching perfumers"}</p>
          ) : (
            perfumers.map((x) => (
              <Link key={x.id} to={`/perfumer?id=${x.id}`} className="block bg-card p-4 border-t border-b border-border">
                {x.name_ar && <p className="text-xs font-body text-[#9D174D]" dir="rtl">{x.name_ar}</p>}
                <p className="font-body font-semibold text-sm">{x.name_en || x.name}</p>
                {x.nationality && <p className="text-xs text-muted-foreground font-body">{x.nationality}</p>}
              </Link>
            ))
          )}
        </div>
      )}

      {type === "notes" && (
        <div className="px-4">
          {notes.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground font-body py-16">{isAr ? "لا نوتات مطابِقة" : "No matching notes"}</p>
          ) : (
            notes.map((n) => (
              <Link key={n.id} to={`/note?id=${n.id}`} className="flex items-center gap-3 bg-card p-3 border-t border-b border-border">
                {n.image_url && <img src={n.image_url} alt="" className="w-8 h-8 object-cover" />}
                <span className="min-w-0">
                  {n.name_ar && <span className="block text-xs font-body text-[#9D174D]" dir="rtl">{n.name_ar}</span>}
                  <span className="font-body text-sm">{n.name_en || n.name}</span>
                </span>
              </Link>
            ))
          )}
        </div>
      )}

      {type === "quotes" && (
        <div className="px-4 space-y-2">
          {quotes.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground font-body py-16">{isAr ? "لا اقتباسات مطابِقة" : "No matching quotes"}</p>
          ) : (
            quotes.map((x) => {
              const t = quoteTexts(x); const au = (x.quoteauthor || x.author || "").trim();
              return (
                <div key={x.id} className="bg-card p-4 border-t border-b border-border">
                  {t.ar && <p className="font-body text-sm" dir="rtl">{t.ar}</p>}
                  {t.en && <p className="font-body text-sm text-muted-foreground">{t.en}</p>}
                  {au && <p className="text-xs text-[var(--brand)] font-body mt-1">— {au}</p>}
                </div>
              );
            })
          )}
        </div>
      )}
    </div>
  );
}
