import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import BackButton from "@/components/shared/BackButton";
import ImagesField from "@/components/shared/ImagesField";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";

const GOLD = "#b8960c";

// صفحة منفردة لإضافة/تعديل: اقتباس، حكمة، رمزية — بدل المنبثقات (تحرير الجوال أدقّ)،
// مع صور حتى خمس لكلّ مدخل.
const TYPES = {
  quote: {
    entity: "Quote",
    title: ["Quote", "اقتباس"],
    fields: [
      { key: "text_en", label: ["English", "إنجليزي"], textarea: true, dir: "ltr", ph: ["English quote", "اقتباس بالإنجليزية"] },
      { key: "text_ar", label: ["Arabic", "العربية"], textarea: true, dir: "rtl", ph: ["", "النص العربي"] },
      { key: "category", label: ["Category", "التصنيف"], dir: "auto", ph: ["Inspiration إلهام", "Inspiration إلهام"] },
      { key: "quoteauthor", label: ["Author (optional)", "القائل (اختياري)"], dir: "auto", ph: ["Author name", "اسم القائل"] },
    ],
    required: (f) => (f.text_en || "").trim() || (f.text_ar || "").trim(),
    queryKeys: [["quotes"]],
  },
  wisdom: {
    entity: "Wisdom",
    title: ["Wisdom", "حكمة"],
    fields: [
      { key: "wisdom", label: ["Wisdom (English)", "الحكمة (إنجليزي)"], textarea: true, dir: "ltr", ph: ["Wisdom in English..", "حكمة بالإنجليزية"] },
      { key: "wisdom_ar", label: ["Wisdom (Arabic)", "الحكمة (عربي)"], textarea: true, dir: "rtl", ph: ["", "الحكمة بالعربية.."] },
      { key: "category", label: ["Category", "القسم"], dir: "auto", ph: ["", ""] },
      { key: "tags", label: ["Tags (comma separated)", "وسوم مفصولة بفاصلة"], dir: "auto", ph: ["", ""], csvArray: true },
    ],
    required: (f) => (f.wisdom || "").trim() || (f.wisdom_ar || "").trim(),
    queryKeys: [["wisdom"], ["wisdoms"]],
  },
  symbolism: {
    entity: "PerfumeSymbolism",
    title: ["Symbolism", "رمزية"],
    fields: [
      { key: "headword_en", alt: "name_en", label: ["Name (English)", "الاسم (إنجليزي)"], dir: "ltr", ph: ["", ""] },
      { key: "headword_ar", alt: "name_ar", label: ["Name (Arabic)", "الاسم (عربي)"], dir: "rtl", ph: ["", ""] },
      { key: "pronunciation_en", label: ["Pronunciation", "اللفظ"], dir: "ltr", ph: ["", ""] },
      { key: "meaning_en", alt: "literal_meaning_en", label: ["Meaning (English)", "المعنى (إنجليزي)"], textarea: true, dir: "ltr", ph: ["", ""] },
      { key: "meaning_ar", label: ["Meaning (Arabic)", "المعنى (عربي)"], textarea: true, dir: "rtl", ph: ["", ""] },
      { key: "tags", label: ["Tags (comma separated)", "وسوم مفصولة بفاصلة"], dir: "auto", ph: ["", ""], csvArray: true },
    ],
    required: (f) => (f.headword_en || "").trim() || (f.headword_ar || "").trim(),
    queryKeys: [["perfumes-symbolism"]],
  },
};

export default function ContentEdit() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [params] = useSearchParams();
  const type = params.get("type") || "quote";
  const id = params.get("id") || "";
  const cfg = TYPES[type] || TYPES.quote;
  const isEdit = !!id;

  const { data: record, isLoading } = useQuery({
    queryKey: ["content-edit", type, id],
    queryFn: () => apphost.entities[cfg.entity].get(Number(id)),
    enabled: isEdit,
  });

  const [form, setForm] = useState(null);
  useEffect(() => {
    if (!isEdit) { setForm({ images: [] }); return; }
    if (record && !form) {
      const f = { images: Array.isArray(record.images) ? record.images : [] };
      cfg.fields.forEach(({ key, alt, csvArray }) => {
        const v = record[key] ?? (alt ? record[alt] : undefined);
        f[key] = csvArray ? (Array.isArray(v) ? v.join(", ") : String(v || "")) : String(v ?? "");
      });
      setForm(f);
    }
  }, [record, isEdit]);  

  const save = useMutation({
    mutationFn: async () => {
      const payload = { images: form.images || [] };
      cfg.fields.forEach(({ key, csvArray }) => {
        const v = String(form[key] || "").trim();
        payload[key] = csvArray ? v.split(",").map((t) => t.trim()).filter(Boolean) : v;
      });
      if (isEdit) return apphost.entities[cfg.entity].update(record.id, payload);
      return apphost.entities[cfg.entity].create({ ...payload, is_user: true });
    },
    onSuccess: () => {
      cfg.queryKeys.forEach((k) => qc.invalidateQueries({ queryKey: k }));
      toast.success(isAr ? "تمّ الحفظ" : "Saved");
      navigate(-1);
    },
    onError: () => toast.error(isAr ? "تعذّر الحفظ" : "Save failed"),
  });

  if (isEdit && (isLoading || !form)) {
    return <div className="px-5 page-top text-center text-sm font-body text-muted-foreground">{isAr ? "جارٍ التحميل…" : "Loading…"}</div>;
  }
  if (!form) return null;

  const title = `${isEdit ? (isAr ? "تعديل" : "Edit") : (isAr ? "إضافة" : "Add")} ${isAr ? cfg.title[1] : cfg.title[0]}`;

  return (
    <div className="px-5 page-top pb-24 space-y-4 max-w-md mx-auto" dir={isAr ? "rtl" : "ltr"}>
      <div className="flex items-center justify-between">
        <BackButton />
        <h1 className="font-heading text-lg font-semibold" style={{ color: GOLD }}>{title}</h1>
        <span className="w-8" />
      </div>

      <div className="space-y-3">
        {cfg.fields.map(({ key, label, textarea, dir, ph }) => (
          <div key={key} className="space-y-1.5">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? label[1] : label[0]}</label>
            {textarea ? (
              <Textarea
                value={form[key] || ""}
                onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                placeholder={isAr ? ph[1] : ph[0]}
                className="rounded-none font-body text-sm min-h-[90px]"
                dir={dir}
              />
            ) : (
              <Input
                value={form[key] || ""}
                onChange={(e) => setForm((f) => ({ ...f, [key]: e.target.value }))}
                placeholder={isAr ? ph[1] : ph[0]}
                className="rounded-none h-10 font-body text-sm"
                dir={dir}
              />
            )}
          </div>
        ))}

        <ImagesField value={form.images} onChange={(arr) => setForm((f) => ({ ...f, images: arr }))} />

        <Button
          className="w-full h-11 rounded-none font-body text-sm bg-[var(--brand)] hover:bg-[#b08f29] text-white"
          onClick={() => save.mutate()}
          disabled={!cfg.required(form) || save.isPending}
        >
          {save.isPending ? (isAr ? "جارٍ الحفظ…" : "Saving…") : (isAr ? "حفظ" : "Save")}
        </Button>
      </div>
    </div>
  );
}
