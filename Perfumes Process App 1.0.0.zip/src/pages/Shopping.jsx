import { useState, useEffect, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link, useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { useNumberEncryption } from "@/lib/useNumberEncryption";
import { DEFAULT_MAIN_CATEGORIES, ALL_SUB_CATEGORIES } from "@/lib/shopCategories";
import { sortStoresBy, buildUsageMap, getStorePageSort } from "@/lib/storeSort";
import { Search, Store, Package, BarChart3, Settings2, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import ShopHeroQuote from "@/components/shopping/ShopHeroQuote";
import ShopCategoryManager from "@/components/shopping/ShopCategoryManager";
import ShopBrandList from "@/components/shopping/ShopBrandList";
import ShopProductList from "@/components/shopping/ShopProductList";
import ShopAnalytics from "@/components/shopping/ShopAnalytics";
import AddShopBrandDialog from "@/components/shopping/AddShopBrandDialog";
import AddShopProductDialog from "@/components/shopping/AddShopProductDialog";
import ShopPurchaseLog from "@/components/shopping/ShopPurchaseLog";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import SettingsSheet from "@/components/layout/SettingsSheet";
import SectionDivider from "@/components/shared/SectionDivider";
import { resolveUserMark } from "@/lib/exportSettings";

const TABS = [
  { id: "log", icon: FileText, en: "Purchase", ar: "شراء" },
  { id: "products", icon: Package, en: "Product", ar: "منتجات" },
  { id: "brands", icon: Store, en: "Brands & Store", ar: "متاجر" },
  { id: "categories", icon: Settings2, en: "Categories", ar: "أقسام" },
  { id: "analytics", icon: BarChart3, en: "Indicator", ar: "مؤشّر" },
];

export default function Shopping() {
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { currency } = useCurrency();
  const { encryptNumbers } = useNumberEncryption();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState(() => {
    try { return new URLSearchParams(window.location.search).get("tab") || "log"; }
    catch { return "log"; }
  });
  const [search, setSearch] = useState("");
  const [showAddBrand, setShowAddBrand] = useState(false);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [viewMode, setViewMode] = useState(() => localStorage.getItem("shopViewMode") || "magazine");
  const [hiddenCats, setHiddenCats] = useState(() => {
    try { return JSON.parse(localStorage.getItem("hiddenShopCats") || "[]"); } catch { return []; }
  });
  const [managingCats, setManagingCats] = useState(false);
  // علامة المستخدم المخصّصة تُجلب من ملفّ المستخدم (auth.me().mark) لا من مفتاح قديم خاطئ
  const [mark, setMark] = useState("");
  useEffect(() => {
    let alive = true;
    resolveUserMark().then((m) => { if (alive) setMark(m || ""); }).catch(() => {});
    return () => { alive = false; };
  }, []);
  const navigate = useNavigate();

  const { data: brands = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: products = [] } = useQuery({
    queryKey: ["shop-products"],
    queryFn: () => apphost.entities.ShopProduct.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  // ترتيب المتاجر في صفحة التسوق — من قائمة المستخدم لا من الصفحة (A 1.808).
  // إشارة الشراء هنا = سجلات منتجات التسوق (brand_id)، و يتجدد حيا عند تغيير الإعداد.
  const [pageSort, setPageSort] = useState(getStorePageSort());
  useEffect(() => {
    const h = () => setPageSort(getStorePageSort());
    window.addEventListener("storeSortChanged", h);
    return () => window.removeEventListener("storeSortChanged", h);
  }, []);
  const sortedBrands = useMemo(
    () => sortStoresBy(pageSort, brands, buildUsageMap(products, "brand_id")),
    [pageSort, brands, products]
  );

  // حكم المستخدم (Wisdom، قابلة للتحرير) + حوض عشوائيّ من «معنى علامة / Marking Meaning» بالموسوعة (مدمج، للعرض).
  const { data: wisdomRows = [] } = useQuery({
    queryKey: ["wisdom"],
    queryFn: () => apphost.entities.Wisdom.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });
  const { data: markingRows = [] } = useQuery({
    queryKey: ["shop-marking-pool"],
    queryFn: async () => {
      const sections = (await apphost.entities.EncSection.list("order", 200)) || [];
      const sec = sections.find((s) => s.name_en === "Marking Meaning" || s.name_en === "Symbolism");
      if (!sec) return [];
      const all = (await apphost.entities.EncEntry.filter({ section_id: sec.id }, "order", 20000)) || [];
      if (!all.length) return [];
      const POOL = Math.min(20, all.length);
      const idxs = new Set();
      while (idxs.size < POOL) idxs.add(Math.floor(Math.random() * all.length));
      return [...idxs].map((i) => { const e = all[i]; return { id: e.id, text_en: (e.texts?.en || e.titles?.en || "").trim(), text_ar: (e.texts?.ar || e.titles?.ar || "").trim(), is_active: true, builtin: true }; });
    },
    staleTime: 1000 * 60 * 5,
  });

  const quotes = useMemo(
    () => {
      const user = wisdomRows.map((w) => ({ id: w.id, text_en: w.wisdom || w.text_en || "", text_ar: w.wisdom_ar || w.text_ar || "", is_active: true }));
      return [...user, ...markingRows].filter((q) => q.text_en || q.text_ar);
    },
    [wisdomRows, markingRows]
  );

  // الحِكَم تُقرأ من جدول Wisdom في قاعدة البيانات، فلا حاجة لزرع افتراضي سطري هنا.

  // Always use static built-in categories — no DB dependency
  const mainCategories = DEFAULT_MAIN_CATEGORIES;
  const subCategories = ALL_SUB_CATEGORIES;

  // Note: Stats will show encrypted costs until decrypted in individual components
  // Each component (ShopPurchaseLog, ShopAnalytics) handles decryption independently
  const stats = useMemo(() => {
    const total = products.reduce((s, p) => s + (p.cost || 0), 0);
    const thisMonth = products.filter(p => {
      if (!p.purchase_date) return false;
      const d = new Date(p.purchase_date);
      const now = new Date();
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    }).reduce((s, p) => s + (p.cost || 0), 0);
    return { total, thisMonth, count: products.length, brandsCount: brands.length };
  }, [products, brands]);

  return (
    <div className={`relative min-h-screen pb-28 ${isAr ? "rtl" : ""}`} style={{ background: "var(--page-bg, hsl(var(--background)))" }}>
      {/* الهيدر: صندوق المستخدم زاوية + «متاجر» الزاوية الأخرى + خطّ ذهبيّ */}
      <div className="flex items-center justify-between px-4 pb-2"
        style={{ paddingTop: "calc(env(safe-area-inset-top, 0px) + 0.6rem)" }}>
        <h1 className="font-heading text-lg font-bold" style={{ color: "var(--brand)" }}>{isAr ? "متاجر" : "Stores"}</h1>
        <SettingsSheet>
          <UserAvatarButton size={30} />
        </SettingsSheet>
      </div>

      {/* صندوق العلامة نُقل لأسفل الصفحة */}

      {/* الروابط نُقلت لأسفل الصفحة (تقارير → بطاقة مقارنة) */}

      {/* المتاجر المثبّتة — فوق الأقسام الرئيسية */}
      {brands.filter((b) => b.pinned && !b.hidden).length > 0 && (
        <div className="px-4 pt-1 pb-1">
          <div className="flex gap-2 overflow-x-auto pb-1 px-0.5">
            {brands.filter((b) => b.pinned && !b.hidden).map((s) => (
              <button
                key={s.id}
                onClick={() => navigate(`/store?id=${s.id}`)}
                className="flex items-center gap-2 flex-shrink-0 bg-secondary/50 hover:bg-secondary rounded-none pl-1.5 pr-3 py-1.5 transition-colors border border-primary/30"
              >
                {s.logo_url ? (
                  <img src={s.logo_url} alt={s.name} className="w-7 h-7 rounded-none object-cover flex-shrink-0" />
                ) : (
                  <div className="w-7 h-7 rounded-none bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Store className="w-3.5 h-3.5 text-primary/70" />
                  </div>
                )}
                <span className="text-xs font-body font-semibold whitespace-nowrap">{isAr ? (s.name_ar || s.name) : s.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* الأقسام نُقلت لصفحة مستقلّة /shop-categories (رابط بعد إدارة الميزانية) */}

      {/* Stats Row */}
      <div className="px-4 py-1.5 grid grid-cols-4 gap-1">
        {[
          { label: isAr ? "الإجمالي" : "Total", value: `${stats.total.toFixed(0)}`, color: "text-primary" },
          { label: isAr ? "هذا الشهر" : "Month", value: `${stats.thisMonth.toFixed(0)}`, color: "text-amber-600" },
          { label: isAr ? "منتجات" : "Items", value: stats.count, color: "text-blue-600" },
          { label: isAr ? "متاجر" : "Stores", value: stats.brandsCount, color: "text-purple-600" },
        ].map((s, i) => (
          <div key={i} className="p-1.5 text-center">
            <p className={`text-xs font-bold font-heading ${s.color}`}>{s.value}</p>
            <p className="text-[7px] text-muted-foreground font-body mt-0.5 leading-tight">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="px-4"><SectionDivider className="my-2" /></div>

      {/* Tabs — fit to screen */}
      <div className="px-4 grid pb-1.5" style={{ gridTemplateColumns: `repeat(${TABS.length}, 1fr)`, gap: "4px" }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={cn("flex flex-col items-center gap-0.5 px-0.5 py-1.5 text-[9px] font-body font-medium transition-colors",
              tab === t.id ? "text-primary font-semibold" : "text-muted-foreground hover:text-foreground")}>
            <t.icon className="w-3 h-3" />
            <span className="leading-tight text-center">{isAr ? t.ar : t.en}</span>
          </button>
        ))}
      </div>

      {/* Search + Add */}
      {(tab === "brands" || tab === "products" || tab === "log") && (
        <div className="px-4 pb-2 flex gap-1.5">
          <div className="flex-1 relative">
            <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)}
              placeholder={isAr ? "ابحث" : "Search"}
              className="pl-8 h-9 font-body text-sm bg-[var(--page-bg,#fff)] border border-transparent rounded-none" />
          </div>
          {tab !== "log" && (
            <Button variant="ghost" className="h-9 px-2 font-body text-[11px] whitespace-nowrap font-semibold text-[var(--brand)] hover:text-[var(--brand)] hover:opacity-80"
              onClick={() => tab === "brands" ? setShowAddBrand(true) : setShowAddProduct(true)}>
              {tab === "brands"
                ? (isAr ? "إضافة متجر" : "Add Store")
                : (isAr ? "إضافة منتج" : "Add Product")}
            </Button>
          )}
        </div>
      )}

      {/* Tab Content */}
      <div className="px-4 pb-2">
        {tab === "log" && (
          <ShopPurchaseLog products={products} brands={brands} search={search} isAr={isAr}
            onRefresh={() => { queryClient.invalidateQueries({ queryKey: ["shop-products"] }); queryClient.invalidateQueries({ queryKey: ["shop-brands"] }); }} />
        )}
        {tab === "products" && (
          <ShopProductList products={products} brands={brands} search={search} isAr={isAr}
            names={names} currency={currency} categories={ALL_SUB_CATEGORIES}
            viewMode={viewMode}
            onRefresh={() => { queryClient.invalidateQueries({ queryKey: ["shop-products"] }); queryClient.invalidateQueries({ queryKey: ["shop-brands"] }); }} />
        )}
        {tab === "brands" && (
          <ShopBrandList brands={sortedBrands} search={search} isAr={isAr} names={names} currency={currency}
            mainCategories={mainCategories} products={products}
            viewMode={viewMode}
            onRefresh={() => queryClient.invalidateQueries({ queryKey: ["shop-brands"] })} />
        )}
        {tab === "categories" && (
          <ShopCategoryManager isAr={isAr} />
        )}
        {tab === "analytics" && (
          <ShopAnalytics products={products} brands={brands} categories={ALL_SUB_CATEGORIES}
            isAr={isAr} currency={currency} names={names} />
        )}
      </div>


      {/* الروابط — منقولة لأسفل الصفحة: أزرار نصّية بلا أيقونات ولا صناديق */}
      <div className="px-4 pt-3 flex flex-wrap gap-x-4 gap-y-1">
        <button onClick={() => navigate("/export?type=shopping")}
          className="font-body text-xs font-medium text-emerald-700 dark:text-emerald-400 py-1.5 hover:opacity-70 transition-opacity">
          {isAr ? "تقارير التسوق و المتاجر" : "Shopping & Stores Reports"}
        </button>
        <Link to="/budget"
          className="font-body text-xs font-medium text-blue-700 dark:text-blue-400 py-1.5 hover:opacity-70 transition-opacity">
          {isAr ? "إدارة الميزانية" : "Budget Management"}
        </Link>
        <Link to="/shop-categories"
          className="font-body text-xs font-medium text-blue-700 dark:text-blue-400 py-1.5 hover:opacity-70 transition-opacity">
          {isAr ? "إدارة الأقسام" : "Manage Categories"}
        </Link>
        <Link to="/shop-stores"
          className="font-body text-xs font-medium text-purple-700 dark:text-purple-400 py-1.5 hover:opacity-70 transition-opacity">
          {isAr ? "المتاجر" : "Stores"}
        </Link>
        <Link to="/marketing-card"
          className="font-body text-xs font-medium text-fuchsia-700 dark:text-fuchsia-400 py-1.5 hover:opacity-70 transition-opacity">
          {isAr ? "إنشاء بطاقة تسويقية" : "Create Marketing Card"}
        </Link>
        <Link to="/compare-card"
          className="font-body text-xs font-medium text-fuchsia-700 dark:text-fuchsia-400 py-1.5 hover:opacity-70 transition-opacity">
          {isAr ? "بطاقة مقارنة عطور" : "Perfume Comparison Card"}
        </Link>
      </div>

      {/* صندوق العلامة غير المكتملة — أسفل الصفحة */}
      <div className="px-4 mt-4"><SectionDivider className="my-3" /></div>
      <ShopHeroQuote quotes={quotes} isAr={isAr} viewMode={viewMode} setViewMode={setViewMode} mark={mark} />

      {/* Dialogs */}
      {showAddBrand && (
        <AddShopBrandDialog isAr={isAr} categories={mainCategories}
          onClose={() => setShowAddBrand(false)}
          onSaved={() => { setShowAddBrand(false); queryClient.invalidateQueries({ queryKey: ["shop-brands"] }); }} />
      )}
      {showAddProduct && (
        <AddShopProductDialog isAr={isAr} brands={brands} categories={ALL_SUB_CATEGORIES}
          mainCategories={mainCategories} subCategories={ALL_SUB_CATEGORIES}
          onClose={() => setShowAddProduct(false)}
          onSaved={() => { setShowAddProduct(false); queryClient.invalidateQueries({ queryKey: ["shop-products"] }); }} />
      )}
    </div>
  );
}