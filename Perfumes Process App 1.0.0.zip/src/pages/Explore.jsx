import { useState, useMemo, useEffect } from "react";
import { OCCASIONS as OCCASIONS_LIST } from "@/lib/occasions";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { apphost } from "@/api/apphostClient";
import { SimplePager } from "@/components/shared/usePagedList";
import { compareEnglish } from "@/lib/sortName";
import { Input } from "@/components/ui/input";
import { Search, SlidersHorizontal, Pin } from "lucide-react";
import BottleMark from "@/components/icons/BottleMark";
import { FORM_PERFUME_TYPES as PERFUME_TYPES } from "@/lib/perfumeTypes";
import OdorMap from "@/components/explore/OdorMap";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import AccordFlaconCard from "@/components/perfume/AccordFlaconCard";
import { usePins } from "@/lib/usePins";
import Pagination from "@/components/Pagination";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { usePersonNames } from "@/lib/usePersonNames";
import { Link, useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";



function HeadacheInline() {
  const navigate = useNavigate();
  const { names } = usePersonNames();
  const { isAr } = useLang();
  const [expandedLevels, setExpandedLevels] = useState({});
  const PER_LEVEL = 20; // حد العرض لكل مستوى لتفادي رسم آلاف العناصر
  const { data: userPerfumes = [], isLoading } = useQuery({
    queryKey: ["user-perfumes-headache"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });
  const LEVELS = [
    { value: "strong", emoji: "🔴", labelAr: "قوي", labelEn: "Strong" },
    { value: "medium", emoji: "🟠", labelAr: "متوسط", labelEn: "Medium" },
    { value: "weak",   emoji: "🟡", labelAr: "ضعيف", labelEn: "Weak" },
    { value: "none",   emoji: "", labelAr: "لا",   labelEn: "None" },
  ];
  const rated = userPerfumes.filter(u => u.headache && u.headache !== "none");
  if (isLoading) return <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  if (rated.length === 0) return <div className="text-center py-16 space-y-2"><p className="text-4xl">🤕</p><p className="text-sm font-body text-muted-foreground">{isAr ? "لا تقييمات صداع بعد" : "No headache ratings yet."}</p></div>;
  return (
    <div className="page-top space-y-5">
      {LEVELS.filter(l => rated.some(u => u.headache === l.value)).map(level => {
        const levelItems = rated.filter(u => u.headache === level.value);
        const isExp = expandedLevels[level.value];
        const shown = isExp ? levelItems : levelItems.slice(0, PER_LEVEL);
        const remaining = levelItems.length - shown.length;
        return (
        <div key={level.value} className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-lg">{level.emoji}</span>
            <h3 className="font-heading font-semibold text-sm">{level.labelAr} · {level.labelEn}</h3>
            <span className="text-[10px] text-muted-foreground font-body rounded-none">{levelItems.length}</span>
          </div>
          <div className="space-y-1.5">
            {shown.map(up => (
              <button key={up.id} onClick={() => navigate(`/perfume?id=${up.perfume_id}`)}
                className="w-full flex items-center justify-between bg-[var(--page-bg,#fff)] rounded-none p-3 shadow-sm border border-border/50 hover:border-primary/30 transition-all text-left">
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-body font-semibold truncate">{up.perfume_name}</p>
                  <p className="text-xs text-muted-foreground font-body truncate">{up.brand_name}</p>
                </div>
                <span className={`text-[10px] font-bold rounded-none flex-shrink-0 ${up.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                  {up.person === "person2" ? names.person2 : names.person1}
                </span>
              </button>
            ))}
            {remaining > 0 && (
              <button onClick={() => setExpandedLevels(p => ({ ...p, [level.value]: true }))}
                className="w-full py-2 text-xs font-body text-primary hover:underline">
                {isAr ? `عرض ${remaining} أكثر` : `Show ${remaining} more`}
              </button>
            )}
            {isExp && levelItems.length > PER_LEVEL && (
              <button onClick={() => setExpandedLevels(p => ({ ...p, [level.value]: false }))}
                className="w-full py-2 text-xs font-body text-muted-foreground hover:underline">
                {isAr ? "عرض أقل" : "Show less"}
              </button>
            )}
          </div>
        </div>
        );
      })}
    </div>
  );
}

function SinusInline() {
  const navigate = useNavigate();
  const { names } = usePersonNames();
  const { isAr } = useLang();
  const [expandedLevels, setExpandedLevels] = useState({});
  const PER_LEVEL = 20;
  const { data: userPerfumes = [], isLoading } = useQuery({
    queryKey: ["user-perfumes-sinus"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });
  const LEVELS = [
    { value: "yes",      emoji: "😤", labelAr: "نعم",    labelEn: "Yes", bg: "bg-red-50 dark:bg-red-950/20 border-red-200" },
    { value: "a_little", emoji: "😕", labelAr: "قليلاً", labelEn: "A Little", bg: "bg-amber-50 dark:bg-amber-950/20 border-amber-200" },
    { value: "no",       emoji: "😊", labelAr: "لا",     labelEn: "No", bg: "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200" },
  ];
  const rated = userPerfumes.filter(u => u.sinus_sensitivity);
  if (isLoading) return <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  if (rated.length === 0) return <div className="text-center py-16 space-y-2"><p className="text-4xl">👃</p><p className="text-sm font-body text-muted-foreground">{isAr ? "لا تقييمات حساسية بعد" : "No sinus ratings yet."}</p></div>;
  return (
    <div className="space-y-5">
      {LEVELS.filter(l => rated.some(u => u.sinus_sensitivity === l.value)).map(level => {
        const levelItems = rated.filter(u => u.sinus_sensitivity === level.value);
        const isExp = expandedLevels[level.value];
        const shown = isExp ? levelItems : levelItems.slice(0, PER_LEVEL);
        const remaining = levelItems.length - shown.length;
        return (
        <div key={level.value} className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="text-lg">{level.emoji}</span>
            <h3 className="font-heading font-semibold text-sm">{level.labelAr} · {level.labelEn}</h3>
            <span className="text-[10px] text-muted-foreground font-body rounded-none">{levelItems.length}</span>
          </div>
          <div className="space-y-1.5">
            {shown.map(up => (
              <button key={up.id} onClick={() => navigate(`/perfume?id=${up.perfume_id}`)}
                className={`w-full flex items-center justify-between rounded-none p-3 border transition-all text-left ${level.bg} hover:opacity-80`}>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-body font-semibold truncate">{up.perfume_name}</p>
                  <p className="text-xs text-muted-foreground font-body truncate">{up.brand_name}</p>
                </div>
                <span className={`text-[10px] font-bold rounded-none flex-shrink-0 ${up.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                  {up.person === "person2" ? names.person2 : names.person1}
                </span>
              </button>
            ))}
            {remaining > 0 && (
              <button onClick={() => setExpandedLevels(p => ({ ...p, [level.value]: true }))}
                className="w-full py-2 text-xs font-body text-primary hover:underline">
                {isAr ? `عرض ${remaining} أكثر` : `Show ${remaining} more`}
              </button>
            )}
            {isExp && levelItems.length > PER_LEVEL && (
              <button onClick={() => setExpandedLevels(p => ({ ...p, [level.value]: false }))}
                className="w-full py-2 text-xs font-body text-muted-foreground hover:underline">
                {isAr ? "عرض أقل" : "Show less"}
              </button>
            )}
          </div>
        </div>
        );
      })}
    </div>
  );
}


export default function Explore() {
const navigate = useNavigate();
const { isAr } = useLang();
const urlParams = new URLSearchParams(window.location.search);
const brandFilter = urlParams.get("brandFilter") || "";
const typeFilterFromURL = urlParams.get("typeFilter") || "";
const genderFilterFromURL = urlParams.get("genderFilter") || "";
const noteSearchFromURL = urlParams.get("noteSearch") || "";
// "نوتات" صارت صفحة مستقلة — إن جئنا من ضغط نوتة نحوّل إليها مباشرة.
useEffect(() => {
  if (noteSearchFromURL) navigate(`/notes-accord?noteSearch=${encodeURIComponent(noteSearchFromURL)}`, { replace: true });
}, [noteSearchFromURL]);
const [search, setSearch] = useState("");
// لا فلترة حية بعد اليوم (قاعدة A): الكتابة لا تجلب نتائج — أيقونة البحث/Enter
// تفتح صفحة النتائج المنفصلة. debouncedSearch يبقى فارغا دائما فلا يضيق شيئا.
const [debouncedSearch] = useState("");
const [genderFilter, setGenderFilter] = useState(genderFilterFromURL || "all");
const [typeFilter, setTypeFilter] = useState(typeFilterFromURL || "all");
// الافتراضي "name" = تصفّح أبجدي فوري عبر فهرس الاسم (pageByIndex) — بلا تحميل
// القاعدة كاملة. name/nameDesc يُتصفّحان فورياً؛ releaseYear* يحتاج مسحاً كاملاً.
const [sortBy, setSortBy] = useState("name");
const [showDiscontinued, setShowDiscontinued] = useState(false);
const [showFilters, setShowFilters] = useState(false);
const [subTab, setSubTab] = useState("list"); // عطور خريطة صداع جيوب

// العطور المثبّتة (حتى ١٢) — تُجلب بمعرّفاتها فقط، وتظهر مصغّرة أعلى قائمة العطور.
const { pinnedIds: pinnedPerfumeIds } = usePins("perfume");
const { data: pinnedPerfumesRaw = [] } = useQuery({
  queryKey: ["pinned-perfumes-explore", pinnedPerfumeIds.join(",")],
  queryFn: () => apphost.entities.Perfume.getMany(pinnedPerfumeIds),
  enabled: pinnedPerfumeIds.length > 0,
  staleTime: 1000 * 60 * 5,
});
const pinnedPerfumes = useMemo(() => {
  const byId = {};
  pinnedPerfumesRaw.forEach((p) => { byId[String(p.id)] = p; });
  return pinnedPerfumeIds.map((pid) => byId[String(pid)]).filter(Boolean);
}, [pinnedPerfumesRaw, pinnedPerfumeIds]);

const PAGE_SIZE = 50;

// عدّ سريع للإجمالي (count الأصلية لـIndexedDB، بلا قراءة السجلات).
// مفتاح منفصل لا يبدأ بـ"perfumes" حتى يصله إبطال 1.812 الموجّه.
const { data: totalCount = 0 } = useQuery({
  queryKey: ["perfumes-total"],
  queryFn: () => apphost.entities.Perfume.count(),
  staleTime: 10 * 60 * 1000,
});

// «وضع كامل»: بحث/فلترة/فرز بالسنة يتطلّب مسح كل السجلات.
// خلا ذلك (أبجدي ↑/↓) = تصفّح فوري عبر فهرس الاسم.
const isFullMode =
  genderFilter !== "all" ||
  typeFilter !== "all" ||
  showDiscontinued ||
  !!brandFilter ||
  (sortBy !== "name" && sortBy !== "nameDesc");

// ── وضع التصفّح: صفحة (50) أبجدياً عبر فهرس الاسم — بلا تحميل القاعدة كلها ──
const browseDir = sortBy === "nameDesc" ? "prev" : "next"; // next = أبجدي تصاعدي A→Z
const [browsePage, setBrowsePage] = useState(1); // 1-indexed
// ارجع للصفحة الأولى عند تغيّر الترتيب أو الدخول/الخروج من الوضع الكامل
useEffect(() => { setBrowsePage(1); }, [browseDir, isFullMode]);

const { data: browseData, isLoading: browseLoading } = useQuery({
  queryKey: ["perfumes", "browse", browseDir, browsePage],
  queryFn: () => apphost.entities.Perfume.pageByIndex("sort_key", (browsePage - 1) * PAGE_SIZE, PAGE_SIZE, browseDir, false, "name"),
  enabled: !isFullMode,
  placeholderData: keepPreviousData, // أبقِ الصفحة السابقة ظاهرة أثناء جلب التالية
  staleTime: 10 * 60 * 1000,
});
const browseItems = browseData?.items || [];
// إجمالي التصفّح من العدّ المخبّأ مرّة واحدة (لا نُعيد مسح الفهرس كل صفحة).
const browseTotal = totalCount;
const browseTotalPages = Math.max(1, Math.ceil(browseTotal / PAGE_SIZE));

// ── الوضع الكامل: يُحمّل كل السجلات مرّة واحدة فقط عند الحاجة (بحث/فلترة/فرز) ──
const { data: allPerfumes = [], isLoading: fullLoading } = useAllPerfumes("-created_date", { enabled: isFullMode });

// ── خريطة الروائح: حتى 4000 عطر تُجلب كسولاً فقط عند فتح تبويب الخريطة ──
const { data: mapPerfumes = [] } = useQuery({
  queryKey: ["perfumes", "map"],
  queryFn: async () => (await apphost.entities.Perfume.page(0, 4000, "prev")).items,
  enabled: subTab === "odormap",
  staleTime: 10 * 60 * 1000,
});

const filtered = useMemo(() => {
  if (!isFullMode) return []; // وضع التصفّح لا يستخدم هذا المسار
  return allPerfumes.filter((p) => {
    const q = debouncedSearch.toLowerCase();
    const matchesSearch =
      !debouncedSearch ||
      String(p.name || "").toLowerCase().includes(q) ||
      String(p.name_en || "").toLowerCase().includes(q) ||
      String(p.name_ar || "").includes(debouncedSearch) ||
      String(p.brand_name || "").toLowerCase().includes(q) ||
      String(p.brand_name_ar || "").includes(debouncedSearch);
    const matchesBrand = !brandFilter || p.brand_name === brandFilter;
    const matchesGender = genderFilter === "all" || p.gender === genderFilter;
    const matchesType = typeFilter === "all" || p.type === typeFilter;
    const matchesDiscontinued = !showDiscontinued || p.discontinued;
    return matchesSearch && matchesBrand && matchesGender && matchesType && matchesDiscontinued;
  });
}, [allPerfumes, isFullMode, debouncedSearch, brandFilter, genderFilter, typeFilter, showDiscontinued]);

const sorted = useMemo(() => {
  if (!isFullMode) return [];
  // الفرز يعتمد الاسم الإنجليزي للعطر (name_en) عبر مكتبة مشتركة — للغتين،
  // بمراتب: إنجليزي → أرقام → لغات أخرى → رموز ("‎:p" آخراً).
  const byName = (a, b, dir = 1) => compareEnglish(a, b, dir);
  return [...filtered].sort((a, b) => {
    // Oldest/Newest only rank perfumes that HAVE a year; undated ones sink to
    // the bottom (so a missing year never masquerades as the oldest perfume).
    if (sortBy === "releaseYear")     return (a.release_year || 1e9) - (b.release_year || 1e9);
    if (sortBy === "releaseYearDesc") return (b.release_year || -1)  - (a.release_year || -1);
    // Year Less: surface the undated perfumes first (then alphabetical).
    if (sortBy === "releaseYearLess") {
      const au = a.release_year ? 1 : 0, bu = b.release_year ? 1 : 0;
      return au !== bu ? au - bu : byName(a, b, 1);
    }
    if (sortBy === "nameDesc") return byName(a, b, -1);
    return byName(a, b, 1);
  });
}, [filtered, isFullMode, sortBy]);

// مؤشّرات موحّدة للعرض
const isLoading = isFullMode ? fullLoading : browseLoading;
const foundCount = isFullMode ? filtered.length : totalCount;

return (
  <div className="px-5 page-top pb-24 space-y-5">
    {/* Header */}
    <div className="flex items-start justify-between">
      <BottleMark className="w-[30px] h-[30px] text-[var(--brand)]" />
      <div className="flex items-center gap-2">
        <SettingsSheet>
            <UserAvatarButton size={28} />
          </SettingsSheet>
      </div>
    </div>

    {/* أزرار التصنيفات أسفل الهيدر قبل البحث */}
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
      {subTab !== "list" && (
        <button type="button" onClick={() => setSubTab("list")} className="text-xs font-body text-muted-foreground hover:opacity-70 transition-opacity">← {isAr ? "رجوع" : "Back"}</button>
      )}
      <button type="button" onClick={() => setSubTab("list")} className={`text-xs font-body py-1 transition-opacity ${subTab === "list" ? "font-semibold text-foreground" : "text-emerald-600 dark:text-emerald-400 hover:opacity-70"}`}>{isAr ? "عطور" : "Perfumes"}</button>
      <button type="button" onClick={() => setSubTab("odormap")} className={`text-xs font-body py-1 transition-opacity ${subTab === "odormap" ? "font-semibold text-foreground" : "text-sky-600 dark:text-sky-400 hover:opacity-70"}`}>{isAr ? "خريطة العطور" : "Perfumes Map"}</button>
      <button type="button" onClick={() => setSubTab("occasions")} className={`text-xs font-body py-1 transition-opacity ${subTab === "occasions" ? "font-semibold text-foreground" : "text-amber-600 dark:text-amber-400 hover:opacity-70"}`}>{isAr ? "مناسبات" : "Occasions"}</button>
      <button type="button" onClick={() => setSubTab("headache")} className={`text-xs font-body py-1 transition-opacity ${subTab === "headache" ? "font-semibold text-foreground" : "text-fuchsia-600 dark:text-fuchsia-400 hover:opacity-70"}`}>{isAr ? "صداع" : "Headache"}</button>
      <button type="button" onClick={() => setSubTab("sinus")} className={`text-xs font-body py-1 transition-opacity ${subTab === "sinus" ? "font-semibold text-foreground" : "text-cyan-600 dark:text-cyan-400 hover:opacity-70"}`}>{isAr ? "جيوب" : "Sinus"}</button>
    </div>

    {/* محرّك البحث — الأيقونة تفتح صفحة النتائج (لا فلترة حية) */}
    <div className="relative">
      <button type="button" aria-label="search"
        onClick={() => { if (search.trim()) navigate(`/search-results?type=perfumes&q=${encodeURIComponent(search.trim())}`); }}
        className={`absolute ${isAr ? "right-3" : "left-3"} top-1/2 -translate-y-1/2 hover:opacity-70 transition-opacity`}>
        <Search className="w-4 h-4" style={{ color: "var(--brand)" }} />
      </button>
      <Input
        placeholder=""
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter" && search.trim()) navigate(`/search-results?type=perfumes&q=${encodeURIComponent(search.trim())}`); }}
        dir={isAr ? "rtl" : "ltr"}
        className="pl-10 pr-10 h-11 font-body bg-[var(--page-bg,#fff)] border border-transparent rounded-none focus-visible:ring-0 focus-visible:ring-offset-0"
      />
      <Button variant="ghost" size="icon" className={`absolute ${isAr ? "left-1" : "right-1"} top-1/2 -translate-y-1/2`} onClick={() => setShowFilters(!showFilters)}>
        <SlidersHorizontal className="w-4 h-4" style={{ color: "var(--brand)" }} />
      </Button>
    </div>

    {showFilters && (
      <div className="space-y-3">
        <div className="flex gap-3">
          <Select value={genderFilter} onValueChange={setGenderFilter}>
            <SelectTrigger className="flex-1 h-9 rounded-none text-xs font-body"><SelectValue placeholder={isAr ? "الفئة" : "Gender"} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{isAr ? "كل الفئات" : "All Genders"}</SelectItem>
              <SelectItem value="Men">Men</SelectItem>
              <SelectItem value="Women">{isAr ? "نساء" : "Women"}</SelectItem>
              <SelectItem value="Unisex">{isAr ? "للجنسين" : "Unisex"}</SelectItem>
            </SelectContent>
          </Select>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="flex-1 h-9 rounded-none text-xs font-body"><SelectValue placeholder={isAr ? "النوع" : "Type"} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{isAr ? "كل الأنواع" : "All Types"}</SelectItem>
              {PERFUME_TYPES.map(t => (
                <SelectItem key={t.value} value={t.value}>{t.value}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex gap-2">
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="flex-1 h-9 rounded-none text-xs font-body"><SelectValue placeholder={isAr ? "ترتيب" : "Sort"} /></SelectTrigger>
            <SelectContent>
              <SelectItem value="name">أبجدي ↑ Alphabetical</SelectItem>
              <SelectItem value="nameDesc">أبجدي ↓ Reversed</SelectItem>
              <SelectItem value="releaseYear">سنة الإصدار ↑ Oldest</SelectItem>
              <SelectItem value="releaseYearDesc">سنة الإصدار ↓ Newest</SelectItem>
              <SelectItem value="releaseYearLess">بدون سنة Year Less</SelectItem>
            </SelectContent>
          </Select>
          <button
            onClick={() => setShowDiscontinued(!showDiscontinued)}
            className={`flex-1 h-9 rounded-none text-xs font-body font-medium transition-all ${showDiscontinued ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
          >
            {showDiscontinued ? "Show All" : "Discontinued"}
          </button>
        </div>
      </div>
    )}


    {/* العطور المثبّتة — صفّ مصغّر (٤ في الصفّ، كأيقونة) أعلى قائمة العطور */}
    {subTab === "list" && !debouncedSearch && pinnedPerfumes.length > 0 && (
      <div className="space-y-1.5">
        <div className={`flex items-center ${isAr ? "justify-end" : ""}`}>
          <Pin className="w-3 h-3" style={{ color: "#b45309" }} fill="#f59e0b" />
        </div>
        <div className="grid grid-cols-4 gap-2" dir="ltr">
          {pinnedPerfumes.map((p) => (
            <Link key={p.id} to={`/perfume?id=${p.id}`} className="block group">
              <div className="aspect-square bg-transparent flex items-center justify-center overflow-hidden">
                <AccordFlaconCard perfume={p} className="w-full h-full" />
              </div>
              <p className="text-center text-[9px] leading-tight text-muted-foreground truncate px-0.5 mt-0.5">
                {p.name_en || p.name || ""}
              </p>
            </Link>
          ))}
        </div>
      </div>
    )}

    {/* المحتوى */}
    {subTab === "list" && (
      isLoading ? (
        <div className="flex justify-center py-20">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-4">
          {isFullMode ? (
            <Pagination
              items={sorted}
              itemsPerPage={50}
              renderItem={(items) => (
                <div className="grid grid-cols-2 gap-3" dir="ltr">
                  {items.map((p) => <PerfumeCard key={p.id} perfume={p} ltr />)}
                </div>
              )}
              emptyMessage="No perfumes found"
            />
          ) : browseItems.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground py-8">No perfumes found</p>
          ) : (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-3" dir="ltr">
                {browseItems.map((p) => <PerfumeCard key={p.id} perfume={p} ltr />)}
              </div>
              <p className="text-center text-[11px] text-muted-foreground font-body tabular-nums" dir={isAr ? "rtl" : "ltr"}>
                {(browsePage - 1) * PAGE_SIZE + 1}–{Math.min(browsePage * PAGE_SIZE, browseTotal)} - {browseTotal}
              </p>
              <SimplePager page={browsePage} setPage={setBrowsePage} totalPages={browseTotalPages} isAr={isAr} />
            </div>
          )}

          {/* عدّ التصفّح — نصّ بلا إطار، بلا فاصلة */}
          <p className="text-center text-xs text-muted-foreground font-body mt-4" dir={isAr ? "rtl" : "ltr"}>
            {isFullMode
              ? `${foundCount} perfumes found`
              : (isAr ? `${browseTotal} عطر تصفّح أبجدي` : `${browseTotal} perfumes alphabetical`)}
          </p>

          {/* روابط ملوّنة بلا إطارات: بحث المجموعة + بطاقة تسويق + بطاقة عطور */}
          <div className="flex flex-wrap items-center justify-start gap-x-5 gap-y-2 mt-2 font-body font-semibold text-sm">
            <button type="button" onClick={() => navigate("/perfume-index")} style={{ color: "var(--brand)" }} className="hover:opacity-70 transition-opacity">{isAr ? "فهرس" : "Index"}</button>
            <Link to="/add" className="text-emerald-600 hover:opacity-70 transition-opacity">{isAr ? "إضافة & عطر" : "Add & Perfume"}</Link>
            <Link to="/collection-search" style={{ color: "#B76E79" }} className="hover:opacity-70 transition-opacity">{isAr ? "بحث مجموعتك" : "Collection Search"}</Link>
            <Link to="/marketing-card" style={{ color: "#059669" }} className="hover:opacity-70 transition-opacity">{isAr ? "بطاقة تسويق" : "Create Marketing Card"}</Link>
            <Link to="/compare-card" style={{ color: "#0284C7" }} className="hover:opacity-70 transition-opacity">{isAr ? "بطاقة عطور" : "Perfume Comparison Card"}</Link>
            <button type="button" onClick={() => navigate("/classify")} className="text-violet-600 dark:text-violet-400 hover:opacity-70 transition-opacity">{isAr ? "تصنيف" : "Classify"}</button>
            <button type="button" onClick={() => navigate("/notes-accord")} className="text-teal-600 dark:text-teal-400 hover:opacity-70 transition-opacity">{isAr ? "ممتزج" : "Blended"}</button>
            <button type="button" onClick={() => navigate("/encyclopedia?sec=sec_phases")} className="text-[var(--brand)] hover:opacity-70 transition-opacity">{isAr ? "أطوار العطور" : "Perfumes Era"}</button>
            <button type="button" onClick={() => navigate("/accords-guide")} style={{ color: "var(--brand)" }} className="hover:opacity-70 transition-opacity">{isAr ? "تناغم عطري" : "Accords"}</button>
            <button type="button" onClick={() => navigate("/headache-guide")} className="text-fuchsia-600 dark:text-fuchsia-400 hover:opacity-70 transition-opacity">{isAr ? "صداع و حساسية" : "Headache & Sensitivity"}</button>
          </div>
        </div>
      )
    )}

    {subTab === "odormap" && <div className="mt-2"><OdorMap perfumes={mapPerfumes} /></div>}
    {subTab === "occasions" && (
      <div className="mt-3 grid grid-cols-2 gap-y-1">
        {OCCASIONS_LIST.map((o) => (
          <button key={o.value} type="button" onClick={() => navigate(`/occasion?o=${encodeURIComponent(o.value)}`)}
            style={{ border: "none", background: "transparent" }}
            className="flex items-center gap-2 py-2 px-1 text-sm font-body text-foreground/85 hover:opacity-70 transition-opacity text-start">
            <span className="text-xl">{o.emoji}</span>
            <span>{isAr ? o.ar : o.en}</span>
          </button>
        ))}
      </div>
    )}
    {subTab === "headache" && <div className="mt-2"><HeadacheInline /></div>}
    {subTab === "sinus" && <div className="mt-2"><SinusInline /></div>}
  </div>
);
}