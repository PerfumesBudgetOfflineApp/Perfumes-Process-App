import { useState, useRef, useMemo, useEffect } from "react";
import { useLang } from "@/lib/LanguageContext";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useCurrency } from "@/lib/useCurrency";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { searchIndexReady, searchPerfumeIds, searchPerfumesDirect } from "@/lib/searchIndex";
import { captureElementHQ } from "@/lib/captureCanvas";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { ExportFooter } from "@/lib/exportHeader";
import { occasionInfo } from "@/lib/occasions";
import { RISK_GROUPS, MECH } from "@/lib/headacheRisk";
import { DEFAULT_USER_MARK, resolveUserMark } from "@/lib/exportSettings";
import { ArrowLeft, Search, X } from "lucide-react";
import PerfumeSprayIcon from "@/components/icons/PerfumeSprayIcon";
import AccordFlacon from "@/components/perfume/AccordFlacon";
import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { toast } from "sonner";
import { exportHistory } from "@/lib/exportHistoryStore";
import ExportHistoryList, { recordExport } from "@/components/export/ExportHistoryList";

// بطاقة مقارنة عطور — جدولٌ صريح: عمودٌ للتسميات وعمودٌ لكلّ عطر (حتى أربعة)،
// صفوفٌ متحاذية (العائلة/النوع/الجنس/السنة/المناسبات/النوتات/التقييم/السعر).
// أساليب مقارنةٍ يحدّدها المستخدم: مصفوفة محايدة، إبراز عطرٍ بعينه، الأفضل سعرًا،
// الأعلى تقييمًا — مع تاجٍ للفائز وهالةٍ ذهبيّة وخيار جدولٍ بلا إطارات. تُحفَظ صورةً واحدة.

// مساعدات ربط أسماء النوتات بسجلاتها (نفس منطق FragranceNotesGrid المختصر)
const latinOf2 = (s) => (s || "").replace(/[\u0600-\u06FF]+/g, " ").replace(/\([^)]*\)/g, " ").replace(/\s+/g, " ").replace(/[-\s]+$/, "").trim();
const arabicOf2 = (s) => { const m = (s || "").match(/[\u0600-\u06FF][\u0600-\u06FF\s،ـ-]*/g); return m ? m.join(" ").replace(/\s+/g, " ").replace(/[-\s]+$/, "").trim() : ""; };
const normKey2 = (s) => (s || "").toLowerCase().replace(/[\u064B-\u0652\u0670\u0640]/g, "").replace(/[إأآٱ]/g, "ا").replace(/ى/g, "ي").replace(/ة/g, "ه").replace(/(^|\s)ال/g, "$1").replace(/[^a-z0-9\u0600-\u06FF ]/g, "").replace(/\s+/g, " ").trim();
const parseAccordsCmp = (raw) => String(raw || "").split(";").map((e) => { const [id, pc] = e.split(":"); const ref = ACCORDS[id]; return ref ? { id, pct: Math.max(0, Math.min(100, parseInt(pc, 10) || 0)), ...ref } : null; }).filter(Boolean);

const GOLD = "var(--brand)";
const PINK = "#B76E79";
const BG_COLORS = ["#ffffff", "#1a1a2e", "#4b1528", "#0c447c", "#173404", "#2c2c2a", "#412402"];
const GENDER_DISP = { male: { ar: "رجالي", en: "Men" }, female: { ar: "نسائي", en: "Women" }, unisex: { ar: "للجميع", en: "Unisex" }, men: { ar: "رجالي", en: "Men" }, women: { ar: "نسائي", en: "Women" } };
const MAX = 4;

// مؤشّر الصحّة المرتبط بنوتات التطبيق: نطابق أسماء نوتات العطر مع عائلات الخطر
// (RISK_GROUPS) — كلّما قلّت النوتات المُثيرة (صداع/جيوب/تحسّس) ارتفعت النسبة.
function healthOf(p) {
  const list = [p.top_notes, p.heart_notes, p.base_notes].filter(Boolean).join(",").toLowerCase()
    .split(/[,\u060C]/).map((x) => x.trim()).filter(Boolean);
  const total = list.length;
  if (!total) return { score: 0, total: 0, risky: 0, mech: [] };
  const mech = new Set(); let risky = 0;
  for (const note of list) {
    let hit = false;
    for (const g of RISK_GROUPS) {
      if (g.keys.some((k) => note.includes(String(k).toLowerCase()))) { hit = true; for (const m of g.mech) mech.add(m); }
    }
    if (hit) risky++;
  }
  return { score: Math.round(((total - risky) / total) * 100), total, risky, mech: [...mech] };
}

export default function ComparisonCard() {
  const { isAr } = useLang();
  const { symbol } = useCurrency();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const cardRef = useRef(null);
  const fitWrapRef = useRef(null);
  const [fitScale, setFitScale] = useState(1);

  const [items, setItems] = useState([]); // [{ id, p, price, discount, rating }]
  const [query, setQuery] = useState("");
  const [busy, setBusy] = useState(false);
  const [recId, setRecId] = useState(null);

  // global pricing + options
  const [taxPct, setTaxPct] = useState("");
  const [customCur, setCustomCur] = useState("");
  const [bg, setBg] = useState("#ffffff");
  const [lang, setLang] = useState("both");
  const [frame, setFrame] = useState("none");
  const [fontScale, setFontScale] = useState(1);

  // comparison style — the user picks how the table reads
  const [mode, setMode] = useState("matrix"); // matrix | spotlight | price | rating
  const [titleText, setTitleText] = useState(""); // عنوان البطاقة — يحرره المستخدم (قاعدة A 1.796)
  const [noteMode, setNoteMode] = useState("img"); // النوتات: img (افتراضي) | text | both
  const [fgChoice, setFgChoice] = useState("auto"); // لون الخط: auto أو لون ثابت
  const [autoK, setAutoK] = useState(1); // معامل ملاءمة تلقائي — ارتفاع البطاقة لا يتجاوز 1024
  const [spotlightId, setSpotlightId] = useState(null);
  const [gridLines, setGridLines] = useState(false); // borderless / airy by default

  // field toggles
  const [showImage, setShowImage] = useState(true);
  const [showBrand, setShowBrand] = useState(true);
  const [showFamily, setShowFamily] = useState(true);
  const [showNotes, setShowNotes] = useState(true);
  const [showOcc, setShowOcc] = useState(true);
  const [showType, setShowType] = useState(true);
  const [showGender, setShowGender] = useState(true);
  const [showYear, setShowYear] = useState(true);
  const [showPrice, setShowPrice] = useState(true);
  const [showMark, setShowMark] = useState(true);
  const [showDesc, setShowDesc] = useState(true);

  const showAr = lang !== "en";
  const showEn = lang !== "ar";
  const curSym = customCur || symbol || "﷼";
  const fs = (n) => Math.max(5, Math.round(n * fontScale * autoK * 10) / 10);

  // ملاءمة تلقائية (قاعدة A): ارتفاع البطاقة الكلي لا يتجاوز 1024 بأي حال —
  // يصغر كل شيء تدريجيا (خط و صور) حتى يستقر الجدول داخل الحد.
  useEffect(() => { setAutoK(1); }, [items, fontScale, noteMode, showDesc, showImage, showNotes, showOcc, showFamily, lang, mode, titleText, gridLines]);  
  useEffect(() => {
    const el = cardRef.current; if (!el) return undefined;
    const t = setTimeout(() => { if (el.offsetHeight > 1024 && autoK > 0.4) setAutoK((k) => Math.max(0.4, Math.round(k * 0.92 * 1000) / 1000)); }, 30);
    return () => clearTimeout(t);
  });

  // ملاءمة العرض للشاشة (A 1.812): نقيس عرض البطاقة الفعلي مقابل عرض الحاوية،
  // فإن فاضت نصغّر بنسبة scale حتى تظهر كل الأعمدة دفعة واحدة (سقف 1 — لا نكبّر).
  useEffect(() => {
    const wrap = fitWrapRef.current, card = cardRef.current;
    if (!wrap || !card) { setFitScale(1); return undefined; }
    const measure = () => {
      const avail = wrap.clientWidth || 1;
      const natural = card.scrollWidth || avail;
      setFitScale(natural > avail ? Math.max(0.4, Math.round((avail / natural) * 1000) / 1000) : 1);
    };
    const t = setTimeout(measure, 40);
    let ro;
    try { ro = new ResizeObserver(measure); ro.observe(wrap); } catch { /* بيئة بلا ResizeObserver */ }
    window.addEventListener("resize", measure);
    return () => { clearTimeout(t); if (ro) ro.disconnect(); window.removeEventListener("resize", measure); };
  }, [items, fontScale, noteMode, lang, mode, titleText, gridLines, autoK, showImage, showNotes, showDesc, showOcc, showFamily]);

  const [userMark, setUserMark] = useState(DEFAULT_USER_MARK);
  useEffect(() => { let on = true; resolveUserMark().then((m) => { if (on) setUserMark(m || DEFAULT_USER_MARK); }); return () => { on = false; }; }, []);

  // efficient search via index (no full-catalog load)
  const t = query.trim();
  const { data: results = [] } = useQuery({
    queryKey: ["cmp-search", t],
    enabled: t.length >= 2,
    queryFn: async () => {
      if (searchIndexReady()) {
        const { ids } = await searchPerfumeIds(t);
        if (ids && ids.length) return apphost.entities.Perfume.getMany(ids.slice(0, 20));
      }
      // بديلٌ مباشر يعمل فورًا حتى قبل اكتمال الفهرس
      return await searchPerfumesDirect(t, 20);
    },
    staleTime: 3e5,
  });

  const addPerfume = (p) => {
    setItems((arr) => (arr.length >= MAX || arr.some((x) => x.id === p.id) ? arr : [...arr, { id: p.id, p, price: "", discount: "", rating: "" }]));
    setQuery("");
  };
  const removeItem = (id) => setItems((arr) => {
    const next = arr.filter((x) => x.id !== id);
    if (spotlightId === id) setSpotlightId(next[0]?.id ?? null);
    return next;
  });
  const setItemField = (id, field, value) => setItems((arr) => arr.map((x) => (x.id === id ? { ...x, [field]: value } : x)));

  const taxNum = parseFloat(taxPct) || 0;
  const priceOf = (it) => {
    const priceNum = parseFloat(it.price) || 0;
    const discNum = parseFloat(it.discount) || 0;
    const afterTax = priceNum + priceNum * (taxNum / 100);
    const total = Math.round(afterTax - afterTax * (discNum / 100));
    return { priceNum, discNum, total };
  };

  // winners per comparison style
  const calc = useMemo(() => {
    const rows = items.map((it) => {
      const { priceNum, total } = priceOf(it);
      const price = total || priceNum;
      const rating = parseFloat(it.rating) || 0;
      const health = healthOf(it.p);
      const value = price > 0 && rating > 0 ? rating / price : 0; // التقييم لكلّ وحدة سعر
      return { id: it.id, total: price, rating, value, health };
    });
    const best = (arr, better) => (arr.length ? arr.reduce((a, b) => (better(b, a) ? b : a)).id : null);
    const bestPriceId = best(rows.filter((r) => r.total > 0), (b, a) => b.total < a.total);
    const bestRatedId = best(rows.filter((r) => r.rating > 0), (b, a) => b.rating > a.rating);
    const bestValueId = best(rows.filter((r) => r.value > 0), (b, a) => b.value > a.value);
    const bestHealthId = best(rows.filter((r) => r.health.total > 0), (b, a) => b.health.score > a.health.score);
    const maxTotal = Math.max(1, ...rows.map((r) => r.total));
    const maxValue = Math.max(0, ...rows.map((r) => r.value)) || 1;
    const byId = Object.fromEntries(rows.map((r) => [r.id, r]));
    return { bestPriceId, bestRatedId, bestValueId, bestHealthId, maxTotal, maxValue, byId };
  }, [items, taxPct]);  
  const winnerId =
    mode === "spotlight" ? spotlightId :
    mode === "price" ? calc.bestPriceId :
    mode === "rating" ? calc.bestRatedId :
    mode === "value" ? calc.bestValueId :
    mode === "health" ? calc.bestHealthId : null;

  const dark = bg !== "#ffffff";
  const fg = fgChoice !== "auto" ? fgChoice : (dark ? "#ffffff" : "#1a1a1a");
  const sub = fgChoice !== "auto" ? `${fgChoice}B3` : (dark ? "rgba(255,255,255,0.7)" : "rgba(0,0,0,0.55)");
  const divider = dark ? "1px solid rgba(255,255,255,0.18)" : "1px solid rgba(0,0,0,0.1)";
  const cardBorder = frame === "none" ? "none" : `2px ${frame === "dotted" ? "dashed" : "solid"} ${GOLD}`;

  const tabCls = (on) => `flex-1 py-2 rounded-none text-xs font-body font-semibold transition-colors ${on ? "bg-[var(--brand)] text-white" : "bg-transparent text-muted-foreground border"}`;
  const miniTab = (on) => `px-3 py-1.5 rounded-none text-[11px] font-body transition-colors ${on ? "bg-[var(--brand)] text-white" : "bg-transparent text-muted-foreground border"}`;

  const info = (p) => ({
    name: p.name_en || p.name || "",
    name_ar: p.name_ar || "",
    brand: p.brand_name || "",
    image: p.image_url || "",
    family: p.odor_family || "",
    notes: [p.top_notes, p.heart_notes, p.base_notes].filter(Boolean).join(isAr ? "، " : ", "),
    occasions: p.occasions || "",
    accords: p.accords || "",
    desc: p.description || p.about_en || "",
    desc_ar: p.description_ar || p.about_ar || "",
    noteNames: [p.top_notes, p.heart_notes, p.base_notes].filter(Boolean).join(",").split(",").map((x) => x.trim()).filter(Boolean),
    type: p.type || "",
    gender: p.gender || "",
    year: p.release_year || "",
  });

  // سجلات النوتات لصور وضعي «صور» و «نص و صور» — تحمل عند الحاجة فقط و تُخبأ
  const wantNoteImgs = showNotes && noteMode !== "text" && items.length > 0;
  const { data: cmpNoteRecords = [] } = useQuery({
    queryKey: ["cmp-note-records"],
    queryFn: () => apphost.entities.PerfumeNote.list("name", 1000000),
    enabled: wantNoteImgs,
    staleTime: 1000 * 60 * 10,
  });
  const noteMaps = useMemo(() => {
    const eng = {}; const seen = {}; const ar = {};
    cmpNoteRecords.forEach((n) => {
      [n.name, n.name_en].forEach((nm) => { const k = normKey2(nm); if (k && !(k in eng)) eng[k] = n; });
      const ka = normKey2(n.name_ar);
      if (ka) { seen[ka] = (seen[ka] || 0) + 1; if (!(ka in ar)) ar[ka] = n; }
    });
    Object.keys(seen).forEach((k) => { if (seen[k] > 1) delete ar[k]; });
    return { eng, ar };
  }, [cmpNoteRecords]);
  const findNoteRec = (rawName) => {
    const lat = normKey2(latinOf2(rawName));
    if (lat && noteMaps.eng[lat]) return noteMaps.eng[lat];
    const ka = normKey2(arabicOf2(rawName) || rawName);
    if (ka && noteMaps.ar[ka]) return noteMaps.ar[ka];
    return null;
  };

  const occEmojis = (csv) =>
    (csv || "").split(",").map((s) => s.trim()).filter(Boolean).slice(0, 8).map((o) => (occasionInfo(o) || { emoji: "", ar: o, en: o }));

  const serialize = () => ({
    items: items.map((it) => ({ id: it.id, price: it.price, discount: it.discount, rating: it.rating })),
    taxPct, customCur, bg, lang, frame, fontScale, mode, spotlightId, gridLines,
    titleText, noteMode, fgChoice, showDesc,
    showImage, showBrand, showFamily, showNotes, showOcc, showType, showGender, showYear, showPrice, showMark,
  });

  // استعادة بطاقة مقارنة محفوظة (?rec=)
  useEffect(() => {
    const rec = searchParams.get("rec");
    if (!rec) return;
    let on = true;
    exportHistory.get(Number(rec)).then(async (r) => {
      if (!on || !r || !r.payload) return;
      const d = r.payload;
      setRecId(r.id);
      setTaxPct(d.taxPct || ""); setCustomCur(d.customCur || "");
      if (d.bg) setBg(d.bg); if (d.lang) setLang(d.lang); if (d.frame) setFrame(d.frame); if (typeof d.fontScale === "number") setFontScale(d.fontScale);
      if (d.mode) setMode(d.mode); if (d.spotlightId != null) setSpotlightId(d.spotlightId); if (typeof d.gridLines === "boolean") setGridLines(d.gridLines);
      if (typeof d.titleText === "string") setTitleText(d.titleText); if (d.noteMode) setNoteMode(d.noteMode); if (d.fgChoice) setFgChoice(d.fgChoice); setShowDesc(d.showDesc !== false);
      setShowImage(d.showImage !== false); setShowBrand(d.showBrand !== false); setShowFamily(d.showFamily !== false); setShowNotes(d.showNotes !== false); setShowOcc(d.showOcc !== false); setShowType(d.showType !== false); setShowGender(d.showGender !== false); setShowYear(d.showYear !== false); setShowPrice(d.showPrice !== false); setShowMark(d.showMark !== false);
      const arr = Array.isArray(d.items) ? d.items : [];
      if (arr.length) {
        try {
          const ps = await apphost.entities.Perfume.getMany(arr.map((x) => x.id));
          if (!on) return;
          const byId = {}; for (const pp of ps || []) byId[pp.id] = pp;
          setItems(arr.filter((x) => byId[x.id]).map((x) => ({ id: x.id, p: byId[x.id], price: x.price || "", discount: x.discount || "", rating: x.rating || "" })));
        } catch { /* noop */ }
      }
    });
    return () => { on = false; };
  }, []);  

  const handleExport = async () => {
    if (!cardRef.current || items.length === 0) return;
    setBusy(true);
    try {
      const canvas = await captureElementHQ(cardRef.current, { pixelRatio: 3, backgroundColor: bg });
      await saveCanvasAsImage(canvas, `comparison-${items.length}.png`);
      const nm = items.map((it) => it.p.name_en || it.p.name).filter(Boolean).slice(0, 3).join(" · ") || (isAr ? "مقارنة" : "Comparison");
      const newId = await recordExport({ type: "comparison", refId: "", name: nm, payload: serialize(), recId });
      if (newId) setRecId(newId);
      toast.success(isAr ? "تم حفظ البطاقة" : "Card saved");
    } catch {
      toast.error(isAr ? "تعذّر الحفظ" : "Export failed");
    } finally {
      setBusy(false);
    }
  };

  const MODE_TABS = [
    ["matrix", isAr ? "مصفوفة" : "Matrix"],
    ["spotlight", isAr ? "إبراز عطر" : "Spotlight"],
    ["price", isAr ? "الأفضل سعرًا" : "Best price"],
    ["rating", isAr ? "الأعلى تقييمًا" : "Top rated"],
    ["value", isAr ? "القيمة" : "Value"],
    ["health", isAr ? "الصحّة" : "Health"],
  ];

  return (
    <div className="min-h-screen bg-background" dir={isAr ? "rtl" : "ltr"}>
      <div className="flex items-center gap-2 p-3 border-b">
        <button onClick={() => navigate(-1)} aria-label="back"><ArrowLeft className="w-5 h-5" /></button>
        <h1 className="font-body font-semibold text-sm flex items-center gap-2">
          {isAr ? "بطاقة عطور" : "Perfume Card"}
        </h1>
      </div>

      <div className="p-4 space-y-4 max-w-md mx-auto">
        {/* search + add (max 4) */}
        <div className="space-y-1">
          <div className="flex items-center gap-2 border rounded-none px-3 py-2">
            <Search className="w-4 h-4 opacity-60" />
            <input
              name="cmp-search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={items.length >= MAX ? (isAr ? "بلغت الحدّ الأقصى (٤)" : "Max reached (4)") : (isAr ? "ابحث وأضف عطرًا" : "Search & add a perfume")}
              disabled={items.length >= MAX}
              className="flex-1 bg-transparent outline-none text-sm disabled:opacity-50"
            />
          </div>
          {!searchIndexReady() && <p className="text-xs text-muted-foreground">{isAr ? "فهرس البحث قيد البناء…" : "Search index building…"}</p>}
          {items.length < MAX && results.length > 0 && t.length >= 2 && (
            <div className="border rounded-none max-h-44 overflow-auto">
              {results.map((p) => (
                <button key={p.id} onClick={() => addPerfume(p)} className="block w-full text-start px-3 py-2 text-sm hover:bg-accent">
                  {p.name_en || p.name}{p.brand_name ? <span className="opacity-60"> · {p.brand_name}</span> : null}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* picked items + per-perfume pricing + your rating */}
        {items.length > 0 && (
          <div className="space-y-2">
            {items.map((it) => {
              const r = parseFloat(it.rating) || 0;
              return (
                <div key={it.id} className="border rounded-none p-2 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="truncate">{it.p.name_en || it.p.name}{it.p.brand_name ? <span className="opacity-60"> · {it.p.brand_name}</span> : null}</span>
                    <button onClick={() => removeItem(it.id)} aria-label="remove" className="text-[#B76E79] ms-2"><X className="w-4 h-4" /></button>
                  </div>
                  <div className="flex gap-2">
                    <label className="flex items-center gap-2 border rounded-none px-2 py-1.5 flex-1">
                      <span className="text-[11px] text-muted-foreground whitespace-nowrap">{isAr ? "السعر" : "Price"}</span>
                      <input name={`cmp-price-${it.id}`} type="number" dir="ltr" value={it.price} onChange={(e) => setItemField(it.id, "price", e.target.value)} className="flex-1 bg-transparent outline-none text-sm w-full" />
                    </label>
                    <label className="flex items-center gap-2 border rounded-none px-2 py-1.5 flex-1">
                      <span className="text-[11px] text-muted-foreground whitespace-nowrap">{isAr ? "خصم %" : "Disc %"}</span>
                      <input name={`cmp-disc-${it.id}`} type="number" dir="ltr" value={it.discount} onChange={(e) => setItemField(it.id, "discount", e.target.value)} className="flex-1 bg-transparent outline-none text-sm w-full" />
                    </label>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-muted-foreground whitespace-nowrap">{isAr ? "تقييمك" : "Your rating"}</span>
                    <div className="flex items-center gap-0.5">
                      {[1, 2, 3, 4, 5].map((n) => (
                        <button
                          key={n}
                          onClick={() => setItemField(it.id, "rating", String(r === n ? 0 : n))}
                          aria-label={`${n}`}
                          className="text-lg leading-none"
                          style={{ color: r >= n ? GOLD : (dark ? "#555" : "#cbcbcb") }}
                        >★</button>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
            <div className="flex gap-2">
              <label className="flex items-center gap-2 border rounded-none px-2 py-1.5 flex-1">
                <span className="text-[11px] text-muted-foreground whitespace-nowrap">{isAr ? "الضريبة %" : "Tax %"}</span>
                <input name="cmp-tax" type="number" dir="ltr" value={taxPct} onChange={(e) => setTaxPct(e.target.value)} className="flex-1 bg-transparent outline-none text-sm w-full" />
              </label>
              <label className="flex items-center gap-2 border rounded-none px-2 py-1.5 flex-1">
                <span className="text-[11px] text-muted-foreground whitespace-nowrap">{isAr ? "العملة" : "Currency"}</span>
                <input name="cmp-cur" dir="ltr" value={customCur} onChange={(e) => setCustomCur(e.target.value)} placeholder={symbol || "﷼"} className="flex-1 bg-transparent outline-none text-sm w-full" />
              </label>
            </div>
          </div>
        )}

        {/* comparison style — the user decides how it reads */}
        <div className="space-y-2">
          <span className="text-[11px] text-muted-foreground">{isAr ? "أسلوب المقارنة:" : "Comparison style:"}</span>
          <div className="flex flex-wrap gap-2">
            {MODE_TABS.map(([v, l]) => (
              <button key={v} onClick={() => { setMode(v); if (v === "spotlight" && spotlightId == null) setSpotlightId(items[0]?.id ?? null); }} className={miniTab(mode === v)}>{l}</button>
            ))}
          </div>
          {mode === "spotlight" && items.length > 0 && (
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[11px] text-muted-foreground">{isAr ? "العطر المُبرَز:" : "Feature:"}</span>
              {items.map((it) => (
                <button key={it.id} onClick={() => setSpotlightId(it.id)} className={miniTab(spotlightId === it.id)}>{it.p.name_en || it.p.name}</button>
              ))}
            </div>
          )}
          {mode === "price" && calc.bestPriceId == null && <p className="text-[11px] text-muted-foreground">{isAr ? "أدخل الأسعار لإظهار الأفضل." : "Enter prices to crown the best."}</p>}
          {mode === "rating" && calc.bestRatedId == null && <p className="text-[11px] text-muted-foreground">{isAr ? "قيّم العطور بالنجوم لإظهار الأعلى." : "Rate the perfumes to crown the top."}</p>}
          {mode === "value" && calc.bestValueId == null && <p className="text-[11px] text-muted-foreground">{isAr ? "القيمة = التقييم ÷ السعر؛ أدخل الاثنين." : "Value = rating ÷ price; enter both."}</p>}
          {mode === "health" && <p className="text-[11px] text-muted-foreground">{isAr ? "الصحّة من نوتات العطر — كلّما قلّت النوتات المُثيرة (صداع/جيوب/تحسّس) ارتفعت." : "Health from the perfume's notes — fewer trigger notes (headache/sinus/allergy) = higher."}</p>}
        </div>

        {/* visual options */}
        <div className="space-y-3">
          {/* عنوان البطاقة — يحرره المستخدم (قاعدة A 1.796) */}
          <input
            type="text"
            value={titleText}
            onChange={(e) => setTitleText(e.target.value.slice(0, 60))}
            placeholder={items.length === 1 ? (isAr ? "عنوان البطاقة (افتراضي: بطاقة عطر)" : "Card title (default: Perfume Card)") : (isAr ? "عنوان البطاقة (افتراضي: مقارنة عطور)" : "Card title (default: Perfume Comparison)")}
            className="w-full h-9 rounded-none border bg-transparent px-3 text-xs font-body"
          />
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] text-muted-foreground">{isAr ? "الخلفية:" : "Background:"}</span>
            {BG_COLORS.map((c) => (
              <button key={c} onClick={() => setBg(c)} style={{ background: c }} className={`w-7 h-7 rounded-none border ${bg === c ? "ring-2 ring-[var(--brand)]" : ""}`} aria-label={c} />
            ))}
          </div>
          {/* لون الخط — بالإضافة لألوان الخلفية (قاعدة A 1.796) */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] text-muted-foreground">{isAr ? "لون الخط:" : "Font color:"}</span>
            <button onClick={() => setFgChoice("auto")} className={miniTab(fgChoice === "auto")}>{isAr ? "تلقائي" : "Auto"}</button>
            {["#1a1a1a", "#ffffff", "var(--brand)", "#B76E79", "#5b4423", "#0c447c"].map((c) => (
              <button key={c} onClick={() => setFgChoice(c)} style={{ background: c }} className={`w-7 h-7 rounded-none border ${fgChoice === c ? "ring-2 ring-[var(--brand)]" : ""}`} aria-label={c} />
            ))}
          </div>
          {/* وضع النوتات: صور (افتراضي) / نص / نص و صور */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] text-muted-foreground">{isAr ? "النوتات:" : "Notes:"}</span>
            {[["img", isAr ? "صور" : "Images"], ["text", isAr ? "نص" : "Text"], ["both", isAr ? "نص و صور" : "Text + images"]].map(([v, l]) => (
              <button key={v} onClick={() => setNoteMode(v)} className={miniTab(noteMode === v)}>{l}</button>
            ))}
          </div>
          <div className="flex gap-2">
            {["both", "ar", "en"].map((l) => (
              <button key={l} onClick={() => setLang(l)} className={tabCls(lang === l)}>{l === "both" ? (isAr ? "اللغتان" : "Both") : l.toUpperCase()}</button>
            ))}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] text-muted-foreground">{isAr ? "الإطار:" : "Frame:"}</span>
            {[["solid", isAr ? "خطّ" : "Solid"], ["dotted", isAr ? "منقّط" : "Dotted"], ["none", isAr ? "بدون" : "None"]].map(([v, l]) => (
              <button key={v} onClick={() => setFrame(v)} className={miniTab(frame === v)}>{l}</button>
            ))}
            <button onClick={() => setGridLines((g) => !g)} className={miniTab(gridLines)}>{isAr ? "خطوط الصفوف" : "Row lines"}</button>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] text-muted-foreground">{isAr ? "الخطّ:" : "Size:"}</span>
            {[0.8, 0.92, 1, 1.12, 1.28].map((v, i) => (
              <button key={v} onClick={() => setFontScale(v)} className={miniTab(Math.abs(fontScale - v) < 0.001)} style={{ fontSize: 9 + i * 2.5, lineHeight: 1, padding: "5px 9px" }}>A</button>
            ))}
          </div>
          <div className="flex gap-x-4 gap-y-2 flex-wrap">
            {[
              [showImage, setShowImage, isAr ? "الصورة" : "Image"],
              [showBrand, setShowBrand, isAr ? "البراند" : "Brand"],
              [showFamily, setShowFamily, isAr ? "الأكورد" : "Accords"],
              [showDesc, setShowDesc, isAr ? "الوصف" : "Description"],
              [showNotes, setShowNotes, isAr ? "النوتات" : "Notes"],
              [showOcc, setShowOcc, isAr ? "المناسبات" : "Occasions"],
              [showType, setShowType, isAr ? "النوع" : "Type"],
              [showGender, setShowGender, isAr ? "الجنس" : "Gender"],
              [showYear, setShowYear, isAr ? "السنة" : "Year"],
              [showPrice, setShowPrice, isAr ? "السعر" : "Price"],
              [showMark, setShowMark, isAr ? "العلامة" : "Mark"],
            ].map(([val, setter, label], i) => (
              <label key={i} className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={val} onChange={(e) => setter(e.target.checked)} />
                {label}
              </label>
            ))}
          </div>
        </div>

        {/* preview card — explicit comparison table.
            ملاءمة للشاشة (A 1.812): المعاينة كانت overflow-auto + minWidth:fit-content
            فبطاقة ٣–٤ عطور أعرض من الشاشة و تتطلب سحبا أفقيا و لا «تلائم». الآن
            نقيس عرض الحاوية و نصغّر البطاقة بصريا (transform scale) لتظهر كاملة —
            دون مس أبعاد التصدير (cardRef يبقى بمقاسه الأصلي للالتقاط عالي الدقة). */}
        <div className="overflow-hidden" ref={fitWrapRef}>
          {items.length === 0 ? (
            <div className="text-sm text-muted-foreground text-center py-10">{isAr ? "أضف عطرًا (حتى أربعة) للمقارنة أو العرض" : "Add a perfume (up to four) to compare or display"}</div>
          ) : (
            <div style={{ transform: `scale(${fitScale})`, transformOrigin: "top center", width: "fit-content", margin: "0 auto" }}>
            <div
              ref={cardRef}
              style={{ background: bg, color: fg, padding: 22, border: cardBorder, display: "flex", flexDirection: "column", alignItems: "center", gap: 12, textAlign: "center", minWidth: "fit-content" }}
            >
              <div style={{ fontFamily: isAr ? "Amiri, serif" : "Cinzel, serif", fontSize: fs(11), letterSpacing: ".12em", textTransform: "uppercase", color: GOLD }}>
                {titleText.trim() || (items.length === 1 ? (isAr ? "بطاقة عطر" : "Perfume Card") : (isAr ? "مقارنة عطور" : "Perfume Comparison"))}
              </div>
              {(() => {
                const n = Math.max(1, items.length);
                const colW = Math.max(94, Math.min(150, Math.round(540 / n)));
                const isWin = (id) => winnerId != null && winnerId === id;
                const isDim = (id) => mode === "spotlight" && winnerId != null && winnerId !== id;
                const labelCell = {
                  padding: "7px 8px", textAlign: isAr ? "right" : "left", fontSize: fs(9),
                  letterSpacing: ".04em", textTransform: "uppercase", color: sub,
                  borderBottom: gridLines ? divider : "none", whiteSpace: "nowrap",
                };
                const cell = (id) => ({
                  width: colW, verticalAlign: "middle", padding: "7px 8px", textAlign: "center",
                  borderBottom: gridLines ? divider : "none",
                  background: isWin(id) ? (dark ? "rgba(200,160,46,0.16)" : "rgba(200,160,46,0.10)") : "transparent",
                  borderInlineStart: isWin(id) ? `2px solid ${GOLD}` : "none",
                  borderInlineEnd: isWin(id) ? `2px solid ${GOLD}` : "none",
                  opacity: isDim(id) ? 0.5 : 1,
                });
                const showRatingRow = mode === "rating" || items.some((it) => (parseFloat(it.rating) || 0) > 0);
                return (
                  <table dir={isAr ? "rtl" : "ltr"} style={{ borderCollapse: "collapse", margin: "0 auto" }}>
                    <thead>
                      <tr>
                        <td style={{ ...labelCell, borderBottom: "none" }} />
                        {items.map((it) => {
                          const d = info(it.p); const win = isWin(it.id);
                          return (
                            <td key={it.id} style={{ ...cell(it.id), verticalAlign: "top", borderTop: win ? `2px solid ${GOLD}` : "none" }}>
                              <div style={{ height: fs(16), fontSize: fs(14), lineHeight: 1 }}>{win ? "👑" : ""}</div>
                              {showImage ? (d.image ? (
                                <img src={d.image} alt="" crossOrigin="anonymous" style={{ width: fs(68), height: fs(84), objectFit: "contain", display: "block", margin: "0 auto" }} />
                              ) : (
                                <AccordFlacon accords={d.accords} style={{ width: fs(58), height: fs(72), display: "block", margin: "0 auto" }} />
                              )) : null}
                              {showEn && d.name ? (
                                <div style={{ fontFamily: "Cinzel, serif", color: GOLD, fontSize: fs(12), fontWeight: 700, letterSpacing: ".02em", textTransform: "uppercase", lineHeight: 1.2, marginTop: 3 }}>{d.name}</div>
                              ) : null}
                              {showAr && d.name_ar ? (
                                <div style={{ fontFamily: "Amiri, serif", color: PINK, fontSize: fs(14), fontWeight: 700, lineHeight: 1.25 }}>{d.name_ar}</div>
                              ) : null}
                              {showBrand && d.brand ? (
                                <div style={{ fontSize: fs(9), color: sub, letterSpacing: ".05em", textTransform: "uppercase", marginTop: 1 }}>{d.brand}</div>
                              ) : null}
                            </td>
                          );
                        })}
                      </tr>
                    </thead>
                    <tbody>
                      {showFamily ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "الأكورد" : "Accords"}</td>
                          {items.map((it) => {
                            const d = info(it.p);
                            const acc = parseAccordsCmp(d.accords);
                            return (
                              <td key={it.id} style={cell(it.id)}>
                                {acc.length ? (
                                  <div style={{ width: "100%" }}>
                                    <div style={{ display: "flex", width: "100%", height: fs(15), overflow: "hidden" }}>
                                      {acc.map((a) => (
                                        <span key={a.id} title={`${a.en} ${a.ar}`} style={{ flex: `${Math.max(4, a.pct)} 1 0%`, background: a.bar, color: a.font || "#fff", fontSize: fs(5.5), lineHeight: 1, display: "inline-flex", alignItems: "center", justifyContent: "center", whiteSpace: "nowrap", overflow: "hidden", minWidth: 0 }} />
                                      ))}
                                    </div>
                                    <div style={{ fontSize: fs(6.5), color: sub, marginTop: 2, lineHeight: 1.4 }}>
                                      {acc.map((a) => `${a.en} ${a.ar}`).join(" · ")}
                                    </div>
                                  </div>
                                ) : (
                                  <span style={{ fontSize: fs(11), color: fg }}>{d.family ? `🌸 ${d.family}` : "—"}</span>
                                )}
                              </td>
                            );
                          })}
                        </tr>
                      ) : null}
                      {showDesc ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "الوصف" : "Description"}</td>
                          {items.map((it) => {
                            const d = info(it.p);
                            const txt = [showAr && d.desc_ar, showEn && d.desc].filter(Boolean).join(" — ");
                            return <td key={it.id} style={cell(it.id)}><span style={{ fontSize: fs(7.5), color: sub, lineHeight: 1.55, display: "block", maxWidth: colW - 8, margin: "0 auto" }}>{txt || "—"}</span></td>;
                          })}
                        </tr>
                      ) : null}
                      {showType ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "النوع" : "Type"}</td>
                          {items.map((it) => { const d = info(it.p); return <td key={it.id} style={cell(it.id)}><span style={{ fontSize: fs(11), color: fg }}>{d.type ? `🏷️ ${d.type}` : "—"}</span></td>; })}
                        </tr>
                      ) : null}
                      {showGender ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "الجنس" : "Gender"}</td>
                          {items.map((it) => { const d = info(it.p); const gd = GENDER_DISP[(d.gender || "").toLowerCase()]; const g = gd ? (isAr ? gd.ar : gd.en) : d.gender; return <td key={it.id} style={cell(it.id)}><span style={{ fontSize: fs(11), color: fg }}>{g ? `⚧ ${g}` : "—"}</span></td>; })}
                        </tr>
                      ) : null}
                      {showYear ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "السنة" : "Year"}</td>
                          {items.map((it) => { const d = info(it.p); return <td key={it.id} style={cell(it.id)}><span style={{ fontSize: fs(11), color: fg }}>{d.year ? `🗓️ ${d.year}` : "—"}</span></td>; })}
                        </tr>
                      ) : null}
                      {showOcc ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "المناسبات" : "Occasions"}</td>
                          {items.map((it) => { const occs = occEmojis(info(it.p).occasions); return <td key={it.id} style={cell(it.id)}><span style={{ fontSize: fs(13) }}>{occs.length ? occs.map((o, i) => (o.emoji ? <span key={i} title={isAr ? o.ar : o.en}>{o.emoji}</span> : null)) : "—"}</span></td>; })}
                        </tr>
                      ) : null}
                      {showNotes ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "النوتات" : "Notes"}</td>
                          {items.map((it) => {
                            const d = info(it.p);
                            if (noteMode === "text" || !d.noteNames.length) {
                              return <td key={it.id} style={cell(it.id)}><span style={{ fontSize: fs(9), color: sub, lineHeight: 1.5 }}>{d.notes || "—"}</span></td>;
                            }
                            return (
                              <td key={it.id} style={cell(it.id)}>
                                <div style={{ display: "flex", flexWrap: "wrap", gap: fs(3), justifyContent: "center" }}>
                                  {d.noteNames.map((nm, i) => {
                                    const rec = findNoteRec(nm);
                                    const img = rec?.image_url || "";
                                    const en = latinOf2(nm) || rec?.name_en || rec?.name || nm;
                                    const arN = arabicOf2(nm) || rec?.name_ar || "";
                                    return (
                                      <div key={i} title={`${en} ${arN}`} style={{ width: fs(noteMode === "both" ? 26 : 22), textAlign: "center" }}>
                                        {img ? (
                                          <img src={img} alt="" crossOrigin="anonymous" style={{ width: fs(noteMode === "both" ? 24 : 20), height: fs(noteMode === "both" ? 24 : 20), objectFit: "cover", display: "block", margin: "0 auto" }} />
                                        ) : (
                                          <div style={{ width: fs(noteMode === "both" ? 24 : 20), height: fs(noteMode === "both" ? 24 : 20), margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "center", background: dark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.05)", fontSize: fs(5), color: sub, lineHeight: 1.15, overflow: "hidden", padding: 1 }}>{showAr && arN ? arN : en}</div>
                                        )}
                                        {noteMode === "both" ? (
                                          <div style={{ fontSize: fs(5.5), color: sub, lineHeight: 1.2, marginTop: 1, overflow: "hidden" }}>{[showEn ? en : "", showAr ? arN : ""].filter(Boolean).join(" ")}</div>
                                        ) : null}
                                      </div>
                                    );
                                  })}
                                </div>
                              </td>
                            );
                          })}
                        </tr>
                      ) : null}
                      {mode === "health" ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "الصحّة" : "Health"}</td>
                          {items.map((it) => {
                            const hi = healthOf(it.p);
                            const col = hi.score >= 67 ? "#2e7d32" : hi.score >= 34 ? GOLD : PINK;
                            return (
                              <td key={it.id} style={cell(it.id)}>
                                {hi.total ? (
                                  <div>
                                    <div style={{ fontSize: fs(15), fontWeight: 700, color: col }}>{hi.score}%</div>
                                    <div style={{ fontSize: fs(11) }}>{hi.mech.length ? hi.mech.map((m) => <span key={m} title={isAr ? MECH[m].ar : MECH[m].en}>{MECH[m].emoji}</span>) : "👩🏻‍⚕️👨🏻‍⚕️"}</div>
                                  </div>
                                ) : <span style={{ fontSize: fs(11), color: sub }}>—</span>}
                              </td>
                            );
                          })}
                        </tr>
                      ) : null}
                      {showRatingRow ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "التقييم" : "Rating"}</td>
                          {items.map((it) => { const r = parseFloat(it.rating) || 0; return <td key={it.id} style={cell(it.id)}><span style={{ fontSize: fs(12), color: GOLD, letterSpacing: "1px" }}>{r > 0 ? "★".repeat(r) + "☆".repeat(5 - r) : "—"}</span></td>; })}
                        </tr>
                      ) : null}
                      {showPrice ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "السعر" : "Price"}</td>
                          {items.map((it) => {
                            const { priceNum, discNum, total } = priceOf(it);
                            const val = total || priceNum;
                            const win = isWin(it.id);
                            const barW = mode === "price" && val > 0 ? Math.round((val / calc.maxTotal) * 100) : 0;
                            return (
                              <td key={it.id} style={cell(it.id)}>
                                {val > 0 ? (
                                  <div>
                                    <div style={{ fontSize: fs(11), fontWeight: 700, color: GOLD }}>{val}{curSym}{taxNum > 0 ? <span style={{ fontSize: fs(6.5), fontWeight: 400, opacity: 0.75, color: sub, marginInlineStart: 3 }}>{isAr ? "شامل الضريبة" : "incl. tax"}</span> : null}</div>
                                    {discNum > 0 && priceNum > 0 ? (
                                      <div style={{ fontSize: fs(7), color: sub }}>
                                        <span style={{ textDecoration: "line-through", opacity: 0.6 }}>{priceNum}{curSym}</span> <span style={{ color: PINK }}>−{discNum}%</span>
                                      </div>
                                    ) : null}
                                    {mode === "price" ? (
                                      <div style={{ height: 4, marginTop: 4, background: dark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.08)" }}>
                                        <div style={{ height: "100%", width: `${barW}%`, background: win ? GOLD : (dark ? "rgba(255,255,255,0.4)" : "rgba(0,0,0,0.25)") }} />
                                      </div>
                                    ) : null}
                                  </div>
                                ) : <span style={{ fontSize: fs(11), color: sub }}>—</span>}
                              </td>
                            );
                          })}
                        </tr>
                      ) : null}
                      {mode === "value" ? (
                        <tr>
                          <td style={labelCell}>{isAr ? "القيمة" : "Value"}</td>
                          {items.map((it) => {
                            const v = calc.byId[it.id]?.value || 0;
                            const win = isWin(it.id);
                            const w = v > 0 ? Math.round((v / calc.maxValue) * 100) : 0;
                            return (
                              <td key={it.id} style={cell(it.id)}>
                                {v > 0 ? (
                                  <div style={{ height: 6, background: dark ? "rgba(255,255,255,0.12)" : "rgba(0,0,0,0.08)" }}>
                                    <div style={{ height: "100%", width: `${w}%`, background: win ? GOLD : (dark ? "rgba(255,255,255,0.4)" : "rgba(0,0,0,0.25)") }} />
                                  </div>
                                ) : <span style={{ fontSize: fs(10), color: sub }}>{isAr ? "سعر + تقييم" : "price + rating"}</span>}
                              </td>
                            );
                          })}
                        </tr>
                      ) : null}
                    </tbody>
                  </table>
                );
              })()}
              {mode === "price" && calc.bestPriceId != null ? <div style={{ fontSize: fs(9), color: sub }}>{isAr ? "👑 الأفضل سعرًا" : "👑 Best price"}</div> : null}
              {mode === "rating" && calc.bestRatedId != null ? <div style={{ fontSize: fs(9), color: sub }}>{isAr ? "👑 الأعلى تقييمًا" : "👑 Top rated"}</div> : null}
              {mode === "value" && calc.bestValueId != null ? <div style={{ fontSize: fs(9), color: sub }}>{isAr ? "👑 الأفضل قيمةً (تقييم ÷ سعر)" : "👑 Best value (rating ÷ price)"}</div> : null}
              {mode === "health" && calc.bestHealthId != null ? <div style={{ fontSize: fs(9), color: sub }}>{isAr ? "👑 الأعلى صحّةً" : "👑 Healthiest"}</div> : null}
              {showMark && userMark ? (
                <div style={{ fontFamily: "Amiri, serif", color: dark ? "rgba(255,255,255,0.85)" : "#2E7D32", fontWeight: 700, fontSize: fs(12), marginTop: 2 }}>{userMark}</div>
              ) : null}
              <ExportFooter compact />
            </div>
            </div>
          )}
        </div>

        <button
          onClick={handleExport}
          disabled={busy || items.length === 0}
          className="w-full h-11 rounded-none bg-[var(--brand)] text-white font-body gap-2 inline-flex items-center justify-center disabled:opacity-50"
        >
          <PerfumeSprayIcon className="w-4 h-4" />
          {busy ? (isAr ? "جارٍ الحفظ…" : "Saving…") : (isAr ? "حفظ صورة المقارنة" : "Save comparison image")}
        </button>

        <ExportHistoryList type="comparison" title={isAr ? "بطاقات المقارنة المحفوظة" : "Saved comparisons"} />
      </div>
    </div>
  );
}
