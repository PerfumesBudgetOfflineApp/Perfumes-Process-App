import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { ArrowLeft, Save, Trash2, Search, Layers } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import ImageUploadButton from "@/components/ui/ImageUploadButton";

export default function MaestroPerfumers() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState({});
  const [localEdits, setLocalEdits] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newItem, setNewItem] = useState({});
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["maestro-perfumers"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
  });

  const filtered = items.filter((p) => p.name?.toLowerCase().includes(search.toLowerCase()));
  const paginated = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const getEdit = (p) => localEdits[p.id] ?? p;
  const setEdit = (id, field, value) => {
    setLocalEdits((prev) => ({ ...prev, [id]: { ...(prev[id] ?? items.find((p) => String(p.id) === String(id))), [field]: value } }));
  };

  const handleSave = async (id) => {
    const data = localEdits[id];
    if (!data) return;
    setSaving((p) => ({ ...p, [id]: true }));
    await apphost.entities.Perfumer.update(id, { ...data, is_default: true });
    setSaving((p) => ({ ...p, [id]: false }));
    qc.invalidateQueries({ queryKey: ["maestro-perfumers"] });
    toast.success(isAr ? "تم التعديل بنجاح في قاعدة بيانات التطبيق" : "Updated successfully in app database");
  };

  const handleDelete = async (id) => {
    if (!confirm(isAr ? "حذف؟" : "Delete?")) return;
    await apphost.entities.Perfumer.delete(id);
    qc.invalidateQueries({ queryKey: ["maestro-perfumers"] });
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleAdd = async () => {
    if (!newItem.name) { toast.error((isAr ? "الاسم مطلوب" : "Name required")); return; }
    await apphost.entities.Perfumer.create({ ...newItem, is_default: true });
    qc.invalidateQueries({ queryKey: ["maestro-perfumers"] });
    setNewItem({});
    setShowAddForm(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">👑 {isAr ? "العطارون" : "Perfumers"}</h1>
          <p className="text-xs text-muted-foreground">{items.length} {isAr ? "عطار" : "perfumers"}</p>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input placeholder={isAr ? "بحث.." : "Search.."} value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} className="pl-9 rounded-none h-9" />
        </div>
        <Button size="sm" className="rounded-none" onClick={() => setShowAddForm(!showAddForm)}>
          {isAr ? "إضافة" : "Add"}
        </Button>
        <Link to="/maestro/perfumers/bulk-add">
          <Button size="sm" variant="outline" className="rounded-none">
            <Layers className="w-4 h-4 mr-1" />{isAr ? "إضافة 20" : "Add 20"}
          </Button>
        </Link>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center gap-2 mb-3 justify-center flex-wrap">
          {Array.from({ length: totalPages }).map((_, i) => (
            <button key={i} onClick={() => setPage(i)} className={`w-7 h-7 rounded-none text-xs ${page === i ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>{i + 1}</button>
          ))}
        </div>
      )}

      {showAddForm && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 mb-4 space-y-2">
          <p className="text-sm font-body font-semibold">{isAr ? "إضافة عطار" : "Add Perfumer"}</p>
          <Input placeholder={isAr ? "الاسم" : "Name*"} value={newItem.name || ""} onChange={(e) => setNewItem({ ...newItem, name: e.target.value })} className="rounded-none h-9 text-xs" />
          <Input placeholder={isAr ? "الجنسية" : "Nationality"} value={newItem.nationality || ""} onChange={(e) => setNewItem({ ...newItem, nationality: e.target.value })} className="rounded-none h-9 text-xs" />
          <Input placeholder={isAr ? "رابط الصورة" : "Photo URL"} value={newItem.photo_url || ""} onChange={(e) => setNewItem({ ...newItem, photo_url: e.target.value })} className="rounded-none h-9 text-xs" />
          <Textarea placeholder={isAr ? "نبذة" : "Bio"} value={newItem.bio || ""} onChange={(e) => setNewItem({ ...newItem, bio: e.target.value })} className="rounded-none text-xs resize-none min-h-[60px]" />
          <Input placeholder="🌐 Website (optional)" value={newItem.website || ""} onChange={(e) => setNewItem({ ...newItem, website: e.target.value })} className="rounded-none h-9 text-xs" />
          <Textarea placeholder="🎓 Education (optional)" value={newItem.education || ""} onChange={(e) => setNewItem({ ...newItem, education: e.target.value })} className="rounded-none text-xs resize-none min-h-[48px]" />
          <Button className="w-full rounded-none h-9 text-xs" onClick={handleAdd}>{isAr ? "إضافة" : "Add"}</Button>
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" /></div>
      ) : (
        <div className="space-y-3">
          {paginated.map((item) => {
            const edit = getEdit(item);
            const isDirty = JSON.stringify(edit) !== JSON.stringify(item);
            return (
              <div key={item.id} className="bg-card border border-border/50 rounded-none p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {item.photo_url && <img src={item.photo_url} className="w-8 h-8 rounded-none object-cover" alt="" />}
                    <div>
                      <p className="text-sm font-body font-semibold">{item.name}</p>
                      <p className="text-[10px] text-muted-foreground">{item.nationality}</p>
                    </div>
                  </div>
                  <button onClick={() => handleDelete(item.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الاسم" : "Name"}</p>
                    <Input value={edit.name || ""} onChange={(e) => setEdit(item.id, "name", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الجنسية" : "Nationality"}</p>
                    <Input value={edit.nationality || ""} onChange={(e) => setEdit(item.id, "nationality", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div className="col-span-2">
                   <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "رابط الصورة" : "Photo URL"}</p>
                   <div className="flex gap-1.5 items-center">
                     <Input value={edit.photo_url || ""} onChange={(e) => setEdit(item.id, "photo_url", e.target.value)} className="h-8 rounded-none text-xs flex-1" />
                     <ImageUploadButton onUploaded={(url) => setEdit(item.id, "photo_url", url)} options={{ maxWidth: 500, maxHeight: 500, quality: 0.85, maxKB: 250 }} />
                   </div>
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "نبذة" : "Bio"}</p>
                    <Textarea value={edit.bio || ""} onChange={(e) => setEdit(item.id, "bio", e.target.value)} className="rounded-none text-xs resize-none min-h-[60px]" style={{ direction: "ltr", textAlign: "left" }} />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "اشتُهر بـ" : "Known For"}</p>
                    <Input value={edit.known_for || ""} onChange={(e) => setEdit(item.id, "known_for", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">🌐 Website</p>
                    <Input value={edit.website || ""} onChange={(e) => setEdit(item.id, "website", e.target.value)} placeholder="https://.." className="h-8 rounded-none text-xs" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">🎓 Education</p>
                    <Textarea value={edit.education || ""} onChange={(e) => setEdit(item.id, "education", e.target.value)} className="rounded-none text-xs resize-none min-h-[48px]" />
                  </div>
                </div>
                <Button onClick={() => handleSave(item.id)} disabled={!isDirty || saving[item.id]} className="w-full h-8 rounded-none text-xs" variant={isDirty ? "default" : "outline"}>
                  <Save className="w-3 h-3 mr-1" />
                  {saving[item.id] ? (isAr ? "جاري الحفظ.." : "Saving..") : (isAr ? "💾 حفظ" : "💾 Save")}
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}