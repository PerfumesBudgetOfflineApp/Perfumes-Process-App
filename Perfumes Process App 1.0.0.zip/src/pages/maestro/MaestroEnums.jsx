import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ArrowLeft, X } from "lucide-react";
import { useNavigate } from "react-router-dom";

const ENUMS = {
  categories: [
    "Floral", "Oriental", "Woody", "Fresh", "Citrus", "Chypre", "Fougère", "Gourmand",
    "Aquatic", "Spicy", "Musky", "Powdery", "Green", "Leather", "Aromatic", "Aldehyic",
    "Amber", "Oud", "Rose", "Vanilla",
  ],
  occasions: [
    { value: "daylight", label: "☀️ Daylight" },
    { value: "evening", label: "🌙 Evening" },
    { value: "wedding", label: "💍 Wedding" },
    { value: "celebration", label: "Celebration" },
    { value: "relax", label: "😌 Relax" },
    { value: "work", label: "💼 Work" },
    { value: "sport", label: "⚽ Sport" },
    { value: "casual", label: "👕 Casual" },
    { value: "very_special", label: "✨ Very Special" },
  ],
  odor_families: [
    "Floral", "Woody", "Oriental", "Fresh / Citrus", "Aquatic / Marine",
    "Fougère", "Chypre", "Gourmand", "Musk", "Spicy", "Green",
    "Leather", "Aromatic", "Powdery", "Amber", "Oud", "Incense",
    "Earthy / Mossy",
  ],
  types: [
    "Parfum - Extrait de Parfum", "Eau de Parfum - EDP", "Eau de Toilette - EDT",
    "Eau de Cologne - EDC", "Eau Fraîche", "Bakhoor Natural Oud - Nadd",
    "Bakhoor Synthetic Oud", "Bakhoor Blue Oud", "Oil Misk Wood", "Rose Oil",
    "Oils", "Mukhallat", "Khumrah", "Anbar Zafaran", "Ward Water",
    "Musk Myrrh Benzoin", "Temple Incense & Sacred Woods", "Agarwood",
    "Luban Frankincense Sandalwood", "Body Lotion", "Hair Lotion",
    "Body Mist", "Body Wash", "Hair Wash", "Face Wash", "Face Creams",
    "Sunscreen", "Serums", "Uncategorized Products",
  ],
};

export default function MaestroEnums() {
   const navigate = useNavigate();
   const [activeTab, setActiveTab] = useState("categories");
   const [items, setItems] = useState(ENUMS[activeTab]);
   const [newItem, setNewItem] = useState("");
   const [editIdx, setEditIdx] = useState(null);
   const [editVal, setEditVal] = useState("");

   const handleAddItem = () => {
     if (!newItem.trim()) return;
     const updated = [...items, newItem.trim()];
     setItems(updated);
     setNewItem("");
   };

   const handleRemoveItem = (index) => {
     setItems(items.filter((_, i) => i !== index));
   };

   const startEdit = (i) => {
     setEditIdx(i);
     setEditVal(typeof items[i] === "string" ? items[i] : items[i].label);
   };

   const saveEdit = (i) => {
     if (!editVal.trim()) return;
     const updated = [...items];
     if (typeof items[i] === "string") {
       updated[i] = editVal.trim();
     } else {
       updated[i] = { ...items[i], label: editVal.trim() };
     }
     setItems(updated);
     setEditIdx(null);
   };

   const handleTabChange = (tab) => {
     setActiveTab(tab);
     setItems(ENUMS[tab]);
     setNewItem("");
     setEditIdx(null);
   };

  return (
    <div className="px-5 pt-12 pb-24 space-y-5">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="font-heading text-2xl font-bold">تعديل القوائم Edit Enums</h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {[
          { id: "categories", label: "Categories" },
          { id: "occasions", label: "Occasions" },
          { id: "odor_families", label: "Odor Families" },
          { id: "types", label: "Types" },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => handleTabChange(tab.id)}
            className={`px-4 py-2 rounded-none text-sm font-body font-medium whitespace-nowrap transition-all ${
              activeTab === tab.id
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="bg-card rounded-none p-5 shadow-sm space-y-4">
        {/* Add new item */}
        <div className="flex gap-2">
          <Input
            value={newItem}
            onChange={(e) => setNewItem(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleAddItem()}
            placeholder={`Add new ${activeTab.replace("_", " ")}..`}
            className="rounded-none h-11 font-body"
          />
          <Button onClick={handleAddItem} size="icon" className="rounded-none h-11">
            Add</Button>
        </div>

        {/* Items list */}
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {items.map((item, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between gap-3 bg-secondary/50 rounded-none p-3 hover:bg-secondary transition-colors group"
            >
              {editIdx === idx ? (
                <input name="MaestroEnums-1"
                  value={editVal}
                  onChange={(e) => setEditVal(e.target.value)}
                  onBlur={() => saveEdit(idx)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") saveEdit(idx);
                    if (e.key === "Escape") setEditIdx(null);
                  }}
                  autoFocus
                  className="bg-transparent outline-none text-sm font-body flex-1"
                />
              ) : (
                <span
                  onClick={() => startEdit(idx)}
                  className="text-sm font-body cursor-pointer hover:opacity-75 flex-1"
                >
                  {typeof item === "string" ? item : item.label}
                </span>
              )}
              <button
                onClick={() => handleRemoveItem(idx)}
                className="text-muted-foreground hover:text-destructive transition-colors opacity-0 group-hover:opacity-100"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>

        {items.length === 0 && (
          <p className="text-sm text-muted-foreground font-body text-center py-8">لا عناصر بعد No items yet</p>
        )}
      </div>


    </div>
  );
}