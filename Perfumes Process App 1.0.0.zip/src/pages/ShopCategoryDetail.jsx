import { useMemo, useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Package, Star, Receipt, Store, ChevronLeft, ChevronRight } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { DEFAULT_MAIN_CATEGORIES, ALL_SUB_CATEGORIES, aliasesForMainCategory } from "@/lib/shopCategories";
import { compareEnglish } from "@/lib/sortName";

function StarDisplay({ rating }) {
  if (!rating) return null;
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(n => (
        <Star key={n} className={`w-2.5 h-2.5 ${n <= rating ? "fill-amber-400 text-amber-400" : "text-border"}`} />
      ))}
    </div>
  );
}


export default function ShopCategoryDetail() {
  const { categoryId } = useParams();
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { currency } = useCurrency();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [categoryId]);

  const category = useMemo(() => {
    return DEFAULT_MAIN_CATEGORIES.find(c => String(c.id) === String(categoryId))
      || ALL_SUB_CATEGORIES.find(c => String(c.id) === String(categoryId));
  }, [categoryId]);

  const { data: products = [] } = useQuery({
    queryKey: ["shop-products-by-category", categoryId],
    queryFn: () => apphost.entities.ShopProduct.list("-created_date"),
  });

  const { data: brands = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  // المعرّفات المكافئة لهذه الفئة (نفسها + ما يُحيل إليها مثل cat_entertainment→cat_tech)
  const catIds = useMemo(() => aliasesForMainCategory(String(categoryId)), [categoryId]);

  const categoryProducts = useMemo(() => {
    return products.filter(p =>
      catIds.includes(String(p.category_id)) || String(p.subcategory_id) === String(categoryId)
    );
  }, [products, categoryId, catIds]);

  const categoryBrands = useMemo(() => {
    return brands.filter(b => catIds.includes(String(b.category_id)));
  }, [brands, categoryId, catIds]);

  const PAGE_SIZE = 20;

  // Sort state
  const [productSort, setProductSort] = useState("newest");
  const [brandSort, setBrandSort] = useState("products_desc");

  // Sorted products
  const sortedProducts = useMemo(() => {
    const arr = [...categoryProducts];
    if (productSort === "newest") arr.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    else if (productSort === "oldest") arr.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    else if (productSort === "cost_desc") arr.sort((a, b) => (b.cost || 0) - (a.cost || 0));
    else if (productSort === "cost_asc") arr.sort((a, b) => (a.cost || 0) - (b.cost || 0));
    else if (productSort === "name_asc") arr.sort((a, b) => compareEnglish(a, b, 1));
    else if (productSort === "name_desc") arr.sort((a, b) => compareEnglish(a, b, -1));
    return arr;
  }, [categoryProducts, productSort]);

  // Products pagination
  const [productPage, setProductPage] = useState(0);
  const totalProductPages = Math.ceil(sortedProducts.length / PAGE_SIZE);
  const displayedProducts = useMemo(() =>
    sortedProducts.slice(productPage * PAGE_SIZE, (productPage + 1) * PAGE_SIZE),
    [sortedProducts, productPage]
  );

  // Sorted brands
  const sortedBrands = useMemo(() => {
    const arr = [...categoryBrands];
    if (brandSort === "products_desc") arr.sort((a, b) => categoryProducts.filter(p => p.brand_id === b.id).length - categoryProducts.filter(p => p.brand_id === a.id).length);
    else if (brandSort === "products_asc") arr.sort((a, b) => categoryProducts.filter(p => p.brand_id === a.id).length - categoryProducts.filter(p => p.brand_id === b.id).length);
    else if (brandSort === "name_asc") arr.sort((a, b) => compareEnglish(a, b, 1));
    else if (brandSort === "name_desc") arr.sort((a, b) => compareEnglish(a, b, -1));
    else if (brandSort === "newest") arr.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
    else if (brandSort === "oldest") arr.sort((a, b) => new Date(a.created_date) - new Date(b.created_date));
    return arr;
  }, [categoryBrands, brandSort, categoryProducts]);

  const totalCost = categoryProducts.reduce((s, p) => s + (p.cost || 0), 0);
  const avgRating = categoryProducts.filter(p => p.rating).reduce((s, p) => s + (p.rating || 0), 0) / (categoryProducts.filter(p => p.rating).length || 1);

  return (
    <div className={`min-h-screen bg-background pb-20 ${isAr ? "rtl" : ""}`}>
      {/* Header */}
      <div className="sticky top-0 bg-background border-b border-border px-3 py-2 flex items-center gap-2" style={{ paddingTop: "calc(env(safe-area-inset-top, 0px) + 8px)" }}>
        <button
          onClick={() => {
            // قسم فرعيّ ← الفئة الأم؛ و إلا وجهة محدّدة موثوقة /shopping.
            // (navigate(-1) كان يتعثّر عند الدخول المباشر أو بعد إعادة توجيه، فتبدو
            // أزرار الرجوع كأنها لا تعمل — الوجهة المحدّدة تعمل دائماً.)
            const sub = ALL_SUB_CATEGORIES.find((s) => String(s.id) === String(categoryId));
            if (sub && sub.parent_id) navigate(`/shop-category/${sub.parent_id}`);
            else navigate("/shopping");
          }}
          className="p-1 hover:bg-secondary rounded-none flex-shrink-0"
          aria-label={isAr ? "رجوع" : "Back"}
        >
          <ArrowLeft className={`w-4 h-4 ${isAr ? "rotate-180" : ""}`} />
        </button>
        <div className="flex-1 min-w-0">
          <h1 className="text-sm font-heading font-bold whitespace-nowrap overflow-hidden" style={{ textOverflow: "clip" }}>
            {category?.icon} {(() => { const nm = (isAr ? category?.name_ar : category?.name_en) || ""; return nm.length > 26 ? nm.slice(0, 26).trimEnd() + ".." : nm; })()}
          </h1>
        </div>
        <div className="text-right flex-shrink-0">
          <p className="text-xs font-bold text-primary">{categoryProducts.length}</p>
          <p className="text-[8px] text-muted-foreground font-body">{isAr ? "منتج" : "Products"}</p>
        </div>
      </div>

      {/* Stats */}
      <div className="px-3 py-2 grid grid-cols-3 gap-1.5">
        <div className="bg-card border border-border rounded-none p-1.5 text-center">
          <p className="text-xs font-bold font-heading text-primary">{categoryProducts.length}</p>
          <p className="text-[8px] text-muted-foreground font-body">{isAr ? "منتجات" : "Products"}</p>
        </div>
        <div className="bg-card border border-border rounded-none p-1.5 text-center">
          <p className="text-xs font-bold font-heading text-amber-600">{totalCost.toFixed(0)}</p>
          <p className="text-[8px] text-muted-foreground font-body">{isAr ? "التكلفة" : "Total"}</p>
        </div>
        <div className="bg-card border border-border rounded-none p-1.5 text-center">
          <p className="text-xs font-bold font-heading text-blue-600">{avgRating > 0 ? avgRating.toFixed(1) : "—"}</p>
          <p className="text-[8px] text-muted-foreground font-body">{isAr ? "التقييم" : "Rating"}</p>
        </div>
      </div>

      {/* Shop Brands in this category */}
      {categoryBrands.length > 0 && (
        <div className="px-3 pb-2">
          <div className="flex items-center justify-between mb-1.5">
            <p className="text-[8px] text-muted-foreground font-body uppercase tracking-wider">
              {isAr ? `المتاجر و العلامات (${categoryBrands.length})` : `Stores & Brands (${categoryBrands.length})`}
            </p>
            <select name="ShopCategoryDetail-sel1" value={brandSort} onChange={e => setBrandSort(e.target.value)}
              className="text-[8px] font-body bg-secondary border border-border rounded px-1 py-0.5 text-foreground">
              <option value="products_desc">{isAr ? "المنتجات ↓" : "Products ↓"}</option>
              <option value="products_asc">{isAr ? "المنتجات ↑" : "Products ↑"}</option>
              <option value="name_asc">{isAr ? "الاسم أ-ي" : "Name ↑"}</option>
              <option value="name_desc">{isAr ? "الاسم ي-أ" : "Name ↓"}</option>
              <option value="newest">{isAr ? "الأحدث" : "Newest"}</option>
              <option value="oldest">{isAr ? "الأقدم" : "Oldest"}</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {sortedBrands.map(brand => {
              const brandProducts = categoryProducts.filter(p => p.brand_id === brand.id);
              return (
                <button key={brand.id} type="button" onClick={() => navigate(`/store?id=${brand.id}`)}
                  className="bg-card border border-border/50 rounded-none p-2 flex items-center gap-2 text-left hover:opacity-80 transition-opacity">
                  {brand.logo_url ? (
                    <img src={brand.logo_url} className="w-8 h-8 rounded-none object-cover flex-shrink-0" />
                  ) : (
                    <div className="w-8 h-8 rounded-none bg-secondary flex items-center justify-center flex-shrink-0">
                      <Store className="w-4 h-4 text-muted-foreground" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-[10px] font-body font-semibold truncate">{isAr ? (brand.name_ar || brand.name) : brand.name}</p>
                    <p className="text-[8px] text-muted-foreground font-body">{brandProducts.length} {isAr ? "منتج" : "items"}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Products List */}
      <div className="px-3 pb-2">
        <div className="flex items-center justify-between mb-1.5">
          <p className="text-[8px] text-muted-foreground font-body uppercase tracking-wider">
            {isAr ? `جميع المنتجات (${categoryProducts.length})` : `All Products (${categoryProducts.length})`}
          </p>
          {totalProductPages > 1 && (
            <div className="flex items-center gap-1">
              <button onClick={() => setProductPage(p => Math.max(0, p - 1))} disabled={productPage === 0}
                className="p-0.5 rounded hover:bg-secondary disabled:opacity-30">
                {isAr ? <ChevronRight className="w-3.5 h-3.5" /> : <ChevronLeft className="w-3.5 h-3.5" />}
              </button>
              <span className="text-[8px] font-body text-muted-foreground">{productPage + 1}/{totalProductPages}</span>
              <button onClick={() => setProductPage(p => Math.min(totalProductPages - 1, p + 1))} disabled={productPage === totalProductPages - 1}
                className="p-0.5 rounded hover:bg-secondary disabled:opacity-30">
                {isAr ? <ChevronLeft className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
              </button>
            </div>
          )}
        </div>
        {categoryProducts.length === 0 ? (
          <div className="bg-secondary/50 rounded-none p-4 text-center">
            <Package className="w-6 h-6 text-muted-foreground mx-auto mb-1" />
            <p className="text-xs font-body text-muted-foreground">
              {isAr ? "لا توجد منتجات" : "No products"}
            </p>
          </div>
        ) : (
          <div className="space-y-1.5">
            {displayedProducts.map(product => {
              const brand = brands.find(b => String(b.id) === String(product.brand_id));
              const isPerfume = !!product.linked_perfume_id;
              return (
                <div
                  key={product.id}
                  onClick={() => navigate(`/shop-product?id=${product.id}`)}
                  className="bg-card border border-border/50 rounded-none p-2 hover:border-primary/50 transition-all cursor-pointer"
                >
                  <div className="flex gap-2">
                    {product.image_url ? (
                      <img src={product.image_url} alt={product.name} className="w-14 h-14 rounded-none object-cover flex-shrink-0 bg-secondary" />
                    ) : (
                      <div className="w-14 h-14 rounded-none bg-secondary flex items-center justify-center flex-shrink-0">
                        <Package className="w-5 h-5 text-muted-foreground" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-1.5">
                        <div className="flex-1 min-w-0">
                          <p className="text-[11px] font-body font-semibold truncate">{product.name}</p>
                          {product.name_ar && (
                            <p className="text-[9px] text-muted-foreground font-body truncate" dir="rtl">{product.name_ar}</p>
                          )}
                        </div>
                        {product.receipt_url && <Receipt className="w-3 h-3 text-amber-500 flex-shrink-0" />}
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                        {brand && (
                          <span className="text-[8px] text-muted-foreground font-body bg-secondary px-1 py-0.5 rounded">{brand.name}</span>
                        )}
                        {isPerfume && (
                          <span className="text-[8px] text-purple-600 font-body bg-purple-50 dark:bg-purple-900/20 px-1 py-0.5 rounded">
                            🌸 {product.linked_perfume_name}
                          </span>
                        )}
                        {product.rating > 0 && <StarDisplay rating={product.rating} />}
                      </div>
                      <div className="flex items-center justify-between mt-1">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-bold font-heading text-primary">
                            {currency}{product.cost?.toFixed(0) || "0"}
                          </span>
                          {product.recurring && (
                            <span className="text-[8px] text-muted-foreground font-body">({isAr ? "دوري" : "recurring"})</span>
                          )}
                        </div>
                        <span className="text-[8px] text-muted-foreground font-body">{names[product.person] || product.person}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}