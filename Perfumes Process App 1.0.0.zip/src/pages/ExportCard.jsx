import { hilalBorder } from "@/lib/hilalArt";
import { brandCategoryLabel } from "@/lib/brandCategories";
import { RATING_AXES } from "@/lib/ratingAxes";
import { computeBrandEssence } from "@/lib/brandEssence";
import AccordFlaconCard from "@/components/perfume/AccordFlaconCard";
import { recordExport } from "@/components/export/ExportHistoryList";
import { useState, useRef, useEffect, useLayoutEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAllPerfumes } from "@/lib/useAllPerfumes";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Upload, X } from "lucide-react";
import { toast } from "sonner";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { DEFAULT_USER_MARK } from "@/lib/exportSettings";
import { captureElementHQ, downscaleCanvas } from "@/lib/captureCanvas";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { analyzePerfume, perfumeLabels, MECH, isHealthNote, strictHealth } from "@/lib/headacheRisk";
import { occasionInfo } from "@/lib/occasions";
import { useOccasionMode } from "@/lib/useOccasionMode";
import { LONGEVITY, SILLAGE, VALUE, SEASONS, TIMES, GENDER_COLORS, GENDER_LABELS } from "@/lib/crowdLabels";
import { typeDisplay, strengthOf } from "@/lib/perfumeTypes";
import { StrengthTrack } from "@/components/perfume/StrengthIndicator";
import { decadeLabel } from "@/lib/decade";
import { getSecureStorage, setSecureStorage } from "@/lib/storageEncryption";
import ACCORDS from "@/data/builtin_database/accords_builtin.json";

/* ===== ExportCard — صفحة تصدير موحّدة =====
   وضعان رئيسيان: «بطاقة العطر» و«مراجعة العطر».
   ضبط تلقائي يضمن اكتمال البطاقة داخل 512×512 بلا قصّ أو تأكّل.
   تصدير بدقّة عالية جداً وألوان دقيقة. الأقسام الفارغة تُخفى تماماً. */

const GOLD = "var(--brand)";
const N = "#e7dfc9"; // حدّ محايد فاتح لواجهة الخيارات (بديل الإطارات الذهبية)
// أسماء النوتات في القاعدة سلاسل ثنائية اللغة — فصلها يمنع تكرار النص عند العرض.
const arOf = (s) => (String(s || "").match(/[\u0600-\u06FF][\u0600-\u06FF\s،ـ-]*/g) || []).join(" ").replace(/\s+/g, " ").replace(/[-\s]+$/, "").trim();
const enOf = (s) => String(s || "").replace(/[\u0600-\u06FF]+/g, " ").replace(/\([^)]*\)/g, " ").replace(/\s+/g, " ").replace(/[-\s]+$/, "").trim();
// اسم النوتة العربيّ للعرض: الصيغة الأساسية قبل أوّل « - »، بلا أقواس، وبلا أداة «ال».
const _stripAl = (w) => /^ال[\u0600-\u06FF]{2,}$/.test(w) ? w.slice(2) : w;
const arNote = (s) => { let t = String(s || "").split(" - ")[0].replace(/\([^)]*\)/g, " "); t = arOf(t); return t.split(/\s+/).filter(Boolean).map(_stripAl).join(" ").trim(); };
const PINK = "#9D174D";
const GREEN = "#3B6D11";
const OPT_KEY = "exportCardOptions";

function splitCsv(s) {
  if (Array.isArray(s)) return s.map((x) => String(x).trim()).filter(Boolean);
  return String(s || "").split(",").map((x) => x.trim()).filter(Boolean);
}

const normKey = (s) => (s || "")
  .toLowerCase()
  .replace(/[\u064B-\u0652\u0670\u0640]/g, "")
  .replace(/[إأآٱ]/g, "ا")
  .replace(/ى/g, "ي")
  .replace(/ة/g, "ه")
  .replace(/(^|\s)ال/g, "$1")
  .replace(/[^a-z0-9\u0600-\u06FF ]/g, "")
  .replace(/\s+/g, " ")
  .trim();

// أيّ & أو + في نصوص البطاقة تتحوّل إلى شرطة (أمر A) — العربية «و» لا تتأثّر.
function dash(s) { return String(s == null ? "" : s).replace(/\s*[&+]\s*/g, " - "); }
// تغميق الألوان الفاتحة فقط (للقراءة داخل صندوق الأكورد)؛ الداكنة تُترك كما هي.
function darken(hex, f = 0.6) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ""));
  if (!m) return hex;
  const n = parseInt(m[1], 16), r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  const lum = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  if (lum < 0.55) return hex;
  const d = (x) => Math.round(x * f);
  return `#${((d(r) << 16) | (d(g) << 8) | d(b)).toString(16).padStart(6, "0")}`;
}
function parseAccords(raw = "") {
  return String(raw)
    .split(";")
    .map((e) => {
      const [id, pct] = e.split(":");
      const ref = ACCORDS[(id || "").trim()];
      if (!ref) return null;
      const n = parseInt(pct, 10);
      return { id: (id || "").trim(), pct: Number.isFinite(n) ? n : 0, ...ref };
    })
    .filter(Boolean);
}

// أوضاع رئيسية: قوائم الحقول الافتراضية لكلّ وضع.
const PRESETS = {
  card: { name: 1, image: 1, brand: 1, collection: 1, info: 1, pcount: 1, year: 1, family: 1, occasions: 1, perfumer: 1, narrative: 1, pyramid: 1, similar: 1, health: 1, strict: 1, myhealth: 1, rating: 1, userRating: 1, reaction: 1, impression: 1, recommend: 1, comment: 1, thought: 1, wears: 1, purchases: 1, axes: 1, essence: 1, date: 0, mark: 1, photo: 1 },
  review: { name: 1, image: 1, brand: 1, collection: 1, info: 1, pcount: 1, year: 1, family: 1, occasions: 1, perfumer: 1, narrative: 1, pyramid: 1, similar: 1, health: 1, strict: 1, myhealth: 1, rating: 1, userRating: 1, reaction: 1, impression: 1, recommend: 1, comment: 1, thought: 1, wears: 1, purchases: 1, axes: 1, essence: 1, date: 0, mark: 1, photo: 1 },
};
const toBoolFields = (o) => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, !!v]));
const REACTION_MAP = { favorite: { emoji: "❤️", ar: "مفضّل", en: "Fav" }, recommend: { emoji: "👍", ar: "إعجاب", en: "Like" }, dislike: { emoji: "👎", ar: "لا يعجبني", en: "Dislike" }, wtf: { emoji: "😱", ar: "WTF", en: "WTF" } };

const _ROSE = { paper: "linear-gradient(180deg,#fff,#fce7ee)", bord: "#e6c3d2", ink: "#3a2230", muted: "#6b4a5a", soft: "#9a7d8a", base: "#fdeef4" };
const _SAGE = { paper: "linear-gradient(180deg,#fff,#e7efe0)", bord: "#c7d6bd", ink: "#26301f", muted: "#4a5a3e", soft: "#7d8a72", base: "#eef4e8" };
const _SKY = { paper: "linear-gradient(180deg,#fff,#e3eef6)", bord: "#bcd2e0", ink: "#1f2c36", muted: "#3e505a", soft: "#728490", base: "#e8f1f8" };
const _LAV = { paper: "linear-gradient(180deg,#fff,#ece6f6)", bord: "#cdc1e0", ink: "#2a2236", muted: "#54485f", soft: "#857d92", base: "#f1ecf8" };
const _SLATE = { paper: "#2b2f36", bord: "#5a626e", ink: "#e9ecf1", muted: "#c2c8d2", soft: "#a3aab6", base: "#2b2f36" };
const BG_PRESETS = {
  "": { paper: "#ffffff", bord: GOLD, ink: "#2b2b2b", muted: "#4a463f", soft: "#7a7368", base: "#ffffff" },
  white: { paper: "#ffffff", bord: "#e6dcc2", ink: "#2b2b2b", muted: "#4a463f", soft: "#7a7368", base: "#ffffff" },
  light: { paper: "linear-gradient(180deg,#ffffff,#f7f3ea)", bord: "#dfd4bb", ink: "#2b2b2b", muted: "#4a463f", soft: "#7a7368", base: "#f9f5ec" },
  gold: { paper: "linear-gradient(160deg,#faf4e4,#f3ecd9)", bord: "#dcc98f", ink: "#2b2b2b", muted: "#4a463f", soft: "#7a7368", base: "#f5efdf" },
  dark: { paper: "#231f18", bord: GOLD, ink: "#ece6d8", muted: "#cfc6ad", soft: "#b6ac8d", base: "#231f18" },
  rose: _ROSE, sage: _SAGE, sky: _SKY, lavender: _LAV, slate: _SLATE,
};

const FONTS = { default: "Cairo, system-ui, sans-serif", serif: "'Playfair Display', serif", display: "Cinzel, serif" };
const SIZES = [0.82, 0.91, 1, 1.12, 1.25];
const ORIENTS = { square: [512, 512], portrait: [432, 540], land: [600, 360] };
const TIME_TEXT = [{ ar: "إشراق", en: "Bright" }, { ar: "غسق", en: "Dusk" }]; // ليل/نهار نصًّا دائمًا — بلا أيقونات
const SEASON_ICONS = ["❄️", "🌸", "🔆", "🍂"]; // شتاء · ربيع (وردة) · صيف (سطوع) · خريف

function Crown({ size = 14 }) {
  return (
    <svg viewBox="0 0 40 16" width={size} height={size * 0.42} aria-hidden="true" style={{ transform: "rotate(-22deg)", display: "inline-block", verticalAlign: "middle" }}>
      <path d="M8 13 l2-7 4 4 6-7 6 7 4-4 2 7z" fill="var(--brand)" stroke="#2E7D32" strokeWidth="0.4" />
    </svg>
  );
}
function Diamonds({ filled = 0, total = 5, size = 11 }) {
  const f = Math.max(0, Math.min(total, Math.round(filled)));
  return (
    <span style={{ letterSpacing: "2px", fontSize: size }}>
      <span style={{ color: GOLD }}>{"\u25A0".repeat(f)}</span>
      <span style={{ color: "#d9cfae" }}>{"\u25A0".repeat(total - f)}</span>
    </span>
  );
}
function Squares({ filled = 0, total = 4 }) {
  const f = Math.max(0, Math.min(total, filled));
  return (
    <span>
      {Array.from({ length: total }).map((_, i) => (
        <span key={i} style={{ display: "inline-block", width: 8, height: 8, border: `1.2px solid ${GOLD}`, background: i < f ? GOLD : "transparent", marginInlineStart: 3, verticalAlign: "middle" }} />
      ))}
    </span>
  );
}
// قنينة عطر وردية أنيقة (بديل نصّ «تذكرني»).
function PinkBottle() {
  return (
    <svg width="30" height="40" viewBox="0 0 34 46" aria-label="remind">
      <rect x="13" y="2" width="8" height="6" rx="1" fill={PINK} />
      <rect x="11" y="8" width="12" height="4" fill="#b84a72" />
      <rect x="6" y="12" width="22" height="32" rx="6" fill="#f6cdde" stroke={PINK} strokeWidth="1.5" />
      <rect x="6" y="28" width="22" height="16" rx="6" fill="#e79bb6" />
      <rect x="11" y="18" width="12" height="18" fill="none" stroke="#fff" strokeOpacity=".5" />
    </svg>
  );
}

export default function ExportCard() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { names, profiles } = usePersonNames();
  const [occMode, setOccMode] = useOccasionMode("perfume");
  const [userOccMode, setUserOccMode] = useOccasionMode("user");
  const params = new URLSearchParams(window.location.search);
  const id = params.get("id");
  const brandId = params.get("brand");
  const isBrand = !!brandId && !id;

  const saved = useMemo(() => getSecureStorage(OPT_KEY, {}) || {}, []);
  // وضع «ورقة Paper» أُلغي بأمر A (1.787) — أي قيمة محفوظة قديمة تعود لبطاقة العطر
  const [mode, setMode] = useState(saved.mode === "paper" ? "card" : (saved.mode || "card"));
  const [lang, setLang] = useState(saved.lang || "mix");
  const [person, setPerson] = useState(saved.person || "all");
  const [font, setFont] = useState(saved.font || "default");
  const [size, setSize] = useState(typeof saved.size === "number" ? saved.size : 1);
  const [align, setAlign] = useState(saved.align || "left");
  const [orient, setOrient] = useState(saved.orient || "square");
  const [notesMode, setNotesMode] = useState(saved.notesMode || "both");
  const [noteFrame, setNoteFrame] = useState(saved.noteFrame === true); // افتراضي: بلا إطار
  // مؤشرات النوتة الصحية (الخطوط العمودية البنية/الحمراء) — افتراضي مفعّل.
  // إزالتها لا تمسّ لون النص ولا قيد الشطب على المقيدة (عنبر الحوت يبقى كما هو).
  const [noteHealthInd, setNoteHealthInd] = useState(saved.noteHealthInd !== false);
  const [groupedNotes, setGroupedNotes] = useState(saved.groupedNotes !== false);
  // موضع اسم النوتة حول صورتها: يمين (افتراضي) / يسار / أسفل (الوضع القديم).
  const [notePos, setNotePos] = useState(saved.notePos || "right");
  const [perfumerPos, setPerfumerPos] = useState(saved.perfumerPos || "left"); // موضع اسم العطّار حول صورته
  const [tone1, setTone1] = useState(saved.tone1 || ""); // لون الخطّ الأول (العناوين/اللاتيني) — فارغ = الذهبي
  const [tone2, setTone2] = useState(saved.tone2 || ""); // لون الخطّ الثاني (العربي) — فارغ = الزهري
  // الخطّ الفاصل بين أقسام البطاقة (منتصف البطاقة + فوق التقييمات): إلغاء + لون.
  const [dividerOff, setDividerOff] = useState(saved.dividerOff || false);
  const [dividerColor, setDividerColor] = useState(saved.dividerColor || ""); // فارغ = الافتراضي لكل موضع
  const [noteAlign, setNoteAlign] = useState(saved.noteAlign || "center"); // محاذاة نص النوتة داخل خانتها
  const [phaseHeads, setPhaseHeads] = useState(saved.phaseHeads !== false); // إظهار عناوين المراحل (هرم/مقدمة/قلب/أساس)
  const [bgKey, setBgKey] = useState(saved.bgKey || "");
  const [customColor, setCustomColor] = useState(saved.customColor || "");
  const [customImage, setCustomImage] = useState(saved.customImage || "");
  // وضع «الصورة بارزة»: الصورة المرفقة تملأ الإطار والبطاقة مصغّرة بداخلها.
  const [imgDom, setImgDom] = useState(!!saved.imgDom);
  const [cardPct, setCardPct] = useState(typeof saved.cardPct === "number" ? saved.cardPct : 0.55);
  const [cardPos, setCardPos] = useState(saved.cardPos || "center");
  // محاذاة مستقلة لكل كتلة من الكتل الخمس (بطاقة العطر) — «تابع» = حسب اللغة (عربي يمين، غيره يسار).
  const [b1Align, setB1Align] = useState(saved.b1Align || "follow"); // الترويسة + الصحة + المواسم
  const [b2Align, setB2Align] = useState(saved.b2Align || "follow"); // القنينة + الكثافة + الفئة
  const [b3Align, setB3Align] = useState(saved.b3Align || "follow"); // المصممون + العائلة + الوصف + المناسبات
  const [b4Align, setB4Align] = useState(saved.b4Align || "follow"); // الهرم (كتلة كاملة، مستقل عن تنسيق النوتات الداخلي)
  const [b5Align, setB5Align] = useState(saved.b5Align || "follow"); // تقييمات المستخدم ALPHA
  const [fields, setFields] = useState({ ...toBoolFields(PRESETS.card), ...(saved.fields || {}) });
  const [tab, setTab] = useState("fields");

  const cardRef = useRef(null);
  const fitRef = useRef(null);
  const [fitScale, setFitScale] = useState(1);
  const [boxH, setBoxH] = useState(0); // ارتفاع الإطار = ارتفاع المحتوى المُحجَّم (يحتضنه بلا قصّ)
  const [quality, setQuality] = useState(saved.quality || "high"); // high | ultra (≤2600)
  const [climateMode, setClimateMode] = useState(saved.climateMode || (saved.climateIcon === false ? "text" : "icon")); // الفصول والوقت: أيقونة | نص | بلا (أعمدة فقط)
  const [scale, setScale] = useState(1);

  const showAr = lang !== "en";
  const showEn = lang !== "ar";

  useEffect(() => {
    setSecureStorage(OPT_KEY, { mode, lang, person, font, size, align, orient, notesMode, noteFrame, noteHealthInd, groupedNotes, notePos, perfumerPos, noteAlign, phaseHeads, bgKey, customColor, customImage, imgDom, cardPct, cardPos, b1Align, b2Align, b3Align, b4Align, b5Align, quality, climateMode, tone1, tone2, dividerOff, dividerColor, fields });
  }, [mode, lang, person, font, size, align, orient, notesMode, noteFrame, noteHealthInd, groupedNotes, notePos, perfumerPos, noteAlign, phaseHeads, bgKey, customColor, customImage, imgDom, cardPct, cardPos, b1Align, b2Align, b3Align, b4Align, b5Align, quality, climateMode, tone1, tone2, dividerOff, dividerColor, fields]);

  useEffect(() => {
    const calc = () => {
      const [w] = ORIENTS[orient];
      const avail = Math.min(window.innerWidth, 460) - 24;
      setScale(Math.min(1, avail / w));
    };
    calc();
    window.addEventListener("resize", calc);
    return () => window.removeEventListener("resize", calc);
  }, [orient]);

  // ---- data ----
  const { data: perfume } = useQuery({ queryKey: ["xc-perfume", id], queryFn: () => apphost.entities.Perfume.filter({ id }), select: (d) => d?.[0], enabled: !!id, staleTime: 0, refetchOnMount: "always" });
  const { data: userPerfumes = [] } = useQuery({ queryKey: ["xc-user", id], queryFn: () => apphost.entities.UserPerfume.filter({ perfume_id: id }), enabled: !!id, staleTime: 0, refetchOnMount: "always" });
  const { data: allPerfumes = [] } = useAllPerfumes("name", { staleTime: 1000 * 60 * 5, enabled: !!perfume });
  const similar = useMemo(() => {
    if (!perfume || !allPerfumes.length) return [];
    const cur = new Set([...(perfume.top_notes?.split(",") || []), ...(perfume.heart_notes?.split(",") || []), ...(perfume.base_notes?.split(",") || [])].map((n) => n.trim().toLowerCase()).filter(Boolean));
    if (!cur.size) return [];
    return allPerfumes
      .filter((pp) => pp.id !== perfume.id && pp.brand_name !== perfume.brand_name)
      .map((pp) => { const on = new Set([...(pp.top_notes?.split(",") || []), ...(pp.heart_notes?.split(",") || []), ...(pp.base_notes?.split(",") || [])].map((n) => n.trim().toLowerCase()).filter(Boolean)); const inter = [...cur].filter((n) => on.has(n)); return { p: pp, score: inter.length / Math.max(cur.size, on.size) }; })
      .filter((it) => it.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);
  }, [perfume, allPerfumes]);
  const { data: wearLogs = [] } = useQuery({ queryKey: ["xc-wear", id], queryFn: () => apphost.entities.WearLog.filter({ perfume_id: id }), enabled: !!id, staleTime: 0, refetchOnMount: "always" });
  const { data: purchases = [] } = useQuery({ queryKey: ["xc-purch", id], queryFn: () => apphost.entities.PurchaseRecord.filter({ perfume_id: id }, "-created_date"), enabled: !!id, staleTime: 0, refetchOnMount: "always" });
  const { data: me } = useQuery({ queryKey: ["xc-me"], queryFn: () => apphost.auth.me() });
  const { data: noteRecords = [] } = useQuery({ queryKey: ["xc-notes"], queryFn: () => apphost.entities.PerfumeNote.list("name"), enabled: !!id, staleTime: 6e5 });
  const { data: perfumerRecords = [] } = useQuery({ queryKey: ["xc-perfumers"], queryFn: () => apphost.entities.Perfumer.list("name"), enabled: !!id || isBrand, staleTime: 6e5 });
  const { data: brand } = useQuery({ queryKey: ["xc-brand", brandId], queryFn: () => apphost.entities.PerfumeBrand.filter({ id: brandId }), select: (d) => d?.[0], enabled: isBrand });
  // مجموعة العطر (الخط) — لإظهار اسمها العربي في بطاقة العطر. يُجلب بالمعرّف وإلا بالاسم.
  const { data: coll } = useQuery({
    queryKey: ["xc-coll", perfume?.collection_id, perfume?.collection],
    queryFn: () => apphost.entities.PerfumeCollection.filter(perfume?.collection_id ? { id: String(perfume.collection_id) } : { name: perfume.collection }),
    select: (d) => d?.[0],
    enabled: !isBrand && !!(perfume?.collection_id || perfume?.collection),
    staleTime: 6e5,
  });
  const { data: brandPerfumes = [] } = useQuery({ queryKey: ["xc-brand-perfumes", brandId, brand?.name], queryFn: () => apphost.entities.Perfume.filter({ brand_name: brand.name }, "name", 60), enabled: isBrand && !!brand?.name });
  // تخصيص المستخدم للبراند (تقييم بتفاصيله + مراجعة) لكلّ شخص — يُعكس في البطاقة.
  const { data: userBrands = [] } = useQuery({ queryKey: ["xc-userbrand", brandId], queryFn: () => apphost.entities.UserBrand.filter({ brand_id: brandId }), enabled: isBrand });

  const { engByNorm, arByNorm } = useMemo(() => {
    const eng = {}; const seen = {}; const ar = {};
    noteRecords.forEach((n) => {
      [n.name, n.name_en].forEach((nm) => { const k = normKey(nm); if (k && !(k in eng)) eng[k] = n; });
      const ka = normKey(n.name_ar);
      if (ka) { seen[ka] = (seen[ka] || 0) + 1; if (!(ka in ar)) ar[ka] = n; }
    });
    Object.keys(seen).forEach((k) => { if (seen[k] > 1) delete ar[k]; });
    return { engByNorm: eng, arByNorm: ar };
  }, [noteRecords]);
  const findNote = (raw) => {
    // الإنجليزي أساس الربط
    const lat = normKey(enOf(raw));
    if (lat && engByNorm[lat]) return engByNorm[lat];
    if (lat && lat.length <= 28 && lat.split(" ").length <= 4) {
      for (const n of noteRecords) {
        for (const nm of [n.name, n.name_en]) {
          const full = normKey(nm);
          if (!full || full.split(" ").length > 2) continue;
          if (lat === full || lat.endsWith(" " + full)) return n;
        }
      }
    }
    const ka = normKey(arOf(raw) || raw);
    if (ka && arByNorm[ka]) return arByNorm[ka];
    return null;
  };

  const up1 = userPerfumes.find((u) => u.person === "person1");
  const up2 = userPerfumes.find((u) => u.person === "person2");
  const ud = person === "none" ? null : ((person === "person2" ? (up2 || up1) : (up1 || up2)) || userPerfumes[0] || null);
  const userMark = person === "none" ? "" : (ud?.mark || me?.mark || DEFAULT_USER_MARK || "").toString().slice(0, 32);
  // صورة الملف المخصّصة (data URL) — فارغة إن لم تُخصَّص فلا تُعرض ولا تشغل مساحة.
  const markPhoto = person === "none" ? "" : ((person === "person2" ? profiles?.person2?.photo : profiles?.person1?.photo) || "");

  // ---- auto-fit: تضمن اكتمال البطاقة بلا قصّ ----
  const [W, H] = ORIENTS[orient];
  const padH = isBrand ? 44 : 30;
  const padV = isBrand ? 44 : 28;
  const contentW = W - padH;
  const innerWidth = contentW / size;
  useLayoutEffect(() => {
    const el = fitRef.current;
    if (!el) return;
    const hn = el.offsetHeight; // ارتفاع التخطيط الطبيعي (لا يتأثّر بالـ transform)
    if (hn <= 0) return;
    const imgStage = bgKey === "custom" && !!customImage && imgDom;
    if (imgStage) {
      // وضع الصورة البارزة يبقى داخل إطارٍ ثابت → نُصغّر المحتوى ليملأه
      const f = (H - padV) / hn;
      setFitScale((prev) => (Math.abs(prev - f) > 0.004 ? f : prev));
    } else {
      // الوضع العادي: الإطار يحتضن المحتوى — ارتفاعه = ارتفاع المحتوى المُحجَّم + الحاشية
      const h = Math.ceil(hn * size + padV);
      setBoxH((prev) => (Math.abs(prev - h) > 1 ? h : prev));
    }
  });

  const [saving, setSaving] = useState(false);
  async function handleSave() {
    const el = cardRef.current;
    if (!el || saving) return;
    setSaving(true);
    try {
      const preset = BG_PRESETS[bgKey] || BG_PRESETS[""];
      const bg = bgKey === "custom" ? (customImage ? "#ffffff" : (customColor || "#ffffff")) : preset.base;
      // حارس مهلة: لا يعلّق الزرّ صامتاً إن تعثّر الالتقاط (خطوط/صور).
      const withTimeout = (pr, ms) => Promise.race([pr, new Promise((_, rej) => setTimeout(() => rej(new Error(isAr ? "انتهت المهلة" : "timeout")), ms))]);
      const canvas = await withTimeout(captureElementHQ(el, { pixelRatio: quality === "ultra" ? 5 : 4, backgroundColor: bg }), 20000);
      if (!canvas) { toast.error(isAr ? "تعذّر الحفظ" : "Could not save"); return; }
      // سوبرسامبلنغ عالٍ (×4 ≈ 2048) ثمّ تصغير عالي الجودة لمقاسٍ نهائيّ ≤860 —
      // دقّة فائقة بحجم ملفٍّ صغير، بحدٍّ أقصى 1024 احتياطاً.
      const out = downscaleCanvas(canvas, isBrand ? 500 : (quality === "ultra" ? 2000 : 1600)) || canvas;
      const base = isBrand ? (brand?.name || "brand") : (perfume?.name_en || perfume?.name || perfume?.name_ar || "card");
      await saveCanvasAsImage(out, `${base}-${Date.now().toString(36)}.png`, "image/png", 0.95, { toDownload: true });
      try {
        await recordExport({
          type: isBrand ? "brand" : "perfume",
          refId: isBrand ? brandId : id,
          name: isBrand ? (brand?.name_ar || brand?.name || "براند") : (perfume?.name_en || perfume?.name || perfume?.name_ar || "عطر"),
          payload: { lang, orient, fields },
        });
      } catch { /* noop */ }
      toast.success(isAr ? "حُفظت البطاقة في Download" : "Card saved to Download");
    } catch (e) {
      toast.error((isAr ? "تعذّر الحفظ: " : "Could not save: ") + (e?.message || ""));
    } finally {
      setSaving(false);
    }
  }
  function onPickImage(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => { setCustomImage(String(reader.result || "")); setBgKey("custom"); };
    reader.readAsDataURL(file);
  }

  const preset = BG_PRESETS[bgKey] || BG_PRESETS[""];
  const paper = bgKey === "custom" ? (customImage ? `center/cover no-repeat url(${customImage})` : (customColor || "#ffffff")) : preset.paper;
  const ink = bgKey === "custom" ? "#2b2b2b" : preset.ink;
  const muted = bgKey === "custom" ? "#4a463f" : preset.muted;
  const soft = bgKey === "custom" ? "#7a7368" : preset.soft;
  const bord = bgKey === "custom" ? GOLD : preset.bord;
  const isDark = bgKey === "dark" || bgKey === "slate";

  // لونا الخطوط الثنائيان القابلان للتخصيص (الافتراضي: ذهبي + زهري)
  const C1 = tone1 || GOLD;  const C1d = tone1 || "#2E7D32";
  const C2 = tone2 || PINK;
  // الخطّ الفاصل بين أقسام البطاقة: إن أُلغي فلا حدّ؛ وإلا لونٌ مخصّص أو الافتراضي لكلّ موضع.
  const sepLine = (def) => (dividerOff ? "none" : `1px solid ${dividerColor || def}`);
  const arSpan = (t) => showAr ? <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{t}</span> : null;
  const fam = FONTS[font] || FONTS.default;
  // ── وضع «الصورة بارزة» (الصورة خلفية والبطاقة مصغّرة داخلها) ──
  const imgBgActive = bgKey === "custom" && !!customImage;
  const useImgStage = imgBgActive && imgDom;
  const cardScale = Math.max(0.3, Math.min(0.95, cardPct || 0.55));
  const effScale = useImgStage ? Math.min(size, fitScale) : size;
  const stageAlign = cardPos === "top" ? "flex-start" : cardPos === "bottom" ? "flex-end" : "center";
  const stageOrigin = cardPos === "top" ? "top center" : cardPos === "bottom" ? "bottom center" : "center";
  const cardPaper = useImgStage ? "rgba(255,255,255,0.94)" : paper;
  const stageStyle = useImgStage
    ? { width: W, height: H, boxSizing: "border-box", position: "relative", overflow: "hidden", background: `center/cover no-repeat url(${customImage})`, display: "flex", justifyContent: "center", alignItems: stageAlign }
    : { width: W, boxSizing: "border-box", display: "block" };
  const cardBoxStyle = (pad) => useImgStage
    ? { width: W, height: H, background: cardPaper, border: `1px solid ${bord}`, boxSizing: "border-box", padding: pad, fontFamily: fam, color: ink, position: "relative", overflow: "hidden", display: "flex", justifyContent: "center", alignItems: "flex-start", transform: `scale(${cardScale})`, transformOrigin: stageOrigin, boxShadow: "0 10px 40px rgba(0,0,0,.45)", flex: "0 0 auto" }
    : { width: W, height: boxH || H, background: paper, border: `1px solid ${bord}`, boxSizing: "border-box", padding: pad, fontFamily: fam, color: ink, position: "relative", overflow: "visible", display: "flex", justifyContent: "center", alignItems: "flex-start" };
  const colItems = align === "left" ? "flex-start" : align === "right" ? "flex-end" : "center";
  // محاذاة الكتل المستقلة: «تابع» يتبع اللغة (عربي يمين، إنجليزي/مدمج يسار).
  const langAlign = lang === "ar" ? "right" : "left";
  const resolveA = (v) => (v && v !== "follow" ? v : langAlign);
  const jOf = (a) => (a === "left" ? "flex-start" : a === "right" ? "flex-end" : "center");

  // ============ TOOLBAR (fixed) ============
  const Toolbar = (
    <div style={{ position: "sticky", top: 0, zIndex: 30, background: "#F3EEE2", borderBottom: `1px solid ${N}`, padding: "9px 12px", display: "flex", alignItems: "center", gap: 10 }}>
      <button onClick={() => navigate(-1)} style={{ display: "flex", alignItems: "center", gap: 4, border: `1px solid ${N}`, background: "#fff", color: "var(--brand)", padding: "5px 11px", fontSize: 12, cursor: "pointer" }}>
        <ArrowLeft size={14} /> {isAr ? "رجوع" : "Back"}
      </button>
      <span style={{ flex: 1 }} />
    </div>
  );

  // زرّ الحفظ أسفل المعاينة (بعد رسم البطاقة كاملةً) — أوثق من وضعه في الشريط العلوي.
  const SaveBar = (
    <div style={{ display: "flex", justifyContent: "center", padding: "14px 12px 22px" }}>
      <button onClick={handleSave} disabled={saving} style={{ border: `1px solid ${GOLD}`, background: GOLD, color: "#fff", padding: "9px 26px", fontSize: 14, fontWeight: 700, cursor: "pointer", opacity: saving ? 0.6 : 1 }}>
        {saving ? (isAr ? "جارٍ الحفظ.." : "Saving..") : (isAr ? "حفظ البطاقة" : "Save Card")}
      </button>
    </div>
  );

  const seg = (val, set, opts) => (
    <div style={{ display: "inline-flex", flexWrap: "wrap", border: `1px solid ${N}` }}>
      {opts.map(([v, l], i) => (
        <button key={v} onClick={() => set(v)} style={{ border: "none", borderInlineStart: i ? `1px solid ${N}` : "none", background: val === v ? GOLD : "#fff", color: val === v ? "#fff" : "var(--brand)", padding: "5px 12px", fontSize: 12, cursor: "pointer", fontFamily: "Cairo, sans-serif" }}>{l}</button>
      ))}
    </div>
  );
  const lbl = (t) => <div style={{ fontSize: 11, color: PINK, fontFamily: "Amiri, serif", fontWeight: 700, marginBottom: 5 }}>{t}</div>;
  // محاذاة الكتلة: تابع (حسب اللغة) / يمين / وسط / يسار.
  const alignSeg = (val, set) => seg(val, set, [["follow", isAr ? "تابع" : "Follow"], ["right", isAr ? "يمين" : "Right"], ["center", isAr ? "وسط" : "Center"], ["left", isAr ? "يسار" : "Left"]]);
  // عنوان مجموعة كتلة في لوحة الخيارات — يجمع خيارات الكتلة الواحدة معاً.
  const blockHead = (n, t) => (
    <div style={{ display: "flex", alignItems: "center", gap: 7, margin: "16px 0 8px", paddingBottom: 4, borderBottom: `1px solid ${N}` }}>
      <span style={{ width: 18, height: 18, flexShrink: 0, display: "inline-flex", alignItems: "center", justifyContent: "center", background: GOLD, color: "#fff", fontSize: 11, fontWeight: 700, fontFamily: "Cinzel, serif" }}>{n}</span>
      <span style={{ fontFamily: "Amiri, serif", fontSize: 12.5, fontWeight: 700, color: "var(--brand)" }}>{t}</span>
    </div>
  );


  const FIELD_LIST = [
    ["name", isAr ? "الاسم" : "Name"], ["image", isAr ? "الصورة" : "Image"],
    ["brand", isAr ? "البراند" : "Brand"], ["collection", isAr ? "المجموعة" : "Collection"], ["info", isAr ? "معلومات" : "Info"],
    ["year", isAr ? "السنة" : "Year"], ["family", isAr ? "عائلة عطرية" : "Family"],
    ["occasions", isAr ? "المناسبات" : "Occasions"], ["perfumer", isAr ? "العطّار" : "Perfumer"],
    ["narrative", isAr ? "النبذة" : "Description"], ["pyramid", isAr ? "هرم" : "Pyramid"],
    ["similar", isAr ? "متقارب" : "Similar"], ["health", isAr ? "مؤشر الصحة" : "Health"], ["strict", isAr ? "متشدد" : "Strict"],
    ["myhealth", isAr ? "صحّتي" : "My Health"],
    ["rating", isAr ? "تقييم مشترك" : "Shared rating"], ["userRating", isAr ? "تقييم شخصي" : "Personal rating"],
    ["reaction", isAr ? "التفاعل" : "Reaction"], ["impression", isAr ? "الانطباع" : "Impression"], ["recommend", isAr ? "ترشيح" : "Recommend"],
    ["comment", isAr ? "مراجعتك" : "Your Review"], ["thought", isAr ? "انطباع المراحل" : "Note Phases"],
    ["wears", isAr ? "الارتداء" : "Wears"], ["purchases", isAr ? "الشراء" : "Purchases"],
    ["date", isAr ? "التاريخ" : "Date"], ["mark", isAr ? "المارك" : "Mark"], ["photo", isAr ? "صورة الملف" : "Profile Photo"],
  ];
  // خيار «عدد العطور» و «محاور التقييم» لبطاقة البراند فقط. بطاقة البراند تعرض فقط
  // الحقول ذات الصلة (تُحذف الخيارات الخاصة بالعطر و الخيارات السابقة الملغاة).
  const BRAND_FIELD_KEYS = ["name", "image", "info", "pcount", "perfumer", "narrative", "similar", "essence", "userRating", "impression", "reaction", "axes", "comment", "mark", "date", "photo"];
  const fieldList = isBrand
    ? [...FIELD_LIST, ["pcount", isAr ? "عدد العطور" : "Perfume Count"], ["axes", isAr ? "محاور التقييم" : "Rating Axes"], ["essence", isAr ? "الجوهر" : "Essence"]].filter(([k]) => BRAND_FIELD_KEYS.includes(k))
    : FIELD_LIST;

  const Options = (
    <div style={{ padding: 12 }}>
      {/* tabs */}
      <div style={{ display: "flex", border: `1px solid ${N}`, marginBottom: 12 }}>
        {[["fields", isAr ? "الحقول" : "Fields"], ["look", isAr ? "المظهر" : "Look"], ["layout", isAr ? "التخطيط" : "Layout"]].map(([v, l], i) => (
          <button key={v} onClick={() => setTab(v)} style={{ flex: 1, border: "none", borderInlineStart: i ? `1px solid ${N}` : "none", background: tab === v ? GOLD : "#fff", color: tab === v ? "#fff" : "var(--brand)", padding: "7px 0", fontSize: 12.5, fontWeight: 700, cursor: "pointer", fontFamily: "Cairo, sans-serif" }}>{l}</button>
        ))}
      </div>

      {tab === "fields" && (
        <div style={{ background: "#fff", padding: 0 }}>
          <div style={{ marginBottom: 11 }}>{lbl(isAr ? "اللغة" : "Language")}{seg(lang, setLang, [["ar", "عربي"], ["en", "English"], ["mix", isAr ? "مزيج" : "Mix"]])}</div>
          <div style={{ marginBottom: 11 }}>{lbl(isAr ? "الملف الشخصي" : "Profile")}{seg(person, setPerson, [["all", isAr ? "الكل" : "All"], ["person1", names.person1], ["person2", names.person2], ["none", isAr ? "بلا" : "None"]])}</div>
          <div>{lbl(isAr ? "ما تريد تضمينه" : "What to include")}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
              {fieldList.map(([k, l]) => {
                const on = !!fields[k];
                return (
                  <button key={k} onClick={() => setFields((f) => ({ ...f, [k]: !f[k] }))}
                    style={{ display: "flex", alignItems: "center", gap: 6, border: `1px solid ${N}`, background: on ? "#fbf6e6" : "#fff", color: "#6a5a18", padding: "5px 9px", fontSize: 11.5, cursor: "pointer", textAlign: "start", fontFamily: "Cairo, sans-serif" }}>
                    <span style={{ width: 7, height: 7, borderRadius: "50%", border: `1.4px solid ${GOLD}`, background: on ? GOLD : "transparent", flexShrink: 0 }} />{l}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {tab === "look" && (
        <div style={{ background: "#fff", padding: 0 }}>
          <div style={{ marginBottom: 11 }}>{lbl(isAr ? "نمط الخط" : "Font style")}
            <select name="ExportCard-sel1" value={font} onChange={(e) => setFont(e.target.value)} style={{ border: `1px solid ${N}`, background: "#fff", color: "#5a4a12", padding: "5px 8px", fontSize: 12, fontFamily: "Cairo, sans-serif" }}>
              <option value="default">{isAr ? "أنيق" : "Elegant"}</option>
              <option value="serif">{isAr ? "كلاسيكي" : "Classic"}</option>
              <option value="display">{isAr ? "رسمي" : "Formal"}</option>
            </select>
          </div>
          <div style={{ marginBottom: 11 }}>{lbl(isAr ? "حجم الخط — الوسط افتراضي" : "Font size — middle is default")}
            <div style={{ display: "inline-flex", alignItems: "flex-end", border: `1px solid ${N}` }}>
              {SIZES.map((z, i) => (
                <button key={z} onClick={() => setSize(z)} style={{ border: "none", borderInlineStart: i ? `1px solid ${N}` : "none", background: size === z ? GOLD : "#fff", color: size === z ? "#fff" : "#2E7D32", padding: "2px 11px", fontFamily: "Cinzel, serif", fontWeight: 700, fontSize: 10 + i * 4, lineHeight: 1, cursor: "pointer" }}>A</button>
              ))}
            </div>
          </div>
          {isBrand && <div style={{ marginBottom: 11 }}>{lbl(isAr ? "المحاذاة" : "Alignment")}{seg(align, setAlign, [["right", isAr ? "يمين" : "Right"], ["center", isAr ? "وسط" : "Center"], ["left", isAr ? "يسار" : "Left"]])}</div>}
          <div style={{ marginBottom: 11 }}>{lbl(isAr ? "دقّة التصدير" : "Export quality")}{seg(quality, setQuality, [["high", isAr ? "مرتفعة" : "High"], ["ultra", isAr ? "مرتفعة جدًا" : "Very high"]])}</div>
          <div style={{ marginBottom: 11 }}>{lbl(isAr ? "لون الخطوط (ثنائي)" : "Font colors (dual)")}
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {[{ v: tone1, set: setTone1, def: GOLD, name: isAr ? "الأول" : "Primary", presets: ["", "#1f2937", "#14532d", "#1e3a8a", "#7c2d12", "#701a75"] },
                { v: tone2, set: setTone2, def: PINK, name: isAr ? "الثاني" : "Secondary", presets: ["", "#9d174d", "#b91c1c", "#6d28d9", "#0e7490", "#92400e"] }].map((r, ri) => (
                <div key={ri} style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 10.5, color: "#2E7D32", width: 46, flexShrink: 0 }}>{r.name}</span>
                  {r.presets.map((c) => (
                    <button key={c || "def"} onClick={() => r.set(c)} title={c || (isAr ? "افتراضي" : "Default")} style={{ width: 22, height: 22, background: c || r.def, border: r.v === c ? `2px solid ${GOLD}` : "1.5px solid #d9cfae", cursor: "pointer", padding: 0 }} />
                  ))}
                  <label style={{ width: 22, height: 22, border: "1.5px solid #d9cfae", overflow: "hidden", display: "inline-flex", cursor: "pointer" }}>
                    <input type="color" value={r.v || r.def} onChange={(e) => r.set(e.target.value)} style={{ width: "200%", height: "200%", margin: "-25% -50%", border: "none", padding: 0, cursor: "pointer" }} />
                  </label>
                </div>
              ))}
            </div>
          </div>
          <div>{lbl(isAr ? "الخلفية" : "Background")}
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
              {[["", "#fff"], ["white", "#fafafa"], ["light", "linear-gradient(180deg,#fff,#f0e8d2)"], ["gold", "linear-gradient(160deg,#f6ecca,#e7d39a)"], ["dark", "#231f18"], ["rose", "linear-gradient(180deg,#fff,#fbd6e3)"], ["sage", "linear-gradient(180deg,#fff,#d4e4c6)"], ["sky", "linear-gradient(180deg,#fff,#cfe2f0)"], ["lavender", "linear-gradient(180deg,#fff,#ddd0f0)"], ["slate", "#2b2f36"]].map(([k, bg]) => (
                <button key={k || "cur"} onClick={() => setBgKey(k)} title={k || (isAr ? "الحالي" : "Current")} style={{ width: 34, height: 26, background: bg, border: bgKey === k ? `2px solid ${GOLD}` : "2px solid #d9cfae", boxShadow: bgKey === k ? `0 0 0 2px #fff, 0 0 0 3px ${GOLD}` : "none", cursor: "pointer" }} />
              ))}
              <label style={{ width: 34, height: 26, border: bgKey === "custom" && !customImage ? `2px solid ${GOLD}` : "2px solid #d9cfae", cursor: "pointer", display: "inline-flex", overflow: "hidden" }}>
                <input type="color" value={customColor || "#ffffff"} onChange={(e) => { setCustomColor(e.target.value); setCustomImage(""); setBgKey("custom"); }} style={{ width: "200%", height: "200%", margin: "-25% -50%", cursor: "pointer", border: "none", padding: 0 }} />
              </label>
              <label style={{ display: "inline-flex", alignItems: "center", gap: 5, border: `1px solid ${N}`, background: bgKey === "custom" && customImage ? "#fbf6e6" : "#fff", color: "#2E7D32", padding: "4px 9px", fontSize: 11.5, cursor: "pointer" }}>
                <Upload size={13} /> {isAr ? "صورة" : "Image"}
                <input type="file" accept="image/*" onChange={onPickImage} style={{ display: "none" }} />
              </label>
              {bgKey === "custom" && (customImage || customColor) && (
                <button onClick={() => { setCustomImage(""); setCustomColor(""); setBgKey(""); }} style={{ border: `1px solid ${N}`, background: "#fff", color: "#2E7D32", padding: "4px 7px", cursor: "pointer", display: "inline-flex", alignItems: "center" }}><X size={13} /></button>
              )}
            </div>
          </div>
          <div style={{ marginTop: 13 }}>{lbl(isAr ? "الخطّ الفاصل" : "Divider line")}
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
              <button onClick={() => setDividerOff(!dividerOff)} style={{ border: `1px solid ${N}`, background: dividerOff ? "#fff" : "#fbf6e6", color: "#2E7D32", padding: "4px 9px", fontSize: 11.5, cursor: "pointer", display: "inline-flex", alignItems: "center", gap: 5, fontFamily: "Cairo, sans-serif" }}>
                <span style={{ width: 7, height: 7, borderRadius: "50%", border: `1.4px solid ${GOLD}`, background: dividerOff ? "transparent" : GOLD, flexShrink: 0 }} />
                {isAr ? (dividerOff ? "مخفي" : "ظاهر") : (dividerOff ? "Hidden" : "Shown")}
              </button>
              {!dividerOff && ["", "#d9cfae", "#e7d39a", "#9d174d", "#14532d", "#1e3a8a"].map((c) => (
                <button key={c || "def"} onClick={() => setDividerColor(c)} title={c || (isAr ? "افتراضي" : "Default")} style={{ width: 22, height: 22, background: c || "#cfc6ad", border: dividerColor === c ? `2px solid ${GOLD}` : "1.5px solid #d9cfae", cursor: "pointer", padding: 0 }} />
              ))}
              {!dividerOff && (
                <label style={{ width: 22, height: 22, border: "1.5px solid #d9cfae", overflow: "hidden", display: "inline-flex", cursor: "pointer" }}>
                  <input type="color" value={dividerColor || "#cccccc"} onChange={(e) => setDividerColor(e.target.value)} style={{ width: "200%", height: "200%", margin: "-25% -50%", border: "none", padding: 0, cursor: "pointer" }} />
                </label>
              )}
            </div>
          </div>
          {imgBgActive && (
            <div style={{ marginTop: 13 }}>
              {lbl(isAr ? "الصورة كخلفية بارزة" : "Image as feature background")}
              <label style={{ display: "inline-flex", alignItems: "center", gap: 6, fontSize: 12, cursor: "pointer", color: "#6a5a18", fontFamily: "Cairo, sans-serif" }}>
                <input type="checkbox" checked={imgDom} onChange={(e) => setImgDom(e.target.checked)} />
                {isAr ? "اجعل الصورة بارزة والبطاقة مصغّرة بداخلها" : "Image dominant — shrink card inside it"}
              </label>
              {imgDom && (
                <div style={{ marginTop: 10 }}>
                  <div style={{ marginBottom: 9 }}>
                    <div style={{ fontSize: 11, color: PINK, fontFamily: "Amiri, serif", fontWeight: 700, marginBottom: 4 }}>{isAr ? `حجم البطاقة: ${Math.round(cardScale * 100)}%` : `Card size: ${Math.round(cardScale * 100)}%`}</div>
                    <input type="range" min={30} max={90} step={5} value={Math.round(cardScale * 100)} onChange={(e) => setCardPct(Number(e.target.value) / 100)} style={{ width: "100%", accentColor: GOLD, cursor: "pointer" }} />
                  </div>
                  {lbl(isAr ? "موضع البطاقة" : "Card position")}
                  {seg(cardPos, setCardPos, [["top", isAr ? "أعلى" : "Top"], ["center", isAr ? "وسط" : "Center"], ["bottom", isAr ? "أسفل" : "Bottom"]])}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {tab === "layout" && (
        <div style={{ background: "#fff", padding: 0 }}>
          <div style={{ marginBottom: 4 }}>{lbl(isAr ? "الاتجاه" : "Orientation")}{seg(orient, setOrient, [["square", isAr ? "مربّع" : "Square"], ["portrait", isAr ? "طولي" : "Portrait"], ["land", isAr ? "عرضي" : "Landscape"]])}</div>

          {isBrand ? (
            <>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "مناسبات العطر" : "Perfume occasions")}{seg(occMode, setOccMode, [["text", isAr ? "نص" : "Text"], ["emoji", isAr ? "ايقونة" : "Icon"], ["both", isAr ? "نص & ايقونة" : "Text & Icon"]])}</div>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "مناسبات المستخدم" : "User occasions")}{seg(userOccMode, setUserOccMode, [["text", isAr ? "نص" : "Text"], ["emoji", isAr ? "ايقونة" : "Icon"], ["both", isAr ? "نص & ايقونة" : "Text & Icon"]])}</div>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "النوتات: نص أو أيقونات" : "Notes: text or icons")}{seg(notesMode, setNotesMode, [["text", isAr ? "نص" : "Text"], ["icons", isAr ? "أيقونات" : "Icons"], ["both", isAr ? "كلاهما" : "Both"]])}</div>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "تجميع النوتات" : "Group notes")}{seg(groupedNotes ? "on" : "off", (v) => setGroupedNotes(v === "on"), [["on", isAr ? "مجمّعة" : "Grouped"], ["off", isAr ? "منفردة" : "Individual"]])}</div>
              {notesMode !== "text" && (
                <>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "إطار النوتات" : "Note frame")}{seg(noteFrame ? "on" : "off", (v) => setNoteFrame(v === "on"), [["on", isAr ? "بإطار" : "Framed"], ["off", isAr ? "بلا إطار" : "No frame"]])}</div>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "مؤشرات النوتة الصحية" : "Note health indicators")}{seg(noteHealthInd ? "on" : "off", (v) => setNoteHealthInd(v === "on"), [["on", isAr ? "ظاهرة" : "On"], ["off", isAr ? "مخفية" : "Off"]])}</div>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "محاذاة اسم النوتة" : "Note name align")}{seg(noteAlign, setNoteAlign, [["right", isAr ? "يمين" : "Right"], ["center", isAr ? "وسط" : "Center"], ["left", isAr ? "يسار" : "Left"]])}</div>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "عناوين المراحل" : "Phase titles")}{seg(phaseHeads ? "on" : "off", (v) => setPhaseHeads(v === "on"), [["on", isAr ? "ظاهرة" : "On"], ["off", isAr ? "مخفية" : "Off"]])}</div>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "موضع اسم النوتة" : "Note name pos")}{seg(notePos, setNotePos, [["above", isAr ? "أعلى" : "Above"], ["below", isAr ? "أسفل" : "Below"], ["right", isAr ? "يمين" : "Right"], ["left", isAr ? "يسار" : "Left"]])}</div>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "موضع اسم العطّار" : "Perfumer name pos")}{seg(perfumerPos, setPerfumerPos, [["above", isAr ? "أعلى" : "Above"], ["below", isAr ? "أسفل" : "Below"], ["right", isAr ? "يمين" : "Right"], ["left", isAr ? "يسار" : "Left"]])}</div>
                </>
              )}
            </>
          ) : (
            <>
              {blockHead("١", isAr ? "الترويسة + الصحة + المواسم" : "Header + Health + Seasons")}
              <div>{lbl(isAr ? "محاذاة الكتلة" : "Block alignment")}{alignSeg(b1Align, setB1Align)}</div>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "الفصول والوقت" : "Seasons & time")}{seg(climateMode, setClimateMode, [["icon", isAr ? "أيقونة" : "Icon"], ["text", isAr ? "نص" : "Text"], ["none", isAr ? "بلا" : "None"]])}</div>

              {blockHead("٢", isAr ? "القنينة + الكثافة + الفئة" : "Bottle + Density + Category")}
              <div>{lbl(isAr ? "محاذاة الكتلة" : "Block alignment")}{alignSeg(b2Align, setB2Align)}</div>

              {blockHead("٣", isAr ? "المصممون + العائلة + الوصف + المناسبات" : "Designers + Family + Description + Occasions")}
              <div>{lbl(isAr ? "محاذاة الكتلة" : "Block alignment")}{alignSeg(b3Align, setB3Align)}</div>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "موضع اسم المصمم" : "Designer name pos")}{seg(perfumerPos, setPerfumerPos, [["above", isAr ? "أعلى" : "Above"], ["below", isAr ? "أسفل" : "Below"], ["right", isAr ? "يمين" : "Right"], ["left", isAr ? "يسار" : "Left"]])}</div>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "مناسبات العطر" : "Perfume occasions")}{seg(occMode, setOccMode, [["text", isAr ? "نص" : "Text"], ["emoji", isAr ? "ايقونة" : "Icon"], ["both", isAr ? "نص & ايقونة" : "Text & Icon"]])}</div>

              {blockHead("٤", isAr ? "الهرم" : "Pyramid")}
              <div>{lbl(isAr ? "محاذاة الكتلة" : "Block alignment")}{alignSeg(b4Align, setB4Align)}</div>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "النوتات: نص أو أيقونات" : "Notes: text or icons")}{seg(notesMode, setNotesMode, [["text", isAr ? "نص" : "Text"], ["icons", isAr ? "أيقونات" : "Icons"], ["both", isAr ? "كلاهما" : "Both"]])}</div>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "تجميع النوتات" : "Group notes")}{seg(groupedNotes ? "on" : "off", (v) => setGroupedNotes(v === "on"), [["on", isAr ? "مجمّعة" : "Grouped"], ["off", isAr ? "منفردة" : "Individual"]])}</div>
              {notesMode !== "text" && (
                <>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "إطار النوتات" : "Note frame")}{seg(noteFrame ? "on" : "off", (v) => setNoteFrame(v === "on"), [["on", isAr ? "بإطار" : "Framed"], ["off", isAr ? "بلا إطار" : "No frame"]])}</div>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "مؤشرات النوتة الصحية" : "Note health indicators")}{seg(noteHealthInd ? "on" : "off", (v) => setNoteHealthInd(v === "on"), [["on", isAr ? "ظاهرة" : "On"], ["off", isAr ? "مخفية" : "Off"]])}</div>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "محاذاة اسم النوتة" : "Note name align")}{seg(noteAlign, setNoteAlign, [["right", isAr ? "يمين" : "Right"], ["center", isAr ? "وسط" : "Center"], ["left", isAr ? "يسار" : "Left"]])}</div>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "عناوين المراحل" : "Phase titles")}{seg(phaseHeads ? "on" : "off", (v) => setPhaseHeads(v === "on"), [["on", isAr ? "ظاهرة" : "On"], ["off", isAr ? "مخفية" : "Off"]])}</div>
                  <div style={{ marginTop: 11 }}>{lbl(isAr ? "موضع اسم النوتة" : "Note name pos")}{seg(notePos, setNotePos, [["above", isAr ? "أعلى" : "Above"], ["below", isAr ? "أسفل" : "Below"], ["right", isAr ? "يمين" : "Right"], ["left", isAr ? "يسار" : "Left"]])}</div>
                </>
              )}

              {blockHead("٥", isAr ? "تقييمات المستخدم" : "User ratings")}
              <div>{lbl(isAr ? "محاذاة الكتلة" : "Block alignment")}{alignSeg(b5Align, setB5Align)}</div>
              <div style={{ marginTop: 11 }}>{lbl(isAr ? "مناسبات المستخدم" : "User occasions")}{seg(userOccMode, setUserOccMode, [["text", isAr ? "نص" : "Text"], ["emoji", isAr ? "ايقونة" : "Icon"], ["both", isAr ? "نص & ايقونة" : "Text & Icon"]])}</div>
            </>
          )}
        </div>
      )}
    </div>
  );

  // غلاف العرض: يصغّر البطاقة كاملةً لتناسب الشاشة (fit to screen).
  // ارتفاع المعاينة يتبع ارتفاع المحتوى الفعلي (boxH) فتظهر البطاقة كاملة وزر الحفظ يليها مباشرة
  const previewInnerH = useImgStage ? H : (boxH || H);
  const preview = (inner) => (
    <div dir="ltr" style={{ display: "flex", justifyContent: "center", padding: "8px 0 12px" }}>
      <div style={{ width: W * scale, height: previewInnerH * scale, overflow: "hidden" }}>
        <div style={{ transform: `scale(${scale})`, transformOrigin: "top left", width: W, height: previewInnerH }}>{inner}</div>
      </div>
    </div>
  );

  // ============ BRAND CARD ============
  if (isBrand) {
    if (!brand) return <div>{Toolbar}<div style={{ padding: 30, textAlign: "center", color: "#2E7D32" }}>{isAr ? "جارٍ التحميل…" : "Loading…"}</div></div>;
    const bCountry = (showEn ? (brand.country || brand.country_ar || "") : (brand.country_ar || brand.country || "")).trim();
    const bMeta = [dash(brandCategoryLabel(brand, isAr)), bCountry, brand.year_established ? String(brand.year_established) : "", brand.owned_by ? String(brand.owned_by) : ""].filter(Boolean);
    const bPerfumers = String(brand.perfumer_names || "").split(",").map((s) => s.trim()).filter(Boolean).slice(0, 6);
    const bPerfAr = {}; const bPerfImg = {}; perfumerRecords.forEach((p) => { if (p.name) { bPerfAr[p.name.toLowerCase()] = p.name_ar; bPerfImg[p.name.toLowerCase()] = p.photo_url || p.image_url || ""; } });
    const bDescFull = ((showEn ? (brand.description || "").trim() : "") || (showAr ? (brand.description_ar || "").trim() : "") || (brand.description || "").trim());
    const bDesc = bDescFull.slice(0, 360);
    const brandBestOfDecade = brandPerfumes.some((bp) => bp.best_of_decade && decadeLabel(bp.release_year));
    // العدد الحقيقيّ من perfume_ids المملوءة وقت الزرع (٥٧٨ لجيرلان مثلاً) لا من
    // brandPerfumes المقطوعة عند ٦٠ — هذا ما كان يظهر «٦٠» خطأً.
    const brandTotal = (brand.perfume_ids ? String(brand.perfume_ids).split(",").filter(Boolean).length : 0) || brandPerfumes.length;
    const bEss = brandPerfumes.length ? computeBrandEssence(brandPerfumes, [], perfumerRecords) : null;
    const bCard = (withRefs) => (
      <div ref={withRefs ? cardRef : null} style={stageStyle}>
        <div style={cardBoxStyle(22)}>
        <div ref={fitRef} style={{ width: innerWidth, transformOrigin: "top center", transform: `scale(${effScale})`, display: "flex", flexDirection: "column", justifyContent: "center", gap: 10, textAlign: "center" }}>
          {(fields.name || fields.image) && (
            <div dir="ltr" style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 4, textAlign: "left" }}>
              {fields.name && (brand.name || brand.name_ar) && (
                <div style={{ flex: 1, minWidth: 0 }}>
                  {showEn && brand.name && <div style={{ fontFamily: "Cinzel, serif", fontWeight: 700, fontSize: 28, letterSpacing: "1px", color: C1, textTransform: "uppercase", lineHeight: 1.06, wordBreak: "break-word" }}>{brand.name}</div>}
                  {((showAr && brand.name_ar) || brandBestOfDecade) && (
                    <div style={{ display: "flex", alignItems: "center", gap: 7, marginTop: 2, flexWrap: "wrap" }}>
                      {showAr && brand.name_ar && <span style={{ fontFamily: "Amiri, serif", fontSize: 16, color: "#9D174D", lineHeight: 1.2 }}>{brand.name_ar}</span>}
                      {brandBestOfDecade && <span style={{ fontFamily: showAr ? "Amiri, serif" : "Cinzel, serif", fontSize: 8.5, color: GREEN, fontWeight: 700, letterSpacing: showAr ? 0 : ".06em", textTransform: showAr ? "none" : "uppercase" }}>{showAr ? "أفضل العقد" : "Best of decade"}</span>}
                    </div>
                  )}
                  {fields.narrative && bDesc && <div style={{ fontSize: 10.5, color: muted, lineHeight: 1.7, marginTop: 5, fontFamily: (showAr && !showEn) ? "Amiri, serif" : fam }}>{bDesc}{bDescFull.length > 360 ? "…" : ""}</div>}
                </div>
              )}
              {fields.image && (
                <div style={{ flex: "0 0 auto", width: 86, height: 86, border: `1.5px solid ${GOLD}`, background: "transparent", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
                  {(brand.logo_url || brand.processappdatabase_logo)
                    ? <img src={brand.logo_url || brand.processappdatabase_logo} alt="" crossOrigin="anonymous" referrerPolicy="no-referrer" style={{ maxWidth: "90%", maxHeight: "90%", objectFit: "contain" }} />
                    : null}
                </div>
              )}
            </div>
          )}
          {fields.pcount && brandTotal > 0 && (
            <div style={{ display: "flex", alignItems: "baseline", justifyContent: "center", gap: 4, marginTop: 1 }}>
              <span style={{ fontFamily: "Cinzel, serif", fontSize: 11, fontWeight: 700, color: soft, lineHeight: 1 }}>{brandTotal}</span>
              {showAr && <span style={{ fontFamily: "Amiri, serif", color: soft, fontSize: 9 }}>عطر</span>}
              {showEn && <span style={{ fontFamily: "Cinzel, serif", fontSize: 8, letterSpacing: ".1em", textTransform: "uppercase", color: soft, marginInlineStart: showAr ? 2 : 0 }}>fragrances</span>}
            </div>
          )}
          {((fields.pcount && brandTotal > 0) || (fields.info && bMeta.length > 0)) && (
            <div style={{ width: 72, height: 2, margin: "5px auto 3px", background: `linear-gradient(90deg, transparent, ${GOLD}, transparent)` }} />
          )}
          {fields.info && bMeta.length > 0 && (
            <div style={{ fontSize: 12.5, color: muted, display: "flex", flexWrap: "wrap", justifyContent: "center", alignItems: "center", gap: 8 }}>
              {bMeta.map((m, i) => <span key={i} style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>{i > 0 && <span style={{ color: soft }}>،</span>}{m}</span>)}
            </div>
          )}
          {fields.perfumer && bPerfumers.length > 0 && (
            <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 13, marginTop: 4 }}>
              {bPerfumers.map((p, i) => {
                const lc = p.toLowerCase(); const ar = bPerfAr[lc]; const img = bPerfImg[lc];
                const bd = hilalBorder(p, ar, `1.5px solid ${GOLD}`);
                return (
                  <span key={i} style={{ display: "inline-flex", flexDirection: "column", alignItems: "center", gap: 3, fontSize: 10.5, color: muted }}>
                    <span style={{ width: 38, height: 38, border: bd, background: "transparent", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", flex: "0 0 auto" }}>
                      {img ? <img src={img} alt="" crossOrigin="anonymous" referrerPolicy="no-referrer" onError={(e) => { e.currentTarget.style.display = "none"; }} style={{ maxWidth: "92%", maxHeight: "92%", objectFit: "contain" }} /> : null}
                    </span>
                    <span style={{ whiteSpace: "nowrap" }}>{showEn && p}{showAr && ar ? <span style={{ fontFamily: "Amiri, serif", color: PINK, marginInlineStart: showEn ? 3 : 0 }}>{ar}</span> : null}</span>
                  </span>
                );
              })}
            </div>
          )}
          {fields.similar && brandPerfumes.length > 0 && (
            <div style={{ marginTop: 10 }}>
              <div style={{ fontFamily: "Cinzel, serif", fontSize: 8, letterSpacing: ".14em", color: "#9a8f7c", textTransform: "uppercase", marginBottom: 5 }}>{showAr && <span style={{ fontFamily: "Amiri, serif", color: PINK }}>أبرز العطور</span>}{showEn && <span style={{ marginInlineStart: showAr ? 5 : 0 }}>Selected perfumes</span>}</div>
              <div style={{ fontSize: 11, color: GOLD, fontWeight: 600, lineHeight: 1.95, maxWidth: innerWidth - 24, marginInline: "auto" }}>
                {brandPerfumes.slice(0, 20).map((p) => (showEn ? (p.name_en || p.name) : (p.name_ar || p.name_en || p.name))).filter(Boolean).join("، ")}
              </div>
            </div>
          )}
          {fields.essence && bEss && (
            <div style={{ marginTop: 8, paddingTop: 9, borderTop: sepLine(isDark ? "#4a4334" : "rgba(0,0,0,.07)") }}>
              <div style={{ fontFamily: "Cinzel, serif", fontSize: 8, letterSpacing: ".14em", color: "#9a8f7c", textTransform: "uppercase", marginBottom: 5 }}>{showAr && <span style={{ fontFamily: "Amiri, serif", color: PINK }}>الجوهر</span>}{showEn && <span style={{ marginInlineStart: showAr ? 5 : 0 }}>Essence</span>}</div>
              <div style={{ display: "flex", flexWrap: "wrap", justifyContent: colItems, alignItems: "center", gap: "4px 12px", fontSize: 10.5, color: muted }}>
                {bEss.density && <span>{showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>كثافة </span>}{showEn && "Density "}<b style={{ color: bEss.density.color }}>{showAr ? bEss.density.ar : bEss.density.en}</b></span>}
                {bEss.strict && bEss.strict.total > 0 && <span>{showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>متشدد </span>}{showEn && "Strict "}<b style={{ color: bEss.strict.pct > 0 ? "#C0392B" : "#3B6D11" }}>{bEss.strict.pct > 0 ? (showAr ? "مُثير" : "Flagged") : (showAr ? "آمن" : "Clear")}</b></span>}
                {(bEss.health || []).slice(0, 3).map((h) => <span key={h.id}>{showAr && <span style={{ fontFamily: "Amiri, serif", color: PINK }}>{h.ar}</span>}{showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{h.en}</span>}</span>)}
              </div>
              {(bEss.topNotes || []).length > 0 && (
                <div style={{ fontSize: 10, color: muted, lineHeight: 1.8, maxWidth: innerWidth - 24, marginInline: "auto", marginTop: 4 }}>
                  {bEss.topNotes.slice(0, 8).map((n) => (showAr ? (n.ar || n.en) : (n.en || n.ar))).filter(Boolean).join("، ")}
                </div>
              )}
            </div>
          )}
          {(() => {
            // تخصيص المستخدم للبراند: الانطباع + التفاعل السريع + التقييم + المراجعة (لكلّ شخص)
            if (person === "none") return null;
            const IMPR = { great: { e: "😍", ar: "رائع", en: "Great" }, neutral: { e: "😐", ar: "حيادي", en: "Neutral" }, not_great: { e: "😕", ar: "ليس رائعاً", en: "Not Great" } };
            const BREACT = { love_it: { e: "🥰", ar: "أحبّه", en: "Love it" }, like_it: { e: "😍", ar: "يعجبني", en: "Like it" }, neutral: { e: "😐", ar: "حيادي", en: "Neutral" }, hate_it: { e: "😠", ar: "أكرهه", en: "Hate it" } };
            const showI = userOccMode !== "text";
            const showT = userOccMode !== "emoji";
            const ub1 = userBrands.find((u) => u.person === "person1");
            const ub2 = userBrands.find((u) => u.person === "person2");
            const rows = person === "person1" ? [["person1", ub1]] : person === "person2" ? [["person2", ub2]] : [["person1", ub1], ["person2", ub2]];
            const cells = rows.map(([pk, u]) => {
              if (!u) return null;
              const reviewText = u.personal_notes || u.review || u.notes || "";
              const axisVals = RATING_AXES.filter((ax) => u[ax.key] != null && u[ax.key] > 0);
              const has = (fields.userRating && u.rating != null) || (fields.impression && u.impression) || (fields.reaction && u.other_rating) || (fields.axes && axisVals.length) || (fields.comment && reviewText);
              if (!has) return null;
              return (
                <div key={pk} style={{ display: "flex", flexDirection: "column", alignItems: colItems, width: "100%", gap: 3 }}>
                  {person === "all" && <span style={{ fontFamily: "Cinzel, serif", fontSize: 8, letterSpacing: ".06em", color: "#9a8f7c", textTransform: "uppercase" }}>{names[pk]}</span>}
                  <div style={{ display: "flex", flexWrap: "wrap", justifyContent: colItems, alignItems: "center", gap: 8, fontSize: 10, color: muted }}>
                    {fields.impression && u.impression && IMPR[u.impression] && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{showI && <span>{IMPR[u.impression].e}</span>}{showT && showAr && <span style={{ fontFamily: "Amiri, serif", color: PINK }}>{IMPR[u.impression].ar}</span>}{showT && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{IMPR[u.impression].en}</span>}</span>}
                    {fields.reaction && u.other_rating && BREACT[u.other_rating] && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{showI && <span>{BREACT[u.other_rating].e}</span>}{showT && showAr && <span style={{ fontFamily: "Amiri, serif", color: PINK }}>{BREACT[u.other_rating].ar}</span>}{showT && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{BREACT[u.other_rating].en}</span>}</span>}
                    {fields.userRating && u.rating != null && <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>{arSpan("تقييمي")}{showEn && <span style={{ marginInlineEnd: 2 }}>My rating</span>} <Diamonds filled={u.rating || 0} /></span>}
                  </div>
                  {fields.axes && axisVals.length > 0 && (
                    <div style={{ display: "flex", flexWrap: "wrap", justifyContent: colItems, alignItems: "center", gap: 8, marginTop: 2, fontSize: 9.5, color: muted }}>
                      {axisVals.map((ax) => (
                        <span key={ax.key} style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>
                          {showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{ax.ar}</span>}
                          {showEn && <span style={{ marginInlineStart: showAr ? 2 : 0 }}>{ax.en}</span>}
                          <Diamonds filled={u[ax.key] || 0} />
                        </span>
                      ))}
                    </div>
                  )}
                  {fields.comment && reviewText && <div style={{ marginTop: 2, fontFamily: "Amiri, serif", color: muted, fontSize: 9, textAlign: align === "right" ? "right" : align === "left" ? "left" : "center", maxWidth: innerWidth - 40 }}>✏️ — {reviewText} —</div>}
                </div>
              );
            }).filter(Boolean);
            if (cells.length === 0) return null;
            return <div style={{ display: "flex", flexDirection: "column", alignItems: "stretch", gap: 9, marginTop: 8, paddingTop: 10, borderTop: sepLine(isDark ? "#4a4334" : "rgba(0,0,0,.07)") }}>{cells}</div>;
          })()}
          {(fields.mark || fields.date || (fields.photo && markPhoto)) && (
            <div style={{ borderTop: sepLine(isDark ? "#4a4334" : "rgba(0,0,0,.07)"), paddingTop: 10, marginTop: 8, display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 11, color: soft }}>
              {(fields.mark || (fields.photo && markPhoto)) ? <span style={{ display: "flex", alignItems: "center", gap: 6 }}>{fields.photo && markPhoto ? <img src={markPhoto} alt="" style={{ width: 24, height: 24, objectFit: "cover", background: "#fff", borderBottom: `1.5px solid ${GOLD}`, display: "block" }} /> : null}{fields.mark && userMark && <span style={{ fontFamily: "Amiri, serif", color: "#2E7D32", fontWeight: 700, fontSize: 13 }}>{userMark}</span>}</span> : <span />}
              {fields.date && <span>Process {new Date().toLocaleDateString(showAr ? "ar-EG" : "en-GB")}</span>}
            </div>
          )}
        </div>
        </div>
      </div>
    );
    const bVpH = typeof window !== "undefined" ? window.innerHeight : 700;
    const bMiniMaxH = Math.min(300, Math.round(bVpH * 0.33));
    const bMiniScale = Math.min(scale, bMiniMaxH / previewInnerH); // يصغّر البطاقة كاملةً لتظهر عمودية بلا قصّ
    const bMiniH = previewInnerH * bMiniScale;
    const bStickyTop = (
      <div style={{ position: "sticky", top: 0, zIndex: 30, background: "#F3EEE2", borderBottom: `1px solid ${N}` }}>
        <div style={{ padding: "9px 12px", display: "flex", alignItems: "center", gap: 10 }}>
          <button onClick={() => navigate(-1)} style={{ display: "flex", alignItems: "center", gap: 4, border: `1px solid ${N}`, background: "#fff", color: "var(--brand)", padding: "5px 11px", fontSize: 12, cursor: "pointer" }}>
            <ArrowLeft size={14} /> {isAr ? "رجوع" : "Back"}
          </button>
          <span style={{ flex: 1 }} />
          <button onClick={handleSave} disabled={saving} style={{ border: `1px solid ${GOLD}`, background: GOLD, color: "#fff", padding: "5px 16px", fontSize: 12.5, fontWeight: 700, cursor: "pointer", opacity: saving ? 0.6 : 1 }}>
            {saving ? (isAr ? "جارٍ.." : "..") : (isAr ? "حفظ" : "Save")}
          </button>
        </div>
        <div dir="ltr" style={{ display: "flex", justifyContent: "center", padding: "0 0 7px", pointerEvents: "none" }}>
          <div style={{ width: W * bMiniScale, height: bMiniH, overflow: "hidden" }}>
            <div style={{ transform: `scale(${bMiniScale})`, transformOrigin: "top left", width: W, height: previewInnerH }}>{bCard(false)}</div>
          </div>
        </div>
      </div>
    );
    return <div>{bStickyTop}{Options}{preview(bCard(true))}{SaveBar}</div>;
  }

  // ============ PERFUME CARD ============
  if (!perfume) return <div>{Toolbar}<div style={{ padding: 30, textAlign: "center", color: "#2E7D32" }}>{isAr ? "جارٍ التحميل…" : "Loading…"}</div></div>;

  const accords = parseAccords(perfume.accords);
  const dom = accords[0] || null;
  const dec = perfume.best_of_decade ? decadeLabel(perfume.release_year) : null;
  // اسم المجموعة للعرض: العربي إن توفّر و كانت اللغة عربية، وإلا الإنجليزي.
  const collEn = dash(String(perfume.collection || coll?.name || "").trim());
  const collArName = String(coll?.name_ar || "").trim();
  const collDisplay = (showAr && collArName) ? collArName : (showEn ? collEn : (collArName || collEn));
  const health = analyzePerfume(perfume);
  const phases = [
    { ar: "مقدمة", en: "Top", notes: splitCsv(perfume.top_notes) },
    { ar: "قلب", en: "Heart", notes: splitCsv(perfume.heart_notes) },
    { ar: "أساس", en: "Base", notes: splitCsv(perfume.base_notes) },
    { ar: "مبتكرة", en: "Innovation", notes: splitCsv(perfume.innovation_notes) },
  ].filter((p) => p.notes.length);
  const occRaw = splitCsv(perfume.occasions);
  const occ = occRaw.map((o) => { const i = occasionInfo(o); return i ? { ar: i.ar, en: i.en, emoji: i.emoji } : { ar: o, en: o, emoji: "" }; });
  // تذكرني: أسماء إنجليزية فقط، حدّ 4.
  const related = splitCsv(perfume.related_perfume_names).slice(0, 4);
  const aboutEn = String(perfume.about_en || "").trim();
  const aboutAr = String(perfume.about_ar || "").trim();
  const about = (showEn && aboutEn) || (showAr && aboutAr) || "";

  const perfumerArByName = {};
  const perfumerPhotoByName = {};
  perfumerRecords.forEach((p) => { if (p.name) { perfumerArByName[p.name.toLowerCase()] = p.name_ar; perfumerPhotoByName[p.name.toLowerCase()] = p.photo_url || ""; } });
  const perfumerNames = splitCsv(perfume.perfumer_names).slice(0, 6);


  const secHead = (ar, en) => (
    <div style={{ fontSize: 9.5 }}>{arSpan(ar)} {showEn && <span style={{ fontFamily: "Cinzel, serif", fontSize: 7.5, letterSpacing: ".1em", color: "#9a8f7c", textTransform: "uppercase" }}>{en}</span>}</div>
  );

  const SINUS_EMOJI = { yes: "😤", a_little: "😕", no: "😊", dont_know: "😏" };
  const SINUS_AR = { yes: "نعم", a_little: "قليلاً", no: "لا", dont_know: "لا أعلم" };
  const SINUS_EN = { yes: "Yes", a_little: "A Little", no: "No", dont_know: "Don't know" };
  const ALLERGY_EMOJI = { yes: "🤧", a_little: "😕", no: "😊", dont_know: "😏" };
  const ALLERGY_AR = { yes: "نعم", a_little: "قليلاً", no: "لا", dont_know: "لا أعلم" };
  const ALLERGY_EN = { yes: "Yes", a_little: "A Little", no: "No", dont_know: "Don't know" };
  const HEAD_EMOJI = { weak: "🟨", medium: "🟧", strong: "🟥" };
  const HEAD_AR = { weak: "ضعيف", medium: "متوسط", strong: "قوي" };
  const HEAD_EN = { weak: "Weak", medium: "Medium", strong: "Strong" };
  const IMPR_MAP = { great: { e: "😍", ar: "رائع", en: "Great" }, neutral: { e: "😐", ar: "حيادي", en: "Neutral" }, not_great: { e: "😕", ar: "ليس رائعاً", en: "Not Great" } };
  const REC_MAP = { no: { e: "🚫", ar: "لا", en: "No" }, women: { e: "🌸", ar: "نساء", en: "Women" }, men: { e: "🔷", ar: "رجال", en: "Men" }, any: { e: "✌🏻", ar: "للجميع", en: "Anyone" } };
  const DETAIL = [ { f: "r_scent", ar: "رائحة", en: "Scent" }, { f: "r_longevity", ar: "ثبات", en: "Longevity" }, { f: "r_sillage", ar: "فوحان", en: "Sillage" }, { f: "r_bottle", ar: "زجاجة", en: "Bottle" } ];
  const BREACT_MAP = { love_it: { e: "🥰", ar: "أحبّه", en: "Love it" }, like_it: { e: "😍", ar: "يعجبني", en: "Like it" }, neutral: { e: "😐", ar: "حيادي", en: "Neutral" }, hate_it: { e: "😠", ar: "أكرهه", en: "Hate it" } };

  const hasSide = (fields.family && dom) || (fields.occasions && occ.length) || (fields.perfumer && perfumerNames.length) || (fields.narrative && about) || (fields.similar && similar.length);
  const hasPyr = fields.pyramid && phases.length > 0;
  const hasUserRow = (fields.rating && perfume.rating != null) || (person !== "none" && fields.purchases && purchases[0]?.ml);

  // المحاذاة المحلولة لكل كتلة + اتجاه flex المقابل.
  const a1 = resolveA(b1Align), j1 = jOf(a1); // الترويسة + الصحة + المواسم
  const a2 = resolveA(b2Align), j2 = jOf(a2); // القنينة + الكثافة + الفئة
  const a3 = resolveA(b3Align), j3 = jOf(a3); // المصممون + العائلة + الوصف + المناسبات
  const a4 = resolveA(b4Align), j4 = jOf(a4); // الهرم (كتلة كاملة)
  const a5 = resolveA(b5Align), j5 = jOf(a5); // تقييمات المستخدم

  const renderCard = (withRefs) => (
    <div ref={withRefs ? cardRef : null} style={stageStyle}>
      <div style={cardBoxStyle("14px 15px")}>
      <div ref={withRefs ? fitRef : null} style={{ width: innerWidth, transformOrigin: "top center", transform: `scale(${effScale})`, display: "flex", flexDirection: "column", lineHeight: 1.4 }}>
        {/* ===== TOP ===== */}
        <div style={{ display: "flex", flexDirection: "row", gap: 12, alignItems: "flex-start" }}>
          <div style={{ flex: 1, order: a2 === "left" ? 2 : 1, display: "flex", flexDirection: "column", gap: 7, textAlign: a1, alignItems: j1, minWidth: 0 }}>
            {fields.name && (
              <div style={{ display: "flex", flexDirection: "column", gap: 2, width: "100%", alignSelf: "stretch" }}>
                {/* الصف الأعلى: البراند (طرف) + المجموعة (الطرف المقابل) — فوق الاسم الإنجليزي */}
                {(() => {
                  const bLeft = (fields.brand || fields.year) && (perfume.brand_name || dec || perfume.discontinued);
                  const bRight = fields.collection && collDisplay;
                  if (!bLeft && !bRight) return null;
                  return (
                  <div style={{ fontSize: 8.5, color: soft, lineHeight: 1.25 }}>
                    {bLeft && dec && <div style={{ marginBottom: 1, lineHeight: 1 }} title={showAr ? "أفضل عطر في العقد" : "Best of decade"}><Crown size={13} color={C1} /></div>}
                    <div style={{ display: "flex", alignItems: "baseline", justifyContent: (bLeft && bRight) ? "space-between" : j1, gap: 10 }}>
                      {bLeft && (
                      <span style={{ minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {fields.brand && (perfume.brand_name || perfume.brand_name_ar) && (
                          <span style={{ fontFamily: showEn ? "Cinzel, serif" : "Amiri, serif", color: showEn ? C1d : C2, letterSpacing: showEn ? ".05em" : 0 }}>
                            {showEn ? String(perfume.brand_name || "").toUpperCase() : (perfume.brand_name_ar || perfume.brand_name)}
                          </span>
                        )}
                        {dec && <span style={{ color: GREEN, fontWeight: 700, marginInlineStart: 8 }}>{showAr ? "أفضل العقد " : "Best of decade "}{dec}</span>}
                        {perfume.discontinued && <span style={{ color: "#a32d2d", fontWeight: 600, marginInlineStart: 8 }}>{showAr ? "منقطع" : "Discontinued"}</span>}
                      </span>
                      )}
                      {bRight && (
                        <span style={{ flexShrink: 0, maxWidth: bLeft ? "55%" : "100%", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", fontFamily: (showAr && collArName) ? "Amiri, serif" : "Cinzel, serif", color: C1, letterSpacing: (showAr && collArName) ? 0 : ".05em" }} title={collDisplay}>
                          {(showAr && collArName) ? collDisplay : (showEn ? collDisplay.toUpperCase() : collDisplay)}
                        </span>
                      )}
                    </div>
                  </div>
                  );
                })()}
                {/* سطر الاسم: الإنجليزي + العربي بجانبه بخطٍّ مُصغَّر */}
                <div style={{ display: "flex", alignItems: "baseline", flexWrap: "wrap", gap: 6, justifyContent: j1 }}>
                  {showEn && (perfume.name_en || perfume.name) && <span style={{ fontFamily: "Cinzel, serif", color: C1, fontSize: 16, fontWeight: 700, letterSpacing: ".05em", textTransform: "uppercase", lineHeight: 1.05 }}>{perfume.name_en || perfume.name}</span>}
                  {showAr && perfume.name_ar && <span style={{ color: C2, fontFamily: "Amiri, serif", fontSize: 11, fontWeight: 700, lineHeight: 1.05 }}>{perfume.name_ar}</span>}
                </div>
              </div>
            )}
            {fields.info && perfume.cd && (() => {
              // رأي الجمهور المستورد — نسخة مطابقة لرسوم صفحة العطر (PerfumeCardBox)
              const cd = perfume.cd;
              const rows = [];
              if (cd.lon && LONGEVITY[cd.lon]) rows.push({ ar: "ثبات", en: "LONGEVITY", v: LONGEVITY[cd.lon] });
              if (cd.sil && SILLAGE[cd.sil]) rows.push({ ar: "فوحان", en: "SILLAGE", v: SILLAGE[cd.sil] });
              if (cd.val && VALUE[cd.val]) rows.push({ ar: "قيمة سعرية", en: "VALUE", v: VALUE[cd.val] });
              const g = Array.isArray(cd.g) && cd.g.length === 3 ? cd.g : null;
              const td = Array.isArray(cd.td) && cd.td.length === 2 ? cd.td : null;
              if (!rows.length && !g && !td) return null;
              const CBar = ({ label, icon, val, color }) => (
                <span style={{ textAlign: "center", flex: "0 0 auto", display: "inline-flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
                  <span style={{ height: 13, width: 13, background: "#f1ede3", display: "flex", alignItems: "flex-end", overflow: "hidden" }}>
                    <span style={{ display: "block", width: "100%", height: `${Math.max(0, Math.min(100, val))}%`, background: color }} />
                  </span>
                  {icon ? (
                    <span style={{ display: "inline-flex", flexDirection: "column", alignItems: "center", gap: 1 }}>
                      <span style={{ fontSize: 12, lineHeight: 1 }}>{icon}</span>
                      <span style={{ fontSize: 5, color: "#8a8276", textTransform: "uppercase", whiteSpace: "nowrap", letterSpacing: ".04em" }}>{label}</span>
                    </span>
                  ) : label ? <span style={{ fontSize: 6, color: "#8a8276", textTransform: "uppercase", whiteSpace: "nowrap" }}>{label}</span> : null}
                </span>
              );
              const crowdJustify = j1;
              return (
                <div style={{ textAlign: a1, fontSize: 8.5 }}>
                  <div style={{ display: "flex", justifyContent: crowdJustify, alignItems: "center", gap: 12 }}>
                    <div>
                      {rows.map((r, i) => (
                        <div key={i} style={{ padding: "1px 0", color: ink }}>
                          {showAr && <span style={{ fontFamily: "Amiri, serif" }}>{r.ar} </span>}
                          {showEn && <span style={{ fontSize: 7, color: "#9a8f7c", letterSpacing: ".04em" }}>{r.en}</span>}
                          <span style={{ fontWeight: 700, color: r.v.color, marginInlineStart: 5 }}>
                            {showAr && <span style={{ fontFamily: "Amiri, serif" }}>{r.v.ar} </span>}
                            {showEn && <span style={{ fontSize: 7, fontWeight: 400 }}>{String(r.v.en).toUpperCase()}</span>}
                          </span>
                        </div>
                      ))}
                    </div>
                    {td && (
                      <div style={{ display: "flex", gap: 6, alignItems: "flex-end" }}>
                        {td.map((v, i) => <CBar key={`t${i}`} label={climateMode === "none" ? "" : `${showAr ? TIME_TEXT[i].ar : ""}${showAr && showEn ? " " : ""}${showEn ? TIME_TEXT[i].en : ""}`} val={v} color={TIMES[i].color} />)}
                      </div>
                    )}
                  </div>
                  {g && (
                    <>
                      <div style={{ display: "flex", justifyContent: crowdJustify, margin: "4px 0 2px" }}>
                        <div style={{ display: "flex", height: 5, width: "100%", maxWidth: 120, overflow: "hidden" }}>
                          {g.map((w, i) => <span key={i} style={{ width: `${w}%`, background: GENDER_COLORS[i] }} />)}
                        </div>
                      </div>
                      <div style={{ display: "flex", gap: 8, justifyContent: crowdJustify, flexWrap: "wrap", fontSize: 6.5, marginBottom: 4, lineHeight: 1.2 }}>
                        {GENDER_LABELS.map((gl, i) => (
                          <span key={i} style={{ whiteSpace: "nowrap", color: GENDER_COLORS[i], fontWeight: 600 }}>■ {showAr && gl.ar}{showEn && <span style={{ marginInlineStart: showAr ? 2 : 0 }}>{gl.en}</span>}</span>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              );
            })()}
            {(() => {
              const hasSeasonBars = Array.isArray(perfume.cd?.se) && perfume.cd.se.length === 4;
              const showHLabels = fields.health || fields.strict;
              if (!showHLabels && !hasSeasonBars) return null;
              return (
            <div style={{ display: "flex", alignItems: "flex-start", justifyContent: j1, gap: 12 }}>
            {showHLabels && (
            <div style={{ flex: "0 1 auto", minWidth: 0 }}>
            {(() => {
              const hLabels = perfumeLabels(perfume);
              const famCount = health.groups.length;
              const heavy = /parfum|extrait|مركّز/i.test(`${perfume.concentration || ""} ${perfume.type || ""}`);
              const score = famCount + (heavy ? 1 : 0);
              let level;
              if (famCount === 0) level = { ar: "مناسب للحسّاسين", en: "Sensitive-friendly", bg: "#EAF3DE", fg: "#3B6D11", dot: "#639922" };
              else if (score <= 2) level = { ar: "منخفض", en: "Low", bg: "#EAF3DE", fg: "#3B6D11", dot: "#639922" };
              else if (score <= 4) level = { ar: "متوسط", en: "Medium", bg: "#FAEEDA", fg: "#854F0B", dot: "#BA7517" };
              else level = { ar: "مرتفع", en: "High", bg: "#FCEBEB", fg: "#791F1F", dot: "#E24B4A" };
              const countFor = (m) => (hLabels.find((l) => l.mech === m)?.groups.length) || 0;
              return (
                <div style={{ fontSize: 8, color: muted }}>
                  {fields.health && (<>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: j1, gap: 6 }}>
                    <span style={{ fontFamily: "Cinzel, serif", fontSize: 7, letterSpacing: ".08em", color: "#9a8f7c", textTransform: "uppercase" }}>{arSpan("مؤشر الصحة")} {showEn && "Health"}</span>
                    <span style={{ color: level.fg, fontWeight: 700 }}>
                      {showAr && level.ar}{showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{level.en}</span>}
                    </span>
                  </div>
                  {famCount > 0 ? (
                    <>
                    <div style={{ marginTop: 2, display: "flex", flexDirection: "column", gap: 2 }}>
                      {["neuro", "sinus", "allergy"].map((m) => (
                        <div key={m} style={{ display: "flex", alignItems: "center", justifyContent: j1, gap: 6 }}>
                          <span style={{ display: "inline-flex", alignItems: "center", gap: 3, width: 92, flexShrink: 0, whiteSpace: "nowrap", overflow: "hidden" }}>{MECH[m].emoji} {showAr && arSpan(MECH[m].ar)}{showEn && <span style={{ marginInlineStart: showAr ? 3 : 0, color: "#9a8f7c" }}>{MECH[m].en}</span>}</span>
                          <Squares filled={Math.min(countFor(m), 4)} />
                        </div>
                      ))}
                    </div>
                    {(() => {
                      const ag = hLabels.find((l) => l.mech === "allergy")?.groups || [];
                      if (!ag.length) return null;
                      return (
                        <div style={{ marginTop: 3, fontSize: 8, lineHeight: 1.5 }}>
                          <span style={{ color: "#9a8f7c" }}>{showAr && arSpan("محسِّسات معروفة")}{showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>Known sensitisers</span>}: </span>
                          {ag.map((g) => [showAr ? g.ar : "", showEn ? g.en : ""].filter(Boolean).join(" ")).join(" - ")}
                        </div>
                      );
                    })()}
                    </>
                  ) : (
                    <div style={{ marginTop: 3, fontSize: 8, color: soft }}>{showAr && "لا وسوم خطر بارزة من نوتاته"}{showEn && <span style={{ marginInlineStart: showAr ? 4 : 0 }}>No prominent risk labels</span>}</div>
                  )}
                  </>)}
                  {fields.strict && (() => { const st = strictHealth(perfume); return (
                    <div style={{ marginTop: fields.health ? 4 : 0, display: "flex", alignItems: "center", justifyContent: j1, gap: 6 }}>
                      <span style={{ fontFamily: "Cinzel, serif", fontSize: 7, letterSpacing: ".08em", color: "#9a8f7c", textTransform: "uppercase" }}>{arSpan("متشدد")} {showEn && "Strict"}</span>
                      <span style={{ color: st.risky ? "#C0392B" : "#3B6D11", fontWeight: 700 }}>{showAr && (st.risky ? "مُثير" : "آمن")}{showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{st.risky ? "Flagged" : "Clear"}</span>}</span>
                    </div>
                  ); })()}
                </div>
              );
            })()}
            </div>
            )}
            {hasSeasonBars && (
              <div style={{ display: "flex", flexWrap: "nowrap", alignItems: "flex-end", gap: 6, flexShrink: 0, marginTop: showHLabels ? 12 : 0 }}>
                {perfume.cd.se.map((v, i) => (
                  <span key={`s${i}`} style={{ textAlign: "center", flex: "0 0 auto", display: "inline-flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
                    <span style={{ height: 13, width: 13, background: "#f1ede3", display: "flex", alignItems: "flex-end", overflow: "hidden" }}>
                      <span style={{ display: "block", width: "100%", height: `${Math.max(0, Math.min(100, v))}%`, background: SEASONS[i].color }} />
                    </span>
                    {climateMode === "icon" ? <span style={{ fontSize: 12, lineHeight: 1 }}>{SEASON_ICONS[i]}</span> : climateMode === "text" ? <span style={{ fontSize: 6, color: "#8a8276", textTransform: "uppercase", whiteSpace: "nowrap" }}>{showAr && !showEn ? SEASONS[i].ar : SEASONS[i].en}</span> : null}
                  </span>
                ))}
              </div>
            )}
            </div>
              );
            })()}
          </div>
          {fields.image && (
            <div style={{ flexShrink: 0, order: a2 === "left" ? 1 : 2, alignSelf: "flex-start", display: "flex", flexDirection: "column", alignItems: j2 }}>
              {perfume.image_url ? (
                <img src={perfume.image_url} alt="" crossOrigin="anonymous" style={{ width: 150, height: 184, objectFit: "contain" }} />
              ) : (
                <div style={{ width: 150, display: "flex", justifyContent: "center", alignItems: "center" }}>
                  <div style={{ width: 150, height: 150 }}><AccordFlaconCard perfume={perfume} bestOfDecade={!!perfume.best_of_decade} /></div>
                </div>
              )}
              {(fields.info || fields.year) && (perfume.category || perfume.type || perfume.concentration || perfume.release_year) && (
                <div style={{ marginTop: 4, textAlign: a2, fontSize: 6, lineHeight: 1.55, color: soft, maxWidth: 150 }}>
                  {/* النوع + الكثافة + التصنيف (نيش) + السنة — قطعة واحدة متّصلة فوق مؤشر الكثافة */}
                  {(() => {
                    const seg = [];
                    if (fields.info && perfume.type) seg.push(<span key="t" style={{ display: "inline-flex", alignItems: "center", gap: 4, verticalAlign: "middle" }}>{typeDisplay(perfume.type, lang === "ar" ? "ar" : lang === "en" ? "en" : "both")}</span>);
                    if (fields.info && perfume.concentration) seg.push(<span key="c">{perfume.concentration}</span>);
                    if (fields.info && perfume.category) seg.push(<span key="g">{perfume.category}</span>);
                    if (fields.year && perfume.release_year) seg.push(<span key="y">{perfume.release_year}</span>);
                    if (!seg.length) return null;
                    return <span>{seg.map((x, i) => <span key={i}>{i ? " — " : ""}{x}</span>)}</span>;
                  })()}
                  {fields.info && strengthOf(perfume.type || perfume.concentration) && <div style={{ width: "100%", display: "flex", justifyContent: j2, marginTop: 2 }}><StrengthTrack strength={strengthOf(perfume.type || perfume.concentration)} width={140} height={4} /></div>}
                </div>
              )}
            </div>
          )}
        </div>

        {/* ===== REMIND ME OF — own row after health (pink bottle, EN names, max 4, " - ") ===== */}
        {fields.similar && related.length > 0 && (
          <div style={{ marginTop: 10, paddingTop: 8, borderTop: sepLine(isDark ? "#4a4334" : "#eee"), display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
            <PinkBottle />
            <div style={{ color: C2, fontFamily: "Cinzel, serif", fontSize: 9, letterSpacing: ".04em", textAlign: "center" }}>{related.join(" - ")}</div>
          </div>
        )}

        {/* ===== MAIN (family/occasions/perfumer/narrative + pyramid) ===== */}
        {(hasSide || hasPyr) && (
          <div style={{ display: "flex", gap: 12, marginTop: 12, paddingTop: 9, borderTop: sepLine(isDark ? "#4a4334" : "#eee"), alignItems: "flex-start" }}>
            {hasSide && (
              <div style={{ flex: 200, display: "flex", flexDirection: "column", gap: 6, textAlign: a3, alignItems: j3, minWidth: 0 }}>
                {fields.perfumer && perfumerNames.length > 0 && (
                  <div style={{ width: "100%" }}>
                    {secHead(perfumerNames.length > 1 ? "مصممي عطور" : "مصمم عطور", perfumerNames.length > 1 ? "Perfume Designers" : "Perfume Designer")}
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8, justifyContent: j3, marginTop: 2 }}>
                      {perfumerNames.map((nm, i) => {
                        const photo = perfumerPhotoByName[nm.toLowerCase()] || "";
                        const pBorder = hilalBorder(nm, perfumerArByName[nm.toLowerCase()], !noteFrame ? "none" : `1px solid ${GOLD}`);
                        const photoEl = (
                          <span style={{ width: 28, height: 28, border: pBorder, background: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", overflow: "hidden", flexShrink: 0 }}>
                            {photo ? <img src={photo} alt="" crossOrigin="anonymous" onError={(e) => { e.currentTarget.style.display = "none"; }} style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : null}
                          </span>
                        );
                        const nameEl = (
                          <span style={{ fontSize: 7, lineHeight: 1.2, color: muted, display: "inline-flex", alignItems: "baseline", gap: 3, whiteSpace: "nowrap" }}>
                            {showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{perfumerArByName[nm.toLowerCase()] || nm}</span>}
                            {showEn && <span>{nm}</span>}
                          </span>
                        );
                        const horiz = perfumerPos === "left" || perfumerPos === "right";
                        const photoFirst = perfumerPos === "right" || perfumerPos === "below";
                        return (
                          <div key={i} style={{ display: "flex", flexDirection: horiz ? "row" : "column", alignItems: "center", gap: 4, maxWidth: horiz ? 132 : 64 }}>
                            {photoFirst ? <>{photoEl}{nameEl}</> : <>{nameEl}{photoEl}</>}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {fields.family && dom && (
                  <div style={{ width: "100%", maxWidth: 148 }}>
                    {secHead("عائلة عطرية", "Odor Family")}
                    {/* أسماء الأكوردات بألوانها — صف موحّد بلا صندوق */}
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "1px 8px", marginTop: 2 }}>
                      {accords.map((a, i) => (
                        <span key={a.id} style={{ fontSize: i === 0 ? 9.5 : 8, fontWeight: i === 0 ? 700 : 600, lineHeight: 1.3, color: darken(a.bar), whiteSpace: "nowrap" }}>
                          {showEn && <span style={{ fontFamily: "Cinzel, serif" }}>{String(a.en).toUpperCase()}</span>}
                          {showAr && <span style={{ fontFamily: "Amiri, serif", marginInlineStart: showEn ? (i === 0 ? 4 : 2) : 0 }}>{a.ar}</span>}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {fields.narrative && (about || aboutAr) && (
                  <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 2 }}>
                    {showEn && aboutEn && (
                      <div dir="ltr" style={{ fontFamily: "'Playfair Display', serif", fontSize: 8, color: isDark ? "#d9cfb6" : "#5a554c", lineHeight: 1.45, textAlign: a3, width: "100%" }}>{aboutEn}</div>
                    )}
                    {showAr && aboutAr && (
                      <div dir="rtl" style={{ fontFamily: "Amiri, serif", fontSize: 8.7, color: isDark ? "#d9cfb6" : "#5a554c", lineHeight: 1.6, textAlign: a3, width: "100%" }}>{aboutAr}</div>
                    )}
                  </div>
                )}

                {fields.occasions && occ.length > 0 && (
                  <div>
                    {secHead("المناسبات", "Best For")}
                    <div style={{ display: "flex", flexWrap: "wrap", gap: "1px 9px", justifyContent: j3, alignItems: "baseline", fontSize: 8, color: muted, marginTop: 1 }}>
                      {occ.map((o, i) => <span key={i} style={{ display: "inline-flex", alignItems: "baseline", gap: 2 }}>{occMode !== "text" && o.emoji && <span>{o.emoji}</span>}{occMode !== "emoji" && showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{o.ar}</span>}{occMode !== "emoji" && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{o.en}</span>}</span>)}
                    </div>
                  </div>
                )}
                {fields.similar && similar.length > 0 && (
                  <div>
                    {secHead("متقارب", "Similar")}
                    {/* صفّ واحد متدفّق، يفصل بين العطور « - »؛ اسم البراند بعد العطر بلون البراند (C1d) — بلا نسبة */}
                    <div style={{ fontSize: 8, color: muted, marginTop: 1, lineHeight: 1.55 }}>
                      {similar.map((it, i) => (
                        <span key={i} style={{ whiteSpace: "nowrap" }}>
                          {i > 0 && <span style={{ color: muted, margin: "0 4px" }}>-</span>}
                          {showEn && <span>{it.p.name_en || it.p.name}</span>}
                          {showAr && it.p.name_ar && <span style={{ fontFamily: "Amiri, serif", marginInlineStart: showEn ? 3 : 0 }}>{it.p.name_ar}</span>}
                          {(it.p.brand_name || it.p.brand_name_ar) && (
                            <span style={{ color: C1d, fontWeight: 700, marginInlineStart: 3, fontFamily: showEn ? "Cinzel, serif" : "Amiri, serif" }}>
                              {showEn ? String(it.p.brand_name || it.p.brand_name_ar || "").toUpperCase() : (it.p.brand_name_ar || it.p.brand_name)}
                            </span>
                          )}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {hasPyr && (
              <div style={{ flex: 230, minWidth: 0, display: "flex", flexDirection: "column", alignItems: j4 }}>
                <div style={{ width: "fit-content", maxWidth: "100%" }}>
                {phaseHeads && <div style={{ textAlign: noteAlign === "right" ? "right" : noteAlign === "left" ? "left" : "center", fontSize: 9.5 }}>{arSpan("هرم")} {showEn && <span style={{ fontFamily: "Cinzel, serif", fontSize: 7.5, letterSpacing: ".1em", color: "#9a8f7c", textTransform: "uppercase" }}>Pyramid</span>}</div>}
                {phases.map((ph) => (
                  <div key={ph.en} style={{ margin: "6px 0" }}>
                    {phaseHeads && <div style={{ fontFamily: "Cinzel, serif", fontSize: 7.5, letterSpacing: ".08em", color: C1, fontWeight: 600, textAlign: noteAlign === "right" ? "right" : noteAlign === "left" ? "left" : "center" }}>
                      {showAr && <span style={{ fontFamily: "Amiri, serif", color: C2, fontSize: 10, marginInlineEnd: 4 }}>{ph.ar}</span>}{showEn && ph.en}
                    </div>}
                    {notesMode !== "text" ? (groupedNotes ? (() => {
                      const list = ph.notes.slice(0, 24);
                      const justify = noteAlign === "left" ? "flex-start" : noteAlign === "right" ? "flex-end" : "center";
                      const grid = (
                        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 21px)", gap: 2, padding: noteFrame ? 3 : 0, border: noteFrame ? `1px solid ${GOLD}` : "none", width: "fit-content" }}>
                          {list.map((n, i) => { const rec = findNote(n); const nBanned = rec?.is_allowed === false; const nHealth = isHealthNote(n); const bl = nBanned ? "3px solid #dc2626" : (noteHealthInd && nHealth ? "3px solid #6b3f1d" : undefined); return rec?.image_url
                            ? <img key={i} src={rec.image_url} alt="" crossOrigin="anonymous" style={{ width: 21, height: 18, objectFit: "cover", background: "#fff", borderLeft: bl }} />
                            : <span key={i} style={{ width: 21, height: 18, background: "#fff", display: "block", borderLeft: bl }} />; })}
                        </div>
                      );
                      const names = notesMode !== "icons" ? (
                        <div style={{ fontSize: (showEn && showAr) ? 6.5 : 7.5, color: "#5f5a50", textAlign: noteAlign, lineHeight: 1.35, maxWidth: 120 }}>
                          {ph.notes.map((n) => { const rec = findNote(n); const en = enOf(n) || rec?.name_en || rec?.name; const ar = arNote(rec?.name_ar || n); return [showEn ? en : "", showAr ? (ar || "") : ""].filter(Boolean).join(" "); }).filter(Boolean).join(" - ")}
                        </div>
                      ) : null;
                      const col = notePos === "above" || notePos === "below";
                      return (
                        <div style={{ display: "flex", flexDirection: col ? "column" : "row", alignItems: col ? justify : "center", justifyContent: justify, gap: 5, marginTop: 3 }}>
                          {(notePos === "above" || notePos === "left") && names}
                          {grid}
                          {(notePos === "below" || notePos === "right") && names}
                        </div>
                      );
                    })() : (
                      <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center", gap: 7, marginTop: 3 }}>
                        {ph.notes.slice(0, 6).map((n, i) => {
                          const rec = findNote(n);
                          const nBanned = rec?.is_allowed === false;
                          const nHealth = isHealthNote(n);
                          const nBorder = !noteFrame ? "none" : nBanned ? "1px solid rgba(220,38,38,0.7)" : `1px solid ${GOLD}`;
                          // اسم النوتة (كتلة واحدة) — اللون والشطب دائمان بمعزل عن خيار المؤشرات.
                          const nameBlock = notesMode === "both" ? (
                            <span style={{ fontSize: (showEn && showAr) ? 6 : 7, color: nBanned ? "#dc2626" : (nHealth ? "#6b3f1d" : "#5f5a50"), textAlign: noteAlign, lineHeight: 1.05, textDecoration: nBanned ? "line-through" : "none", textDecorationColor: "#dc2626", maxWidth: (showEn && showAr) ? 58 : 52 }}>
                              {showEn && (enOf(n) || rec?.name_en || rec?.name) && <span style={{ color: nHealth && !nBanned ? "#6b3f1d" : undefined }}>{enOf(n) || rec?.name_en || rec?.name || n}</span>}{showEn && showAr && (enOf(n) || rec?.name_en) && arOf(rec?.name_ar || n) && <span> </span>}{showAr && arOf(rec?.name_ar || n) && <span style={{ fontFamily: "Amiri, serif", color: nBanned ? "#dc2626" : (nHealth ? "#6b3f1d" : PINK), fontSize: (showEn && showAr) ? 6.5 : 8 }}>{arNote(rec?.name_ar || n)}</span>}
                            </span>
                          ) : null;
                          // صورة النوتة + المؤشّر العمودي: بنّي للصحية، أحمر للمقيدة —
                          // يُرسمان فقط حين خيار «مؤشرات النوتة الصحية» مفعّل.
                          const imgBlock = (
                            <span style={{ display: "inline-flex", alignItems: "stretch", gap: 2 }}>
                              {nBanned && <span style={{ width: 2, alignSelf: "stretch", background: "#dc2626", display: "block" }} />}
                              {noteHealthInd && nHealth && !nBanned && <span style={{ width: 2, alignSelf: "stretch", background: "#6b3f1d", display: "block" }} />}
                              {rec?.image_url ? (
                                <img src={rec.image_url} alt="" crossOrigin="anonymous" style={{ width: 28, height: 28, objectFit: "cover", border: nBorder, background: "#fff" }} />
                              ) : (
                                <span style={{ width: 28, height: 28, border: nBorder, background: "#fff", display: "block" }} />
                              )}
                            </span>
                          );
                          return (
                            <span key={i} style={{ display: "inline-flex", flexDirection: (notePos === "below" || notePos === "above") ? "column" : "row", alignItems: "center", gap: (notePos === "below" || notePos === "above") ? 2 : 3, width: (notePos === "below" || notePos === "above") ? (notesMode === "icons" ? 34 : 44) : "auto", maxWidth: 88 }}>
                              {(notePos === "left" || notePos === "above") && nameBlock}
                              {imgBlock}
                              {(notePos === "right" || notePos === "below") && nameBlock}
                            </span>
                          );
                        })}
                        {ph.notes.length > 6 && (
                          <div style={{ width: "100%", textAlign: noteAlign, fontSize: 7, color: isDark ? "#d9cfb6" : "#5f5a50", marginTop: 1 }}>
                            {ph.notes.slice(6).map((n) => { const rec = findNote(n); const en = enOf(n); const ar = arNote(rec?.name_ar || n); return [showEn ? en : "", showAr ? ar : ""].filter(Boolean).join(" ") || n; }).join("، ")}
                          </div>
                        )}
                      </div>
                    )) : (
                      <div style={{ textAlign: "center", fontSize: 9, color: isDark ? "#d9cfb6" : "#403c36", marginTop: 2 }}>
                        {ph.notes.map((n) => { const rec = findNote(n); const en = enOf(n); const ar = arNote(rec?.name_ar || n); return [showEn ? en : "", showAr ? ar : ""].filter(Boolean).join(" ") || n; }).join(" - ")}
                      </div>
                    )}
                  </div>
                ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ===== USER ROW ===== */}
        {hasUserRow && (
          <div style={{ marginTop: 8, paddingTop: 6, borderTop: sepLine(isDark ? "#4a4334" : "rgba(0,0,0,.07)"), display: "flex", justifyContent: j5, alignItems: "flex-start", gap: 6, flexWrap: "wrap" }}>
            {fields.rating && perfume.rating != null && (
              <div style={{ textAlign: a5, fontSize: 7.5 }}>
                <div style={{ fontFamily: "Cinzel, serif", fontSize: 7, letterSpacing: ".08em", color: "#9a8f7c", textTransform: "uppercase" }}>{arSpan("مشترك")} {showEn && "Shared"}</div>
                <Diamonds filled={perfume.rating || 0} />
              </div>
            )}
          </div>
        )}

        {(() => {
          const custPersons = person === "none" ? []
            : person === "person1" ? [["person1", up1]]
            : person === "person2" ? [["person2", up2]]
            : [["person1", up1], ["person2", up2]];
          const rows = custPersons.filter(([, u]) => u && (
            (fields.userRating && (u.rating != null || u.r_scent || u.r_longevity || u.r_sillage || u.r_bottle)) || (fields.reaction && (u.list || u.other_rating)) ||
            (fields.impression && u.impression) || (fields.recommend && u.recommend_to) ||
            (fields.comment && (u.review || u.notes || u.personal_notes)) || (fields.thought && (u.note_top || u.note_heart || u.note_base)) || (fields.occasions && u.occasions) ||
            (fields.myhealth && (u.headache || u.sinus_sensitivity || u.allergy_sensitivity)) ||
            (fields.axes && RATING_AXES.some((ax) => u[ax.key] != null && u[ax.key] > 0))
          ));
          if (!rows.length) return null;
          return rows.map(([pk, u]) => {
            const showI = userOccMode !== "text";
            const showT = userOccMode !== "emoji";
            const uocc = (fields.occasions && u.occasions) ? splitCsv(u.occasions).map((o) => { const i = occasionInfo(o); return i ? { ar: i.ar, en: i.en, emoji: i.emoji } : { ar: o, en: o, emoji: "" }; }) : [];
            const phases = [["note_top", "مقدمة", "Top"], ["note_heart", "قلب", "Heart"], ["note_base", "أساس", "Base"]];
            const reviewText = u.review || u.notes || u.personal_notes || "";
            return (
              <div key={pk}>
                <div style={{ marginTop: 5, display: "flex", flexWrap: "wrap", justifyContent: j5, alignItems: "baseline", gap: "2px 6px", fontSize: 7, color: muted, textAlign: a5 }}>
                {person === "all" && <span style={{ fontFamily: "Cinzel, serif", fontSize: 7, letterSpacing: ".06em", color: "#9a8f7c", textTransform: "uppercase" }}>{names[pk]}</span>}
                {fields.impression && u.impression && IMPR_MAP[u.impression] && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{showI && <span>{IMPR_MAP[u.impression].e}</span>}{showT && showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{IMPR_MAP[u.impression].ar}</span>}{showT && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{IMPR_MAP[u.impression].en}</span>}</span>}
                {fields.reaction && u.list && REACTION_MAP[u.list] && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{showI && <span>{REACTION_MAP[u.list].emoji}</span>}{showT && <span>{isAr ? REACTION_MAP[u.list].ar : REACTION_MAP[u.list].en}</span>}</span>}
                {fields.reaction && u.other_rating && BREACT_MAP[u.other_rating] && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{showI && <span>{BREACT_MAP[u.other_rating].e}</span>}{showT && showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{BREACT_MAP[u.other_rating].ar}</span>}{showT && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{BREACT_MAP[u.other_rating].en}</span>}</span>}
                {fields.userRating && u.rating != null && <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>{arSpan("تقييمي")} <Diamonds filled={u.rating || 0} /></span>}
                {fields.userRating && DETAIL.map((d) => (u[d.f] ? <span key={d.f} style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>{arSpan(d.ar)}{showEn && <span style={{ marginInlineEnd: 2 }}>{d.en}</span>} <Diamonds filled={u[d.f] || 0} /></span> : null))}
                {fields.axes && RATING_AXES.map((ax) => (u[ax.key] != null && u[ax.key] > 0 ? <span key={ax.key} style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>{showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{ax.ar}</span>}{showEn && <span style={{ marginInlineStart: showAr ? 2 : 0 }}>{ax.en}</span>} <Diamonds filled={u[ax.key] || 0} /></span> : null))}
                {fields.myhealth && u.headache && HEAD_EMOJI[u.headache] && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{arSpan("صداع")} {showI && <span>{HEAD_EMOJI[u.headache]}</span>}{showT && showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{HEAD_AR[u.headache]}</span>}{showT && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{HEAD_EN[u.headache]}</span>}</span>}
                {fields.myhealth && u.sinus_sensitivity && SINUS_EMOJI[u.sinus_sensitivity] && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{arSpan("جيوب")} {showI && <span>{SINUS_EMOJI[u.sinus_sensitivity]}</span>}{showT && showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{SINUS_AR[u.sinus_sensitivity]}</span>}{showT && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{SINUS_EN[u.sinus_sensitivity]}</span>}</span>}
                {fields.myhealth && u.allergy_sensitivity && ALLERGY_EMOJI[u.allergy_sensitivity] && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{arSpan("تحسس")} {showI && <span>{ALLERGY_EMOJI[u.allergy_sensitivity]}</span>}{showT && showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{ALLERGY_AR[u.allergy_sensitivity]}</span>}{showT && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{ALLERGY_EN[u.allergy_sensitivity]}</span>}</span>}
                {uocc.map((o, i) => <span key={i} style={{ display: "inline-flex", alignItems: "baseline", gap: 2 }}>{showI && o.emoji && <span>{o.emoji}</span>}{showT && showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{o.ar}</span>}{showT && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{o.en}</span>}</span>)}
                {fields.recommend && u.recommend_to && REC_MAP[u.recommend_to] && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{arSpan("ترشيح")} {showI && <span>{REC_MAP[u.recommend_to].e}</span>}{showT && showAr && <span style={{ fontFamily: "Amiri, serif", color: C2 }}>{REC_MAP[u.recommend_to].ar}</span>}{showT && showEn && <span style={{ marginInlineStart: showAr ? 3 : 0 }}>{REC_MAP[u.recommend_to].en}</span>}</span>}
                {fields.thought && phases.map(([f, ar, en]) => (u[f] ? <span key={f} style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>{showT && <span style={{ fontFamily: showAr ? "Amiri, serif" : undefined, color: C2 }}>{showAr ? ar : en}</span>}<span>{u[f] === "like" ? "👍" : "👎"}</span></span> : null))}
                {fields.wears && wearLogs.length > 0 && <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>🔁 <span style={{ color: "#2E7D32", fontWeight: 600 }}>{wearLogs.length}</span></span>}
                </div>
                {fields.comment && reviewText && <div style={{ marginTop: 3, fontFamily: "Amiri, serif", color: muted, fontSize: 7, textAlign: a5 }}>✏️ — {reviewText} —</div>}
              </div>
            );
          });
        })()}

        {person !== "none" && fields.purchases && purchases[0]?.ml && (
          <div style={{ marginTop: 5, textAlign: a5, fontSize: 7.5 }}>
            <span style={{ fontFamily: "Cinzel, serif", fontSize: 7, letterSpacing: ".08em", color: "#9a8f7c", textTransform: "uppercase" }}>{arSpan("الحجم")} {showEn && "Size"}</span>
            <span style={{ fontSize: 8, color: muted, marginInlineStart: 6 }}>{purchases[0].ml}ml</span>
          </div>
        )}

        {/* ===== FOOTER: mark + profile photo + date ===== */}
        {((fields.mark && userMark) || fields.date || (fields.photo && markPhoto)) && (
          <div style={{ marginTop: 7, display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 9, color: soft }}>
            {((fields.photo && markPhoto) || (fields.mark && userMark)) ? (
              <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                {fields.photo && markPhoto && (
                  <img src={markPhoto} alt="" style={{ width: 22, height: 22, objectFit: "cover", background: "#fff", borderBottom: `1.5px solid ${GOLD}`, display: "block" }} />
                )}
                {fields.mark && userMark && <span style={{ fontFamily: "Amiri, serif", color: "#2E7D32", fontWeight: 700, fontSize: 12 }}>{userMark}</span>}
              </span>
            ) : <span />}
            {fields.date && <span>Process {new Date().toLocaleDateString(showAr ? "ar-EG" : "en-GB")}</span>}
          </div>
        )}
      </div>
      </div>
    </div>
  );

  const card = renderCard(true);
  // معاينة مصغّرة مثبّتة بالأعلى — fit to screen، لا تعترض تمرير الجوال.
  const vpH = typeof window !== "undefined" ? window.innerHeight : 700;
  const miniMaxH = Math.min(300, Math.round(vpH * 0.33));   // مساحة المعاينة العمودية
  const miniScale = Math.min(scale, miniMaxH / previewInnerH); // يصغّر البطاقة كاملةً لتظهر عمودية
  const miniH = previewInnerH * miniScale;                  // البطاقة كاملة بلا قصّ
  const stickyTop = (
    <div style={{ position: "sticky", top: 0, zIndex: 30, background: "#F3EEE2", borderBottom: `1px solid ${N}` }}>
      <div style={{ padding: "9px 12px", display: "flex", alignItems: "center", gap: 10 }}>
        <button onClick={() => navigate(-1)} style={{ display: "flex", alignItems: "center", gap: 4, border: `1px solid ${N}`, background: "#fff", color: "var(--brand)", padding: "5px 11px", fontSize: 12, cursor: "pointer" }}>
          <ArrowLeft size={14} /> {isAr ? "رجوع" : "Back"}
        </button>
        <span style={{ flex: 1 }} />
        <button onClick={handleSave} disabled={saving} style={{ border: `1px solid ${GOLD}`, background: GOLD, color: "#fff", padding: "5px 16px", fontSize: 12.5, fontWeight: 700, cursor: "pointer", opacity: saving ? 0.6 : 1 }}>
          {saving ? (isAr ? "جارٍ.." : "..") : (isAr ? "حفظ" : "Save")}
        </button>
      </div>
      <div dir="ltr" style={{ display: "flex", justifyContent: "center", padding: "0 0 7px", pointerEvents: "none" }}>
        <div style={{ width: W * miniScale, height: miniH, overflow: "hidden" }}>
          <div style={{ transform: `scale(${miniScale})`, transformOrigin: "top left", width: W, height: previewInnerH }}>{renderCard(false)}</div>
        </div>
      </div>
    </div>
  );

  return <div>{stickyTop}{Options}{preview(card)}{SaveBar}</div>;
}
