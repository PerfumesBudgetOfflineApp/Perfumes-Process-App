import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Search, X, Bookmark } from "lucide-react";
import { Input } from "@/components/ui/input";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import { useLang } from "@/lib/LanguageContext";

const STORAGE_KEY = "collection_saved_searches";

function getSavedSearches() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); } catch { return []; }
}

export default function CollectionSearch() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [query, setQuery] = useState("");
  const [savedSearches, setSavedSearches] = useState(getSavedSearches);
  const [activeQuickFilter, setActiveQuickFilter] = useState(null);

  // قائمة المجموعة (UserPerfume) — صغيرة. نجمع منها معرّفات العطور المملوكة فقط.
  const { data: userPerfumes = [], isLoading: upLoading } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const collectionIds = useMemo(
    () => [...new Set(userPerfumes.map((u) => u.perfume_id).filter(Boolean))],
    [userPerfumes]
  );

  // نجلب عطور المجموعة بمعرّفاتها مباشرةً عبر getMany (قراءة مفتاحية)
  // بدل تحميل ~130k عبر Perfume.list ثم ترشيحها — هذا ما كان يجمّد الصفحة.
  const { data: collectionPerfumes = [], isLoading: cpLoading } = useQuery({
    queryKey: ["collection-perfumes", collectionIds],
    queryFn: () => apphost.entities.Perfume.getMany(collectionIds),
    enabled: collectionIds.length > 0,
  });

  const isLoading = upLoading || (collectionIds.length > 0 && cpLoading);

  const effectiveQuery = activeQuickFilter ?? query;

  const results = useMemo(() => {
    const q = effectiveQuery.trim().toLowerCase();
    const qRaw = effectiveQuery.trim();
    if (!q) return collectionPerfumes;
    return collectionPerfumes.filter((p) => {
      const inName = p.name?.toLowerCase().includes(q) || p.name_en?.toLowerCase().includes(q) || p.name_ar?.includes(qRaw);
      const inBrand = p.brand_name?.toLowerCase().includes(q) || p.brand_name_ar?.includes(qRaw);
      const inNotes = [p.top_notes, p.heart_notes, p.base_notes, p.innovation_notes]
        .filter(Boolean)
        .some((field) => field.toLowerCase().includes(q));
      return inName || inBrand || inNotes;
    });
  }, [collectionPerfumes, effectiveQuery]);

  const handleSave = () => {
    const q = query.trim();
    if (!q || savedSearches.includes(q)) return;
    const updated = [q, ...savedSearches].slice(0, 12);
    setSavedSearches(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const handleDeleteSaved = (s) => {
    const updated = savedSearches.filter((x) => x !== s);
    setSavedSearches(updated);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  };

  const handleQuickFilter = (s) => {
    if (activeQuickFilter === s) {
      setActiveQuickFilter(null);
    } else {
      setActiveQuickFilter(s);
      setQuery("");
    }
  };

  return (
    <div className="px-4 page-top pb-24 space-y-5">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity flex-shrink-0">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="font-heading text-xl font-bold">{isAr ? "بحث المجموعة" : "Collection Search"}</h1>
        </div>
      </div>

      {/* Search bar — white background, no frame, two dots, monolingual placeholder */}
      <div className="relative flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder={isAr ? "ابحث بالاسم أو البراند أو النوتات.." : "Search by name, brand, or notes.."}
            value={query}
            onChange={(e) => { setQuery(e.target.value); setActiveQuickFilter(null); }}
            className="pl-10 pr-4 h-11 font-body bg-[var(--page-bg,#fff)] border-0 focus-visible:ring-1"
            style={{ boxShadow: "inset 0 0 0 1px rgba(0,0,0,0.06)" }}
            autoFocus
          />
          
        </div>
        {query.trim() && !savedSearches.includes(query.trim()) && (
          <button
            onClick={handleSave}
            className="h-11 px-3 text-xs font-body font-medium text-primary hover:opacity-70 transition-opacity flex items-center gap-1.5 whitespace-nowrap"
          >
            <Bookmark className="w-3.5 h-3.5" /> {isAr ? "حفظ" : "Save"}
          </button>
        )}
      </div>

      {/* Saved searches / quick filters */}
      {savedSearches.length > 0 && (
        <div className="space-y-2">
          <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "مرشّحات سريعة" : "Quick Filters"}</p>
          <div className="flex flex-wrap gap-2">
            {savedSearches.map((s) => (
              <div key={s} className="flex items-center gap-0.5">
                <button
                  onClick={() => handleQuickFilter(s)}
                  className={` rounded-none text-xs font-body font-medium transition-all ${
 activeQuickFilter === s
 ? " text-primary-foreground "
 : " text-foreground "
 }`}
                >
                  {s}
                </button>
                <button
                  onClick={() => handleDeleteSaved(s)}
                  className="w-4 h-4 flex items-center justify-center text-muted-foreground hover:text-destructive transition-colors"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Results count */}
      <p className="text-xs text-muted-foreground font-body">
        {effectiveQuery.trim()
          ? (isAr
              ? `${results.length} نتيجة لـ "${effectiveQuery.trim()}"`
              : `${results.length} result${results.length !== 1 ? "s" : ""} for "${effectiveQuery.trim()}"`)
          : (isAr ? `${results.length} عطر` : `${results.length} perfumes`)}
      </p>

      {/* Results */}
      {isLoading ? (
        <div className="flex justify-center py-20">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : results.length === 0 ? (
        <div className="text-center py-16 space-y-2">
          <Search className="w-10 h-10 text-primary/20 mx-auto" />
          <p className="text-sm text-muted-foreground font-body">{isAr ? "لا عطور" : "No perfumes found"}</p>
          <p className="text-xs text-muted-foreground font-body">{isAr ? "جرّب اسماً أو برانداً أو نوتة مختلفة" : "Try a different name, brand, or note"}</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {results.map((p) => (
            <PerfumeCard key={p.id} perfume={p} />
          ))}
        </div>
      )}

      {/* Bottom collection counter — moved from header per spec */}
      <p className="text-center text-[11px] text-muted-foreground font-body pt-4">
        {isAr
          ? `${collectionPerfumes.length} عطر في مجموعتك`
          : `${collectionPerfumes.length} perfume${collectionPerfumes.length !== 1 ? "s" : ""} in your collection`}
      </p>
    </div>
  );
}