import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // جلب جميع النوتات
    const notes = await base44.asServiceRole.entities.PerfumeNote.list('-created_date', 10000);
    
    // تنسيق البيانات
    const formatted = notes.map(note => ({
      name: note.name,
      name_ar: note.name_ar,
      category: note.category,
      note_category: note.note_category,
      odor_family: note.odor_family,
      pyramid: note.pyramid,
      description: note.description,
      origin: note.origin,
      image_url: note.image_url
    }));

    // إرجاع كـ JSON download
    const jsonString = JSON.stringify(formatted, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    
    return new Response(blob, {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': 'attachment; filename=notes_builtin.json'
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});