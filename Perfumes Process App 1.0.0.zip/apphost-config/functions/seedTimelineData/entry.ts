import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Brands to seed
    const brandsToSeed = [
      { name: "Houbigant", year_established: 1775, country: "France", is_default: true },
      { name: "Lubin", year_established: 1798, country: "France", is_default: true },
      { name: "Jean Patou", year_established: 1924, country: "France", is_default: true },
      { name: "Lanvin", year_established: 1885, country: "France", is_default: true },
      { name: "Estée Lauder", year_established: 1946, country: "USA", is_default: true },
      { name: "Rochas", year_established: 1925, country: "France", is_default: true },
      { name: "Nina Ricci", year_established: 1951, country: "France", is_default: true },
      { name: "Yves Saint Laurent", year_established: 1961, country: "France", is_default: true },
      { name: "Paco Rabanne", year_established: 1966, country: "Spain", is_default: true },
      { name: "Hermès", year_established: 1837, country: "France", is_default: true },
      { name: "Revlon", year_established: 1932, country: "USA", is_default: true },
      { name: "Chloé", year_established: 1952, country: "France", is_default: true },
      { name: "Guy Laroche", year_established: 1961, country: "France", is_default: true },
      { name: "Giorgio Beverly Hills", year_established: 1982, country: "USA", is_default: true },
      { name: "Calvin Klein", year_established: 1968, country: "USA", is_default: true },
      { name: "Thierry Mugler", year_established: 1973, country: "France", is_default: true },
      { name: "Issey Miyake", year_established: 1978, country: "Japan", is_default: true },
      { name: "Tommy Hilfiger", year_established: 1985, country: "USA", is_default: true },
      { name: "Armani", year_established: 1975, country: "Italy", is_default: true },
      { name: "Dolce & Gabbana", year_established: 1985, country: "Italy", is_default: true },
      { name: "Lancôme", year_established: 1935, country: "France", is_default: true },
      { name: "Le Labo", year_established: 2006, country: "USA", is_default: true },
      { name: "Maison Francis Kurkdjian", year_established: 2009, country: "France", is_default: true },
      { name: "Creed", year_established: 1760, country: "UK", is_default: true },
      { name: "Heeley", year_established: 2011, country: "UK", is_default: true },
      { name: "Tom Ford", year_established: 2006, country: "USA", is_default: true },
      { name: "Solstice Scents", year_established: 2009, country: "USA", is_default: true },
    ];

    // Perfumers to seed
    const perfumersToSeed = [
      { name: "Aimé Guerlain", gender: "Male", nationality: "France", birth_year: 1806, is_default: true },
      { name: "Paul Parquet", gender: "Male", nationality: "France", is_default: true },
      { name: "Jacques Guerlain", gender: "Male", nationality: "France", birth_year: 1891, is_default: true },
      { name: "François Coty", gender: "Male", nationality: "France", birth_year: 1874, is_default: true },
      { name: "Ernest Beaux", gender: "Male", nationality: "Russia", birth_year: 1881, is_default: true },
      { name: "Henri Alméras", gender: "Male", nationality: "France", is_default: true },
      { name: "André Fraysse", gender: "Male", nationality: "France", is_default: true },
      { name: "Paul Vacher", gender: "Male", nationality: "France", is_default: true },
      { name: "Francis Fabron", gender: "Male", nationality: "France", is_default: true },
      { name: "Jean-Louis Sieuzac", gender: "Male", nationality: "France", is_default: true },
      { name: "Dmitri Berlin", gender: "Male", nationality: "Russia", is_default: true },
      { name: "Guy Robert", gender: "Male", nationality: "France", is_default: true },
      { name: "Jean Amic", gender: "Male", nationality: "France", is_default: true },
      { name: "Edmond Roudnitska", gender: "Male", nationality: "France", birth_year: 1914, is_default: true },
      { name: "Luc Chevallier", gender: "Male", nationality: "France", is_default: true },
      { name: "Maurice Roucel", gender: "Male", nationality: "France", is_default: true },
      { name: "Bernard Chant", gender: "Male", nationality: "France", is_default: true },
      { name: "Pierre Bourdon", gender: "Male", nationality: "France", is_default: true },
      { name: "Tetsuro Shimizu", gender: "Male", nationality: "Japan", is_default: true },
      { name: "Olivier Cresp", gender: "Male", nationality: "France", is_default: true },
      { name: "Jacques Cavallier", gender: "Male", nationality: "France", is_default: true },
      { name: "Michel Almairac", gender: "Male", nationality: "France", is_default: true },
      { name: "Jacques Polge", gender: "Male", nationality: "France", is_default: true },
      { name: "Frank Voelkl", gender: "Male", nationality: "Germany", is_default: true },
      { name: "Francis Kurkdjian", gender: "Male", nationality: "France", is_default: true },
      { name: "Anne Flipo", gender: "Female", nationality: "France", is_default: true },
      { name: "Olivier Douzou", gender: "Male", nationality: "France", is_default: true },
      { name: "Olivier Creed", gender: "Male", nationality: "UK", is_default: true },
      { name: "James Heeley", gender: "Male", nationality: "UK", is_default: true },
      { name: "Dominique Ropion", gender: "Male", nationality: "France", is_default: true },
    ];

    let brandsAdded = 0;
    let perfumersAdded = 0;

    // Check and add brands
    for (const brand of brandsToSeed) {
      const exists = await base44.asServiceRole.entities.PerfumeBrand.filter({ name: brand.name });
      if (!exists || exists.length === 0) {
        await base44.asServiceRole.entities.PerfumeBrand.create(brand);
        brandsAdded++;
      }
    }

    // Check and add perfumers
    for (const perfumer of perfumersToSeed) {
      const exists = await base44.asServiceRole.entities.Perfumer.filter({ name: perfumer.name });
      if (!exists || exists.length === 0) {
        await base44.asServiceRole.entities.Perfumer.create(perfumer);
        perfumersAdded++;
      }
    }

    return Response.json({
      status: 'success',
      brandsAdded,
      perfumersAdded,
      message: `Added ${brandsAdded} brands and ${perfumersAdded} perfumers for Timeline`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});