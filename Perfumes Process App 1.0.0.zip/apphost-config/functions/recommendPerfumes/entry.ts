import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { person = "person1", limit = 6 } = await req.json();

    // Fetch all data
    const userPerfumes = await base44.asServiceRole.entities.UserPerfume.list("-created_date", 1000);
    const perfumes = await base44.asServiceRole.entities.Perfume.list("-created_date", 500);

    // Get favorites for the person
    const favPerfumeIds = userPerfumes
      .filter(up => up.person === person && up.list === "favorite")
      .map(up => up.perfume_id);

    const favPerfumes = perfumes.filter(p => favPerfumeIds.includes(p.id));

    if (favPerfumes.length === 0) {
      return Response.json({ recommendations: [] });
    }

    // Extract common attributes from favorites
    const favCategories = favPerfumes.map(p => p.category).filter(Boolean);
    const favBrands = favPerfumes.map(p => p.brand_name).filter(Boolean);
    const favSeasons = favPerfumes.map(p => p.season).filter(Boolean);
    const favGenders = favPerfumes.map(p => p.gender).filter(Boolean);

    // Score all other perfumes
    const recommendations = perfumes
      .filter(p => !favPerfumeIds.includes(p.id)) // Exclude already favorited
      .map(p => {
        let score = 0;

        // Category match (highest weight)
        if (p.category && favCategories.includes(p.category)) score += 3;

        // Brand match
        if (p.brand_name && favBrands.includes(p.brand_name)) score += 2;

        // Season match
        if (p.season && favSeasons.includes(p.season)) score += 1;

        // Gender match
        if (p.gender && favGenders.includes(p.gender)) score += 1;

        return { perfume: p, score };
      })
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, limit)
      .map(item => item.perfume);

    return Response.json({
      recommendations,
      basedOn: {
        favCount: favPerfumes.length,
        categories: [...new Set(favCategories)],
        brands: [...new Set(favBrands)].slice(0, 3)
      }
    });
  } catch (error) {
    console.error('Recommendation error:', error);
    return Response.json({ error: error.message, recommendations: [] }, { status: 500 });
  }
});