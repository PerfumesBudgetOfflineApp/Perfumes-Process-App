import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const results = { brands: 0, perfumers: 0, notes: 0, quotes: 0, glossary: 0, wisdom: 0 };

    // ===== SEED BRANDS (inline data) =====
    try {
      const brandsData = [
        { name: "Chanel", name_ar: "شانيل", country: "France", country_ar: "فرنسا", year_established: 1910, owned_by: "Alain Wertheimer, Gérard Wertheimer", description: "The world's most prestigious luxury perfume house", description_ar: "أعرق دور العطور الفاخرة في العالم" },
        { name: "Dior", name_ar: "ديور", country: "France", country_ar: "فرنسا", year_established: 1946, owned_by: "LVMH", description: "Pioneer of couture and fragrance elegance", description_ar: "رائد الأناقة والفخامة العطرية" },
        { name: "Guerlain", name_ar: "جيرلان", country: "France", country_ar: "فرنسا", year_established: 1828, owned_by: "LVMH", description: "Historic perfume house with artistic legacy", description_ar: "دار عطور تاريخية بإرث فني عريق" }
      ];

      const existingBrands = await base44.asServiceRole.entities.PerfumeBrand.list("-created_date", 500000);
      const existingBrandNames = new Set(existingBrands.map(b => b.name.toLowerCase()));
      const toCreateBrands = brandsData.filter(b => !existingBrandNames.has(b.name.toLowerCase()));
      
      if (toCreateBrands.length > 0) {
        await base44.asServiceRole.entities.PerfumeBrand.bulkCreate(toCreateBrands.map(b => ({
          ...b,
          is_default: true
        })));
        results.brands = toCreateBrands.length;
      }
    } catch (e) {
      console.error('Error seeding brands:', e.message);
    }

    // ===== SEED PERFUMERS (inline data) =====
    try {
      const perfumersData = [
        { name: "Ernest Beaux", name_ar: "إرنست بو", nationality: "French-Russian", nationality_ar: "فرنسي-روسي", gender: "Male", birth_year: 1881, death_year: 1961, brand_ids: "", brand_names: "Chanel", perfume_ids: "", perfume_names: "", photo_url: null, website: null, education: "Trained in St. Petersburg", famous_works: "Chanel No. 5, Chanel No. 22, Cuir de Russie", favorite_perfumes: "Chanel No. 5", favorite_notes: "Aldehydes, Rose, Jasmine", bio: "Creator of the iconic Chanel No. 5, considered one of the most important perfumers in history. · مبتكر رقم 5 الشهير من شانيل، يُعتبر أحد أهم العطارين في التاريخ." },
        { name: "Jacques Guerlain", name_ar: "جاك غيرلان", nationality: "French", nationality_ar: "فرنسي", gender: "Male", birth_year: 1874, death_year: 1963, brand_ids: "", brand_names: "Guerlain", perfume_ids: "", perfume_names: "", photo_url: null, website: null, education: "Family heritage", famous_works: "Shalimar, Mitsouko, Vol de Nuit, L'Heure Bleue", favorite_perfumes: "Shalimar", favorite_notes: "Jasmine, Vanilla, Sandalwood", bio: "Fourth-generation Guerlain perfumer and one of the greatest noses of the 20th century. · عطار من الجيل الرابع من عائلة غيرلان وأحد أعظم الأنف في القرن العشرين." },
        { name: "François Coty", name_ar: "فرانسوا كوتي", nationality: "French", nationality_ar: "فرنسي", gender: "Male", birth_year: 1874, death_year: 1934, brand_ids: "", brand_names: "Coty", perfume_ids: "", perfume_names: "", photo_url: null, website: null, education: "Apprentice at Grasse", famous_works: "L'Origan, La Rose Jacqueminot, Chypre", favorite_perfumes: "Chypre", favorite_notes: "Oakmoss, Rose, Bergamot", bio: "Founder of Coty and pioneer of modern commercial perfumery who invented the chypre fragrance family. · مؤسس كوتي ورائد صناعة الروائح التجارية الحديثة الذي اخترع عائلة العطور الشيبرية." }
      ];

      const existingPerfumers = await base44.asServiceRole.entities.Perfumer.list("-created_date", 500000);
      const existingPerfumerNames = new Set(existingPerfumers.map(p => p.name.toLowerCase()));
      const toCreatePerfumers = perfumersData.filter(p => !existingPerfumerNames.has(p.name.toLowerCase()));
      
      if (toCreatePerfumers.length > 0) {
        await base44.asServiceRole.entities.Perfumer.bulkCreate(toCreatePerfumers);
        results.perfumers = toCreatePerfumers.length;
      }
    } catch (e) {
      console.error('Error seeding perfumers:', e.message);
    }

    return Response.json({
      success: true,
      message: `✅ تم تحميل البيانات · All Data Seeded Successfully`,
      data: {
        'البراندات · Brands': results.brands,
        'العطارون · Perfumers': results.perfumers,
      },
      total: Object.values(results).reduce((a, b) => a + b, 0)
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});