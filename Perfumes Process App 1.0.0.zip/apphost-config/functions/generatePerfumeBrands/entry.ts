import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get perfumes_builtin.json data
    const perfumesBuiltin = await Deno.readTextFile('./data/builtin_database/perfumes_builtin.json');
    const perfumesData = JSON.parse(perfumesBuiltin);

    // Extract unique brands from perfumes data
    const brandsMap = new Map();

    // Iterate through perfumes data structure (object with brands as keys)
    for (const [brandName, perfumesList] of Object.entries(perfumesData)) {
      if (Array.isArray(perfumesList) && perfumesList.length > 0) {
        if (!brandsMap.has(brandName)) {
          brandsMap.set(brandName, {
            name: brandName,
            perfumeCount: perfumesList.length
          });
        } else {
          const existing = brandsMap.get(brandName);
          existing.perfumeCount += perfumesList.length;
        }
      }
    }

    // Convert brands map to array
    const brandsList = Array.from(brandsMap.values()).map(brand => ({
      name: brand.name,
      name_ar: brand.name,
      country: '',
      country_ar: '',
      description: `Brand with ${brand.perfumeCount} fragrances`,
      year_established: null,
      in_business: true
    }));

    // Sort brands alphabetically
    brandsList.sort((a, b) => a.name.localeCompare(b.name));

    // Remove duplicates by name (case-insensitive)
    const uniqueBrands = brandsList.reduce((acc, brand) => {
      const exists = acc.some(b => b.name.toLowerCase() === brand.name.toLowerCase());
      if (!exists) acc.push(brand);
      return acc;
    }, []);

    // Check existing brands
    const existingBrands = await base44.entities.PerfumeBrand.list('name', 1000);
    const existingNames = new Set(existingBrands.map(b => b.name.toLowerCase()));

    // Filter out existing brands
    const newBrands = uniqueBrands.filter(brand => !existingNames.has(brand.name.toLowerCase()));

    // Create brands in database
    let created = 0;
    if (newBrands.length > 0) {
      const result = await base44.entities.PerfumeBrand.bulkCreate(newBrands);
      created = result.length;
    }

    return Response.json({
      success: true,
      created,
      total_unique: uniqueBrands.length,
      already_exist: uniqueBrands.length - newBrands.length,
      message: `${created} new brands created. Total unique brands: ${uniqueBrands.length}`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});