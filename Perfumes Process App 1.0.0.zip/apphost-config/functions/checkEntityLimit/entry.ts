import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { entity_name } = await req.json();
    
    if (!entity_name) {
      return Response.json({ error: 'entity_name is required' }, { status: 400 });
    }

    // Define entity limits
    const limits = {
      PerfumeBrand: 1500,
      Perfume: 130000,
      Store: 1000000,
      ShopProduct: 1000000,
    };

    const limit = limits[entity_name];
    
    if (!limit) {
      return Response.json({ 
        allowed: true, 
        message: `No limit configured for ${entity_name}` 
      });
    }

    // Count existing records
    const count = await base44.asServiceRole.entities[entity_name].list({ limit: 1 });
    const totalCount = count.length;

    const allowed = totalCount < limit;

    return Response.json({
      allowed,
      current_count: totalCount,
      limit,
      remaining: Math.max(0, limit - totalCount),
      message: allowed 
        ? `You can add more ${entity_name} records` 
        : `Limit reached: ${totalCount}/${limit} ${entity_name} records`
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});