import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin only' }, { status: 403 });
    }

    // Create test perfume
    const testPerfume = await base44.entities.Perfume.create({
      name_en: "Test Perfume",
      name_ar: "عطر تجريبي",
      brand_name: "Test Brand",
      brand_id: "",
      category: "Floral",
      type: "Eau de Parfum - EDP",
      gender: "Unisex",
      about_en: "This is a test perfume for testing purposes",
      about_ar: "هذا عطر تجريبي لأغراض الاختبار",
      image_url: "",
      ml: 100,
      price: 99.99,
      release_year: 2024,
      season: "All Seasons",
      top_notes: "Bergamot, Lemon",
      heart_notes: "Rose, Jasmine",
      base_notes: "Sandalwood, Musk",
      odor_family: "Fresh · منعش",
      occasions: "daylight, casual",
      list: "none",
      rating: 0,
    });

    return Response.json({
      success: true,
      perfume: testPerfume,
      message: "Test perfume created successfully"
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});