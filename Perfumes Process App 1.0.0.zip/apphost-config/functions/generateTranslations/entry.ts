import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Get English translations
    const enTranslations = {
      common: {
        loading: "Loading...",
        save: "Save",
        cancel: "Cancel",
        delete: "Delete",
        edit: "Edit",
        add: "Add",
        close: "Close",
        search: "Search",
        filter: "Filter",
        sort: "Sort",
        back: "Back",
        next: "Next",
        previous: "Previous",
        more: "More",
        less: "Less",
        yes: "Yes",
        no: "No",
        error: "Error",
        success: "Success",
        warning: "Warning",
        info: "Info",
        empty: "Empty"
      },
      navigation: {
        home: "Home",
        perfumes: "Perfumes",
        explore: "Explore",
        wearHistory: "Wear History",
        progress: "Progress",
        goals: "Goals",
        layering: "Layering",
        blog: "Blog",
        quotes: "Quotes",
        notes: "Notes",
        glossary: "Glossary",
        brands: "Brands",
        perfumers: "Perfumers",
        samples: "Samples",
        lists: "Lists",
        settings: "Settings"
      },
      quotes: {
        title: "Quotes",
        addQuote: "Add Quote",
        noQuotes: "No quotes here yet",
        reactToQuotes: "React to quotes to see them here",
        addNew: "Add new quote",
        writeQuote: "Write the quote...",
        author: "Author (optional)",
        addThought: "Add thought",
        myThought: "My thought",
        editThought: "Edit",
        deleteThought: "Delete",
        addYourThought: "Add your thought",
        whatDoYouThink: "What do you think about this quote?",
        saveThought: "Save thought",
        quoteCreated: "Quote created!",
        like: "Like",
        dislike: "Dislike",
        wtf: "WTF",
        total: "total",
        keepPrivate: "Keep private",
        addToCollection: "Add to collection"
      },
      perfumes: {
        title: "Perfumes",
        myCollection: "My Collection",
        addPerfume: "Add Perfume",
        perfumeName: "Perfume Name",
        brand: "Brand",
        description: "Description",
        category: "Category",
        type: "Type",
        gender: "Gender",
        rating: "Rating",
        notes: "Notes",
        topNotes: "Top Notes",
        heartNotes: "Heart Notes",
        baseNotes: "Base Notes",
        noNotes: "No perfumes in your collection",
        startExploring: "Start exploring perfumes",
        viewDetails: "View Details",
        editPerfume: "Edit Perfume",
        deletePerfume: "Delete Perfume",
        addToList: "Add to List",
        removeFromList: "Remove from List",
        favorites: "Favorites",
        wishlist: "Wishlist",
        owned: "Owned",
        dislike: "Dislike",
        recommend: "Recommend"
      },
      wearHistory: {
        title: "Wear History",
        logWear: "Log Wear",
        mood: "Mood",
        note: "Note",
        date: "Date",
        today: "Today",
        yesterday: "Yesterday",
        thisWeek: "This Week",
        thisMonth: "This Month",
        noLogs: "No wear logs yet",
        startLogging: "Start logging your wears",
        amazing: "Amazing",
        happy: "Happy",
        calm: "Calm",
        confident: "Confident",
        romantic: "Romantic",
        sexy: "Sexy",
        sad: "Sad",
        energetic: "Energetic",
        thoughtful: "Thoughtful",
        relaxing: "Relaxing",
        neutral: "Neutral"
      },
      blog: {
        title: "Blog",
        writeEntry: "Write Entry",
        newEntry: "New Entry",
        content: "Content",
        category: "Category",
        tags: "Tags",
        media: "Media",
        archived: "Archived",
        publish: "Publish",
        draft: "Draft",
        noBlogPosts: "No blog entries yet",
        startWriting: "Start writing your thoughts"
      },
      glossary: {
        title: "Glossary",
        term: "Term",
        meaning: "Meaning",
        addTerm: "Add Term",
        englishTerm: "English Term",
        arabicTerm: "Arabic Term",
        definition: "Definition",
        tags: "Tags",
        noTerms: "No terms yet",
        learnMore: "Learn More"
      },
      settings: {
        title: "Settings",
        language: "Language",
        darkMode: "Dark Mode",
        tabLabels: "Tab Labels",
        currency: "Currency",
        profiles: "Profiles",
        profileA: "Profile A",
        profileB: "Profile B",
        color: "Color",
        bio: "Bio",
        mark: "Mark",
        backup: "Backup",
        restore: "Restore",
        appInfo: "App Info",
        aboutApp: "About App",
        privacyPolicy: "Privacy Policy",
        termsOfUse: "Terms of Use",
        logout: "Logout",
        refreshApp: "Refresh App",
        updateApp: "Update App"
      },
      home: {
        title: "Home",
        dashboard: "Dashboard",
        recentActivity: "Recent Activity",
        statistics: "Statistics",
        totalPerfumes: "Total Perfumes",
        totalValue: "Total Value",
        favoriteCount: "Favorite Count",
        noActivity: "No recent activity",
        welcomeBack: "Welcome back!"
      },
      validation: {
        required: "This field is required",
        invalidEmail: "Invalid email address",
        passwordTooShort: "Password must be at least 6 characters",
        confirmPassword: "Passwords do not match",
        selectOption: "Please select an option"
      },
      messages: {
        successfullySaved: "Successfully saved!",
        successfullyDeleted: "Successfully deleted!",
        successfullyCreated: "Successfully created!",
        errorSaving: "Error saving. Please try again.",
        errorDeleting: "Error deleting. Please try again.",
        errorLoading: "Error loading. Please try again.",
        confirmDelete: "Are you sure you want to delete this?",
        addedToCollection: "Added to collection",
        removedFromCollection: "Removed from collection"
      }
    };

    // Flatten all translations to a single list for translation
    const allStrings = [];
    const keyMap = {};

    const flatten = (obj, prefix = '') => {
      for (const key in obj) {
        const fullKey = prefix ? `${prefix}.${key}` : key;
        if (typeof obj[key] === 'object') {
          flatten(obj[key], fullKey);
        } else {
          allStrings.push(obj[key]);
          keyMap[obj[key]] = fullKey;
        }
      }
    };

    flatten(enTranslations);

    // Generate Arabic translations using LLM
    const prompt = `You are a professional Arabic translator for a luxury perfume app. Translate the following English UI labels and messages to Arabic (Modern Standard Arabic with natural conversational tone where appropriate).

Keep translations concise and appropriate for mobile UI. Return ONLY a JSON object with English text as keys and Arabic translations as values.

English terms to translate:
${allStrings.map((s, i) => `${i + 1}. "${s}"`).join('\n')}

Return a valid JSON object like:
{
  "Loading...": "جارٍ التحميل...",
  "Save": "حفظ",
  ...
}`;

    const response = await base44.integrations.Core.InvokeLLM({
      prompt,
      model: 'claude_sonnet_4_6'
    });

    const translations = typeof response === 'string' ? JSON.parse(response) : response;

    // Reconstruct the nested structure
    const arTranslations = {};
    
    const setNested = (obj, path, value) => {
      const parts = path.split('.');
      let current = obj;
      for (let i = 0; i < parts.length - 1; i++) {
        if (!current[parts[i]]) current[parts[i]] = {};
        current = current[parts[i]];
      }
      current[parts[parts.length - 1]] = value;
    };

    for (const [enText, arText] of Object.entries(translations)) {
      const key = keyMap[enText];
      if (key) {
        setNested(arTranslations, key, arText);
      }
    }

    return Response.json({
      success: true,
      message: 'Arabic translations generated successfully',
      arTranslations
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});