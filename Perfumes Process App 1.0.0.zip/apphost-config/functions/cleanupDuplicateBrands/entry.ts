import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch all brands
    const allBrands = await base44.entities.PerfumeBrand.list("name", 1000);
    
    // Track seen brands and duplicates
    const seen = new Map();
    const duplicates = [];
    
    for (const brand of allBrands) {
      const key = brand.name.toLowerCase();
      if (seen.has(key)) {
        // Mark as duplicate
        duplicates.push(brand.id);
      } else {
        seen.set(key, brand.id);
      }
    }
    
    // Delete duplicates
    let deletedCount = 0;
    for (const dupId of duplicates) {
      await base44.entities.PerfumeBrand.delete(dupId);
      deletedCount++;
    }
    
    // Get final count
    const finalBrands = await base44.entities.PerfumeBrand.list("name", 1000);
    
    return Response.json({ 
      success: true,
      deleted: deletedCount,
      remaining: finalBrands.length,
      message: `Removed ${deletedCount} duplicate brands. Database now has ${finalBrands.length} unique brands.`
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});