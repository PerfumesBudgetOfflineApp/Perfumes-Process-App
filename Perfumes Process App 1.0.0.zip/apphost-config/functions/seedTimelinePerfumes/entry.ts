import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const HISTORICAL_PERFUMES = [
  { year: 1889, name: "Jicky", brand: "Guerlain", notes: "Lavender, coumarin, vanilla", gender: "Unisex" },
  { year: 1889, name: "Peau d'Espagne", brand: "Fragonard", notes: "Rose, musk, civet", gender: "Unisex" },
  { year: 1889, name: "Violette Mousseuse", brand: "Pinaud", notes: "Violet, aldehydes", gender: "Women" },
  { year: 1889, name: "Eau de Lubin", brand: "Lubin", notes: "Rose, bergamot, musk", gender: "Unisex" },
  { year: 1910, name: "Chypre", brand: "Coty", notes: "Oakmoss, bergamot, labdanum", gender: "Unisex" },
  { year: 1920, name: "Chanel No. 5", brand: "Chanel", notes: "Aldehydes, jasmine, rose, sandalwood", gender: "Women" },
  { year: 1920, name: "Shalimar", brand: "Guerlain", notes: "Bergamot, iris, rose, vanilla", gender: "Women" },
  { year: 1920, name: "Coco", brand: "Chanel", notes: "Florals, amber, musk", gender: "Women" },
  { year: 1930, name: "Joy", brand: "Jean Patou", notes: "Rose, jasmine, ylang-ylang", gender: "Women" },
  { year: 1940, name: "Youth Dew", brand: "Estée Lauder", notes: "Spices, patchouli, rose, amber", gender: "Women" },
  { year: 1940, name: "Miss Dior", brand: "Dior", notes: "Green notes, aldehyde, rose, oakmoss", gender: "Women" },
  { year: 1940, name: "Arpège", brand: "Lanvin", notes: "Aldehydes, rose, jasmine, sandalwood", gender: "Women" },
  { year: 1950, name: "L'Air du Temps", brand: "Nina Ricci", notes: "Carnation, rose, sandalwood", gender: "Women" },
  { year: 1950, name: "No. 19", brand: "Chanel", notes: "Aldehydes, iris, citrus, green", gender: "Women" },
  { year: 1960, name: "Rive Gauche", brand: "YSL", notes: "Aldehydes, rose, jasmine, vetiver", gender: "Women" },
  { year: 1960, name: "Calandre", brand: "Paco Rabanne", notes: "Aldehydes, rose, violet, sandalwood", gender: "Women" },
  { year: 1960, name: "Cristalle", brand: "Chanel", notes: "Aldehydes, citrus, jasmine, vetiver", gender: "Women" },
  { year: 1960, name: "Calèche", brand: "Hermès", notes: "Aldehydes, rose, jasmine, vetiver", gender: "Women" },
  { year: 1970, name: "Charlie", brand: "Revlon", notes: "Green, floral, aldehyde, musk", gender: "Women" },
  { year: 1970, name: "Opium", brand: "YSL", notes: "Spices, patchouli, myrrh, rose", gender: "Women" },
  { year: 1970, name: "Eau Sauvage", brand: "Dior", notes: "Lemon, hedione, jasmine, vetiver", gender: "Men" },
  { year: 1970, name: "Chloé", brand: "Chloé", notes: "Florals, aldehydes, amber", gender: "Women" },
  { year: 1980, name: "Drakkar Noir", brand: "Guy Laroche", notes: "Lavender, fir, sandalwood, musk", gender: "Men" },
  { year: 1980, name: "Giorgio", brand: "Giorgio Beverly Hills", notes: "Florals, peach, tuberose, patchouli", gender: "Women" },
  { year: 1980, name: "Poison", brand: "Dior", notes: "Tuberose, plum, opoponax, musk", gender: "Women" },
  { year: 1990, name: "CK One", brand: "Calvin Klein", notes: "Green tea, bergamot, musk, sandalwood", gender: "Unisex" },
  { year: 1990, name: "Angel", brand: "Thierry Mugler", notes: "Patchouli, caramel, chocolate, musk", gender: "Women" },
  { year: 1990, name: "L'Eau d'Issey", brand: "Miyake", notes: "Water, lotus, peony, cedar", gender: "Women" },
  { year: 2000, name: "Acqua di Giò", brand: "Armani", notes: "Bergamot, jasmine, rosemary, cedar", gender: "Men" },
  { year: 2000, name: "Light Blue", brand: "Dolce & Gabbana", notes: "Sicilian lemon, apple, cedar", gender: "Women" },
  { year: 2000, name: "La Vie Est Belle", brand: "Lancôme", notes: "Iris, praline, patchouli, vanilla", gender: "Women" },
  { year: 2000, name: "Allure", brand: "Chanel", notes: "Florals, amber, musk", gender: "Women" },
  { year: 2010, name: "Santal 33", brand: "Le Labo", notes: "Sandalwood, iris, cardamom, violet", gender: "Unisex" },
  { year: 2010, name: "Baccarat Rouge 540", brand: "Maison Francis Kurkdjian", notes: "Jasmine, saffron, amberwood, fir", gender: "Unisex" },
  { year: 2010, name: "Black Opium", brand: "YSL", notes: "Coffee, vanilla, white flowers", gender: "Women" },
  { year: 2010, name: "Prada L'Homme", brand: "Prada", notes: "Iris, ambroxan, cedar", gender: "Men" },
  { year: 2020, name: "Libre", brand: "YSL", notes: "Lavender, orange blossom, vanilla, musk", gender: "Women" },
  { year: 2020, name: "Dylan Blue", brand: "Versace", notes: "Fig, violet, patchouli, musk", gender: "Women" },
  { year: 2020, name: "Bleu de Chanel", brand: "Chanel", notes: "Citrus, ambroxan, sandalwood", gender: "Men" },
];

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Get all existing brands
    const brands = await base44.entities.PerfumeBrand.list("-created_date", 500);
    const brandMap = {};
    brands.forEach((b) => { brandMap[b.name] = b.id; });

    // Get all existing perfumes
    const perfumes = await base44.entities.Perfume.list("-created_date", 500);
    const perfumeMap = {};
    perfumes.forEach((p) => { perfumeMap[`${p.name}|${p.brand_name}`] = p; });

    const createdBrands = [];
    const createdPerfumes = [];

    for (const item of HISTORICAL_PERFUMES) {
      // Ensure brand exists
      if (!brandMap[item.brand]) {
        const newBrand = await base44.entities.PerfumeBrand.create({
          name: item.brand,
          year_established: item.year,
        });
        brandMap[item.brand] = newBrand.id;
        createdBrands.push(item.brand);
      }

      // Check if perfume exists (with version handling)
      const key = `${item.name}|${item.brand}`;
      if (!perfumeMap[key]) {
        // Check for version conflicts
        const existing = perfumes.filter((p) => p.name === item.name && p.brand_name === item.brand);
        let versionSuffix = '';
        if (existing.length > 0) {
          versionSuffix = ` (v${existing.length + 1})`;
        }

        const newPerfume = await base44.entities.Perfume.create({
          name: item.name + versionSuffix,
          brand_id: brandMap[item.brand],
          brand_name: item.brand,
          description: `${item.notes}`,
          top_notes: item.notes.split(',')[0]?.trim() || '',
          gender: item.gender || "Unisex",
          release_year: item.year,
          type: "Eau de Parfum",
        });
        perfumeMap[key] = newPerfume;
        createdPerfumes.push(`${item.name} by ${item.brand}`);
      }
    }

    return Response.json({
      success: true,
      message: `Created ${createdBrands.length} brands and ${createdPerfumes.length} perfumes`,
      createdBrands,
      createdPerfumes: createdPerfumes.slice(0, 10), // Show first 10
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});