import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get all active recurring expenses
    const recurringExpenses = await base44.entities.RecurringExpense.list('title', 500);
    const activeRecurring = recurringExpenses.filter(r => r.is_active);

    if (activeRecurring.length === 0) {
      return Response.json({ success: true, generated: 0, message: 'No active recurring expenses' });
    }

    const today = new Date();
    const currentMonth = today.toISOString().slice(0, 7);
    const generated = [];

    for (const recurring of activeRecurring) {
      // Check if already exists for this month
      const existingExpenses = await base44.entities.BudgetExpense.filter({
        category: recurring.category,
        person: recurring.person,
        description: `Auto: ${recurring.title}`
      }, 'date', 10);

      const monthlyExists = existingExpenses.some(e => e.date.startsWith(currentMonth));
      
      if (monthlyExists) {
        continue; // Skip if already generated for this month
      }

      // Calculate the expense date based on frequency
      let expenseDate = new Date(today);

      if (recurring.frequency === 'daily') {
        expenseDate = new Date(today);
      } else if (recurring.frequency === 'weekly') {
        expenseDate.setDate(today.getDate() - today.getDay()); // Start of week
      } else if (recurring.frequency === 'monthly') {
        const dayOfMonth = recurring.day_of_month || 1;
        expenseDate.setDate(dayOfMonth);
      } else if (recurring.frequency === 'quarterly') {
        const quarterMonth = Math.floor(today.getMonth() / 3) * 3;
        expenseDate.setMonth(quarterMonth);
        expenseDate.setDate(1);
      } else if (recurring.frequency === 'yearly') {
        expenseDate.setMonth(0);
        expenseDate.setDate(1);
      }

      const dateStr = expenseDate.toISOString().slice(0, 10);

      // Only create if within valid range
      if (!recurring.end_date || new Date(dateStr) <= new Date(recurring.end_date)) {
        try {
          const expense = await base44.entities.BudgetExpense.create({
            date: dateStr,
            amount: recurring.amount,
            category: recurring.category,
            person: recurring.person,
            description: `Auto: ${recurring.title}`,
            recurring: true,
            frequency: recurring.frequency,
            type: 'essential',
            purchase_record_id: null,
            purchase_record_name: null
          });
          
          generated.push({
            expenseId: expense.id,
            recurringId: recurring.id,
            title: recurring.title,
            amount: recurring.amount,
            date: dateStr
          });
        } catch (err) {
          console.error(`Failed to create expense for ${recurring.title}:`, err.message);
        }
      }
    }

    return Response.json({
      success: true,
      generated: generated.length,
      details: generated,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Error in generateRecurringExpenses:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});