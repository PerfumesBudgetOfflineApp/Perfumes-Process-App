# Seed Architecture — Perfumes Process App (public fork)

> How the app fills its local database on first launch. This public fork ships a
> **minimal demo dataset** plus a **built-in encyclopedia** — not the large private
> perfume catalogue of the upstream app. Read this before touching `public/seed/` or
> `src/lib/localSeeder.js`.

## TL;DR
- The app is offline. On first launch it seeds IndexedDB **once**, then reads only from the DB.
- Two independent sources:
  1. **App entities** (brands, perfumes, perfumers, notes) — a tiny placeholder set.
  2. **Encyclopedia** (stories, quotes, marking-meaning, vocabulary) — loaded from `public/seed/enc/`.
- There is **no** large perfume shard catalogue in this fork. The only sizable file is
  `notes_builtin.json` (a reference list of fragrance notes).

## 1. App entities (placeholders)
Defined in code, not in big JSON files:
- `src/lib/localSeeder.js` -> `seedExamplesLocal()` seeds **1 brand** (`Arabian` / عربية),
  **1 perfume** (`Marhaba` / مرحبا), **4 perfumers**, and **1 collection**
  (`Hospitality & Values` / ضيافة و قيم). These are demo rows labelled
  *"For app preview. Delete it."* — replace them with your own content.
- `public/seed/notes_builtin.json` — **2,679** reference fragrance notes (bilingual). This is the
  one large data file and powers note pickers / accords.
- `public/seed/brands_builtin.json` and `perfumers_builtin.json` are intentionally empty `[]`
  (the demo brand/perfumers are created in code so linking by id is exact).
- `getExpectedSeedCounts()` in `localSeeder.js` holds the expected row counts that drive the
  first-run progress bar — keep it in sync if you change the demo data.

## 2. Encyclopedia (`public/seed/enc/`)
Loaded by `src/lib/encyclopedia.js`, independent of the app entities. Files:

| file | holds |
|---|---|
| `meta.json` | `seed_rev`, languages, sections, subclasses (kinds/regions), timelines |
| `stories.json` | story entries (per `sec_stories`) |
| `quotes.json` | quote entries (per `sec_quotes`) |
| `symbol.json` | marking-meaning entries (`sec_symbol` / معنى علامة) |
| `vocab.json` | vocabulary entries (`sec_vocab`) |
| `timelines.json` | timeline tracks |

Sections are: Stories, Quotes, Marking Meaning, Vocabulary, and a computed Perfume-Phases view.
Stories are organised on two axes — **kind** (`k_*`) and **region** (`r_*`).

## 3. Reseed mechanisms
- **Encyclopedia**: bump `seed_rev` in `public/seed/enc/meta.json`. On next launch the app
  notices the higher revision and reseeds the encyclopedia sections.
- **App entities / schema**: the DB tag in `src/lib/dbName.js` (`DB_TAG`) and `SEED_REV` in
  `localSeeder.js` force a clean reseed when bumped — use after any data-model change.
- Manual: the **Maestro** admin page exposes seeding controls and live counts.

## 4. What was removed from the upstream app
- The ~130k-perfume catalogue (18 brand-keyed shards) — **gone**.
- The old glossary / quotes / wisdom DB tables and their bulk-seed pages — replaced by the
  encyclopedia under `public/seed/enc/`.
- Timeline corpus files at the root of `public/seed/` are present but empty `[]`.

> Never hand-edit a generated seed by guesswork. Change the source, reseed (bump the relevant
> revision/tag), and verify on a fresh install.
