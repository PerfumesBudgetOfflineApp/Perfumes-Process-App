# Screenshots لقطات

Put PNG screenshots here so they render in the main README.
ضع لقطات PNG هنا لتظهر في README الرئيسي.

Suggested set (portrait phone) — اللقطات المقترحة (جوال عمودي):
- `home.png` — Home / الدار
- `perfumes.png` — Perfumes front page / واجهة العطور
- `encyclopedia.png` — Encyclopedia / الموسوعة
- `export.png` — a perfume export card / بطاقة تصدير عطر
- `progress.png` — statistics / الإحصاءات

Tip: capture on device (1080x2400 or similar) and keep file sizes modest.
نصيحة: التقطها من الجهاز و أبقِ أحجام الملفّات معقولة.
