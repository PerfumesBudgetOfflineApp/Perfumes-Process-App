// بوّابة no-undef (flat config) — تكشف المعرّفات غير المعرّفة (صنف كارثة N/_ROSE).
const browserGlobals = ["window","document","console","localStorage","sessionStorage","fetch","setTimeout","clearTimeout","setInterval","clearInterval","FileReader","Blob","URL","URLSearchParams","atob","btoa","navigator","alert","confirm","prompt","IDBKeyRange","indexedDB","Image","requestAnimationFrame","cancelAnimationFrame","crypto","TextEncoder","TextDecoder","AbortController","ResizeObserver","MutationObserver","IntersectionObserver","performance","File","FormData","structuredClone","CustomEvent","Event","HTMLElement","getComputedStyle","DOMParser","XMLSerializer","history","location","queueMicrotask","matchMedia","scrollTo","Audio","WebSocket","Worker"]
  .reduce((o,k)=>(o[k]="readonly",o),{});
export default [{
  files: ["**/*.js", "**/*.jsx", "**/*.mjs"],
  languageOptions: {
    ecmaVersion: 2022,
    sourceType: "module",
    parserOptions: { ecmaFeatures: { jsx: true } },
    globals: { ...browserGlobals, process: "readonly", module: "readonly", require: "readonly", __dirname: "readonly" },
  },
  rules: { "no-undef": "error" },
}];
